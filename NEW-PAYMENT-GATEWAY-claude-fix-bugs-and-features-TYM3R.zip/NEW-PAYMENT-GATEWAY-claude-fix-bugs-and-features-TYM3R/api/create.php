<?php
/**
 * NEO PGA API - Create Transaction
 *
 * MULTI-MERCHANT SAFE VERSION
 * - Ensures globally unique total_amount across ALL merchants
 * - Uses database locking to prevent race conditions
 * - Supports 100+ merchants with high transaction volume
 *
 * POST /api/create.php
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-API-Key, X-Signature');

// Handle preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Config loaded via init.php (includes RateLimiter)
require_once __DIR__ . '/../includes/init.php';

$startTime = microtime(true);

// IP-based rate limiting (60 requests/minute per IP)
checkIpRateLimit(60, 60);

// Only POST allowed
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

// Get API Key from header
$apiKey = $_SERVER['HTTP_X_API_KEY'] ?? '';
$signature = $_SERVER['HTTP_X_SIGNATURE'] ?? '';

if (empty($apiKey)) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'API key required']);
    exit;
}

$db = Database::getInstance();

// Validate merchant
$merchant = $db->fetch("SELECT * FROM merchants WHERE api_key = ? AND status = 'active'", [$apiKey]);

if (!$merchant) {
    http_response_code(401);
    logApiRequest(null, '/api/create', 'POST', [], 401, ['error' => 'Invalid API key'], $startTime);
    echo json_encode(['success' => false, 'error' => 'Invalid or inactive API key']);
    exit;
}

// API key based rate limiting (100 requests/minute per API key)
checkApiKeyRateLimit($apiKey, 100, 60);

// Get JSON body
$rawBody = file_get_contents('php://input');
$body = json_decode($rawBody, true);

if (!$body) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid JSON body']);
    exit;
}

// Validate signature (optional but recommended)
if ($signature) {
    $expectedSignature = hash_hmac('sha256', $rawBody, $merchant['secret_key']);
    if (!hash_equals($expectedSignature, $signature)) {
        http_response_code(401);
        echo json_encode(['success' => false, 'error' => 'Invalid signature']);
        exit;
    }
}

// Required fields
$referenceId = trim($body['reference_id'] ?? '');
$amount = (int)($body['amount'] ?? 0);
$paymentMethod = strtolower($body['payment_method'] ?? 'qris');

// Optional fields
$customerName = trim($body['customer_name'] ?? '');
$customerEmail = trim($body['customer_email'] ?? '');
$customerPhone = trim($body['customer_phone'] ?? '');
$description = trim($body['description'] ?? '');
$callbackUrl = trim($body['callback_url'] ?? $merchant['callback_url'] ?? '');
$expiryMinutes = (int)($body['expiry_minutes'] ?? PAYMENT_EXPIRY_MINUTES);
$bankCode = strtoupper($body['bank_code'] ?? '');

// Validate required fields
$errors = [];

if (empty($referenceId)) {
    $errors[] = 'reference_id is required';
}

if ($amount < MIN_AMOUNT) {
    $errors[] = 'amount must be at least ' . MIN_AMOUNT;
}

if ($amount > MAX_AMOUNT) {
    $errors[] = 'amount cannot exceed ' . MAX_AMOUNT;
}

if (!in_array($paymentMethod, ['qris', 'bank_transfer'])) {
    $errors[] = 'payment_method must be qris or bank_transfer';
}

if ($expiryMinutes < 5 || $expiryMinutes > 1440) {
    $errors[] = 'expiry_minutes must be between 5 and 1440';
}

if (!empty($errors)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'errors' => $errors]);
    exit;
}

// Check for duplicate reference_id
$existing = $db->fetch(
    "SELECT id FROM transactions WHERE merchant_id = ? AND reference_id = ? AND status IN ('pending', 'waiting', 'success')",
    [$merchant['id'], $referenceId]
);

if ($existing) {
    http_response_code(409);
    echo json_encode(['success' => false, 'error' => 'Duplicate reference_id. Transaction already exists.']);
    exit;
}

try {
    // START DATABASE TRANSACTION for atomicity
    $db->beginTransaction();

    // Generate invoice number
    $invoiceNumber = 'INV' . date('Ymd') . strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, 8));

    // ================================================================
    // FIND GLOBALLY UNIQUE TOTAL AMOUNT
    // This ensures no two pending transactions have the same total
    // across ALL merchants (important for auto-verify)
    // ================================================================

    $uniqueCode = 0;
    $paymentCodeId = null;
    $foundUniqueAmount = false;

    // Extended unique code range for high volume (1-9999)
    $codeMin = defined('UNIQUE_CODE_MIN') ? UNIQUE_CODE_MIN : 1;
    $codeMax = defined('UNIQUE_CODE_MAX') ? UNIQUE_CODE_MAX : 999;

    // For high volume, extend range if default
    if ($codeMax <= 999) {
        $codeMax = 9999; // Support more unique combinations
    }

    if (QRIS_UNIQUE_CODE_ENABLED || $paymentMethod === 'bank_transfer') {
        // Get all currently used total_amounts from pending transactions (GLOBAL - all merchants)
        // Use FOR UPDATE to lock these rows and prevent race conditions
        $usedAmounts = $db->fetchAll(
            "SELECT DISTINCT (amount + COALESCE(unique_code, 0)) as total
             FROM transactions
             WHERE status IN ('pending', 'waiting')
             AND created_at > DATE_SUB(NOW(), INTERVAL 60 MINUTE)
             FOR UPDATE"
        );

        // Convert to simple array for fast lookup
        $usedTotals = [];
        foreach ($usedAmounts as $row) {
            $usedTotals[(int)$row['total']] = true;
        }

        // Try to find available code from merchant's pool first
        // Use FOR UPDATE to lock the selected code and prevent race conditions
        $paymentCode = $db->fetch(
            "SELECT * FROM payment_codes
             WHERE merchant_id = ? AND status = 'available'
             ORDER BY RAND() LIMIT 1
             FOR UPDATE",
            [$merchant['id']]
        );

        // Reset expired codes if none available
        if (!$paymentCode) {
            $db->query(
                "UPDATE payment_codes
                 SET status = 'available', transaction_id = NULL, reserved_at = NULL, expires_at = NULL, used_at = NULL
                 WHERE merchant_id = ? AND status IN ('reserved', 'used')
                 AND (expires_at < NOW() OR used_at < DATE_SUB(NOW(), INTERVAL 24 HOUR))",
                [$merchant['id']]
            );

            $paymentCode = $db->fetch(
                "SELECT * FROM payment_codes
                 WHERE merchant_id = ? AND status = 'available'
                 ORDER BY RAND() LIMIT 1
                 FOR UPDATE",
                [$merchant['id']]
            );
        }

        // Generate codes if pool empty
        if (!$paymentCode) {
            for ($code = $codeMin; $code <= min($codeMax, 999); $code++) {
                $db->query(
                    "INSERT IGNORE INTO payment_codes (merchant_id, code, status) VALUES (?, ?, 'available')",
                    [$merchant['id'], $code]
                );
            }

            $paymentCode = $db->fetch(
                "SELECT * FROM payment_codes
                 WHERE merchant_id = ? AND status = 'available'
                 ORDER BY RAND() LIMIT 1
                 FOR UPDATE",
                [$merchant['id']]
            );
        }

        // STRATEGY 1: Try codes from merchant's pool
        if ($paymentCode) {
            // Lock all available codes to prevent race conditions
            $allAvailableCodes = $db->fetchAll(
                "SELECT * FROM payment_codes
                 WHERE merchant_id = ? AND status = 'available'
                 FOR UPDATE",
                [$merchant['id']]
            );

            shuffle($allAvailableCodes); // Randomize

            foreach ($allAvailableCodes as $code) {
                $testTotal = $amount + (int)$code['code'];

                if (!isset($usedTotals[$testTotal])) {
                    // Found unique total!
                    $uniqueCode = (int)$code['code'];
                    $paymentCodeId = $code['id'];
                    $foundUniqueAmount = true;

                    $db->query(
                        "UPDATE payment_codes
                         SET status = 'reserved', reserved_at = NOW(),
                             expires_at = DATE_ADD(NOW(), INTERVAL ? MINUTE)
                         WHERE id = ?",
                        [$expiryMinutes, $paymentCodeId]
                    );
                    break;
                }
            }
        }

        // STRATEGY 2: If pool exhausted, try extended range (1-9999)
        if (!$foundUniqueAmount) {
            // Shuffle the range for randomness
            $extendedCodes = range($codeMin, $codeMax);
            shuffle($extendedCodes);

            foreach ($extendedCodes as $code) {
                $testTotal = $amount + $code;

                if (!isset($usedTotals[$testTotal])) {
                    $uniqueCode = $code;
                    $foundUniqueAmount = true;
                    break;
                }
            }
        }

        // STRATEGY 3: Last resort - use millisecond timestamp
        if (!$foundUniqueAmount) {
            // Use combination of timestamp + random for uniqueness
            $uniqueCode = ((int)(microtime(true) * 1000) % 9000) + 1000;

            // Double check it's unique
            $testTotal = $amount + $uniqueCode;
            $maxAttempts = 100;
            $attempt = 0;

            while (isset($usedTotals[$testTotal]) && $attempt < $maxAttempts) {
                $uniqueCode = rand($codeMin, $codeMax);
                $testTotal = $amount + $uniqueCode;
                $attempt++;
            }

            if ($attempt >= $maxAttempts) {
                $db->rollback();
                http_response_code(503);
                echo json_encode([
                    'success' => false,
                    'error' => 'System busy. Too many pending transactions. Please try again later.'
                ]);
                exit;
            }

            error_log("Warning: Used fallback unique code generation for merchant #{$merchant['id']}");
        }
    }

    // Calculate amounts
    $totalAmount = $amount + $uniqueCode;
    $commissionAmount = round($totalAmount * ($merchant['commission_rate'] / 100), 0);
    $netAmount = $totalAmount - $commissionAmount;
    $expiredAt = date('Y-m-d H:i:s', strtotime("+{$expiryMinutes} minutes"));

    // Generate QRIS if method is qris
    $qrisString = null;
    $qrisImageUrl = null;

    if ($paymentMethod === 'qris') {
        $qrisGenerator = new QRISGenerator();
        $qrisString = $qrisGenerator->generateDynamic($totalAmount, $invoiceNumber);

        if ($qrisString) {
            $qrisImageUrl = $qrisGenerator->generateQRImage($qrisString);
        }
    }

    // Get bank account for bank transfer
    $bankAccountId = null;
    if ($paymentMethod === 'bank_transfer') {
        if ($bankCode) {
            $bank = $db->fetch("SELECT id FROM bank_accounts WHERE bank_code = ? AND is_active = 1", [$bankCode]);
            $bankAccountId = $bank['id'] ?? null;
        }

        if (!$bankAccountId) {
            $bank = $db->fetch("SELECT id FROM bank_accounts WHERE is_active = 1 ORDER BY display_order LIMIT 1");
            $bankAccountId = $bank['id'] ?? null;
        }
    }

    // Insert transaction
    $db->query(
        "INSERT INTO transactions (
            invoice_number, merchant_id, payment_code_id, reference_id,
            customer_name, customer_email, customer_phone, description,
            amount, unique_code, total_amount, commission_amount, net_amount,
            payment_method, bank_account_id, qris_string, qris_image_url,
            status, expired_at, ip_address, user_agent, metadata
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?, ?, ?)",
        [
            $invoiceNumber, $merchant['id'], $paymentCodeId, $referenceId,
            $customerName, $customerEmail, $customerPhone, $description,
            $amount, $uniqueCode, $totalAmount, $commissionAmount, $netAmount,
            $paymentMethod, $bankAccountId, $qrisString, $qrisImageUrl,
            $expiredAt, $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0', $_SERVER['HTTP_USER_AGENT'] ?? '',
            json_encode([
                'callback_url' => $callbackUrl,
                'request_time' => date('c')
            ])
        ]
    );

    $transactionId = $db->lastInsertId();

    // Update payment code with transaction id
    if ($paymentCodeId) {
        $db->query("UPDATE payment_codes SET transaction_id = ? WHERE id = ?", [$transactionId, $paymentCodeId]);
    }

    // COMMIT TRANSACTION
    $db->commit();

    // Generate payment URL
    $paymentUrl = PUBLIC_URL . '/pay.php?invoice=' . $invoiceNumber;

    // Build response
    $response = [
        'success' => true,
        'data' => [
            'transaction_id' => $transactionId,
            'invoice_number' => $invoiceNumber,
            'reference_id' => $referenceId,
            'payment_method' => $paymentMethod,
            'amount' => $amount,
            'unique_code' => $uniqueCode,
            'total_amount' => $totalAmount,
            'status' => 'pending',
            'expired_at' => $expiredAt,
            'payment_url' => $paymentUrl,
        ]
    ];

    // Add QRIS data if applicable
    if ($paymentMethod === 'qris' && $qrisString) {
        $response['data']['qris_string'] = $qrisString;
        $response['data']['qr_url'] = PUBLIC_URL . '/qr.php?invoice=' . $invoiceNumber;
    }

    // Add bank data if applicable
    if ($paymentMethod === 'bank_transfer' && $bankAccountId) {
        $bankAccount = $db->fetch("SELECT bank_name, bank_code, account_number, account_name FROM bank_accounts WHERE id = ?", [$bankAccountId]);
        $response['data']['bank'] = $bankAccount;
    }

    // Log API request
    logApiRequest($merchant['id'], '/api/create', 'POST', $body, 200, $response, $startTime);

    echo json_encode($response);

} catch (Exception $e) {
    // Rollback on error
    if ($db->inTransaction()) {
        $db->rollback();
    }

    http_response_code(500);
    $error = APP_DEBUG ? $e->getMessage() : 'Internal server error';
    logApiRequest($merchant['id'], '/api/create', 'POST', $body, 500, ['error' => $error], $startTime);
    echo json_encode(['success' => false, 'error' => $error]);
}

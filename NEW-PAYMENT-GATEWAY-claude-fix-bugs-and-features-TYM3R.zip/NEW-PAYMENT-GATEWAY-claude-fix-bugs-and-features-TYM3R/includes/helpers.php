<?php
/**
 * NEO PGA Helper Functions
 * Common utility functions
 */

// ============================================
// FORMATTING HELPERS
// ============================================

/**
 * Format currency (Indonesian Rupiah)
 */
function formatRupiah($amount, bool $withPrefix = true): string
{
    $formatted = number_format((float) $amount, 0, ',', '.');
    return $withPrefix ? 'Rp ' . $formatted : $formatted;
}

/**
 * Format date Indonesian
 */
function formatDate(?string $date, string $format = 'd M Y'): string
{
    if ($date === null || $date === '') return '-';
    
    $timestamp = strtotime($date);
    if ($timestamp === false) return '-';
    
    $months = [
        'Jan' => 'Jan', 'Feb' => 'Feb', 'Mar' => 'Mar', 'Apr' => 'Apr',
        'May' => 'Mei', 'Jun' => 'Jun', 'Jul' => 'Jul', 'Aug' => 'Agu',
        'Sep' => 'Sep', 'Oct' => 'Okt', 'Nov' => 'Nov', 'Dec' => 'Des'
    ];
    
    $formatted = date($format, $timestamp);
    
    foreach ($months as $en => $id) {
        $formatted = str_replace($en, $id, $formatted);
    }
    
    return $formatted;
}

/**
 * Format datetime Indonesian
 */
function formatDateTime(?string $date): string
{
    if (!$date) return '-';
    return formatDate($date, 'd M Y H:i');
}

/**
 * Time ago format
 */
function timeAgo(?string $datetime): string
{
    if ($datetime === null || $datetime === '') {
        return '-';
    }
    
    $time = strtotime($datetime);
    if ($time === false) {
        return '-';
    }
    
    $diff = time() - $time;
    
    if ($diff < 60) {
        return 'Baru saja';
    } elseif ($diff < 3600) {
        $mins = floor($diff / 60);
        return $mins . ' menit lalu';
    } elseif ($diff < 86400) {
        $hours = floor($diff / 3600);
        return $hours . ' jam lalu';
    } elseif ($diff < 604800) {
        $days = floor($diff / 86400);
        return $days . ' hari lalu';
    } else {
        return formatDate($datetime);
    }
}

// ============================================
// STRING HELPERS
// ============================================

/**
 * Generate random string
 */
function generateRandomString(int $length = 16, string $type = 'mixed'): string
{
    // PHP 7.4 compatible (no match expression)
    switch ($type) {
        case 'numeric':
            $chars = '0123456789';
            break;
        case 'alpha':
            $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
            break;
        case 'alphanumeric':
            $chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
            break;
        default:
            $chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*';
    }
    
    return substr(str_shuffle(str_repeat($chars, (int) ceil($length / strlen($chars)))), 0, $length);
}

/**
 * Generate invoice number
 */
function generateInvoiceNumber(string $prefix = 'INV'): string
{
    return $prefix . date('Ymd') . strtoupper(generateRandomString(6, 'alphanumeric'));
}

/**
 * Generate API key
 */
function generateApiKey(string $prefix = 'nb_live'): string
{
    return $prefix . '_' . bin2hex(random_bytes(24));
}

/**
 * Generate secret key
 */
function generateSecretKey(): string
{
    return bin2hex(random_bytes(32));
}

/**
 * Mask string (for sensitive data display)
 */
function maskString(?string $string, int $visibleStart = 4, int $visibleEnd = 4): string
{
    if ($string === null || $string === '') {
        return '';
    }
    
    $length = strlen($string);
    
    if ($length <= $visibleStart + $visibleEnd) {
        return str_repeat('*', $length);
    }
    
    $masked = substr($string, 0, $visibleStart);
    $masked .= str_repeat('*', $length - $visibleStart - $visibleEnd);
    $masked .= substr($string, -$visibleEnd);
    
    return $masked;
}

/**
 * Truncate string
 */
function truncateString(?string $string, int $length = 50, string $suffix = '...'): string
{
    if ($string === null || $string === '') {
        return '';
    }
    
    if (mb_strlen($string) <= $length) {
        return $string;
    }
    return mb_substr($string, 0, $length) . $suffix;
}

/**
 * Slugify string
 */
function slugify(?string $string): string
{
    if ($string === null || $string === '') {
        return '';
    }
    
    $string = preg_replace('/[^a-zA-Z0-9\s]/', '', $string) ?? '';
    $string = strtolower(trim($string));
    return preg_replace('/\s+/', '-', $string) ?? '';
}

// ============================================
// VALIDATION HELPERS
// ============================================

/**
 * Validate email
 */
function isValidEmail(?string $email): bool
{
    if ($email === null || $email === '') {
        return false;
    }
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * Validate phone number (Indonesian)
 */
function isValidPhone(?string $phone): bool
{
    if ($phone === null || $phone === '') {
        return false;
    }
    $phone = preg_replace('/[^0-9]/', '', $phone) ?? '';
    return (bool) preg_match('/^(08|628)[0-9]{8,11}$/', $phone);
}

/**
 * Format phone number
 */
function formatPhone(?string $phone): string
{
    if ($phone === null || $phone === '') {
        return '';
    }
    
    $phone = preg_replace('/[^0-9]/', '', $phone) ?? '';
    
    if (substr($phone, 0, 2) === '62') {
        $phone = '0' . substr($phone, 2);
    }
    
    return $phone;
}

/**
 * Validate URL
 */
function isValidUrl(?string $url): bool
{
    if ($url === null || $url === '') {
        return false;
    }
    return filter_var($url, FILTER_VALIDATE_URL) !== false;
}

/**
 * Sanitize input (enhanced XSS protection)
 */
function sanitize($input)
{
    if ($input === null) {
        return '';
    }

    if (is_array($input)) {
        return array_map('sanitize', $input);
    }

    $input = trim((string) $input);

    // Strip HTML and PHP tags first
    $input = strip_tags($input);

    // Remove null bytes
    $input = str_replace(chr(0), '', $input);

    // Encode special characters
    return htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
}

/**
 * Sanitize input but allow some HTML (for rich text)
 */
function sanitizeAllowHtml($input, array $allowedTags = ['<p>', '<br>', '<strong>', '<em>', '<ul>', '<li>'])
{
    if ($input === null) {
        return '';
    }

    $input = trim((string) $input);

    // Strip tags except allowed ones
    $input = strip_tags($input, implode('', $allowedTags));

    // Remove null bytes
    $input = str_replace(chr(0), '', $input);

    return $input;
}

/**
 * Check for XSS patterns in input
 */
function detectXSS($input): bool
{
    if ($input === null || $input === '') {
        return false;
    }

    $patterns = [
        '/<script\b[^>]*>/i',
        '/javascript:/i',
        '/on\w+\s*=/i',
        '/<iframe/i',
        '/<object/i',
        '/<embed/i',
        '/<link[^>]*href/i',
        '/<meta/i',
        '/expression\s*\(/i',
        '/vbscript:/i',
        '/data:/i'
    ];

    foreach ($patterns as $pattern) {
        if (preg_match($pattern, $input)) {
            // Log the attempt
            if (class_exists('Security')) {
                Security::logSecurityEvent('xss_attempt', substr($input, 0, 200));
            }
            return true;
        }
    }

    return false;
}

/**
 * Clean filename
 */
function cleanFilename(?string $filename): string
{
    if ($filename === null || $filename === '') {
        return '';
    }
    
    $filename = preg_replace('/[^a-zA-Z0-9_\-\.]/', '', $filename) ?? '';
    return strtolower($filename);
}

// ============================================
// SECURITY HELPERS
// ============================================

/**
 * Generate CSRF token
 */
function generateCsrfToken(): string
{
    if (!isset($_SESSION[CSRF_TOKEN_NAME])) {
        $_SESSION[CSRF_TOKEN_NAME] = bin2hex(random_bytes(32));
    }
    return $_SESSION[CSRF_TOKEN_NAME];
}

/**
 * Verify CSRF token
 */
function verifyCsrfToken(?string $token): bool
{
    if (!$token || !isset($_SESSION[CSRF_TOKEN_NAME])) {
        return false;
    }
    return hash_equals($_SESSION[CSRF_TOKEN_NAME], $token);
}

/**
 * CSRF input field
 */
function csrfField(): string
{
    return '<input type="hidden" name="' . CSRF_TOKEN_NAME . '" value="' . generateCsrfToken() . '">';
}

/**
 * Get client IP
 */
function getClientIP(): string
{
    $headers = ['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'REMOTE_ADDR'];
    
    foreach ($headers as $header) {
        if (!empty($_SERVER[$header])) {
            $ips = explode(',', $_SERVER[$header]);
            return trim($ips[0]);
        }
    }
    
    return '0.0.0.0';
}

/**
 * Hash API signature
 */
function hashSignature(string $data, string $secretKey): string
{
    return hash_hmac('sha256', $data, $secretKey);
}

/**
 * Verify API signature
 */
function verifySignature(string $data, string $signature, string $secretKey): bool
{
    $expected = hashSignature($data, $secretKey);
    return hash_equals($expected, $signature);
}

// ============================================
// RESPONSE HELPERS
// ============================================

/**
 * JSON response
 */
function jsonResponse(array $data, int $statusCode = 200): void
{
    http_response_code($statusCode);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/**
 * Success JSON response
 */
function successResponse(string $message, array $data = [], int $statusCode = 200): void
{
    jsonResponse([
        'success' => true,
        'message' => $message,
        'data' => $data
    ], $statusCode);
}

/**
 * Error JSON response
 */
function errorResponse(string $message, array $errors = [], int $statusCode = 400): void
{
    jsonResponse([
        'success' => false,
        'message' => $message,
        'errors' => $errors
    ], $statusCode);
}

/**
 * Redirect with message
 */
function redirect(string $url, string $message = '', string $type = 'success'): void
{
    if ($message) {
        $_SESSION['flash_message'] = $message;
        $_SESSION['flash_type'] = $type;
    }
    header('Location: ' . $url);
    exit;
}

/**
 * Get and clear flash message
 */
function getFlashMessage(): ?array
{
    if (!isset($_SESSION['flash_message'])) {
        return null;
    }
    
    $message = [
        'message' => $_SESSION['flash_message'],
        'type' => $_SESSION['flash_type'] ?? 'success'
    ];
    
    unset($_SESSION['flash_message'], $_SESSION['flash_type']);
    
    return $message;
}

// ============================================
// FILE HELPERS
// ============================================

/**
 * Upload file
 */
function uploadFile(array $file, string $destination, array $allowedTypes = []): array
{
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $errors = [
            UPLOAD_ERR_INI_SIZE => 'File terlalu besar',
            UPLOAD_ERR_FORM_SIZE => 'File terlalu besar',
            UPLOAD_ERR_PARTIAL => 'Upload tidak lengkap',
            UPLOAD_ERR_NO_FILE => 'Tidak ada file',
            UPLOAD_ERR_NO_TMP_DIR => 'Folder temporary tidak ditemukan',
            UPLOAD_ERR_CANT_WRITE => 'Gagal menulis file',
            UPLOAD_ERR_EXTENSION => 'Extension tidak diizinkan'
        ];
        return ['success' => false, 'message' => $errors[$file['error']] ?? 'Upload gagal'];
    }

    // Check file size
    if ($file['size'] > MAX_UPLOAD_SIZE) {
        return ['success' => false, 'message' => 'File terlalu besar (max ' . (MAX_UPLOAD_SIZE / 1024 / 1024) . 'MB)'];
    }

    // Check file type
    $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!empty($allowedTypes) && !in_array($extension, $allowedTypes)) {
        return ['success' => false, 'message' => 'Tipe file tidak diizinkan'];
    }

    // Generate unique filename
    $filename = generateRandomString(16, 'alphanumeric') . '_' . time() . '.' . $extension;
    $filepath = $destination . '/' . $filename;

    // Create directory if not exists
    if (!is_dir($destination)) {
        mkdir($destination, 0755, true);
    }

    // Move file
    if (!move_uploaded_file($file['tmp_name'], $filepath)) {
        return ['success' => false, 'message' => 'Gagal menyimpan file'];
    }

    return [
        'success' => true,
        'filename' => $filename,
        'filepath' => $filepath,
        'url' => str_replace(ROOT_PATH, APP_URL, $filepath)
    ];
}

/**
 * Delete file
 */
function deleteFile(string $filepath): bool
{
    if (file_exists($filepath)) {
        return unlink($filepath);
    }
    return false;
}

// ============================================
// ARRAY HELPERS
// ============================================

/**
 * Get array value by dot notation
 */
function arrayGet(array $array, string $key, $default = null)
{
    $keys = explode('.', $key);
    
    foreach ($keys as $k) {
        if (!isset($array[$k])) {
            return $default;
        }
        $array = $array[$k];
    }
    
    return $array;
}

/**
 * Paginate array
 */
function paginate(array $items, int $page = 1, int $perPage = 10): array
{
    $total = count($items);
    $totalPages = ceil($total / $perPage);
    $page = max(1, min($page, $totalPages));
    $offset = ($page - 1) * $perPage;
    
    return [
        'data' => array_slice($items, $offset, $perPage),
        'pagination' => [
            'current_page' => $page,
            'per_page' => $perPage,
            'total' => $total,
            'total_pages' => $totalPages,
            'has_prev' => $page > 1,
            'has_next' => $page < $totalPages
        ]
    ];
}

// ============================================
// STATUS HELPERS
// ============================================

/**
 * Get transaction status badge
 */
function getStatusBadge(string $status): array
{
    $badges = [
        'pending' => ['class' => 'badge-warning', 'label' => 'Menunggu'],
        'waiting' => ['class' => 'badge-info', 'label' => 'Menunggu Bayar'],
        'processing' => ['class' => 'badge-info', 'label' => 'Diproses'],
        'success' => ['class' => 'badge-success', 'label' => 'Berhasil'],
        'failed' => ['class' => 'badge-danger', 'label' => 'Gagal'],
        'expired' => ['class' => 'badge-neutral', 'label' => 'Kadaluarsa'],
        'refunded' => ['class' => 'badge-warning', 'label' => 'Refund'],
        'cancelled' => ['class' => 'badge-neutral', 'label' => 'Dibatalkan'],
        'active' => ['class' => 'badge-success', 'label' => 'Aktif'],
        'suspended' => ['class' => 'badge-warning', 'label' => 'Suspended'],
        'banned' => ['class' => 'badge-danger', 'label' => 'Banned'],
        'verified' => ['class' => 'badge-success', 'label' => 'Terverifikasi'],
        'unverified' => ['class' => 'badge-warning', 'label' => 'Belum Verifikasi'],
        'completed' => ['class' => 'badge-success', 'label' => 'Selesai'],
        'rejected' => ['class' => 'badge-danger', 'label' => 'Ditolak']
    ];
    
    return $badges[$status] ?? ['class' => 'badge-neutral', 'label' => ucfirst($status)];
}

/**
 * Get payment method label
 */
function getPaymentMethodLabel(string $method): string
{
    $labels = [
        'qris' => 'QRIS',
        'bank_transfer' => 'Transfer Bank',
        'virtual_account' => 'Virtual Account',
        'ewallet' => 'E-Wallet'
    ];
    
    return $labels[$method] ?? ucfirst($method);
}

// ============================================
// SETTING HELPERS
// ============================================

/**
 * Get system setting
 */
function getSetting(string $key, $default = null)
{
    static $settings = [];
    
    if (empty($settings)) {
        $results = db()->query("SELECT setting_key, setting_value, setting_type FROM system_settings")->fetchAll();
        foreach ($results as $row) {
            $value = $row['setting_value'];
            
            switch ($row['setting_type']) {
                case 'integer':
                    $value = (int) $value;
                    break;
                case 'boolean':
                    $value = $value === '1' || $value === 'true';
                    break;
                case 'json':
                    $value = json_decode($value, true);
                    break;
            }
            
            $settings[$row['setting_key']] = $value;
        }
    }
    
    return $settings[$key] ?? $default;
}

/**
 * Update system setting
 */
function updateSetting(string $key, $value): bool
{
    return db()->update('system_settings', [
        'setting_value' => is_array($value) ? json_encode($value) : $value,
        'updated_at' => date('Y-m-d H:i:s')
    ], 'setting_key = ?', [$key]) > 0;
}

// ============================================
// CSRF SIMPLE HELPER
// ============================================

/**
 * Verify CSRF from POST (simplified)
 */
function verifyCsrf(): void
{
    $token = $_POST[CSRF_TOKEN_NAME] ?? '';
    if (!verifyCsrfToken($token)) {
        if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest') {
            errorResponse('Invalid CSRF token', [], 403);
        }
        die('Invalid CSRF token. Please refresh the page and try again.');
    }
}

// ============================================
// ACTIVITY LOG HELPERS
// ============================================

/**
 * Log activity to database
 * @param string $userType Type of user (admin, merchant, system)
 * @param int|null $userId User ID or null for system actions
 * @param string $action Action performed
 * @param string $module Module name
 * @param string $description Description of the action
 * @return bool
 */
function logActivity(string $userType, ?int $userId, string $action, string $module, string $description = ''): bool
{
    try {
        $db = Database::getInstance();
        return $db->insert('activity_logs', [
            'user_type' => $userType,
            'user_id' => $userId,
            'action' => $action,
            'module' => $module,
            'description' => $description,
            'ip_address' => getClientIP(),
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'created_at' => date('Y-m-d H:i:s')
        ]) > 0;
    } catch (Exception $e) {
        error_log("Activity log error: " . $e->getMessage());
        return false;
    }
}

/**
 * Get activity logs
 */
function getActivityLogs(array $filters = [], int $limit = 50, int $offset = 0): array
{
    $db = Database::getInstance();
    $where = "1=1";
    $params = [];

    if (!empty($filters['user_type'])) {
        $where .= " AND user_type = ?";
        $params[] = $filters['user_type'];
    }
    if (!empty($filters['user_id'])) {
        $where .= " AND user_id = ?";
        $params[] = $filters['user_id'];
    }
    if (!empty($filters['action'])) {
        $where .= " AND action = ?";
        $params[] = $filters['action'];
    }
    if (!empty($filters['module'])) {
        $where .= " AND module = ?";
        $params[] = $filters['module'];
    }
    if (!empty($filters['date_from'])) {
        $where .= " AND DATE(created_at) >= ?";
        $params[] = $filters['date_from'];
    }
    if (!empty($filters['date_to'])) {
        $where .= " AND DATE(created_at) <= ?";
        $params[] = $filters['date_to'];
    }

    return $db->fetchAll(
        "SELECT * FROM activity_logs WHERE $where ORDER BY created_at DESC LIMIT $limit OFFSET $offset",
        $params
    );
}

// ============================================
// DB HELPER
// ============================================
// Note: db() helper function is defined in init.php to avoid duplicate declaration
// Do not redeclare here - init.php handles the db() function definition

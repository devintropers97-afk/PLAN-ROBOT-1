<?php
/**
 * NEO PGA - QRIS Generator
 * 
 * DYNAMIC QRIS dengan amount otomatis
 * - Produk biasa: Amount otomatis sesuai harga
 * - Top up game: Amount 0 (input manual)
 * 
 * Menggunakan data asli VOKENTRA yang sudah terdaftar di BI
 */

class QRISGenerator
{
    // Data QRIS asli VOKENTRA (JANGAN DIUBAH - ini menentukan kemana uang masuk)
    private $realNMID = "ID1025436258392";
    private $realGopayId = "936009143670340254";
    private $realGopayShort = "G670340254";
    private $acquirerCode = "UKE";
    
    // Data display (harus sama dengan yang terdaftar di BI)
    private $displayMerchantName = "Vokentra Pelatihan & Outs";
    private $displayCity = "JAKARTA UTARA";
    private $postalCode = "14140";
    private $mcc = "5812";
    private $currency = "360";
    private $countryCode = "ID";
    
    /**
     * Generate QRIS string
     * 
     * @param int $amount - Nominal pembayaran (0 = input manual oleh customer)
     * @param string $invoiceNumber - Tidak dipakai, untuk kompatibilitas
     * @return string QRIS string
     */
    public function generate(int $amount = 0, string $invoiceNumber = ''): string
    {
        // Build QRIS string - STRUKTUR SAMA DENGAN QRIS ASLI VOKENTRA
        $qris = '';
        
        // [00] Payload Format Indicator
        $qris .= '000201';
        
        // [01] Point of Initiation Method
        // 11 = Static (tanpa amount, customer input manual)
        // 12 = Dynamic (dengan amount tetap)
        if ($amount > 0) {
            $qris .= '010212'; // Dynamic - amount sudah ditentukan
        } else {
            $qris .= '010211'; // Static - customer input manual
        }
        
        // [26] Merchant Account Information - GoPay channel
        $tag26Content = $this->buildTag('00', 'COM.GO-JEK.WWW');
        $tag26Content .= $this->buildTag('01', $this->realGopayId);
        $tag26Content .= $this->buildTag('02', $this->realGopayShort);
        $tag26Content .= $this->buildTag('03', $this->acquirerCode);
        $qris .= $this->buildTag('26', $tag26Content);
        
        // [51] Merchant Account Information - QRIS
        $tag51Content = $this->buildTag('00', 'ID.CO.QRIS.WWW');
        $tag51Content .= $this->buildTag('02', $this->realNMID);
        $tag51Content .= $this->buildTag('03', $this->acquirerCode);
        $qris .= $this->buildTag('51', $tag51Content);
        
        // [52] Merchant Category Code
        $qris .= $this->buildTag('52', $this->mcc);
        
        // [53] Transaction Currency
        $qris .= $this->buildTag('53', $this->currency);
        
        // [54] Transaction Amount - HANYA jika amount > 0
        if ($amount > 0) {
            $qris .= $this->buildTag('54', (string)$amount);
        }
        
        // [58] Country Code
        $qris .= $this->buildTag('58', $this->countryCode);
        
        // [59] Merchant Name (harus sama dengan yang terdaftar di BI)
        $qris .= $this->buildTag('59', $this->displayMerchantName);
        
        // [60] Merchant City
        $qris .= $this->buildTag('60', $this->displayCity);
        
        // [61] Postal Code
        $qris .= $this->buildTag('61', $this->postalCode);
        
        // [62] Additional Data Field - Terminal only
        $tag62Content = $this->buildTag('07', 'A01');
        $qris .= $this->buildTag('62', $tag62Content);
        
        // [63] CRC - harus dihitung terakhir
        $qris .= '6304';
        $crc = $this->calculateCRC($qris);
        $qris .= $crc;
        
        return $qris;
    }
    
    /**
     * Generate Static QRIS (tanpa amount - untuk top up game)
     */
    public function generateStatic(): string
    {
        return $this->generate(0);
    }
    
    /**
     * Generate Dynamic QRIS (dengan amount - untuk produk biasa)
     */
    public function generateDynamic(int $amount, string $invoiceNumber = ''): ?string
    {
        try {
            if ($amount <= 0) {
                // Jika amount 0 atau kurang, generate static
                return $this->generate(0, $invoiceNumber);
            }
            return $this->generate($amount, $invoiceNumber);
        } catch (Exception $e) {
            error_log("QRIS Generate Error: " . $e->getMessage());
            return null;
        }
    }
    
    /**
     * Generate QRIS and return as array
     */
    public function generateWithResult(int $amount, string $invoiceNumber = ''): array
    {
        try {
            $qrisString = $this->generate($amount, $invoiceNumber);
            return [
                'success' => true,
                'qris_string' => $qrisString,
                'qris_type' => $amount > 0 ? 'dynamic' : 'static',
                'message' => 'QRIS generated successfully'
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'qris_string' => null,
                'message' => $e->getMessage()
            ];
        }
    }
    
    /**
     * Generate QR Code image URL
     */
    public function generateQRImage($amountOrQrisString, string $invoiceNumber = '', int $size = 300): string
    {
        if (is_string($amountOrQrisString) && strpos($amountOrQrisString, '00020101') === 0) {
            $qrisString = $amountOrQrisString;
        } else {
            $qrisString = $this->generate((int)$amountOrQrisString, $invoiceNumber);
        }
        
        $url = 'https://api.qrserver.com/v1/create-qr-code/?size=' . $size . 'x' . $size . '&data=' . urlencode($qrisString) . '&ecc=M';
        
        return $url;
    }
    
    /**
     * Generate QR dengan library lokal (jika tersedia)
     */
    public function generateQRBase64(int $amount, string $invoiceNumber = '', int $size = 300): string
    {
        $qrisString = $this->generate($amount, $invoiceNumber);
        
        $qrLibPath = __DIR__ . '/../vendor/phpqrcode/qrlib.php';
        if (file_exists($qrLibPath)) {
            require_once $qrLibPath;
            ob_start();
            QRcode::png($qrisString, null, QR_ECLEVEL_M, 10, 2);
            $imageData = ob_get_clean();
            return 'data:image/png;base64,' . base64_encode($imageData);
        }
        
        return $this->generateQRImage($amount, $invoiceNumber, $size);
    }
    
    /**
     * Build TLV tag
     */
    private function buildTag(string $tag, string $value): string
    {
        $length = strlen($value);
        return $tag . str_pad($length, 2, '0', STR_PAD_LEFT) . $value;
    }
    
    /**
     * Calculate CRC-16 CCITT
     */
    private function calculateCRC(string $data): string
    {
        $crc = 0xFFFF;
        $polynomial = 0x1021;
        
        for ($i = 0; $i < strlen($data); $i++) {
            $byte = ord($data[$i]);
            $crc ^= ($byte << 8);
            
            for ($j = 0; $j < 8; $j++) {
                if (($crc & 0x8000) !== 0) {
                    $crc = (($crc << 1) ^ $polynomial) & 0xFFFF;
                } else {
                    $crc = ($crc << 1) & 0xFFFF;
                }
            }
        }
        
        return strtoupper(str_pad(dechex($crc), 4, '0', STR_PAD_LEFT));
    }
    
    /**
     * Set custom display name - TIDAK BERLAKU untuk QRIS terdaftar
     */
    public function setDisplayName(string $name): self
    {
        // Nama harus sama dengan yang terdaftar di BI
        return $this;
    }
    
    /**
     * Set custom city - TIDAK BERLAKU untuk QRIS terdaftar
     */
    public function setCity(string $city): self
    {
        // City harus sama dengan yang terdaftar di BI
        return $this;
    }
    
    /**
     * Validate QRIS string
     */
    public function validate(string $qris): bool
    {
        if (strlen($qris) < 20) {
            return false;
        }
        
        $dataWithoutCRC = substr($qris, 0, -4);
        $providedCRC = substr($qris, -4);
        $calculatedCRC = $this->calculateCRC($dataWithoutCRC . '6304');
        
        return strtoupper($providedCRC) === $calculatedCRC;
    }
    
    /**
     * Parse QRIS string untuk debugging
     */
    public function parse(string $qris): array
    {
        $result = [];
        $i = 0;
        
        while ($i < strlen($qris)) {
            if ($i + 4 > strlen($qris)) break;
            
            $tag = substr($qris, $i, 2);
            $length = (int)substr($qris, $i + 2, 2);
            $value = substr($qris, $i + 4, $length);
            
            $result[$tag] = [
                'length' => $length,
                'value' => $value
            ];
            
            $i += 4 + $length;
        }
        
        return $result;
    }
}

<?php
/**
 * ============================================
 * DIGISTORE - CEK STATUS PESANAN
 * ============================================
 * 
 * Halaman untuk customer mengecek status pesanan mereka.
 * Bisa cek via Order ID atau Invoice Number.
 * 
 * 📁 Lokasi: /cek-status.php
 */

// Load konfigurasi
require_once __DIR__ . '/config.php';

$order = null;
$error = '';
$searchQuery = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check for XSS attempts
    if (detectXSS($_POST['query'] ?? '')) {
        $error = 'Input tidak valid terdeteksi!';
    } else {
        $searchQuery = sanitize($_POST['query'] ?? '');
    }

    if (empty($searchQuery) && empty($error)) {
        $error = 'Masukkan Order ID atau Invoice Number';
    } else {
        // Coba cari berdasarkan Order ID
        $order = getOrder($searchQuery);
        
        // Kalau tidak ketemu, coba cari berdasarkan Invoice
        if (!$order) {
            $order = getOrderByInvoice($searchQuery);
        }
        
        // Kalau masih tidak ketemu, coba call API NEO PGA
        if (!$order) {
            // Cek ke API NEO PGA
            $apiResult = callNeoPGAAPI('/api/status.php?invoice=' . urlencode($searchQuery));
            
            if ($apiResult['success'] ?? false) {
                // Data dari NEO PGA
                $order = [
                    'order_id' => $apiResult['data']['reference_id'] ?? $searchQuery,
                    'invoice_number' => $apiResult['data']['invoice_number'] ?? '',
                    'product_name' => $apiResult['data']['description'] ?? 'Produk',
                    'amount' => $apiResult['data']['amount'] ?? 0,
                    'status' => $apiResult['data']['status'] ?? 'unknown',
                    'customer_name' => $apiResult['data']['customer']['name'] ?? '',
                    'customer_email' => $apiResult['data']['customer']['email'] ?? '',
                    'created_at' => $apiResult['data']['created_at'] ?? '',
                    'paid_at' => $apiResult['data']['paid_at'] ?? '',
                    'from_api' => true
                ];
            } else {
                $error = 'Pesanan tidak ditemukan. Pastikan Order ID atau Invoice Number benar.';
            }
        }
    }
}

// Status labels dan warna
$statusLabels = [
    'pending' => ['label' => 'Menunggu Pembayaran', 'color' => '#ffd93d', 'icon' => '⏳'],
    'paid' => ['label' => 'Sudah Dibayar', 'color' => '#00d4aa', 'icon' => '✅'],
    'success' => ['label' => 'Berhasil', 'color' => '#00d4aa', 'icon' => '✅'],
    'expired' => ['label' => 'Kedaluwarsa', 'color' => '#8a8a9a', 'icon' => '⏰'],
    'failed' => ['label' => 'Gagal', 'color' => '#ff6b6b', 'icon' => '❌'],
    'cancelled' => ['label' => 'Dibatalkan', 'color' => '#8a8a9a', 'icon' => '🚫'],
];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cek Status Pesanan - <?= STORE_NAME ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600;700&family=Space+Mono:wght@400;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-primary: #0a0a0f;
            --bg-card: #1a1a24;
            --accent: #00d4aa;
            --accent-glow: rgba(0, 212, 170, 0.3);
            --text-primary: #ffffff;
            --text-secondary: #8a8a9a;
            --border: rgba(255, 255, 255, 0.08);
            --error: #ff6b6b;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Sora', sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            min-height: 100vh;
            padding: 40px 20px;
        }

        .bg-pattern {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 0;
            opacity: 0.4;
            background: radial-gradient(ellipse 80% 50% at 50% -20%, var(--accent-glow), transparent);
        }

        .container {
            position: relative;
            z-index: 1;
            max-width: 500px;
            margin: 0 auto;
        }

        .header {
            text-align: center;
            margin-bottom: 32px;
        }

        .logo {
            font-family: 'Space Mono', monospace;
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--accent);
            text-decoration: none;
            margin-bottom: 8px;
            display: inline-block;
        }

        .logo span { color: var(--text-primary); }

        h1 {
            font-size: 1.5rem;
            margin-bottom: 8px;
        }

        .subtitle {
            color: var(--text-secondary);
            font-size: 0.9rem;
        }

        .card {
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: 20px;
            padding: 28px;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: block;
            font-size: 0.8rem;
            color: var(--text-secondary);
            margin-bottom: 8px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .form-input {
            width: 100%;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 16px;
            color: var(--text-primary);
            font-size: 1rem;
            font-family: 'Space Mono', monospace;
            transition: all 0.2s ease;
        }

        .form-input:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 3px var(--accent-glow);
        }

        .form-input::placeholder {
            color: var(--text-secondary);
            font-family: 'Sora', sans-serif;
        }

        .btn {
            display: inline-block;
            padding: 16px 32px;
            border-radius: 12px;
            font-size: 1rem;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            font-family: 'Sora', sans-serif;
            cursor: pointer;
            border: none;
            width: 100%;
        }

        .btn-primary {
            background: var(--accent);
            color: var(--bg-primary);
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 30px -10px var(--accent-glow);
        }

        .btn-secondary {
            background: transparent;
            border: 1px solid var(--border);
            color: var(--text-primary);
            margin-top: 12px;
        }

        .error-message {
            background: rgba(255, 107, 107, 0.1);
            border: 1px solid var(--error);
            color: var(--error);
            padding: 12px 16px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-size: 0.9rem;
        }

        /* Result Card */
        .result-card {
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: 20px;
            overflow: hidden;
        }

        .result-header {
            padding: 24px;
            text-align: center;
            border-bottom: 1px solid var(--border);
        }

        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 20px;
            border-radius: 100px;
            font-weight: 600;
            font-size: 0.9rem;
            margin-bottom: 12px;
        }

        .result-body {
            padding: 24px;
        }

        .info-row {
            display: flex;
            justify-content: space-between;
            padding: 12px 0;
            border-bottom: 1px solid var(--border);
        }

        .info-row:last-child {
            border-bottom: none;
        }

        .info-label {
            color: var(--text-secondary);
            font-size: 0.9rem;
        }

        .info-value {
            font-weight: 600;
            font-family: 'Space Mono', monospace;
            text-align: right;
            max-width: 60%;
            word-break: break-all;
        }

        .result-footer {
            padding: 24px;
            border-top: 1px solid var(--border);
            display: flex;
            gap: 12px;
        }

        .result-footer .btn {
            flex: 1;
        }

        .back-link {
            text-align: center;
            margin-top: 24px;
        }

        .back-link a {
            color: var(--text-secondary);
            text-decoration: none;
            font-size: 0.9rem;
        }

        .back-link a:hover {
            color: var(--accent);
        }

        .help-text {
            text-align: center;
            margin-top: 24px;
            color: var(--text-secondary);
            font-size: 0.85rem;
        }

        .help-text a {
            color: var(--accent);
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="bg-pattern"></div>
    
    <div class="container">
        <div class="header">
            <a href="./" class="logo">Digi<span>Store</span></a>
            <h1>🔍 Cek Status Pesanan</h1>
            <p class="subtitle">Masukkan Order ID atau Invoice Number</p>
        </div>
        
        <!-- Form Pencarian -->
        <div class="card">
            <?php if ($error): ?>
                <div class="error-message"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            
            <form method="POST" action="">
                <div class="form-group">
                    <label class="form-label">Order ID / Invoice Number</label>
                    <input 
                        type="text" 
                        name="query" 
                        class="form-input" 
                        placeholder="Contoh: DGS-20241210-ABC123 atau INV20241210XXX"
                        value="<?= htmlspecialchars($searchQuery) ?>"
                        required
                    >
                </div>
                
                <button type="submit" class="btn btn-primary">🔍 Cek Status</button>
            </form>
        </div>
        
        <?php if ($order): ?>
        <!-- Hasil Pencarian -->
        <?php 
            $status = $order['status'] ?? 'pending';
            $statusInfo = $statusLabels[$status] ?? ['label' => ucfirst($status), 'color' => '#8a8a9a', 'icon' => '❓'];
        ?>
        <div class="result-card">
            <div class="result-header">
                <div class="status-badge" style="background: <?= $statusInfo['color'] ?>22; color: <?= $statusInfo['color'] ?>; border: 1px solid <?= $statusInfo['color'] ?>44;">
                    <?= $statusInfo['icon'] ?> <?= $statusInfo['label'] ?>
                </div>
                <h2><?= htmlspecialchars($order['product_name'] ?? 'Produk') ?></h2>
            </div>
            
            <div class="result-body">
                <div class="info-row">
                    <span class="info-label">Order ID</span>
                    <span class="info-value"><?= htmlspecialchars($order['order_id'] ?? '-') ?></span>
                </div>
                
                <?php if (!empty($order['invoice_number'])): ?>
                <div class="info-row">
                    <span class="info-label">Invoice</span>
                    <span class="info-value"><?= htmlspecialchars($order['invoice_number']) ?></span>
                </div>
                <?php endif; ?>
                
                <div class="info-row">
                    <span class="info-label">Nama</span>
                    <span class="info-value"><?= htmlspecialchars($order['customer_name'] ?? '-') ?></span>
                </div>
                
                <div class="info-row">
                    <span class="info-label">Email</span>
                    <span class="info-value"><?= htmlspecialchars($order['customer_email'] ?? '-') ?></span>
                </div>
                
                <div class="info-row">
                    <span class="info-label">Harga</span>
                    <span class="info-value"><?= formatRupiah($order['amount'] ?? 0) ?></span>
                </div>
                
                <?php 
                $uniqueCode = $order['unique_code'] ?? 0;
                $totalAmount = $order['total_amount'] ?? ($order['payment_amount'] ?? $order['amount'] ?? 0);
                ?>
                
                <?php if ($uniqueCode > 0): ?>
                <div class="info-row">
                    <span class="info-label">Kode Unik</span>
                    <span class="info-value" style="color: var(--accent);">+<?= number_format($uniqueCode, 0, ',', '.') ?></span>
                </div>
                <?php endif; ?>
                
                <div class="info-row" style="background: rgba(0,212,170,0.1); margin: 0 -24px; padding: 12px 24px;">
                    <span class="info-label" style="font-weight: 600;">Total Bayar</span>
                    <span class="info-value" style="color: var(--accent); font-size: 1.1rem;">
                        <?= formatRupiah($totalAmount) ?>
                    </span>
                </div>
                
                <div class="info-row">
                    <span class="info-label">Tanggal Order</span>
                    <span class="info-value"><?= htmlspecialchars($order['created_at'] ?? '-') ?></span>
                </div>
                
                <?php if (!empty($order['paid_at'])): ?>
                <div class="info-row">
                    <span class="info-label">Tanggal Bayar</span>
                    <span class="info-value"><?= htmlspecialchars($order['paid_at']) ?></span>
                </div>
                <?php endif; ?>
            </div>
            
            <?php if ($status === 'paid' || $status === 'success'): ?>
            <div class="result-footer">
                <?php if (!empty($order['download_url'])): ?>
                <a href="<?= htmlspecialchars($order['download_url']) ?>" class="btn btn-primary" target="_blank">
                    ⬇️ Download Produk
                </a>
                <?php else: ?>
                <a href="success.php?order_id=<?= urlencode($order['order_id'] ?? '') ?>" class="btn btn-primary">
                    📄 Lihat Detail
                </a>
                <?php endif; ?>
            </div>
            <?php elseif ($status === 'pending'): ?>
            <div class="result-footer">
                <a href="<?= NEOPGA_URL ?>/public/pay.php?invoice=<?= urlencode($order['invoice_number'] ?? '') ?>" class="btn btn-primary" target="_blank">
                    💳 Bayar Sekarang
                </a>
            </div>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        
        <div class="back-link">
            <a href="./">← Kembali ke Toko</a>
        </div>
        
        <div class="help-text">
            Butuh bantuan? <a href="https://wa.me/<?= STORE_WHATSAPP ?>" target="_blank">Chat WhatsApp</a>
        </div>
    </div>
</body>
</html>

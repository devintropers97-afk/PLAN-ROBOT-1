<?php
/**
 * NEO PGA - Export Transactions
 * Export transaksi ke CSV atau Excel
 */
require_once __DIR__ . '/../includes/init.php';

// Manual auth check - TIDAK pakai requireAuth() karena trigger 503
if (!isset($_SESSION['merchant_user']) || empty($_SESSION['merchant_user']['id'])) {
    header('Location: login.php');
    exit;
}

$merchantUser = $_SESSION['merchant_user'];
$merchantId = $merchantUser['merchant_id'];
$db = Database::getInstance();

// Get format
$format = $_GET['format'] ?? 'csv';
if (!in_array($format, ['csv', 'excel'])) {
    die('Format tidak valid');
}

// Get filters (same as transactions.php)
$status = $_GET['status'] ?? '';
$method = $_GET['method'] ?? '';
$search = $_GET['search'] ?? '';
$dateFrom = $_GET['date_from'] ?? '';
$dateTo = $_GET['date_to'] ?? '';

$where = "merchant_id = ?";
$params = [$merchantId];

if ($status) {
    $where .= " AND status = ?";
    $params[] = $status;
}

if ($method) {
    $where .= " AND payment_method = ?";
    $params[] = $method;
}

if ($search) {
    $where .= " AND (invoice_number LIKE ? OR reference_id LIKE ? OR customer_name LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if ($dateFrom) {
    $where .= " AND DATE(created_at) >= ?";
    $params[] = $dateFrom;
}

if ($dateTo) {
    $where .= " AND DATE(created_at) <= ?";
    $params[] = $dateTo;
}

// Limit export to max 10000 rows for performance
$transactions = $db->fetchAll(
    "SELECT * FROM transactions WHERE $where ORDER BY created_at DESC LIMIT 10000",
    $params
);

if (empty($transactions)) {
    die('Tidak ada transaksi untuk diexport');
}

// Generate filename
$filename = 'transaksi_' . date('Y-m-d_His');

if ($format === 'csv') {
    // CSV Export
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '.csv"');

    $output = fopen('php://output', 'w');

    // BOM for Excel UTF-8 compatibility
    fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));

    // Header row
    fputcsv($output, [
        'No',
        'Invoice Number',
        'Reference ID',
        'Customer Name',
        'Customer Email',
        'Customer Phone',
        'Amount',
        'Unique Code',
        'Total Amount',
        'Fee',
        'Net Amount',
        'Payment Method',
        'Status',
        'Description',
        'Created At',
        'Paid At',
        'Expired At'
    ]);

    // Data rows
    $no = 1;
    foreach ($transactions as $trx) {
        fputcsv($output, [
            $no++,
            $trx['invoice_number'],
            $trx['reference_id'] ?? '',
            $trx['customer_name'] ?? '',
            $trx['customer_email'] ?? '',
            $trx['customer_phone'] ?? '',
            $trx['amount'],
            $trx['unique_code'] ?? 0,
            $trx['total_amount'],
            $trx['fee_amount'] ?? 0,
            $trx['net_amount'] ?? 0,
            strtoupper($trx['payment_method']),
            ucfirst($trx['status']),
            $trx['description'] ?? '',
            $trx['created_at'],
            $trx['paid_at'] ?? '',
            $trx['expired_at'] ?? ''
        ]);
    }

    fclose($output);

} else {
    // Excel Export (using HTML table with .xls extension - compatible with Excel)
    header('Content-Type: application/vnd.ms-excel; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '.xls"');

    echo '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel">';
    echo '<head><meta charset="utf-8"></head>';
    echo '<body>';
    echo '<table border="1" cellpadding="5" cellspacing="0">';

    // Header row with styling
    echo '<tr style="background-color: #0d9488; color: white; font-weight: bold;">';
    echo '<th>No</th>';
    echo '<th>Invoice Number</th>';
    echo '<th>Reference ID</th>';
    echo '<th>Customer Name</th>';
    echo '<th>Customer Email</th>';
    echo '<th>Customer Phone</th>';
    echo '<th>Amount</th>';
    echo '<th>Unique Code</th>';
    echo '<th>Total Amount</th>';
    echo '<th>Fee</th>';
    echo '<th>Net Amount</th>';
    echo '<th>Payment Method</th>';
    echo '<th>Status</th>';
    echo '<th>Description</th>';
    echo '<th>Created At</th>';
    echo '<th>Paid At</th>';
    echo '<th>Expired At</th>';
    echo '</tr>';

    // Data rows
    $no = 1;
    foreach ($transactions as $trx) {
        // Status color
        $statusColor = '';
        switch ($trx['status']) {
            case 'success': $statusColor = 'background-color: #d1fae5;'; break;
            case 'pending': $statusColor = 'background-color: #fef3c7;'; break;
            case 'failed': $statusColor = 'background-color: #fee2e2;'; break;
            case 'expired': $statusColor = 'background-color: #f3f4f6;'; break;
        }

        echo '<tr>';
        echo '<td>' . $no++ . '</td>';
        echo '<td>' . htmlspecialchars($trx['invoice_number']) . '</td>';
        echo '<td>' . htmlspecialchars($trx['reference_id'] ?? '') . '</td>';
        echo '<td>' . htmlspecialchars($trx['customer_name'] ?? '') . '</td>';
        echo '<td>' . htmlspecialchars($trx['customer_email'] ?? '') . '</td>';
        echo '<td>' . htmlspecialchars($trx['customer_phone'] ?? '') . '</td>';
        echo '<td style="text-align: right;">' . number_format($trx['amount'], 0, ',', '.') . '</td>';
        echo '<td style="text-align: right;">' . number_format($trx['unique_code'] ?? 0, 0, ',', '.') . '</td>';
        echo '<td style="text-align: right; font-weight: bold;">' . number_format($trx['total_amount'], 0, ',', '.') . '</td>';
        echo '<td style="text-align: right;">' . number_format($trx['fee_amount'] ?? 0, 0, ',', '.') . '</td>';
        echo '<td style="text-align: right;">' . number_format($trx['net_amount'] ?? 0, 0, ',', '.') . '</td>';
        echo '<td>' . strtoupper($trx['payment_method']) . '</td>';
        echo '<td style="' . $statusColor . '">' . ucfirst($trx['status']) . '</td>';
        echo '<td>' . htmlspecialchars($trx['description'] ?? '') . '</td>';
        echo '<td>' . $trx['created_at'] . '</td>';
        echo '<td>' . ($trx['paid_at'] ?? '-') . '</td>';
        echo '<td>' . ($trx['expired_at'] ?? '-') . '</td>';
        echo '</tr>';
    }

    // Summary row
    $totalAmount = array_sum(array_column($transactions, 'total_amount'));
    $totalFee = array_sum(array_column($transactions, 'fee_amount'));
    $totalNet = array_sum(array_column($transactions, 'net_amount'));
    $successCount = count(array_filter($transactions, fn($t) => $t['status'] === 'success'));

    echo '<tr style="background-color: #f3f4f6; font-weight: bold;">';
    echo '<td colspan="6">TOTAL (' . count($transactions) . ' transaksi, ' . $successCount . ' sukses)</td>';
    echo '<td style="text-align: right;">' . number_format(array_sum(array_column($transactions, 'amount')), 0, ',', '.') . '</td>';
    echo '<td style="text-align: right;">' . number_format(array_sum(array_column($transactions, 'unique_code')), 0, ',', '.') . '</td>';
    echo '<td style="text-align: right;">' . number_format($totalAmount, 0, ',', '.') . '</td>';
    echo '<td style="text-align: right;">' . number_format($totalFee, 0, ',', '.') . '</td>';
    echo '<td style="text-align: right;">' . number_format($totalNet, 0, ',', '.') . '</td>';
    echo '<td colspan="6"></td>';
    echo '</tr>';

    echo '</table>';
    echo '</body></html>';
}

// Log export activity
logActivity('merchant', $merchantId, 'export_transactions', 'transactions',
    "Exported " . count($transactions) . " transactions to " . strtoupper($format));

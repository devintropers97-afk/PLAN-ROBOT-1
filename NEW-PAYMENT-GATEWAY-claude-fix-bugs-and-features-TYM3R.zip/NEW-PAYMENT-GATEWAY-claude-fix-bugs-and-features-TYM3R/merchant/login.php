<?php
/**
 * NEO PGA Merchant Login
 * Modern Teal Theme with Animated Background
 */
require_once __DIR__ . '/../includes/init.php';

// Redirect if already logged in
if (isset($_SESSION['merchant_user'])) {
    header('Location: index.php');
    exit;
}

$error = '';
$successMessage = '';

// Check for flash message from logout
if (isset($_SESSION['flash_message'])) {
    if ($_SESSION['flash_type'] === 'success') {
        $successMessage = $_SESSION['flash_message'];
    } else {
        $error = $_SESSION['flash_message'];
    }
    unset($_SESSION['flash_message'], $_SESSION['flash_type']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verify CSRF token
    verifyCsrf();

    $email = sanitize($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        $error = 'Email dan password wajib diisi';
    } else {
        $db = Database::getInstance();
        $merchant = $db->fetch("SELECT * FROM merchants WHERE email = ?", [$email]);
        
        if ($merchant && password_verify($password, $merchant['password'])) {
            // Check if merchant account is rejected
            if ($merchant['status'] === 'rejected') {
                $error = 'Akun Anda telah ditolak. Silakan hubungi admin untuk informasi lebih lanjut.';
            } else {
                // Set session dengan struktur yang benar
                $_SESSION['merchant_user'] = [
                    'id' => $merchant['id'],
                    'merchant_code' => $merchant['merchant_code'],
                    'business_name' => $merchant['business_name'],
                    'email' => $merchant['email'],
                    'status' => $merchant['status']
                ];

                // Update last login
                $db->update('merchants', [
                    'last_login' => date('Y-m-d H:i:s'),
                    'login_ip' => $_SERVER['REMOTE_ADDR'] ?? ''
                ], 'id = ?', [$merchant['id']]);

                header('Location: index.php');
                exit;
            }
        } else {
            $error = 'Email atau password salah';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Merchant - <?= APP_NAME ?></title>
    <link rel="icon" type="image/svg+xml" href="<?= ASSETS_URL ?>/images/favicon.svg">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #0d9488;
            --primary-light: #14b8a6;
            --primary-dark: #0f766e;
            --secondary: #0f172a;
        }
        
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: #0f172a;
            color: #e2e8f0;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem;
            overflow-x: hidden;
        }
        
        .bg-animation {
            position: fixed;
            top: 0; left: 0;
            width: 100%; height: 100%;
            z-index: 0;
            overflow: hidden;
        }
        
        .gradient-orb {
            position: absolute;
            border-radius: 50%;
            filter: blur(80px);
            opacity: 0.35;
            animation: float 20s infinite;
        }
        
        .orb-1 {
            width: 450px; height: 450px;
            background: linear-gradient(135deg, #0d9488, #14b8a6);
            top: -150px; right: -100px;
        }
        
        .orb-2 {
            width: 350px; height: 350px;
            background: linear-gradient(135deg, #0891b2, #06b6d4);
            bottom: -100px; left: -100px;
            animation-delay: -10s;
        }
        
        .orb-3 {
            width: 200px; height: 200px;
            background: linear-gradient(135deg, #10b981, #34d399);
            top: 50%; left: 30%;
            animation-delay: -5s;
        }
        
        @keyframes float {
            0%, 100% { transform: translate(0, 0) scale(1); }
            25% { transform: translate(50px, -50px) scale(1.1); }
            50% { transform: translate(-30px, 30px) scale(0.9); }
            75% { transform: translate(-50px, -30px) scale(1.05); }
        }
        
        .login-wrapper {
            position: relative;
            z-index: 10;
            width: 100%;
            max-width: 440px;
        }
        
        .login-logo {
            text-align: center;
            margin-bottom: 2rem;
        }
        
        .login-logo a {
            display: inline-flex;
            align-items: center;
            gap: 0.75rem;
            text-decoration: none;
        }
        
        .logo-icon {
            width: 52px; height: 52px;
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 20px rgba(13, 148, 136, 0.4);
        }
        
        .logo-icon svg { width: 28px; height: 28px; color: white; }
        
        .logo-text {
            font-size: 1.75rem;
            font-weight: 800;
            color: white;
        }
        
        .logo-text span {
            background: linear-gradient(135deg, var(--primary-light), #5eead4);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .login-subtitle {
            color: #94a3b8;
            font-size: 0.95rem;
            margin-top: 0.5rem;
        }
        
        .merchant-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.35rem;
            padding: 0.25rem 0.75rem;
            background: rgba(13, 148, 136, 0.2);
            border: 1px solid rgba(13, 148, 136, 0.3);
            border-radius: 2rem;
            font-size: 0.7rem;
            color: var(--primary-light);
            text-transform: uppercase;
            letter-spacing: 0.05em;
            font-weight: 600;
            margin-top: 0.75rem;
        }
        
        .login-card {
            background: rgba(30, 41, 59, 0.8);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 1.5rem;
            padding: 2.5rem;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
        }
        
        .card-header {
            text-align: center;
            margin-bottom: 2rem;
        }
        
        .card-header h1 {
            font-size: 1.5rem;
            font-weight: 700;
            color: white;
            margin-bottom: 0.5rem;
        }
        
        .card-header p {
            color: #94a3b8;
            font-size: 0.9rem;
        }
        
        .alert {
            padding: 1rem 1.25rem;
            border-radius: 0.75rem;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            font-size: 0.9rem;
        }
        
        .alert-danger {
            background: rgba(239, 68, 68, 0.15);
            border: 1px solid rgba(239, 68, 68, 0.3);
            color: #fca5a5;
        }
        
        .alert svg { width: 20px; height: 20px; flex-shrink: 0; }
        
        .form-group { margin-bottom: 1.5rem; }
        
        .form-label {
            display: block;
            font-size: 0.875rem;
            font-weight: 600;
            color: #e2e8f0;
            margin-bottom: 0.5rem;
        }
        
        .input-wrapper { position: relative; }
        
        .input-icon {
            position: absolute;
            left: 1rem;
            top: 50%;
            transform: translateY(-50%);
            color: #64748b;
            pointer-events: none;
        }
        
        .input-icon svg { width: 20px; height: 20px; }
        
        .form-input {
            width: 100%;
            padding: 0.875rem 1rem 0.875rem 3rem;
            background: rgba(15, 23, 42, 0.6);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 0.75rem;
            font-size: 1rem;
            color: white;
            transition: all 0.3s;
            font-family: inherit;
        }
        
        .form-input::placeholder { color: #64748b; }
        
        .form-input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(13, 148, 136, 0.2);
            background: rgba(15, 23, 42, 0.8);
        }
        
        .password-toggle {
            position: absolute;
            right: 1rem;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: #64748b;
            cursor: pointer;
            padding: 0.25rem;
            transition: color 0.3s;
        }
        
        .password-toggle:hover { color: #94a3b8; }
        .password-toggle svg { width: 20px; height: 20px; }
        
        .form-check {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 1.5rem;
        }
        
        .checkbox-wrapper {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            cursor: pointer;
        }
        
        .checkbox-wrapper input {
            width: 18px; height: 18px;
            accent-color: var(--primary);
            cursor: pointer;
        }
        
        .checkbox-label {
            font-size: 0.875rem;
            color: #94a3b8;
        }
        
        .forgot-link {
            font-size: 0.875rem;
            color: var(--primary-light);
            text-decoration: none;
            transition: color 0.3s;
        }
        
        .forgot-link:hover { color: #5eead4; }
        
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            padding: 0.875rem 1.5rem;
            border-radius: 0.75rem;
            font-weight: 600;
            font-size: 1rem;
            text-decoration: none;
            transition: all 0.3s;
            cursor: pointer;
            border: none;
            width: 100%;
            font-family: inherit;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            color: white;
            box-shadow: 0 4px 20px rgba(13, 148, 136, 0.4);
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 30px rgba(13, 148, 136, 0.5);
        }
        
        .btn svg { width: 20px; height: 20px; }
        
        .divider {
            display: flex;
            align-items: center;
            margin: 1.5rem 0;
            color: #475569;
            font-size: 0.8rem;
        }
        
        .divider::before, .divider::after {
            content: '';
            flex: 1;
            height: 1px;
            background: rgba(255,255,255,0.1);
        }
        
        .divider span { padding: 0 1rem; }
        
        .register-link {
            text-align: center;
        }
        
        .register-link a {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.75rem 1.5rem;
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(255,255,255,0.1);
            border-radius: 0.75rem;
            color: #e2e8f0;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s;
        }
        
        .register-link a:hover {
            background: rgba(255,255,255,0.1);
            border-color: rgba(255,255,255,0.2);
        }
        
        .back-home {
            text-align: center;
            margin-top: 2rem;
        }
        
        .back-home a {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            color: #64748b;
            text-decoration: none;
            font-size: 0.875rem;
            transition: color 0.3s;
        }
        
        .back-home a:hover { color: white; }
        .back-home svg { width: 16px; height: 16px; }
        
        .copyright {
            text-align: center;
            margin-top: 1.5rem;
            color: #475569;
            font-size: 0.8rem;
        }
        
        @media (max-width: 480px) {
            body { padding: 1rem; }
            .login-card { padding: 1.5rem; }
            .logo-text { font-size: 1.5rem; }
        }
    </style>
</head>
<body>
    <div class="bg-animation">
        <div class="gradient-orb orb-1"></div>
        <div class="gradient-orb orb-2"></div>
        <div class="gradient-orb orb-3"></div>
    </div>
    
    <div class="login-wrapper">
        <div class="login-logo">
            <a href="<?= APP_URL ?>">
                <div class="logo-icon">
                    <svg viewBox="0 0 24 24" fill="none">
                        <path d="M4 20 C4 20, 7 15, 10 10 C11 8, 11.5 6, 12 4" stroke="#14B8A6" stroke-width="2.5" stroke-linecap="round"/>
                        <path d="M20 20 C20 20, 17 15, 14 10 C13 8, 12.5 6, 12 4" stroke="#0D9488" stroke-width="2.5" stroke-linecap="round"/>
                        <circle cx="12" cy="4" r="2.5" fill="#F59E0B"/>
                        <line x1="12" y1="7" x2="12" y2="18" stroke="#0D9488" stroke-width="2" stroke-linecap="round"/>
                    </svg>
                </div>
                <span class="logo-text">NEO <span>PGA</span></span>
            </a>
            <p class="login-subtitle">Payment Gateway Platform</p>
            <span class="merchant-badge">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" style="width:12px;height:12px">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/>
                </svg>
                Merchant Portal
            </span>
        </div>
        
        <div class="login-card">
            <div class="card-header">
                <h1>Login Merchant</h1>
                <p>Masuk ke dashboard bisnis Anda</p>
            </div>
            
            <?php if ($successMessage): ?>
            <div class="alert alert-success" style="background: rgba(16, 185, 129, 0.15); border: 1px solid rgba(16, 185, 129, 0.3); color: #6ee7b7;">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                </svg>
                <span><?= htmlspecialchars($successMessage) ?></span>
            </div>
            <?php endif; ?>

            <?php if ($error): ?>
            <div class="alert alert-danger">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                </svg>
                <span><?= htmlspecialchars($error) ?></span>
            </div>
            <?php endif; ?>
            
            <form method="POST" autocomplete="off">
                <?= csrfField() ?>
                <div class="form-group">
                    <label class="form-label">Email</label>
                    <div class="input-wrapper">
                        <span class="input-icon">
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
                            </svg>
                        </span>
                        <input type="email" name="email" class="form-input" placeholder="email@bisnis.com" required autofocus value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Password</label>
                    <div class="input-wrapper">
                        <span class="input-icon">
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/>
                            </svg>
                        </span>
                        <input type="password" name="password" id="password" class="form-input" placeholder="••••••••" required>
                        <button type="button" class="password-toggle" onclick="togglePassword()">
                            <svg id="eyeIcon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                            </svg>
                        </button>
                    </div>
                </div>
                
                <div class="form-check">
                    <label class="checkbox-wrapper">
                        <input type="checkbox" name="remember">
                        <span class="checkbox-label">Ingat saya</span>
                    </label>
                    <a href="#" class="forgot-link">Lupa password?</a>
                </div>
                
                <button type="submit" class="btn btn-primary">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1"/>
                    </svg>
                    Login
                </button>
            </form>
            
            <div class="divider"><span>atau</span></div>
            
            <div class="register-link">
                <a href="register.php">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" style="width:18px;height:18px">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z"/>
                    </svg>
                    Daftar Jadi Merchant
                </a>
            </div>
        </div>
        
        <div class="back-home">
            <a href="<?= APP_URL ?>">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
                </svg>
                Kembali ke Homepage
            </a>
        </div>
        
        <p class="copyright">&copy; <?= date('Y') ?> <?= APP_NAME ?>. All rights reserved.</p>
    </div>
    
    <script>
        function togglePassword() {
            const input = document.getElementById('password');
            const icon = document.getElementById('eyeIcon');
            if (input.type === 'password') {
                input.type = 'text';
                icon.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21"/>';
            } else {
                input.type = 'password';
                icon.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>';
            }
        }
    </script>

    <!-- Security Protection -->
    <script src="<?= ASSETS_URL ?>/js/security.js"></script>
</body>
</html>

<?php
/**
 * NEO PGA - Auto-Verify API Endpoint
 *
 * Endpoint untuk auto-approve transaksi dari MacroDroid
 * Support 2 metode:
 * 1. QRIS - Verify by exact amount
 * 2. Bank Transfer - Verify by unique code
 */

header('Content-Type: application/json');
require_once __DIR__ . '/../includes/init.php';

// Get request start time for logging
$startTime = microtime(true);

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'message' => 'Method not allowed. Use POST.'
    ]);
    exit;
}

// Get JSON input
$input = file_get_contents('php://input');
$data = json_decode($input, true);

if (!$data) {
    errorResponse('Invalid JSON payload', [], 400);
}

// Get MacroDroid secret key from system settings
$macroDroidKey = getSetting('macrodroid_secret_key', '');

// Verify authorization (optional but recommended)
$authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['HTTP_X_AUTH_KEY'] ?? '';
if (!empty($macroDroidKey) && $authHeader !== $macroDroidKey) {
    errorResponse('Unauthorized. Invalid auth key.', [], 401);
}

// Validate required fields
$method = $data['method'] ?? ''; // 'qris' or 'bank_transfer'
$amount = (int)($data['amount'] ?? 0);

if (empty($method) || $amount <= 0) {
    errorResponse('Missing required fields: method, amount', [], 400);
}

try {
    db()->beginTransaction();

    $transaction = null;
    $verifyMethod = '';

    // METHOD 1: QRIS - Verify by exact amount (including unique code)
    if ($method === 'qris') {
        $verifyMethod = 'QRIS Exact Amount Matching';

        // Find waiting transaction with exact total amount (base + unique_code)
        // Prioritize oldest transaction (FIFO) to avoid wrong approval
        // Use FOR UPDATE to lock the row and prevent race conditions
        $sql = "SELECT * FROM transactions
                WHERE status IN ('pending', 'waiting')
                AND payment_method = 'qris'
                AND (amount + COALESCE(unique_code, 0)) = ?
                AND created_at > DATE_SUB(NOW(), INTERVAL 60 MINUTE)
                ORDER BY created_at ASC
                LIMIT 1
                FOR UPDATE";

        $transaction = db()->fetch($sql, [$amount]);
    }

    // METHOD 2: Bank Transfer - Verify by unique code (MORE ACCURATE!)
    elseif ($method === 'bank_transfer') {
        $verifyMethod = 'Bank Transfer Unique Code';

        // Extract unique code from amount (last 3 digits)
        $uniqueCode = $amount % 1000;

        // Get unique code from request (if provided directly)
        if (isset($data['unique_code'])) {
            $uniqueCode = (int)$data['unique_code'];
        }

        // Find transaction with matching unique code
        // Use FOR UPDATE to lock the row and prevent race conditions
        $sql = "SELECT * FROM transactions
                WHERE status IN ('pending', 'waiting')
                AND payment_method = 'bank_transfer'
                AND unique_code = ?
                AND created_at > DATE_SUB(NOW(), INTERVAL 24 HOUR)
                ORDER BY created_at ASC
                LIMIT 1
                FOR UPDATE";

        $transaction = db()->fetch($sql, [$uniqueCode]);

        // Double check: amount should match (base + unique code)
        if ($transaction) {
            $expectedAmount = $transaction['amount'] + $uniqueCode;
            if ($amount !== $expectedAmount) {
                // Amount mismatch - maybe wrong transaction
                $transaction = null;
            }
        }
    }

    else {
        db()->rollback();
        errorResponse('Invalid method. Use "qris" or "bank_transfer"', [], 400);
    }

    // Transaction not found
    if (!$transaction) {
        db()->rollback();

        // Log failed attempt
        logActivity('system', null, 'auto_verify_failed', 'transactions',
            "Auto-verify failed: No matching transaction found. Method: {$method}, Amount: {$amount}"
        );

        errorResponse('No matching transaction found', [
            'method' => $method,
            'amount' => $amount,
            'hint' => 'Transaction might be already verified, expired, or amount mismatch'
        ], 404);
    }

    // Found transaction - Auto-approve it!
    $transactionId = $transaction['id'];
    $invoiceNumber = $transaction['invoice_number'];
    $merchantId = $transaction['merchant_id'];

    // Update transaction status to 'success'
    db()->query(
        "UPDATE transactions
         SET status = 'success',
             paid_at = NOW(),
             payment_proof = ?,
             verification_notes = ?
         WHERE id = ?",
        [
            'Auto-verified by MacroDroid',
            "Auto-verified via {$verifyMethod} at " . date('Y-m-d H:i:s'),
            $transactionId
        ]
    );

    // Update merchant balance with proper locking
    // Use FOR UPDATE to lock merchant row and prevent concurrent balance updates
    $merchant = db()->fetch(
        "SELECT * FROM merchants WHERE id = ? FOR UPDATE",
        [$merchantId]
    );

    if ($merchant) {
        $netAmount = (float)$transaction['net_amount'];
        $balanceBefore = (float)$merchant['balance'];
        $balanceAfter = $balanceBefore + $netAmount;

        // Use ATOMIC balance update with SQL arithmetic
        db()->query(
            "UPDATE merchants SET balance = balance + ?, updated_at = NOW() WHERE id = ?",
            [$netAmount, $merchantId]
        );

        // Log balance change
        db()->insert('balance_logs', [
            'merchant_id' => $merchantId,
            'transaction_id' => $transactionId,
            'type' => 'credit',
            'amount' => $netAmount,
            'balance_before' => $balanceBefore,
            'balance_after' => $balanceAfter,
            'description' => "Auto-verified payment for invoice {$invoiceNumber}",
            'created_at' => date('Y-m-d H:i:s')
        ]);
    }

    // Mark payment code as used (konsisten dengan api/verify.php)
    // Gunakan payment_code_id untuk akurasi, bukan hanya code
    if (!empty($transaction['payment_code_id'])) {
        db()->query(
            "UPDATE payment_codes
             SET status = 'used',
                 transaction_id = ?,
                 used_at = NOW(),
                 updated_at = NOW()
             WHERE id = ? AND status = 'reserved'",
            [$transactionId, $transaction['payment_code_id']]
        );
    }

    db()->commit();

    // Log successful auto-verify
    logActivity('system', null, 'auto_verify_success', 'transactions',
        "Transaction {$invoiceNumber} auto-verified successfully via {$verifyMethod}"
    );

    // Send webhook notification to merchant (async)
    $webhookPayload = [
        'event' => 'payment.success',
        'invoice_number' => $transaction['invoice_number'],
        'reference_id' => $transaction['reference_id'],
        'amount' => $transaction['amount'],
        'status' => 'success',
        'paid_at' => date('Y-m-d H:i:s'),
        'customer' => [
            'name' => $transaction['customer_name'],
            'email' => $transaction['customer_email'],
            'phone' => $transaction['customer_phone']
        ],
        'auto_verified' => true,
        'verify_method' => $verifyMethod
    ];

    // Send webhook in background (don't wait for response)
    if (!empty($merchant['webhook_url'])) {
        sendWebhook($transactionId, $webhookPayload);
    }

    // Return success response
    successResponse('Transaction auto-verified successfully', [
        'transaction_id' => $transactionId,
        'invoice_number' => $invoiceNumber,
        'amount' => $transaction['amount'],
        'status' => 'success',
        'verify_method' => $verifyMethod,
        'merchant_id' => $merchantId,
        'webhook_sent' => !empty($merchant['webhook_url'])
    ]);

} catch (Exception $e) {
    db()->rollback();

    error_log("Auto-verify error: " . $e->getMessage());
    $errorMessage = APP_DEBUG ? $e->getMessage() : 'Internal server error';
    errorResponse('Auto-verify failed: ' . $errorMessage, [], 500);
}
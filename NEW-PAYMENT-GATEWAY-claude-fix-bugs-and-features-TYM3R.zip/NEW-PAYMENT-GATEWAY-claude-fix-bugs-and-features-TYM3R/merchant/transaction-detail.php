<?php
/**
 * NEO PGA - Merchant Transaction Detail
 * Using Layout Template v2
 */
require_once __DIR__ . '/../includes/init.php';

// Get transaction before layout
$db = Database::getInstance();
$merchantId = $_SESSION['merchant_user']['id'] ?? 0;

$transactionId = (int)($_GET['id'] ?? 0);
$transaction = $db->fetch(
    "SELECT * FROM transactions WHERE id = ? AND merchant_id = ?",
    [$transactionId, $merchantId]
);

if (!$transaction) {
    $_SESSION['flash_message'] = 'Transaksi tidak ditemukan';
    $_SESSION['flash_type'] = 'error';
    header('Location: transactions.php');
    exit;
}

// Get webhook logs
$webhookLogs = $db->fetchAll(
    "SELECT * FROM webhook_logs WHERE transaction_id = ? ORDER BY created_at DESC LIMIT 5",
    [$transactionId]
);

// Page settings for layout
$pageTitle = 'Detail Transaksi';
$currentPage = 'transactions';

// Include layout header (handles auth check)
include 'layout_header.php';
?>

<style>
    /* Transaction Detail page specific styles */
    .back-link {
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        color: var(--gray-500);
        text-decoration: none;
        font-size: 0.9rem;
        margin-bottom: 1.5rem;
        transition: color 0.2s;
    }

    .back-link:hover {
        color: var(--gray-700);
    }

    .back-link svg {
        width: 18px;
        height: 18px;
    }

    /* Status Banner */
    .status-banner {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 1rem 1.5rem;
        border-radius: 12px;
        margin-bottom: 1.5rem;
    }

    .status-banner.pending {
        background: var(--warning-light);
        border: 1px solid rgba(245, 158, 11, 0.3);
    }

    .status-banner.success {
        background: var(--success-light);
        border: 1px solid rgba(16, 185, 129, 0.3);
    }

    .status-banner.failed,
    .status-banner.cancelled {
        background: var(--danger-light);
        border: 1px solid rgba(239, 68, 68, 0.3);
    }

    .status-banner.expired {
        background: var(--gray-100);
        border: 1px solid var(--gray-200);
    }

    .status-text {
        font-size: 1.1rem;
        font-weight: 600;
    }

    .status-banner.pending .status-text { color: #92400e; }
    .status-banner.success .status-text { color: #065f46; }
    .status-banner.failed .status-text,
    .status-banner.cancelled .status-text { color: #991b1b; }
    .status-banner.expired .status-text { color: var(--gray-600); }

    .status-meta {
        font-size: 0.85rem;
        opacity: 0.8;
        margin-left: 0.5rem;
    }

    /* Grid Layout */
    .detail-grid {
        display: grid;
        grid-template-columns: 2fr 1fr;
        gap: 1.5rem;
    }

    /* Cards */
    .detail-card {
        background: white;
        border-radius: 16px;
        border: 1px solid var(--gray-200);
        overflow: hidden;
        margin-bottom: 1.5rem;
    }

    .detail-card-header {
        padding: 1rem 1.25rem;
        border-bottom: 1px solid var(--gray-100);
    }

    .detail-card-title {
        font-size: 0.95rem;
        font-weight: 600;
        color: var(--gray-900);
    }

    .detail-card-body {
        padding: 1.25rem;
    }

    /* Info Grid */
    .info-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 1.25rem;
    }

    .info-grid-3 {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 1.25rem;
    }

    .info-item {
        display: flex;
        flex-direction: column;
        gap: 0.25rem;
    }

    .info-item.full-width {
        grid-column: span 2;
    }

    .info-label {
        font-size: 0.75rem;
        color: var(--gray-500);
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    .info-value {
        font-size: 0.9rem;
        color: var(--gray-900);
    }

    .info-value.mono {
        font-family: var(--font-mono);
        font-weight: 500;
    }

    /* Badge */
    .badge {
        display: inline-block;
        padding: 0.25rem 0.75rem;
        border-radius: 6px;
        font-size: 0.7rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    .badge-primary {
        background: var(--primary-100);
        color: var(--primary-dark);
    }

    .badge-success {
        background: var(--success-light);
        color: #065f46;
    }

    .badge-danger {
        background: var(--danger-light);
        color: #991b1b;
    }

    /* Amount Card */
    .amount-card {
        text-align: center;
        padding: 1.5rem;
    }

    .amount-label {
        font-size: 0.8rem;
        color: var(--gray-500);
        margin-bottom: 0.5rem;
    }

    .amount-value {
        font-size: 2rem;
        font-weight: 700;
        color: var(--primary);
    }

    .amount-breakdown {
        margin-top: 1.5rem;
        padding-top: 1.5rem;
        border-top: 1px solid var(--gray-100);
    }

    .breakdown-item {
        display: flex;
        justify-content: space-between;
        padding: 0.5rem 0;
        font-size: 0.85rem;
    }

    .breakdown-item .label {
        color: var(--gray-500);
    }

    .breakdown-item .value {
        color: var(--gray-800);
    }

    .breakdown-item.danger .value {
        color: var(--danger);
    }

    .breakdown-item.total {
        margin-top: 0.5rem;
        padding-top: 0.75rem;
        border-top: 1px solid var(--gray-100);
        font-weight: 600;
    }

    .breakdown-item.total .value {
        color: var(--success);
    }

    /* QR Card */
    .qr-card {
        text-align: center;
    }

    .qr-card img {
        border-radius: 12px;
        margin: 0 auto;
    }

    .qr-card-hint {
        font-size: 0.75rem;
        color: var(--gray-500);
        margin-top: 0.75rem;
    }

    /* Bank Info */
    .bank-info {
        display: flex;
        flex-direction: column;
        gap: 1rem;
    }

    .bank-info-item {
        display: flex;
        flex-direction: column;
        gap: 0.25rem;
    }

    .bank-info-label {
        font-size: 0.75rem;
        color: var(--gray-500);
    }

    .bank-info-value {
        font-size: 0.9rem;
        color: var(--gray-900);
    }

    .bank-info-value.large {
        font-family: var(--font-mono);
        font-size: 1.1rem;
        font-weight: 600;
    }

    /* Webhook Log */
    .webhook-log {
        display: flex;
        flex-direction: column;
        gap: 0.75rem;
    }

    .webhook-item {
        display: flex;
        align-items: flex-start;
        gap: 0.75rem;
        padding: 0.75rem 0;
        border-bottom: 1px solid var(--gray-100);
    }

    .webhook-item:last-child {
        border-bottom: none;
    }

    .webhook-url {
        flex: 1;
        min-width: 0;
    }

    .webhook-url-text {
        font-family: var(--font-mono);
        font-size: 0.8rem;
        color: var(--gray-700);
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .webhook-meta {
        font-size: 0.75rem;
        color: var(--gray-500);
        margin-top: 0.25rem;
    }

    /* Actions Card */
    .actions-card {
        display: flex;
        flex-direction: column;
        gap: 0.75rem;
    }

    /* Buttons */
    .btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 0.5rem;
        padding: 0.75rem 1.25rem;
        border-radius: 10px;
        font-size: 0.9rem;
        font-weight: 500;
        text-decoration: none;
        cursor: pointer;
        border: none;
        transition: all 0.2s;
        font-family: inherit;
        width: 100%;
    }

    .btn-primary {
        background: var(--primary);
        color: white;
    }

    .btn-primary:hover {
        background: var(--primary-dark);
    }

    .btn-secondary {
        background: var(--gray-100);
        color: var(--gray-700);
        border: 1px solid var(--gray-300);
    }

    .btn-secondary:hover {
        background: var(--gray-200);
    }

    .btn-sm {
        padding: 0.5rem 1rem;
        font-size: 0.8rem;
    }

    .btn svg {
        width: 18px;
        height: 18px;
    }

    /* Responsive */
    @media (max-width: 1024px) {
        .detail-grid {
            grid-template-columns: 1fr;
        }
    }

    @media (max-width: 640px) {
        .info-grid,
        .info-grid-3 {
            grid-template-columns: 1fr;
        }

        .info-item.full-width {
            grid-column: span 1;
        }

        .status-banner {
            flex-direction: column;
            gap: 1rem;
            text-align: center;
        }
    }
</style>

<a href="transactions.php" class="back-link">
    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
    </svg>
    Kembali ke Transaksi
</a>

<!-- Status Banner -->
<div class="status-banner <?= $transaction['status'] ?>">
    <div>
        <span class="status-text">Status: <?= ucfirst($transaction['status']) ?></span>
        <?php if ($transaction['status'] === 'success' && $transaction['paid_at']): ?>
        <span class="status-meta">• Dibayar <?= date('d M Y, H:i', strtotime($transaction['paid_at'])) ?></span>
        <?php elseif ($transaction['status'] === 'pending'): ?>
        <span class="status-meta">• Menunggu pembayaran</span>
        <?php elseif ($transaction['status'] === 'expired'): ?>
        <span class="status-meta">• Expired <?= date('d M Y, H:i', strtotime($transaction['expired_at'])) ?></span>
        <?php endif; ?>
    </div>
    <?php if ($transaction['status'] === 'pending'): ?>
    <a href="<?= PUBLIC_URL ?>/pay.php?invoice=<?= $transaction['invoice_number'] ?>" target="_blank" class="btn btn-primary btn-sm">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/>
        </svg>
        Buka Halaman Bayar
    </a>
    <?php endif; ?>
</div>

<div class="detail-grid">
    <!-- Main Content -->
    <div>
        <!-- Transaction Info -->
        <div class="detail-card">
            <div class="detail-card-header">
                <h3 class="detail-card-title">Informasi Transaksi</h3>
            </div>
            <div class="detail-card-body">
                <div class="info-grid">
                    <div class="info-item">
                        <span class="info-label">Invoice Number</span>
                        <span class="info-value mono"><?= htmlspecialchars($transaction['invoice_number']) ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Reference ID</span>
                        <span class="info-value mono"><?= htmlspecialchars($transaction['reference_id'] ?: '-') ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Metode Pembayaran</span>
                        <span class="info-value">
                            <span class="badge badge-primary"><?= strtoupper($transaction['payment_method']) ?></span>
                        </span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Dibuat</span>
                        <span class="info-value"><?= date('d M Y, H:i:s', strtotime($transaction['created_at'])) ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Batas Waktu</span>
                        <span class="info-value"><?= date('d M Y, H:i:s', strtotime($transaction['expired_at'])) ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">IP Address</span>
                        <span class="info-value mono"><?= htmlspecialchars($transaction['ip_address'] ?? '-') ?></span>
                    </div>
                    <?php if ($transaction['description']): ?>
                    <div class="info-item full-width">
                        <span class="info-label">Deskripsi</span>
                        <span class="info-value"><?= htmlspecialchars($transaction['description']) ?></span>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Customer Info -->
        <?php if ($transaction['customer_name'] || $transaction['customer_email'] || $transaction['customer_phone']): ?>
        <div class="detail-card">
            <div class="detail-card-header">
                <h3 class="detail-card-title">Informasi Customer</h3>
            </div>
            <div class="detail-card-body">
                <div class="info-grid-3">
                    <div class="info-item">
                        <span class="info-label">Nama</span>
                        <span class="info-value"><?= htmlspecialchars($transaction['customer_name'] ?: '-') ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Email</span>
                        <span class="info-value"><?= htmlspecialchars($transaction['customer_email'] ?: '-') ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Telepon</span>
                        <span class="info-value"><?= htmlspecialchars($transaction['customer_phone'] ?: '-') ?></span>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Webhook Logs -->
        <?php if (!empty($webhookLogs)): ?>
        <div class="detail-card">
            <div class="detail-card-header">
                <h3 class="detail-card-title">Webhook Log</h3>
            </div>
            <div class="detail-card-body">
                <div class="webhook-log">
                    <?php foreach ($webhookLogs as $log): ?>
                    <div class="webhook-item">
                        <span class="badge <?= $log['status'] === 'success' ? 'badge-success' : 'badge-danger' ?>">
                            <?= strtoupper($log['status']) ?>
                        </span>
                        <div class="webhook-url">
                            <div class="webhook-url-text"><?= htmlspecialchars($log['url']) ?></div>
                            <div class="webhook-meta">
                                HTTP <?= $log['response_code'] ?> • <?= date('d/m/Y H:i:s', strtotime($log['created_at'])) ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <!-- Sidebar -->
    <div>
        <!-- Amount Card -->
        <div class="detail-card">
            <div class="detail-card-body amount-card">
                <div class="amount-label">Total Pembayaran</div>
                <div class="amount-value"><?= formatRupiah($transaction['total_amount']) ?></div>

                <div class="amount-breakdown">
                    <div class="breakdown-item">
                        <span class="label">Amount</span>
                        <span class="value"><?= formatRupiah($transaction['amount']) ?></span>
                    </div>
                    <?php if ($transaction['unique_code'] > 0): ?>
                    <div class="breakdown-item">
                        <span class="label">Kode Unik</span>
                        <span class="value">+<?= number_format($transaction['unique_code']) ?></span>
                    </div>
                    <?php endif; ?>
                    <div class="breakdown-item danger">
                        <span class="label">Komisi (<?= number_format($merchant['commission_rate'], 2) ?>%)</span>
                        <span class="value">-<?= formatRupiah($transaction['commission_amount']) ?></span>
                    </div>
                    <div class="breakdown-item total">
                        <span class="label">Net Diterima</span>
                        <span class="value"><?= formatRupiah($transaction['net_amount']) ?></span>
                    </div>
                </div>
            </div>
        </div>

        <!-- QRIS Card -->
        <?php if ($transaction['payment_method'] === 'qris' && $transaction['qris_string']): ?>
        <div class="detail-card">
            <div class="detail-card-header">
                <h3 class="detail-card-title">QRIS Code</h3>
            </div>
            <div class="detail-card-body qr-card">
                <img src="<?= PUBLIC_URL ?>/qr.php?invoice=<?= $transaction['invoice_number'] ?>&size=180" alt="QR Code">
                <p class="qr-card-hint">Scan dengan e-wallet atau mobile banking</p>
            </div>
        </div>
        <?php endif; ?>

        <!-- Bank Transfer Card -->
        <?php if ($transaction['payment_method'] === 'bank_transfer' && $transaction['bank_name']): ?>
        <div class="detail-card">
            <div class="detail-card-header">
                <h3 class="detail-card-title">Bank Transfer</h3>
            </div>
            <div class="detail-card-body">
                <div class="bank-info">
                    <div class="bank-info-item">
                        <span class="bank-info-label">Bank</span>
                        <span class="bank-info-value"><?= htmlspecialchars($transaction['bank_name']) ?></span>
                    </div>
                    <div class="bank-info-item">
                        <span class="bank-info-label">No. Rekening</span>
                        <span class="bank-info-value large"><?= htmlspecialchars($transaction['bank_account_number']) ?></span>
                    </div>
                    <div class="bank-info-item">
                        <span class="bank-info-label">Atas Nama</span>
                        <span class="bank-info-value"><?= htmlspecialchars($transaction['bank_account_name']) ?></span>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Actions Card -->
        <div class="detail-card">
            <div class="detail-card-body actions-card">
                <button onclick="copyInvoice()" class="btn btn-secondary">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3"/>
                    </svg>
                    Copy Invoice
                </button>
                <?php if ($transaction['status'] === 'pending'): ?>
                <button onclick="copyPaymentUrl()" class="btn btn-secondary">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"/>
                    </svg>
                    Copy Payment Link
                </button>
                <a href="<?= PUBLIC_URL ?>/pay.php?invoice=<?= $transaction['invoice_number'] ?>" target="_blank" class="btn btn-primary">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/>
                    </svg>
                    Buka Halaman Bayar
                </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
function copyInvoice() {
    const invoice = '<?= $transaction['invoice_number'] ?>';
    navigator.clipboard.writeText(invoice).then(function() {
        alert('Invoice berhasil disalin!');
    }).catch(function() {
        // Fallback
        const textarea = document.createElement('textarea');
        textarea.value = invoice;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        alert('Invoice berhasil disalin!');
    });
}

function copyPaymentUrl() {
    const url = '<?= PUBLIC_URL ?>/pay.php?invoice=<?= $transaction['invoice_number'] ?>';
    navigator.clipboard.writeText(url).then(function() {
        alert('Payment link berhasil disalin!');
    }).catch(function() {
        const textarea = document.createElement('textarea');
        textarea.value = url;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        alert('Payment link berhasil disalin!');
    });
}
</script>

<?php include 'layout_footer.php'; ?>

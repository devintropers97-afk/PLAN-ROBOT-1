<?php
/**
 * NEO PGA Merchant API - Dashboard Stats
 * Real-time stats for dashboard auto-refresh
 *
 * GET /merchant/api/dashboard-stats.php
 */
header('Content-Type: application/json');
header('Cache-Control: no-cache, must-revalidate');

require_once __DIR__ . '/../../includes/init.php';

// Check session
if (!isset($_SESSION['merchant_user']) || empty($_SESSION['merchant_user']['id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

$merchantUser = $_SESSION['merchant_user'];
$merchantId = $merchantUser['id'];
$db = Database::getInstance();

$today = date('Y-m-d');
$lastCheck = $_GET['last_check'] ?? null;
$checkNew = isset($_GET['check_new']);
$sinceTimestamp = $_GET['since'] ?? null;

try {
    // Today stats
    $todayStats = $db->fetch(
        "SELECT
            COUNT(*) as total,
            SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) as success,
            SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
            COALESCE(SUM(CASE WHEN status = 'success' THEN amount ELSE 0 END), 0) as amount
         FROM transactions WHERE merchant_id = ? AND DATE(created_at) = ?",
        [$merchantId, $today]
    );

    // New transactions since last check (for notifications)
    $newTransactions = [];
    if ($checkNew && $sinceTimestamp) {
        // Convert JavaScript timestamp (milliseconds) to MySQL datetime
        $sinceDate = date('Y-m-d H:i:s', (int)($sinceTimestamp / 1000));
        $newTransactions = $db->fetchAll(
            "SELECT id, invoice_number, customer_name, amount, total_amount, status, paid_at
             FROM transactions
             WHERE merchant_id = ? AND status = 'success' AND paid_at > ?
             ORDER BY paid_at DESC LIMIT 5",
            [$merchantId, $sinceDate]
        ) ?: [];
    } elseif ($lastCheck) {
        $newTransactions = $db->fetchAll(
            "SELECT id, invoice_number, customer_name, total_amount, status, created_at
             FROM transactions
             WHERE merchant_id = ? AND created_at > ?
             ORDER BY created_at DESC LIMIT 5",
            [$merchantId, $lastCheck]
        ) ?: [];
    }

    // Recent successful payments (for notification)
    $recentSuccess = $db->fetchAll(
        "SELECT invoice_number, customer_name, total_amount, paid_at
         FROM transactions
         WHERE merchant_id = ? AND status = 'success' AND paid_at > DATE_SUB(NOW(), INTERVAL 5 MINUTE)
         ORDER BY paid_at DESC LIMIT 3",
        [$merchantId]
    ) ?: [];

    // Balance - use merchants.balance (already maintained by system)
    $merchant = $db->fetch("SELECT balance FROM merchants WHERE id = ?", [$merchantId]);
    $balance = $merchant['balance'] ?? 0;

    echo json_encode([
        'success' => true,
        'data' => [
            'today' => [
                'total' => (int)($todayStats['total'] ?? 0),
                'success' => (int)($todayStats['success'] ?? 0),
                'pending' => (int)($todayStats['pending'] ?? 0),
                'amount' => (int)($todayStats['amount'] ?? 0)
            ],
            'balance' => (int)$balance,
            'new_transactions' => $newTransactions,
            'recent_success' => $recentSuccess,
            'server_time' => date('Y-m-d H:i:s')
        ]
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Server error']);
}

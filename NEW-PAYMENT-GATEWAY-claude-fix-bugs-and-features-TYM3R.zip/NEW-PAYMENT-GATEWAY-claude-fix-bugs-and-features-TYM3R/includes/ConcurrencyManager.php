<?php
/**
 * NEO PGA Concurrency Manager
 *
 * Provides mutex locks and concurrency control for high-volume transactions
 * Supports 100+ merchants with concurrent operations
 *
 * Uses MySQL GET_LOCK() for distributed locking across multiple PHP processes
 */

class ConcurrencyManager
{
    private static $instance = null;
    private $db;
    private $acquiredLocks = [];

    // Lock timeout in seconds
    const LOCK_TIMEOUT = 10;

    // Lock names
    const LOCK_MERCHANT_BALANCE = 'neo_merchant_balance_%d';
    const LOCK_TRANSACTION_VERIFY = 'neo_tx_verify_%d';
    const LOCK_PAYMENT_CODE = 'neo_payment_code_%d';
    const LOCK_SETTLEMENT = 'neo_settlement_%d';
    const LOCK_UNIQUE_AMOUNT = 'neo_unique_amount';

    private function __construct()
    {
        $this->db = Database::getInstance();
    }

    public static function getInstance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Acquire a named lock using MySQL GET_LOCK()
     * This provides process-level mutex across multiple PHP workers
     *
     * @param string $lockName The lock name
     * @param int $timeout Timeout in seconds
     * @return bool True if lock acquired
     */
    public function acquireLock(string $lockName, int $timeout = self::LOCK_TIMEOUT): bool
    {
        try {
            $result = $this->db->fetch(
                "SELECT GET_LOCK(?, ?) as acquired",
                [$lockName, $timeout]
            );

            if ($result && $result['acquired'] == 1) {
                $this->acquiredLocks[$lockName] = true;
                return true;
            }

            return false;
        } catch (Exception $e) {
            error_log("ConcurrencyManager: Failed to acquire lock '{$lockName}': " . $e->getMessage());
            return false;
        }
    }

    /**
     * Release a named lock
     *
     * @param string $lockName The lock name
     * @return bool True if lock released
     */
    public function releaseLock(string $lockName): bool
    {
        try {
            $result = $this->db->fetch(
                "SELECT RELEASE_LOCK(?) as released",
                [$lockName]
            );

            unset($this->acquiredLocks[$lockName]);

            return $result && $result['released'] == 1;
        } catch (Exception $e) {
            error_log("ConcurrencyManager: Failed to release lock '{$lockName}': " . $e->getMessage());
            return false;
        }
    }

    /**
     * Check if a lock is held (by any process)
     *
     * @param string $lockName The lock name
     * @return bool True if lock is held
     */
    public function isLocked(string $lockName): bool
    {
        try {
            $result = $this->db->fetch(
                "SELECT IS_FREE_LOCK(?) as is_free",
                [$lockName]
            );

            return $result && $result['is_free'] == 0;
        } catch (Exception $e) {
            return false;
        }
    }

    /**
     * Execute a callback with merchant balance lock
     * Ensures only one process can update merchant balance at a time
     *
     * @param int $merchantId Merchant ID
     * @param callable $callback Function to execute while holding lock
     * @return mixed Result from callback
     * @throws Exception If lock cannot be acquired
     */
    public function withMerchantBalanceLock(int $merchantId, callable $callback)
    {
        $lockName = sprintf(self::LOCK_MERCHANT_BALANCE, $merchantId);

        if (!$this->acquireLock($lockName)) {
            throw new Exception("Unable to acquire balance lock for merchant #{$merchantId}. Please try again.");
        }

        try {
            $result = $callback();
            return $result;
        } finally {
            $this->releaseLock($lockName);
        }
    }

    /**
     * Execute a callback with transaction verification lock
     * Prevents double verification of the same transaction
     *
     * @param int $transactionId Transaction ID
     * @param callable $callback Function to execute while holding lock
     * @return mixed Result from callback
     * @throws Exception If lock cannot be acquired
     */
    public function withTransactionLock(int $transactionId, callable $callback)
    {
        $lockName = sprintf(self::LOCK_TRANSACTION_VERIFY, $transactionId);

        if (!$this->acquireLock($lockName)) {
            throw new Exception("Transaction #{$transactionId} is being processed. Please try again.");
        }

        try {
            $result = $callback();
            return $result;
        } finally {
            $this->releaseLock($lockName);
        }
    }

    /**
     * Execute a callback with payment code lock
     * Ensures payment codes are not double-allocated
     *
     * @param int $merchantId Merchant ID
     * @param callable $callback Function to execute while holding lock
     * @return mixed Result from callback
     * @throws Exception If lock cannot be acquired
     */
    public function withPaymentCodeLock(int $merchantId, callable $callback)
    {
        $lockName = sprintf(self::LOCK_PAYMENT_CODE, $merchantId);

        if (!$this->acquireLock($lockName)) {
            throw new Exception("Payment code allocation busy for merchant #{$merchantId}. Please try again.");
        }

        try {
            $result = $callback();
            return $result;
        } finally {
            $this->releaseLock($lockName);
        }
    }

    /**
     * Execute a callback with settlement lock
     * Prevents double withdrawal requests
     *
     * @param int $merchantId Merchant ID
     * @param callable $callback Function to execute while holding lock
     * @return mixed Result from callback
     * @throws Exception If lock cannot be acquired
     */
    public function withSettlementLock(int $merchantId, callable $callback)
    {
        $lockName = sprintf(self::LOCK_SETTLEMENT, $merchantId);

        if (!$this->acquireLock($lockName)) {
            throw new Exception("Settlement processing busy for merchant #{$merchantId}. Please try again.");
        }

        try {
            $result = $callback();
            return $result;
        } finally {
            $this->releaseLock($lockName);
        }
    }

    /**
     * Execute a callback with global unique amount lock
     * Ensures unique amounts are not duplicated across merchants
     *
     * @param callable $callback Function to execute while holding lock
     * @return mixed Result from callback
     * @throws Exception If lock cannot be acquired
     */
    public function withUniqueAmountLock(callable $callback)
    {
        $lockName = self::LOCK_UNIQUE_AMOUNT;

        if (!$this->acquireLock($lockName, 5)) { // Shorter timeout for high throughput
            throw new Exception("System busy generating unique amount. Please try again.");
        }

        try {
            $result = $callback();
            return $result;
        } finally {
            $this->releaseLock($lockName);
        }
    }

    /**
     * Release all locks held by this instance
     * Called automatically on script end
     */
    public function releaseAllLocks(): void
    {
        foreach (array_keys($this->acquiredLocks) as $lockName) {
            $this->releaseLock($lockName);
        }
    }

    /**
     * Retry a callback with exponential backoff
     * Useful for high-contention scenarios
     *
     * @param callable $callback Function to execute
     * @param int $maxRetries Maximum number of retries
     * @param int $baseDelayMs Base delay in milliseconds
     * @return mixed Result from callback
     * @throws Exception If all retries fail
     */
    public function retryWithBackoff(callable $callback, int $maxRetries = 3, int $baseDelayMs = 100)
    {
        $lastException = null;

        for ($attempt = 0; $attempt <= $maxRetries; $attempt++) {
            try {
                return $callback();
            } catch (Exception $e) {
                $lastException = $e;

                if ($attempt < $maxRetries) {
                    // Exponential backoff with jitter
                    $delay = $baseDelayMs * pow(2, $attempt);
                    $jitter = rand(0, $delay / 2);
                    usleep(($delay + $jitter) * 1000);
                }
            }
        }

        throw $lastException;
    }

    /**
     * Destructor - release all locks
     */
    public function __destruct()
    {
        $this->releaseAllLocks();
    }
}

/**
 * Helper function to get ConcurrencyManager instance
 */
function concurrency(): ConcurrencyManager
{
    return ConcurrencyManager::getInstance();
}

<?php
/**
 * NEO PGA Admin - Bank & Payment Methods Management
 * Kelola bank transfer dan metode pembayaran
 */
require_once __DIR__ . '/../includes/init.php';

$auth = new Auth('admin');
$auth->requireAuth();

$adminUser = $auth->user();
$db = Database::getInstance();

$message = '';
$messageType = '';

// Check and create table if not exists
try {
    $db->query("CREATE TABLE IF NOT EXISTS bank_accounts (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        bank_name VARCHAR(100) NOT NULL,
        bank_code VARCHAR(20) NULL,
        account_number VARCHAR(50) NOT NULL,
        account_name VARCHAR(100) NOT NULL,
        branch VARCHAR(100) NULL,
        min_amount BIGINT UNSIGNED DEFAULT 10000,
        max_amount BIGINT UNSIGNED DEFAULT 100000000,
        admin_fee INT UNSIGNED DEFAULT 0,
        fee_type ENUM('fixed', 'percent') DEFAULT 'fixed',
        is_active TINYINT(1) DEFAULT 1,
        display_order INT DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
} catch (Exception $e) {
    // Table might already exist
}

// Handle Add Bank
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_bank'])) {
    verifyCsrf();

    // Check for XSS attempts
    $xssDetected = detectXSS($_POST['bank_name'] ?? '') ||
                   detectXSS($_POST['bank_code'] ?? '') ||
                   detectXSS($_POST['account_number'] ?? '') ||
                   detectXSS($_POST['account_name'] ?? '') ||
                   detectXSS($_POST['branch'] ?? '');

    if ($xssDetected) {
        $message = 'Input tidak valid terdeteksi!';
        $messageType = 'danger';
    } else {
        $bankName = sanitize($_POST['bank_name'] ?? '');
        $bankCode = strtoupper(sanitize($_POST['bank_code'] ?? ''));
        $accountNumber = sanitize($_POST['account_number'] ?? '');
        $accountName = sanitize($_POST['account_name'] ?? '');
        $branch = sanitize($_POST['branch'] ?? '');
        $minAmount = (int)($_POST['min_amount'] ?? 10000);
        $maxAmount = (int)($_POST['max_amount'] ?? 100000000);
        $adminFee = (int)($_POST['admin_fee'] ?? 0);
        $feeType = sanitize($_POST['fee_type'] ?? 'fixed');
        $isActive = isset($_POST['is_active']) ? 1 : 0;
        $displayOrder = (int)($_POST['display_order'] ?? 0);

        if (empty($bankName) || empty($accountNumber) || empty($accountName)) {
            $message = 'Nama Bank, No. Rekening, dan Nama Pemilik wajib diisi';
            $messageType = 'danger';
        } else {
            try {
                $sql = "INSERT INTO bank_accounts (bank_name, bank_code, account_number, account_name, branch, min_amount, max_amount, admin_fee, fee_type, is_active, display_order, created_at)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";
                $db->query($sql, [$bankName, $bankCode, $accountNumber, $accountName, $branch, $minAmount, $maxAmount, $adminFee, $feeType, $isActive, $displayOrder]);
                $message = 'Bank "' . htmlspecialchars($bankName) . '" berhasil ditambahkan';
                $messageType = 'success';
            } catch (Exception $e) {
                $message = 'Gagal menambahkan bank: ' . $e->getMessage();
                $messageType = 'danger';
            }
        }
    }
}

// Handle Update Bank
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_bank'])) {
    verifyCsrf();
    $id = (int)$_POST['bank_id'];

    // Check for XSS attempts
    $xssDetected = detectXSS($_POST['bank_name'] ?? '') ||
                   detectXSS($_POST['bank_code'] ?? '') ||
                   detectXSS($_POST['account_number'] ?? '') ||
                   detectXSS($_POST['account_name'] ?? '') ||
                   detectXSS($_POST['branch'] ?? '');

    if ($xssDetected) {
        $message = 'Input tidak valid terdeteksi!';
        $messageType = 'danger';
    } else {
        $bankName = sanitize($_POST['bank_name'] ?? '');
        $bankCode = strtoupper(sanitize($_POST['bank_code'] ?? ''));
        $accountNumber = sanitize($_POST['account_number'] ?? '');
        $accountName = sanitize($_POST['account_name'] ?? '');
        $branch = sanitize($_POST['branch'] ?? '');
        $minAmount = (int)($_POST['min_amount'] ?? 10000);
        $maxAmount = (int)($_POST['max_amount'] ?? 100000000);
        $adminFee = (int)($_POST['admin_fee'] ?? 0);
        $feeType = sanitize($_POST['fee_type'] ?? 'fixed');
        $isActive = isset($_POST['is_active']) ? 1 : 0;
        $displayOrder = (int)($_POST['display_order'] ?? 0);

        try {
            $sql = "UPDATE bank_accounts SET bank_name=?, bank_code=?, account_number=?, account_name=?, branch=?, min_amount=?, max_amount=?, admin_fee=?, fee_type=?, is_active=?, display_order=?, updated_at=NOW() WHERE id=?";
            $db->query($sql, [$bankName, $bankCode, $accountNumber, $accountName, $branch, $minAmount, $maxAmount, $adminFee, $feeType, $isActive, $displayOrder, $id]);
            $message = 'Bank berhasil diupdate';
            $messageType = 'success';
        } catch (Exception $e) {
            $message = 'Gagal update: ' . $e->getMessage();
            $messageType = 'danger';
        }
    }
}

// Handle Delete Bank
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_bank'])) {
    verifyCsrf();
    $id = (int)$_POST['bank_id'];
    try {
        $bank = $db->fetch("SELECT bank_name FROM bank_accounts WHERE id = ?", [$id]);
        $db->query("DELETE FROM bank_accounts WHERE id = ?", [$id]);
        $message = 'Bank "' . htmlspecialchars($bank['bank_name'] ?? '') . '" berhasil dihapus';
        $messageType = 'success';
    } catch (Exception $e) {
        $message = 'Gagal menghapus: ' . $e->getMessage();
        $messageType = 'danger';
    }
}

// Handle Toggle Status
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle_status'])) {
    verifyCsrf();
    $id = (int)$_POST['bank_id'];
    try {
        $bank = $db->fetch("SELECT bank_name, is_active FROM bank_accounts WHERE id = ?", [$id]);
        if ($bank) {
            $newStatus = $bank['is_active'] ? 0 : 1;
            $db->query("UPDATE bank_accounts SET is_active = ?, updated_at = NOW() WHERE id = ?", [$newStatus, $id]);
            $statusText = $newStatus ? 'diaktifkan' : 'dinonaktifkan';
            $message = 'Bank "' . htmlspecialchars($bank['bank_name']) . '" berhasil ' . $statusText;
            $messageType = 'success';
        }
    } catch (Exception $e) {
        $message = 'Gagal update status: ' . $e->getMessage();
        $messageType = 'danger';
    }
}

// Get all banks with error handling
$banks = [];
$activeCount = 0;
$inactiveCount = 0;

try {
    $banks = $db->fetchAll("SELECT * FROM bank_accounts ORDER BY display_order ASC, bank_name ASC") ?: [];
    foreach ($banks as $b) {
        if (!empty($b['is_active'])) $activeCount++;
        else $inactiveCount++;
    }
} catch (Exception $e) {
    $message = 'Error mengambil data: ' . $e->getMessage();
    $messageType = 'danger';
}

$pageTitle = 'Kelola Rekening Bank';
$currentPage = 'banks';

$extraCss = '
.bank-grid { display: grid; gap: 1rem; }
.bank-card { 
    background: white; 
    border-radius: 16px; 
    border: 1px solid var(--gray-200); 
    padding: 1.5rem; 
    display: grid;
    grid-template-columns: 1fr auto auto;
    align-items: center;
    gap: 1.5rem;
    transition: all 0.2s;
}
.bank-card:hover { box-shadow: 0 4px 15px rgba(0,0,0,0.08); }
.bank-card.inactive { background: var(--gray-50); opacity: 0.7; }
.bank-info { display: flex; align-items: center; gap: 1rem; }
.bank-logo { 
    width: 50px; 
    height: 50px; 
    background: linear-gradient(135deg, var(--primary), var(--primary-light)); 
    border-radius: 12px; 
    display: flex; 
    align-items: center; 
    justify-content: center; 
    font-weight: 700; 
    font-size: 0.75rem; 
    color: white;
    text-transform: uppercase;
    flex-shrink: 0;
}
.bank-card.inactive .bank-logo { background: var(--gray-400); }
.bank-detail h4 { font-weight: 600; font-size: 1rem; margin-bottom: 0.25rem; color: var(--gray-900); }
.bank-detail .account { font-size: 0.875rem; color: var(--gray-600); font-family: monospace; }
.bank-detail .owner { font-size: 0.8rem; color: var(--gray-500); margin-top: 0.125rem; }
.bank-meta { display: flex; gap: 1rem; }
.bank-meta-item { text-align: center; padding: 0.5rem 0.75rem; background: var(--gray-50); border-radius: 8px; min-width: 80px; }
.bank-meta-item .label { font-size: 0.65rem; color: var(--gray-500); text-transform: uppercase; letter-spacing: 0.5px; }
.bank-meta-item .value { font-weight: 600; font-size: 0.8rem; color: var(--gray-800); margin-top: 0.125rem; }
.bank-actions { display: flex; gap: 0.5rem; flex-shrink: 0; }
.toggle-btn { 
    padding: 0.5rem 0.875rem; 
    border-radius: 8px; 
    border: none; 
    cursor: pointer; 
    font-weight: 600; 
    font-size: 0.75rem;
    transition: all 0.2s;
    display: inline-flex;
    align-items: center;
    gap: 0.25rem;
}
.toggle-btn.on { background: #dcfce7; color: #166534; }
.toggle-btn.on:hover { background: #bbf7d0; }
.toggle-btn.off { background: #fee2e2; color: #991b1b; }
.toggle-btn.off:hover { background: #fecaca; }
.modal-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center; padding: 1rem; }
.modal-overlay.show { display: flex; }
.modal-box { background: white; border-radius: 16px; width: 100%; max-width: 500px; max-height: 90vh; overflow-y: auto; }
.modal-head { padding: 1.25rem 1.5rem; border-bottom: 1px solid var(--gray-200); display: flex; justify-content: space-between; align-items: center; }
.modal-head h3 { font-weight: 700; font-size: 1.1rem; margin: 0; }
.modal-close { background: none; border: none; font-size: 1.5rem; cursor: pointer; color: var(--gray-400); line-height: 1; }
.modal-close:hover { color: var(--gray-600); }
.modal-body { padding: 1.5rem; }
.row-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
.stats-row { display: grid; grid-template-columns: repeat(3, 1fr); gap: 1rem; margin-bottom: 1.5rem; }
.stat-box { background: white; border-radius: 12px; padding: 1.25rem; border: 1px solid var(--gray-200); text-align: center; }
.stat-box .num { font-size: 1.75rem; font-weight: 800; color: var(--gray-900); }
.stat-box .lbl { font-size: 0.8rem; color: var(--gray-500); margin-top: 0.25rem; }
.stat-box.green .num { color: var(--success); }
.stat-box.red .num { color: var(--danger); }
@media (max-width: 768px) {
    .bank-card { grid-template-columns: 1fr; gap: 1rem; }
    .bank-meta { flex-wrap: wrap; }
    .bank-actions { justify-content: flex-start; }
    .stats-row { grid-template-columns: 1fr; }
    .row-2 { grid-template-columns: 1fr; }
}
';

ob_start();
?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem;">
    <div>
        <h1 style="font-size: 1.5rem; font-weight: 700; color: var(--gray-900); margin: 0;">🏦 Kelola Rekening Bank</h1>
        <p style="color: var(--gray-500); margin-top: 0.25rem; font-size: 0.9rem;">Atur rekening bank untuk menerima pembayaran dari merchant</p>
    </div>
    <button onclick="openModal('addModal')" class="btn btn-primary">
        ➕ Tambah Bank
    </button>
</div>

<?php if ($message): ?>
<div class="alert alert-<?= $messageType ?>" style="margin-bottom: 1.5rem;">
    <?= $messageType === 'success' ? '✅' : '❌' ?> <?= $message ?>
</div>
<?php endif; ?>

<!-- Stats -->
<div class="stats-row">
    <div class="stat-box">
        <div class="num"><?= count($banks) ?></div>
        <div class="lbl">Total Bank</div>
    </div>
    <div class="stat-box green">
        <div class="num"><?= $activeCount ?></div>
        <div class="lbl">Aktif</div>
    </div>
    <div class="stat-box red">
        <div class="num"><?= $inactiveCount ?></div>
        <div class="lbl">Nonaktif</div>
    </div>
</div>

<!-- Info -->
<div style="background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 12px; padding: 1rem 1.25rem; margin-bottom: 1.5rem;">
    <span style="font-size: 1rem;">💡</span>
    <span style="font-size: 0.875rem; color: #1e40af; margin-left: 0.5rem;">
        Bank yang <strong>nonaktif</strong> tidak akan muncul sebagai opsi pembayaran di halaman merchant dan customer.
    </span>
</div>

<!-- Bank List -->
<div class="bank-grid">
    <?php if (empty($banks)): ?>
    <div class="card" style="text-align: center; padding: 3rem;">
        <div style="font-size: 3rem; margin-bottom: 1rem;">🏦</div>
        <h3 style="color: var(--gray-700); margin-bottom: 0.5rem;">Belum Ada Rekening Bank</h3>
        <p style="color: var(--gray-500); margin-bottom: 1.5rem;">Tambahkan rekening bank untuk menerima pembayaran transfer</p>
        <button onclick="openModal('addModal')" class="btn btn-primary">➕ Tambah Bank Pertama</button>
    </div>
    <?php else: ?>
        <?php foreach ($banks as $bank): ?>
        <div class="bank-card <?= empty($bank['is_active']) ? 'inactive' : '' ?>">
            <div class="bank-info">
                <div class="bank-logo"><?= strtoupper(substr($bank['bank_code'] ?: $bank['bank_name'], 0, 3)) ?></div>
                <div class="bank-detail">
                    <h4>
                        <?= htmlspecialchars($bank['bank_name']) ?>
                        <?php if (empty($bank['is_active'])): ?>
                        <span class="badge badge-danger" style="margin-left: 0.5rem; font-size: 0.6rem; vertical-align: middle;">OFF</span>
                        <?php endif; ?>
                    </h4>
                    <div class="account"><?= htmlspecialchars($bank['account_number']) ?></div>
                    <div class="owner">a.n. <?= htmlspecialchars($bank['account_name']) ?></div>
                </div>
            </div>
            
            <div class="bank-meta">
                <div class="bank-meta-item">
                    <div class="label">Min</div>
                    <div class="value">Rp <?= number_format($bank['min_amount'] ?? 0, 0, ',', '.') ?></div>
                </div>
                <div class="bank-meta-item">
                    <div class="label">Max</div>
                    <div class="value">Rp <?= number_format($bank['max_amount'] ?? 0, 0, ',', '.') ?></div>
                </div>
                <div class="bank-meta-item">
                    <div class="label">Fee</div>
                    <div class="value">
                        <?php if (($bank['fee_type'] ?? 'fixed') === 'percent'): ?>
                            <?= $bank['admin_fee'] ?? 0 ?>%
                        <?php else: ?>
                            Rp <?= number_format($bank['admin_fee'] ?? 0, 0, ',', '.') ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <div class="bank-actions">
                <!-- Toggle -->
                <form method="POST" style="display: inline;">
                    <?= csrfField() ?>
                    <input type="hidden" name="bank_id" value="<?= $bank['id'] ?>">
                    <button type="submit" name="toggle_status" class="toggle-btn <?= !empty($bank['is_active']) ? 'on' : 'off' ?>">
                        <?= !empty($bank['is_active']) ? '✓ ON' : '✗ OFF' ?>
                    </button>
                </form>
                
                <!-- Edit -->
                <button onclick='editBank(<?= json_encode($bank, JSON_HEX_APOS | JSON_HEX_QUOT) ?>)' class="btn btn-sm btn-secondary">✏️</button>
                
                <!-- Delete -->
                <form method="POST" style="display: inline;" onsubmit="return confirm('Hapus bank <?= htmlspecialchars(addslashes($bank['bank_name'])) ?>?')">
                    <?= csrfField() ?>
                    <input type="hidden" name="bank_id" value="<?= $bank['id'] ?>">
                    <button type="submit" name="delete_bank" class="btn btn-sm" style="background: #fee2e2; color: #991b1b;">🗑️</button>
                </form>
            </div>
        </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<!-- Add Modal -->
<div class="modal-overlay" id="addModal">
    <div class="modal-box">
        <div class="modal-head">
            <h3>➕ Tambah Bank Baru</h3>
            <button class="modal-close" onclick="closeModal('addModal')">&times;</button>
        </div>
        <div class="modal-body">
            <form method="POST">
                <?= csrfField() ?>
                <input type="hidden" name="add_bank" value="1">
                
                <div class="row-2">
                    <div class="form-group">
                        <label class="form-label">Nama Bank *</label>
                        <input type="text" name="bank_name" class="form-input" placeholder="Bank BCA" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Kode Bank</label>
                        <input type="text" name="bank_code" class="form-input" placeholder="BCA" maxlength="10">
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Nomor Rekening *</label>
                    <input type="text" name="account_number" class="form-input" placeholder="1234567890" required>
                </div>
                
                <div class="row-2">
                    <div class="form-group">
                        <label class="form-label">Nama Pemilik Rekening *</label>
                        <input type="text" name="account_name" class="form-input" placeholder="PT NEO PGA INDONESIA" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Cabang</label>
                        <input type="text" name="branch" class="form-input" placeholder="Jakarta Pusat">
                    </div>
                </div>
                
                <div class="row-2">
                    <div class="form-group">
                        <label class="form-label">Min. Transaksi (Rp)</label>
                        <input type="number" name="min_amount" class="form-input" value="10000">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Max. Transaksi (Rp)</label>
                        <input type="number" name="max_amount" class="form-input" value="100000000">
                    </div>
                </div>
                
                <div class="row-2">
                    <div class="form-group">
                        <label class="form-label">Admin Fee</label>
                        <input type="number" name="admin_fee" class="form-input" value="0">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Tipe Fee</label>
                        <select name="fee_type" class="form-select">
                            <option value="fixed">Fixed (Rp)</option>
                            <option value="percent">Percent (%)</option>
                        </select>
                    </div>
                </div>
                
                <div class="row-2">
                    <div class="form-group">
                        <label class="form-label">Urutan Tampil</label>
                        <input type="number" name="display_order" class="form-input" value="0">
                    </div>
                    <div class="form-group">
                        <label class="form-label">&nbsp;</label>
                        <label style="display: flex; align-items: center; gap: 0.5rem; padding: 0.75rem 0;">
                            <input type="checkbox" name="is_active" checked style="width: 18px; height: 18px;">
                            <span>Aktif</span>
                        </label>
                    </div>
                </div>
                
                <div style="display: flex; gap: 1rem; margin-top: 1.5rem;">
                    <button type="button" onclick="closeModal('addModal')" class="btn btn-secondary" style="flex: 1;">Batal</button>
                    <button type="submit" class="btn btn-primary" style="flex: 1;">💾 Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Modal -->
<div class="modal-overlay" id="editModal">
    <div class="modal-box">
        <div class="modal-head">
            <h3>✏️ Edit Bank</h3>
            <button class="modal-close" onclick="closeModal('editModal')">&times;</button>
        </div>
        <div class="modal-body">
            <form method="POST" id="editForm">
                <?= csrfField() ?>
                <input type="hidden" name="update_bank" value="1">
                <input type="hidden" name="bank_id" id="edit_id">
                
                <div class="row-2">
                    <div class="form-group">
                        <label class="form-label">Nama Bank *</label>
                        <input type="text" name="bank_name" id="edit_bank_name" class="form-input" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Kode Bank</label>
                        <input type="text" name="bank_code" id="edit_bank_code" class="form-input" maxlength="10">
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Nomor Rekening *</label>
                    <input type="text" name="account_number" id="edit_account_number" class="form-input" required>
                </div>
                
                <div class="row-2">
                    <div class="form-group">
                        <label class="form-label">Nama Pemilik *</label>
                        <input type="text" name="account_name" id="edit_account_name" class="form-input" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Cabang</label>
                        <input type="text" name="branch" id="edit_branch" class="form-input">
                    </div>
                </div>
                
                <div class="row-2">
                    <div class="form-group">
                        <label class="form-label">Min. Transaksi</label>
                        <input type="number" name="min_amount" id="edit_min_amount" class="form-input">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Max. Transaksi</label>
                        <input type="number" name="max_amount" id="edit_max_amount" class="form-input">
                    </div>
                </div>
                
                <div class="row-2">
                    <div class="form-group">
                        <label class="form-label">Admin Fee</label>
                        <input type="number" name="admin_fee" id="edit_admin_fee" class="form-input">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Tipe Fee</label>
                        <select name="fee_type" id="edit_fee_type" class="form-select">
                            <option value="fixed">Fixed (Rp)</option>
                            <option value="percent">Percent (%)</option>
                        </select>
                    </div>
                </div>
                
                <div class="row-2">
                    <div class="form-group">
                        <label class="form-label">Urutan Tampil</label>
                        <input type="number" name="display_order" id="edit_display_order" class="form-input">
                    </div>
                    <div class="form-group">
                        <label class="form-label">&nbsp;</label>
                        <label style="display: flex; align-items: center; gap: 0.5rem; padding: 0.75rem 0;">
                            <input type="checkbox" name="is_active" id="edit_is_active" style="width: 18px; height: 18px;">
                            <span>Aktif</span>
                        </label>
                    </div>
                </div>
                
                <div style="display: flex; gap: 1rem; margin-top: 1.5rem;">
                    <button type="button" onclick="closeModal('editModal')" class="btn btn-secondary" style="flex: 1;">Batal</button>
                    <button type="submit" class="btn btn-primary" style="flex: 1;">💾 Update</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function openModal(id) {
    document.getElementById(id).classList.add('show');
}

function closeModal(id) {
    document.getElementById(id).classList.remove('show');
}

function editBank(bank) {
    document.getElementById('edit_id').value = bank.id || '';
    document.getElementById('edit_bank_name').value = bank.bank_name || '';
    document.getElementById('edit_bank_code').value = bank.bank_code || '';
    document.getElementById('edit_account_number').value = bank.account_number || '';
    document.getElementById('edit_account_name').value = bank.account_name || '';
    document.getElementById('edit_branch').value = bank.branch || '';
    document.getElementById('edit_min_amount').value = bank.min_amount || 10000;
    document.getElementById('edit_max_amount').value = bank.max_amount || 100000000;
    document.getElementById('edit_admin_fee').value = bank.admin_fee || 0;
    document.getElementById('edit_fee_type').value = bank.fee_type || 'fixed';
    document.getElementById('edit_display_order').value = bank.display_order || 0;
    document.getElementById('edit_is_active').checked = (bank.is_active == 1 || bank.is_active === true);
    openModal('editModal');
}

// Close on overlay click
document.querySelectorAll('.modal-overlay').forEach(function(modal) {
    modal.addEventListener('click', function(e) {
        if (e.target === this) {
            closeModal(this.id);
        }
    });
});

// Close on ESC key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        document.querySelectorAll('.modal-overlay.show').forEach(function(modal) {
            closeModal(modal.id);
        });
    }
});
</script>

<?php
$content = ob_get_clean();
include __DIR__ . '/layout.php';
?>

<?php
/**
 * Public Index - Redirect to main page or payment if invoice provided
 */

// Sanitize invoice parameter - only allow alphanumeric and dash
$invoice = preg_replace('/[^a-zA-Z0-9\-_]/', '', $_GET['invoice'] ?? '');

if ($invoice) {
    header('Location: pay.php?invoice=' . urlencode($invoice));
} else {
    header('Location: ../');
}
exit;

<?php
$page_title = 'Automated Trading Robot';
require_once 'includes/header.php';
?>

<!-- Hero Section -->
<section class="hero-section">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6 hero-content">
                <span class="hero-badge">
                    <i class="fas fa-robot"></i> Next-Generation Trading
                </span>
                <h1 class="hero-title">
                    <span class="text-gradient">ZYN</span> Trade System
                </h1>
                <p class="hero-tagline">
                    💰 "Tidur Nyenyak, Bangun Profit"
                </p>
                <p class="hero-subtitle">
                    Robot Trading 24 Jam - Kamu Istirahat, Uang Bekerja! 🚀<br>
                    Profit 5-10% Sehari? Cukup ON-kan Robot, Sisanya Autopilot.
                </p>
                <div class="hero-buttons">
                    <a href="register.php" class="btn btn-primary btn-lg">
                        <i class="fas fa-rocket"></i> Get Started Free
                    </a>
                    <a href="#how-it-works" class="btn btn-secondary btn-lg">
                        <i class="fas fa-play-circle"></i> How It Works
                    </a>
                </div>

                <div class="hero-stats">
                    <div class="stat-item">
                        <div class="stat-value">10</div>
                        <div class="stat-label">Strategies</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value">85%</div>
                        <div class="stat-label">Avg Win Rate</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value">24/7</div>
                        <div class="stat-label">Automation</div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 text-center d-none d-lg-block">
                <div class="hero-visual">
                    <div class="hero-chart animate-float">
                        <!-- Animated Chart SVG -->
                        <svg viewBox="0 0 400 300" class="chart-svg">
                            <defs>
                                <linearGradient id="chartGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                                    <stop offset="0%" style="stop-color:#00d4ff;stop-opacity:0.3"/>
                                    <stop offset="100%" style="stop-color:#00d4ff;stop-opacity:0"/>
                                </linearGradient>
                            </defs>
                            <path d="M0 250 L50 200 L100 220 L150 150 L200 180 L250 100 L300 120 L350 50 L400 80 L400 300 L0 300 Z" fill="url(#chartGradient)"/>
                            <path d="M0 250 L50 200 L100 220 L150 150 L200 180 L250 100 L300 120 L350 50 L400 80" stroke="#00d4ff" stroke-width="3" fill="none"/>
                            <circle cx="350" cy="50" r="8" fill="#00d4ff" class="animate-pulse"/>
                        </svg>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Features Section -->
<section class="section" id="features">
    <div class="container">
        <div class="section-header fade-in">
            <span class="section-badge">Features</span>
            <h2 class="section-title">Why Choose <span class="text-gradient">ZYN</span>?</h2>
            <p class="section-desc">Our trading system is designed to eliminate emotional trading and maximize consistency.</p>
        </div>

        <div class="row g-4">
            <div class="col-lg-4 col-md-6 fade-in">
                <div class="card feature-card h-100">
                    <div class="feature-icon">
                        <i class="fas fa-brain"></i>
                    </div>
                    <h3 class="feature-title">Zero Emotion Trading</h3>
                    <p class="feature-desc">Our algorithm removes fear and greed from the equation. Every trade is based on data, not feelings.</p>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 fade-in">
                <div class="card feature-card h-100">
                    <div class="feature-icon">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <h3 class="feature-title">Yield-Oriented Logic</h3>
                    <p class="feature-desc">Every strategy is optimized for consistent returns with strict risk management protocols.</p>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 fade-in">
                <div class="card feature-card h-100">
                    <div class="feature-icon">
                        <i class="fas fa-robot"></i>
                    </div>
                    <h3 class="feature-title">Full Automation</h3>
                    <p class="feature-desc">Set it and forget it. The robot monitors markets 24/7 and executes trades automatically.</p>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 fade-in">
                <div class="card feature-card h-100">
                    <div class="feature-icon">
                        <i class="fas fa-shield-alt"></i>
                    </div>
                    <h3 class="feature-title">Risk Management</h3>
                    <p class="feature-desc">Built-in stop loss, take profit, and daily limits to protect your capital at all times.</p>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 fade-in">
                <div class="card feature-card h-100">
                    <div class="feature-icon">
                        <i class="fas fa-tachometer-alt"></i>
                    </div>
                    <h3 class="feature-title">Real-Time Analytics</h3>
                    <p class="feature-desc">Detailed statistics, trade history, and performance metrics all in one dashboard.</p>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 fade-in">
                <div class="card feature-card h-100">
                    <div class="feature-icon">
                        <i class="fas fa-headset"></i>
                    </div>
                    <h3 class="feature-title">24/7 Support</h3>
                    <p class="feature-desc">Our team is always available via Telegram to help you maximize your trading experience.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- How It Works Section -->
<section class="section bg-darker" id="how-it-works">
    <div class="container">
        <div class="section-header fade-in">
            <span class="section-badge">Process</span>
            <h2 class="section-title">How It Works</h2>
            <p class="section-desc">Get started in 5 simple steps</p>
        </div>

        <div class="process-steps fade-in">
            <div class="process-step">
                <div class="step-number">1</div>
                <h4 class="step-title">Register OlympTrade</h4>
                <p class="step-desc">Sign up via our affiliate link with minimum $10 deposit</p>
            </div>
            <div class="process-step">
                <div class="step-number">2</div>
                <h4 class="step-title">Create ZYN Account</h4>
                <p class="step-desc">Register on our platform with your OlympTrade ID</p>
            </div>
            <div class="process-step">
                <div class="step-number">3</div>
                <h4 class="step-title">Get Verified</h4>
                <p class="step-desc">Our admin will verify your account within 24 hours</p>
            </div>
            <div class="process-step">
                <div class="step-number">4</div>
                <h4 class="step-title">Configure Robot</h4>
                <p class="step-desc">Select strategies and set your risk parameters</p>
            </div>
            <div class="process-step">
                <div class="step-number">5</div>
                <h4 class="step-title">Start Trading</h4>
                <p class="step-desc">Turn on the robot and watch it trade for you</p>
            </div>
        </div>

        <div class="text-center mt-5 fade-in">
            <a href="<?php echo OLYMPTRADE_AFFILIATE_LINK; ?>" target="_blank" class="btn btn-primary btn-lg">
                <i class="fas fa-external-link-alt"></i> Register OlympTrade Now
            </a>
            <p class="text-muted mt-3">
                <small>Minimum deposit: $10 USD</small>
            </p>
        </div>
    </div>
</section>

<!-- Strategies Preview Section -->
<section class="section" id="strategies">
    <div class="container">
        <div class="section-header fade-in">
            <span class="section-badge">Strategies</span>
            <h2 class="section-title">10 Powerful Strategies</h2>
            <p class="section-desc">Each strategy is optimized for different market conditions and risk profiles</p>
        </div>

        <div class="row g-4">
            <?php
            $strategies = getAllStrategies();
            foreach (array_slice($strategies, 0, 6) as $strategy):
                $riskClass = 'risk-medium';
                if (strpos(strtolower($strategy['risk']), 'low') !== false) $riskClass = 'risk-low';
                elseif (strpos(strtolower($strategy['risk']), 'high') !== false) $riskClass = 'risk-high';
                if (strpos(strtolower($strategy['risk']), 'very') !== false) $riskClass = 'risk-very-high';
            ?>
            <div class="col-lg-4 col-md-6 fade-in">
                <div class="card strategy-card h-100">
                    <div class="card-body">
                        <div class="strategy-header">
                            <h3 class="strategy-name"><?php echo $strategy['name']; ?></h3>
                            <span class="strategy-risk <?php echo $riskClass; ?>"><?php echo $strategy['risk']; ?></span>
                        </div>
                        <p class="text-muted"><?php echo $strategy['description']; ?></p>
                        <div class="strategy-winrate">
                            <i class="fas fa-chart-line"></i>
                            <?php echo $strategy['win_rate']; ?> Win Rate
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <div class="text-center mt-5 fade-in">
            <a href="strategies.php" class="btn btn-secondary btn-lg">
                View All Strategies <i class="fas fa-arrow-right"></i>
            </a>
        </div>
    </div>
</section>

<!-- Pricing Preview Section -->
<section class="section bg-darker" id="pricing">
    <div class="container">
        <div class="section-header fade-in">
            <span class="section-badge">Pricing</span>
            <h2 class="section-title">Pricing Transparan</h2>
            <p class="section-desc">Mulai GRATIS selamanya, upgrade untuk strategi premium</p>
        </div>

        <div class="row g-4 justify-content-center">
            <!-- FREE -->
            <div class="col-lg-3 col-md-6 fade-in">
                <div class="card pricing-card h-100">
                    <div class="card-body">
                        <h3 class="pricing-name">FREE</h3>
                        <div class="pricing-price">
                            <span class="amount">GRATIS</span>
                            <span class="period">selamanya</span>
                        </div>
                        <ul class="pricing-features">
                            <li><i class="fas fa-check"></i> 2 strategi dasar</li>
                            <li><i class="fas fa-check"></i> Win rate 55-78%</li>
                            <li><i class="fas fa-check"></i> Statistik dasar</li>
                            <li><i class="fas fa-check"></i> Telegram support</li>
                        </ul>
                        <a href="register.php" class="btn btn-secondary w-100">Mulai Gratis</a>
                        <small class="d-block text-muted mt-2">Via link afiliasi</small>
                    </div>
                </div>
            </div>

            <!-- PRO -->
            <div class="col-lg-3 col-md-6 fade-in">
                <div class="card pricing-card h-100">
                    <div class="card-body">
                        <h3 class="pricing-name">PRO</h3>
                        <div class="pricing-price">
                            <span class="amount">Rp299K</span>
                            <span class="period">/ bulan</span>
                        </div>
                        <ul class="pricing-features">
                            <li><i class="fas fa-check"></i> 4 strategi</li>
                            <li><i class="fas fa-check"></i> Win rate hingga 78%</li>
                            <li><i class="fas fa-check"></i> Statistik lengkap</li>
                            <li><i class="fas fa-check"></i> Priority support</li>
                        </ul>
                        <a href="pricing.php" class="btn btn-secondary w-100">Lihat Detail</a>
                    </div>
                </div>
            </div>

            <!-- ELITE -->
            <div class="col-lg-3 col-md-6 fade-in">
                <div class="card pricing-card featured h-100">
                    <div class="card-body">
                        <h3 class="pricing-name">ELITE</h3>
                        <div class="pricing-price">
                            <span class="amount">Rp599K</span>
                            <span class="period">/ bulan</span>
                        </div>
                        <ul class="pricing-features">
                            <li><i class="fas fa-check"></i> 7 strategi</li>
                            <li><i class="fas fa-check"></i> Win rate hingga 83%</li>
                            <li><i class="fas fa-check"></i> Auto-pause system</li>
                            <li><i class="fas fa-check"></i> VIP support</li>
                        </ul>
                        <a href="pricing.php" class="btn btn-primary w-100">Pilih ELITE</a>
                    </div>
                </div>
            </div>

            <!-- VIP -->
            <div class="col-lg-3 col-md-6 fade-in">
                <div class="card pricing-card h-100" style="border-color: var(--primary-color);">
                    <div class="card-body">
                        <h3 class="pricing-name text-gradient">VIP</h3>
                        <div class="pricing-price">
                            <span class="amount">Rp999K</span>
                            <span class="period">/ bulan</span>
                        </div>
                        <ul class="pricing-features">
                            <li><i class="fas fa-crown text-warning"></i> Semua 10 strategi</li>
                            <li><i class="fas fa-check"></i> Win rate hingga <strong>91%</strong></li>
                            <li><i class="fas fa-check"></i> Triple RSI premium</li>
                            <li><i class="fas fa-check"></i> Direct owner support</li>
                        </ul>
                        <a href="pricing.php" class="btn btn-outline-primary w-100">Lihat Detail</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Testimonials Section -->
<section class="section" id="testimonials">
    <div class="container">
        <div class="section-header fade-in">
            <span class="section-badge">Testimoni</span>
            <h2 class="section-title">Apa Kata Mereka?</h2>
            <p class="section-desc">Ribuan trader sudah merasakan manfaat ZYN Trade System</p>
        </div>

        <div class="row g-4">
            <div class="col-lg-4 col-md-6 fade-in">
                <div class="card testimonial-card h-100">
                    <div class="card-body">
                        <div class="testimonial-header">
                            <div class="testimonial-avatar">
                                <i class="fas fa-user-circle fa-3x text-primary"></i>
                            </div>
                            <div>
                                <h5 class="testimonial-name">Andi S.</h5>
                                <span class="testimonial-country">
                                    <i class="fas fa-map-marker-alt"></i> Jakarta, Indonesia
                                </span>
                            </div>
                        </div>
                        <div class="testimonial-stars mb-3">
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                        </div>
                        <p class="testimonial-text">
                            "Awalnya ragu, tapi setelah pakai VIP seminggu, profit saya naik 3x lipat. Robot ini WORTH IT! Sekarang tidur tenang, bangun tinggal cek profit 💰"
                        </p>
                        <div class="testimonial-stats">
                            <span class="badge bg-success">Win Rate: 88%</span>
                            <span class="badge bg-primary">Paket: VIP</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 fade-in">
                <div class="card testimonial-card h-100">
                    <div class="card-body">
                        <div class="testimonial-header">
                            <div class="testimonial-avatar">
                                <i class="fas fa-user-circle fa-3x text-info"></i>
                            </div>
                            <div>
                                <h5 class="testimonial-name">Maria L.</h5>
                                <span class="testimonial-country">
                                    <i class="fas fa-map-marker-alt"></i> Surabaya, Indonesia
                                </span>
                            </div>
                        </div>
                        <div class="testimonial-stars mb-3">
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star-half-alt text-warning"></i>
                        </div>
                        <p class="testimonial-text">
                            "Sekarang tidur nyenyak, bangun tinggal cek profit. Ga perlu mantau chart lagi 😂 Fitur Auto-Pause sangat berguna untuk membatasi kerugian!"
                        </p>
                        <div class="testimonial-stats">
                            <span class="badge bg-success">Win Rate: 75%</span>
                            <span class="badge bg-info">Paket: ELITE</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 fade-in">
                <div class="card testimonial-card h-100">
                    <div class="card-body">
                        <div class="testimonial-header">
                            <div class="testimonial-avatar">
                                <i class="fas fa-user-circle fa-3x text-success"></i>
                            </div>
                            <div>
                                <h5 class="testimonial-name">Budi P.</h5>
                                <span class="testimonial-country">
                                    <i class="fas fa-map-marker-alt"></i> Bandung, Indonesia
                                </span>
                            </div>
                        </div>
                        <div class="testimonial-stars mb-3">
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                            <i class="fas fa-star text-warning"></i>
                        </div>
                        <p class="testimonial-text">
                            "Dari FREE upgrade ke ELITE, langsung kerasa bedanya. Win rate beneran naik! Support Telegram juga responsif, worth it banget pokoknya!"
                        </p>
                        <div class="testimonial-stats">
                            <span class="badge bg-success">Win Rate: 72%</span>
                            <span class="badge bg-primary">Paket: PRO</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mt-5">
            <div class="col-12">
                <div class="stats-banner fade-in">
                    <div class="row g-4 text-center">
                        <div class="col-6 col-md-3">
                            <div class="stat-big">
                                <span class="stat-number text-gradient">2,500+</span>
                                <span class="stat-label">Active Users</span>
                            </div>
                        </div>
                        <div class="col-6 col-md-3">
                            <div class="stat-big">
                                <span class="stat-number text-success">$150K+</span>
                                <span class="stat-label">Total Profit</span>
                            </div>
                        </div>
                        <div class="col-6 col-md-3">
                            <div class="stat-big">
                                <span class="stat-number text-info">50,000+</span>
                                <span class="stat-label">Trades Executed</span>
                            </div>
                        </div>
                        <div class="col-6 col-md-3">
                            <div class="stat-big">
                                <span class="stat-number text-warning">85%</span>
                                <span class="stat-label">Avg Win Rate</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Support Us Section -->
<section class="section" id="support-us">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card support-card fade-in">
                    <div class="card-body text-center py-5">
                        <h3 class="mb-3">🏠 INI RUMAHMU, TOLONG DIRAWAT!</h3>
                        <p class="text-muted mb-4">
                            Cara support kami agar sistem selalu kasih yang <strong>terbaik</strong> untuk kamu:
                        </p>
                        <div class="row g-4 mb-4">
                            <div class="col-md-6">
                                <div class="support-step">
                                    <span class="step-num">1️⃣</span>
                                    <p>Daftar akun <strong>GRATIS</strong> via link kami</p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="support-step">
                                    <span class="step-num">2️⃣</span>
                                    <p>Ketika sudah profit, naik level <strong>PREMIUM</strong> dengan bayar bulanan</p>
                                </div>
                            </div>
                        </div>
                        <p class="text-muted">
                            Itu sudah cukup sebagai tanda support! 🙏<br>
                            <strong>Kami akan selalu kasih yang TERBAIK untuk kamu.</strong>
                        </p>
                        <div class="mt-4">
                            <a href="<?php echo OLYMPTRADE_AFFILIATE_LINK; ?>" target="_blank" class="btn btn-primary">
                                <i class="fas fa-gift"></i> Daftar Gratis + Dapat Robot! 🎁
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="section cta-section">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8 text-center fade-in">
                <span class="cta-badge mb-3">
                    <i class="fas fa-rocket"></i> Mulai Sekarang
                </span>
                <h2 class="section-title mb-4">Siap Trading Lebih Cerdas?</h2>
                <p class="section-desc mb-4">
                    💡 "Kenapa capek trading manual? Biarkan robot yang kerja, kamu tinggal cek profit" 💰
                </p>

                <div class="cta-features mb-4">
                    <span class="cta-feature"><i class="fas fa-check-circle text-success"></i> 100% Gratis untuk Tier FREE</span>
                    <span class="cta-feature"><i class="fas fa-check-circle text-success"></i> Tidak perlu pengalaman trading</span>
                    <span class="cta-feature"><i class="fas fa-check-circle text-success"></i> Support 24/7 via Telegram</span>
                </div>

                <div class="d-flex gap-3 justify-content-center flex-wrap">
                    <a href="register.php" class="btn btn-primary btn-lg">
                        <i class="fas fa-rocket"></i> Mulai Gratis Sekarang
                    </a>
                    <a href="<?php echo TELEGRAM_CHANNEL; ?>" target="_blank" class="btn btn-outline-light btn-lg">
                        <i class="fab fa-telegram"></i> Join Channel
                    </a>
                </div>

                <div class="mt-4">
                    <small class="text-muted">
                        Ada pertanyaan? Chat langsung dengan
                        <a href="https://t.me/<?php echo str_replace('@', '', TELEGRAM_USERNAME); ?>" target="_blank" class="text-primary"><?php echo TELEGRAM_USERNAME; ?></a>
                    </small>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Risk Disclaimer Banner -->
<section class="py-4 bg-darker border-top border-bottom" style="border-color: var(--border-color) !important;">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-auto">
                <i class="fas fa-exclamation-triangle text-warning fa-2x"></i>
            </div>
            <div class="col">
                <p class="mb-0 text-muted small">
                    <strong class="text-warning">Risk Disclaimer:</strong>
                    Trading mengandung risiko. Tidak ada sistem yang menjamin profit. Hasil trading bergantung pada kondisi market dan disiplin penggunaan sistem.
                    <a href="disclaimer.php" class="text-primary">Read full disclaimer</a>
                </p>
            </div>
        </div>
    </div>
</section>

<style>
.hero-visual {
    position: relative;
    padding: 2rem;
}

.chart-svg {
    width: 100%;
    max-width: 500px;
    filter: drop-shadow(0 0 30px rgba(0, 212, 255, 0.3));
}

.hero-section {
    background:
        radial-gradient(ellipse at 30% 20%, rgba(0, 212, 255, 0.08) 0%, transparent 50%),
        radial-gradient(ellipse at 70% 80%, rgba(124, 58, 237, 0.08) 0%, transparent 50%);
}

/* Testimonial Cards */
.testimonial-card {
    background: var(--card-bg);
    border: 1px solid var(--border-color);
    transition: transform 0.3s, box-shadow 0.3s;
}

.testimonial-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 40px rgba(0, 212, 255, 0.15);
}

.testimonial-header {
    display: flex;
    align-items: center;
    gap: 1rem;
    margin-bottom: 1rem;
}

.testimonial-name {
    margin-bottom: 0;
    font-weight: 600;
}

.testimonial-country {
    font-size: 0.85rem;
    color: var(--text-muted);
}

.testimonial-text {
    font-style: italic;
    color: var(--text-muted);
    margin-bottom: 1rem;
}

.testimonial-stats {
    display: flex;
    gap: 0.5rem;
}

/* Stats Banner */
.stats-banner {
    background: linear-gradient(135deg, rgba(0, 212, 255, 0.1) 0%, rgba(124, 58, 237, 0.1) 100%);
    border: 1px solid var(--border-color);
    border-radius: 1rem;
    padding: 2rem;
}

.stat-big {
    display: flex;
    flex-direction: column;
}

.stat-number {
    font-size: 2rem;
    font-weight: 700;
}

.stat-label {
    font-size: 0.9rem;
    color: var(--text-muted);
}

/* CTA Section */
.cta-section {
    background:
        radial-gradient(ellipse at 50% 50%, rgba(0, 212, 255, 0.1) 0%, transparent 70%);
}

.cta-badge {
    display: inline-block;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    padding: 0.5rem 1.5rem;
    border-radius: 50px;
    font-size: 0.9rem;
    font-weight: 600;
}

.cta-features {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 1.5rem;
}

.cta-feature {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    font-size: 0.95rem;
}

@media (max-width: 768px) {
    .cta-features {
        flex-direction: column;
        align-items: center;
        gap: 0.75rem;
    }

    .stat-number {
        font-size: 1.5rem;
    }
}

/* Hero Tagline */
.hero-tagline {
    font-size: 1.5rem;
    font-weight: 700;
    color: var(--primary-color);
    margin-bottom: 1rem;
    font-family: 'Orbitron', monospace;
}

/* Support Card */
.support-card {
    background: linear-gradient(135deg, rgba(0, 212, 255, 0.05) 0%, rgba(124, 58, 237, 0.05) 100%);
    border: 2px solid var(--primary-color);
}

.support-step {
    background: var(--card-bg);
    padding: 1.5rem;
    border-radius: 1rem;
    border: 1px solid var(--border-color);
}

.support-step .step-num {
    font-size: 2rem;
    display: block;
    margin-bottom: 0.5rem;
}

.support-step p {
    margin-bottom: 0;
    color: var(--text-muted);
}

/* Promo Banner */
.promo-banner {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    background: linear-gradient(135deg, #ff6b35, #f7c42d);
    color: #000;
    padding: 1rem;
    z-index: 1000;
    text-align: center;
    box-shadow: 0 -4px 20px rgba(0, 0, 0, 0.3);
}

.promo-banner h5 {
    margin-bottom: 0.5rem;
    font-weight: 700;
}

.promo-banner .countdown {
    font-family: 'Orbitron', monospace;
    font-size: 1.2rem;
    font-weight: 700;
    margin: 0.5rem 0;
}

.promo-banner .btn {
    margin-top: 0.5rem;
}
</style>

<?php require_once 'includes/footer.php'; ?>

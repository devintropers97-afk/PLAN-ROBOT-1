<?php
/**
 * ============================================
 * DIGISTORE - HALAMAN SUKSES PEMBAYARAN
 * ============================================
 * 
 * Halaman ini ditampilkan setelah customer selesai bayar.
 * Customer akan di-redirect ke sini dari NEO PGA.
 * 
 * 📁 Lokasi: /success.php
 * 🔗 URL: https://toko-kamu.com/success.php?invoice=INVxxxxx
 * 
 * CATATAN PENTING:
 * - Halaman ini BUKAN konfirmasi pembayaran berhasil!
 * - Konfirmasi asli datang dari Webhook
 * - Halaman ini hanya untuk UX (user experience) yang baik
 */

// Load konfigurasi
require_once __DIR__ . '/config.php';

// Ambil parameter dari URL (sanitized untuk keamanan)
$invoiceNumber = sanitize($_GET['invoice'] ?? '');
$orderId = sanitize($_GET['order_id'] ?? '');
$status = sanitize($_GET['status'] ?? '');

// Cari data pesanan
$order = null;
$paymentStatus = 'checking';  // checking, paid, pending, not_found

if (!empty($orderId)) {
    $order = getOrder($orderId);
} elseif (!empty($invoiceNumber)) {
    $order = getOrderByInvoice($invoiceNumber);
}

// Tentukan status
if ($order) {
    $paymentStatus = $order['status'] ?? 'pending';
} else {
    $paymentStatus = 'not_found';
}

// Ambil info produk jika ada
$productName = $order['product_name'] ?? 'Produk Digital';
$customerName = $order['customer_name'] ?? 'Customer';
$customerEmail = $order['customer_email'] ?? '';
$downloadUrl = $order['download_url'] ?? '';
$amount = $order['amount'] ?? 0;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Status Pembayaran - <?= STORE_NAME ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600;700&family=Space+Mono:wght@400;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-primary: #0a0a0f;
            --bg-card: #1a1a24;
            --accent: #00d4aa;
            --accent-glow: rgba(0, 212, 170, 0.3);
            --text-primary: #ffffff;
            --text-secondary: #8a8a9a;
            --border: rgba(255, 255, 255, 0.08);
            --success: #00d4aa;
            --warning: #ffd93d;
            --error: #ff6b6b;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Sora', sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .bg-pattern {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 0;
            opacity: 0.4;
            background: radial-gradient(ellipse 80% 50% at 50% -20%, var(--accent-glow), transparent);
        }

        .container {
            position: relative;
            z-index: 1;
            width: 100%;
            max-width: 500px;
        }

        .card {
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: 24px;
            padding: 40px;
            text-align: center;
        }

        .status-icon {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 3rem;
            margin: 0 auto 24px;
        }

        .status-icon.success {
            background: linear-gradient(135deg, rgba(0, 212, 170, 0.2), rgba(0, 212, 170, 0.05));
            border: 2px solid var(--success);
        }

        .status-icon.pending {
            background: linear-gradient(135deg, rgba(255, 217, 61, 0.2), rgba(255, 217, 61, 0.05));
            border: 2px solid var(--warning);
            animation: pulse 2s infinite;
        }

        .status-icon.error {
            background: linear-gradient(135deg, rgba(255, 107, 107, 0.2), rgba(255, 107, 107, 0.05));
            border: 2px solid var(--error);
        }

        @keyframes pulse {
            0%, 100% { transform: scale(1); opacity: 1; }
            50% { transform: scale(1.05); opacity: 0.8; }
        }

        h1 {
            font-size: 1.8rem;
            margin-bottom: 12px;
        }

        .subtitle {
            color: var(--text-secondary);
            margin-bottom: 32px;
            line-height: 1.6;
        }

        .info-box {
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 20px;
            margin-bottom: 24px;
            text-align: left;
        }

        .info-row {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid var(--border);
        }

        .info-row:last-child {
            border-bottom: none;
        }

        .info-label {
            color: var(--text-secondary);
            font-size: 0.9rem;
        }

        .info-value {
            font-weight: 600;
            font-family: 'Space Mono', monospace;
            color: var(--text-primary);
        }

        .btn {
            display: inline-block;
            padding: 16px 32px;
            border-radius: 12px;
            font-size: 1rem;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            font-family: 'Sora', sans-serif;
            cursor: pointer;
            border: none;
        }

        .btn-primary {
            background: var(--accent);
            color: var(--bg-primary);
            width: 100%;
            margin-bottom: 12px;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 30px -10px var(--accent-glow);
        }

        .btn-secondary {
            background: transparent;
            border: 1px solid var(--border);
            color: var(--text-primary);
            width: 100%;
        }

        .btn-secondary:hover {
            background: rgba(255, 255, 255, 0.05);
        }

        .download-box {
            background: linear-gradient(135deg, rgba(0, 212, 170, 0.1), rgba(0, 212, 170, 0.02));
            border: 1px solid var(--accent);
            border-radius: 16px;
            padding: 20px;
            margin-bottom: 24px;
        }

        .download-box h3 {
            color: var(--accent);
            margin-bottom: 8px;
            font-size: 1rem;
        }

        .download-box p {
            color: var(--text-secondary);
            font-size: 0.85rem;
            margin-bottom: 16px;
        }

        .checking-status {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            color: var(--text-secondary);
            margin-bottom: 24px;
        }

        .spinner {
            width: 20px;
            height: 20px;
            border: 2px solid var(--border);
            border-top-color: var(--accent);
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        .footer {
            margin-top: 32px;
            color: var(--text-secondary);
            font-size: 0.85rem;
        }

        .footer a {
            color: var(--accent);
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="bg-pattern"></div>
    
    <div class="container">
        <div class="card">
            <?php if ($paymentStatus === 'paid'): ?>
                <!-- ✅ PEMBAYARAN BERHASIL -->
                <div class="status-icon success">✅</div>
                <h1>Pembayaran Berhasil!</h1>
                <p class="subtitle">
                    Terima kasih, <?= htmlspecialchars($customerName) ?>! 
                    Pembayaran kamu sudah kami terima.
                </p>
                
                <div class="info-box">
                    <div class="info-row">
                        <span class="info-label">Produk</span>
                        <span class="info-value"><?= htmlspecialchars($productName) ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Total Bayar</span>
                        <span class="info-value"><?= formatRupiah($order['payment_amount'] ?? $amount) ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Invoice</span>
                        <span class="info-value"><?= htmlspecialchars($order['invoice_number'] ?? '-') ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Waktu Bayar</span>
                        <span class="info-value"><?= htmlspecialchars($order['paid_at'] ?? '-') ?></span>
                    </div>
                </div>
                
                <?php if (!empty($downloadUrl)): ?>
                <div class="download-box">
                    <h3>📦 Download Produk</h3>
                    <p>Klik tombol di bawah untuk download produk kamu.</p>
                    <a href="<?= htmlspecialchars($downloadUrl) ?>" class="btn btn-primary" target="_blank">
                        ⬇️ Download Sekarang
                    </a>
                </div>
                <?php endif; ?>
                
                <p style="color: var(--text-secondary); font-size: 0.85rem; margin-bottom: 16px;">
                    Link download juga sudah dikirim ke<br>
                    <strong><?= htmlspecialchars($customerEmail) ?></strong>
                </p>
                
                <a href="./" class="btn btn-secondary">← Kembali ke Toko</a>
                
            <?php elseif ($paymentStatus === 'pending'): ?>
                <!-- ⏳ MENUNGGU PEMBAYARAN -->
                <?php
                    $baseAmount = $order['amount'] ?? 0;
                    $uniqueCode = $order['unique_code'] ?? 0;  // Ambil dari order data
                    $totalAmount = $order['total_amount'] ?? ($baseAmount + $uniqueCode);
                ?>
                <div class="status-icon pending">⏳</div>
                <h1>Menunggu Pembayaran</h1>
                <p class="subtitle">
                    Pembayaran kamu sedang diproses. Halaman ini akan otomatis update.
                </p>
                
                <div class="checking-status">
                    <div class="spinner"></div>
                    <span>Mengecek status pembayaran...</span>
                </div>
                
                <!-- INFO PEMBAYARAN DENGAN KODE UNIK -->
                <div class="info-box">
                    <div class="info-row">
                        <span class="info-label">Produk</span>
                        <span class="info-value"><?= htmlspecialchars($productName) ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Harga</span>
                        <span class="info-value"><?= formatRupiah($baseAmount) ?></span>
                    </div>
                    <?php if ($uniqueCode > 0): ?>
                    <div class="info-row">
                        <span class="info-label">Kode Unik</span>
                        <span class="info-value" style="color: var(--accent);">+<?= number_format($uniqueCode, 0, ',', '.') ?></span>
                    </div>
                    <?php endif; ?>
                    <div class="info-row" style="background: rgba(0,212,170,0.1); margin: 8px -20px -20px; padding: 16px 20px; border-radius: 0 0 16px 16px;">
                        <span class="info-label" style="font-weight: 600; color: var(--text-primary);">TOTAL BAYAR</span>
                        <span class="info-value" style="color: var(--accent); font-size: 1.2rem;"><?= formatRupiah($totalAmount) ?></span>
                    </div>
                </div>
                
                <!-- PERINGATAN KODE UNIK -->
                <?php if ($uniqueCode > 0): ?>
                <div style="background: rgba(255, 217, 61, 0.1); border: 1px solid rgba(255, 217, 61, 0.3); border-radius: 12px; padding: 16px; margin-bottom: 24px; text-align: left;">
                    <div style="display: flex; align-items: flex-start; gap: 12px;">
                        <span style="font-size: 1.5rem;">⚠️</span>
                        <div>
                            <div style="color: var(--warning); font-weight: 600; margin-bottom: 4px;">PENTING!</div>
                            <div style="color: var(--text-secondary); font-size: 0.85rem; line-height: 1.5;">
                                Transfer <strong style="color: var(--warning);">PERSIS <?= formatRupiah($totalAmount) ?></strong><br>
                                Jangan dibulatkan! Kode unik <strong style="color: var(--accent);">+<?= number_format($uniqueCode, 0, ',', '.') ?></strong> diperlukan untuk verifikasi otomatis.
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                
                <p style="color: var(--text-secondary); font-size: 0.85rem; margin-bottom: 24px;">
                    Sudah bayar tapi status belum berubah?<br>
                    Tunggu 1-2 menit atau hubungi kami.
                </p>
                
                <a href="./" class="btn btn-secondary">← Kembali ke Toko</a>
                
                <!-- Auto refresh setiap 5 detik -->
                <script>
                    setTimeout(() => {
                        location.reload();
                    }, 5000);
                </script>
                
            <?php elseif ($paymentStatus === 'expired'): ?>
                <!-- ⏰ EXPIRED -->
                <div class="status-icon error">⏰</div>
                <h1>Pembayaran Kedaluwarsa</h1>
                <p class="subtitle">
                    Maaf, waktu pembayaran sudah habis. Silakan buat pesanan baru.
                </p>
                
                <a href="./" class="btn btn-primary">🛒 Belanja Lagi</a>
                
            <?php elseif ($paymentStatus === 'failed'): ?>
                <!-- ❌ GAGAL -->
                <div class="status-icon error">❌</div>
                <h1>Pembayaran Gagal</h1>
                <p class="subtitle">
                    Maaf, pembayaran tidak berhasil diproses. Silakan coba lagi.
                </p>
                
                <a href="./" class="btn btn-primary">🔄 Coba Lagi</a>
                
            <?php else: ?>
                <!-- ❓ TIDAK DITEMUKAN -->
                <div class="status-icon error">❓</div>
                <h1>Pesanan Tidak Ditemukan</h1>
                <p class="subtitle">
                    Maaf, kami tidak dapat menemukan data pesanan kamu.
                </p>
                
                <a href="cek-status.php" class="btn btn-primary" style="margin-bottom: 12px;">🔍 Cek Status Pesanan</a>
                <a href="./" class="btn btn-secondary">← Kembali ke Toko</a>
                
            <?php endif; ?>
            
            <div class="footer">
                <p>Butuh bantuan? <a href="https://wa.me/<?= STORE_WHATSAPP ?>" target="_blank">Chat WhatsApp</a></p>
            </div>
        </div>
    </div>
</body>
</html>

<?php
/**
 * =====================================================================
 * NEO PGA SDK - QRIS ONLY (SDK SAJA)
 * =====================================================================
 *
 * File ini HANYA berisi class SDK untuk generate QRIS.
 * Gunakan jika Anda SUDAH PUNYA form deposit sendiri.
 *
 * =====================================================================
 * CARA PAKAI:
 * =====================================================================
 *
 * 1. Upload file ini ke folder website (misal: /includes/neopga.php)
 *
 * 2. Di file form deposit Anda, tambahkan kode berikut:
 *
 *    require_once 'includes/neopga.php';
 *
 *    // Ketika user submit form
 *    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
 *        $nominal = (int) $_POST['nominal'];
 *        $orderId = 'DEP-' . $userId . '-' . time();
 *
 *        $result = NeoPGA::createQRIS($nominal, $orderId);
 *
 *        if ($result['success']) {
 *            // Redirect ke halaman QRIS NEO PGA
 *            header('Location: ' . $result['payment_url']);
 *            exit;
 *        }
 *    }
 *
 * 3. Buat file callback.php:
 *
 *    require_once 'includes/neopga.php';
 *
 *    $payment = NeoPGA::verifyCallback();
 *
 *    if ($payment && $payment['status'] === 'success') {
 *        $orderId = $payment['reference_id'];
 *        $amount  = $payment['amount'];
 *
 *        // Update saldo user di database Anda
 *        // $pdo->query("UPDATE users SET saldo = saldo + $amount WHERE ...");
 *
 *        http_response_code(200);
 *        echo json_encode(['status' => 'ok']);
 *    }
 *
 * 4. Set URL callback di Dashboard NEO PGA > Pengaturan
 *
 * =====================================================================
 */

class NeoPGA
{
    // =====================================================================
    // GANTI DENGAN KREDENSIAL ANDA
    // Dapatkan di: Dashboard NEO PGA > API Keys
    // =====================================================================
    const API_KEY    = 'GANTI_DENGAN_API_KEY_ANDA';
    const SECRET_KEY = 'GANTI_DENGAN_SECRET_KEY_ANDA';
    const BASE_URL   = 'https://DOMAIN_NEOPGA_ANDA.com';
    // =====================================================================

    /**
     * BUAT PEMBAYARAN QRIS
     *
     * @param int    $amount      Nominal deposit (contoh: 50000)
     * @param string $referenceId ID unik transaksi Anda (contoh: 'DEP-123-1702900000')
     * @param string $description Keterangan (opsional)
     * @param array  $customer    Data customer (opsional)
     * @return array
     *
     * CONTOH:
     *   $result = NeoPGA::createQRIS(50000, 'DEP-USER123-' . time());
     *
     *   if ($result['success']) {
     *       header('Location: ' . $result['payment_url']);
     *       exit;
     *   }
     */
    public static function createQRIS($amount, $referenceId, $description = '', $customer = [])
    {
        $data = [
            'reference_id'   => $referenceId,
            'amount'         => (int) $amount,
            'payment_method' => 'qris',
            'description'    => $description ?: 'Deposit',
            'customer_name'  => $customer['name'] ?? '',
            'customer_email' => $customer['email'] ?? '',
            'customer_phone' => $customer['phone'] ?? '',
        ];

        return self::request('POST', '/api/create.php', $data);
    }

    /**
     * CEK STATUS PEMBAYARAN
     *
     * @param string $invoice Invoice number dari NEO PGA
     * @return array
     */
    public static function checkStatus($invoice)
    {
        return self::request('GET', '/api/status.php?invoice=' . urlencode($invoice));
    }

    /**
     * VERIFIKASI CALLBACK/WEBHOOK
     *
     * Panggil di callback.php untuk memastikan request dari NEO PGA.
     * Return false jika signature tidak valid.
     *
     * @return array|false Data pembayaran jika valid
     *
     * DATA YANG TERSEDIA:
     *   - reference_id    : ID transaksi Anda
     *   - amount          : Nominal deposit
     *   - total_amount    : Nominal + kode unik
     *   - unique_code     : Kode unik (1-999)
     *   - invoice_number  : Invoice NEO PGA
     *   - payment_method  : 'qris'
     *   - status          : 'success'
     *   - paid_at         : Waktu pembayaran
     */
    public static function verifyCallback()
    {
        $payload = file_get_contents('php://input');
        $signature = $_SERVER['HTTP_X_SIGNATURE'] ?? '';

        if (empty($payload) || empty($signature)) {
            return false;
        }

        $expectedSignature = hash_hmac('sha256', $payload, self::SECRET_KEY);

        if (!hash_equals($expectedSignature, $signature)) {
            return false;
        }

        $data = json_decode($payload, true);
        return $data['data'] ?? $data;
    }

    /**
     * GET PAYMENT URL
     *
     * @param string $invoice Invoice number
     * @return string URL halaman pembayaran
     */
    public static function getPaymentUrl($invoice)
    {
        return self::BASE_URL . '/public/pay.php?invoice=' . urlencode($invoice);
    }

    // =====================================================================
    // INTERNAL - Tidak perlu diubah
    // =====================================================================
    private static function request($method, $endpoint, $data = [])
    {
        $url = self::BASE_URL . $endpoint;

        $headers = [
            'Content-Type: application/json',
            'X-API-Key: ' . self::API_KEY,
        ];

        if ($method === 'POST' && !empty($data)) {
            $jsonData = json_encode($data);
            $signature = hash_hmac('sha256', $jsonData, self::SECRET_KEY);
            $headers[] = 'X-Signature: ' . $signature;
        }

        $ch = curl_init();

        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData ?? '');
        }

        curl_setopt_array($ch, [
            CURLOPT_URL            => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 30,
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);

        $response = curl_exec($ch);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) {
            return ['success' => false, 'error' => 'Connection error: ' . $error];
        }

        $result = json_decode($response, true);

        if (!$result) {
            return ['success' => false, 'error' => 'Invalid response'];
        }

        if (isset($result['data']['invoice_number'])) {
            $result['payment_url'] = self::getPaymentUrl($result['data']['invoice_number']);
        }

        return $result;
    }
}

<?php
/**
 * ============================================
 * DIGISTORE - LANDING PAGE
 * ============================================
 *
 * Support:
 * - Produk Digital (harga fixed)
 * - Top Up Game (input manual nominal)
 */

require_once __DIR__ . '/config.php';

$paymentResult = null;
$showPayment = false;
$selectedProduct = null;

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {

    if ($_POST['action'] === 'create_payment') {
        global $PRODUCTS;

        $productId = $_POST['product_id'] ?? '';
        $customerName = htmlspecialchars(trim($_POST['customer_name'] ?? ''));
        $customerEmail = filter_var(trim($_POST['customer_email'] ?? ''), FILTER_SANITIZE_EMAIL);
        $customerPhone = preg_replace('/[^0-9]/', '', $_POST['customer_phone'] ?? '');
        $customAmount = (int) preg_replace('/[^0-9]/', '', $_POST['custom_amount'] ?? '0');

        // Game ID untuk top up
        $gameId = htmlspecialchars(trim($_POST['game_id'] ?? ''));
        $serverId = htmlspecialchars(trim($_POST['server_id'] ?? ''));

        if (!isset($PRODUCTS[$productId])) {
            $paymentResult = ['success' => false, 'message' => 'Produk tidak valid'];
        } elseif (empty($customerName) || empty($customerEmail) || empty($customerPhone)) {
            $paymentResult = ['success' => false, 'message' => 'Semua field harus diisi'];
        } elseif (!filter_var($customerEmail, FILTER_VALIDATE_EMAIL)) {
            $paymentResult = ['success' => false, 'message' => 'Format email tidak valid'];
        } else {
            $selectedProduct = $PRODUCTS[$productId];

            // Tentukan amount
            if ($selectedProduct['type'] === 'topup') {
                // Top up game - pakai custom amount
                $amount = $customAmount;
                $minAmount = $selectedProduct['min_amount'] ?? 1000;
                $maxAmount = $selectedProduct['max_amount'] ?? 5000000;

                if ($amount < $minAmount || $amount > $maxAmount) {
                    $paymentResult = ['success' => false, 'message' => "Nominal harus antara " . formatRupiah($minAmount) . " - " . formatRupiah($maxAmount)];
                }
            } else {
                // Produk digital - pakai harga fixed
                $amount = (int) $selectedProduct['price'];
            }

            if (!isset($paymentResult['success']) || $paymentResult['success'] !== false) {
                $orderId = generateOrderId();

                // Deskripsi untuk top up game
                $description = $selectedProduct['name'];
                if ($selectedProduct['type'] === 'topup' && !empty($gameId)) {
                    $description .= " (ID: {$gameId}";
                    if (!empty($serverId)) {
                        $description .= ", Server: {$serverId}";
                    }
                    $description .= ")";
                }

                $paymentData = [
                    'reference_id'    => $orderId,
                    'amount'          => $amount,
                    'payment_method'  => 'qris',
                    'customer_name'   => $customerName,
                    'customer_email'  => $customerEmail,
                    'customer_phone'  => $customerPhone,
                    'description'     => $description,
                    'callback_url'    => WEBHOOK_URL,
                    'expiry_minutes'  => 60
                ];

                $paymentResult = callNeoPGAAPI('/api/create.php', 'POST', $paymentData);

                if ($paymentResult['success'] ?? false) {
                    $showPayment = true;

                    saveOrder([
                        'order_id'        => $orderId,
                        'invoice_number'  => $paymentResult['data']['invoice_number'] ?? '',
                        'product_id'      => $productId,
                        'product_name'    => $selectedProduct['name'],
                        'amount'          => $amount,
                        'unique_code'     => $paymentResult['data']['unique_code'] ?? 0,
                        'total_amount'    => $paymentResult['data']['total_amount'] ?? $amount,
                        'customer_name'   => $customerName,
                        'customer_email'  => $customerEmail,
                        'customer_phone'  => $customerPhone,
                        'game_id'         => $gameId,
                        'server_id'       => $serverId,
                        'download_url'    => $selectedProduct['download_url'] ?? '',
                        'status'          => 'pending',
                        'payment_url'     => $paymentResult['data']['payment_url'] ?? '',
                        'created_at'      => date('Y-m-d H:i:s')
                    ]);
                }
            }
        }
    }
}

// Separate products by type
$digitalProducts = [];
$topupProducts = [];
foreach ($PRODUCTS as $id => $product) {
    if (($product['type'] ?? 'digital') === 'topup') {
        $topupProducts[$id] = $product;
    } else {
        $digitalProducts[$id] = $product;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= STORE_NAME ?> - Digital Products & Game Top Up</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-dark: #0f0f14;
            --bg-card: #1a1a23;
            --bg-card-hover: #22222e;
            --bg-input: #13131a;
            --accent: #6366f1;
            --accent-light: #818cf8;
            --accent-glow: rgba(99, 102, 241, 0.25);
            --success: #10b981;
            --success-glow: rgba(16, 185, 129, 0.25);
            --warning: #f59e0b;
            --warning-glow: rgba(245, 158, 11, 0.25);
            --error: #ef4444;
            --game: #ec4899;
            --game-glow: rgba(236, 72, 153, 0.25);
            --text: #ffffff;
            --text-secondary: #9ca3af;
            --text-muted: #6b7280;
            --border: rgba(255, 255, 255, 0.08);
            --border-hover: rgba(255, 255, 255, 0.15);
            --gradient-primary: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
            --gradient-game: linear-gradient(135deg, #ec4899 0%, #f43f5e 100%);
            --gradient-success: linear-gradient(135deg, #10b981 0%, #059669 100%);
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        html { scroll-behavior: smooth; }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: var(--bg-dark);
            color: var(--text);
            min-height: 100vh;
            line-height: 1.6;
        }

        .container {
            max-width: 1280px;
            margin: 0 auto;
            padding: 0 24px;
        }

        /* Header */
        header {
            position: sticky;
            top: 0;
            z-index: 100;
            background: rgba(15, 15, 20, 0.8);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid var(--border);
        }

        .header-content {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 16px 0;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
            text-decoration: none;
        }

        .logo-icon {
            width: 44px;
            height: 44px;
            background: var(--gradient-primary);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            box-shadow: 0 8px 24px var(--accent-glow);
        }

        .logo-text {
            font-size: 1.5rem;
            font-weight: 800;
            background: var(--gradient-primary);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .header-nav {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .nav-link {
            padding: 10px 16px;
            color: var(--text-secondary);
            text-decoration: none;
            font-size: 0.9rem;
            font-weight: 500;
            border-radius: 10px;
            transition: all 0.2s;
        }

        .nav-link:hover {
            color: var(--text);
            background: rgba(255, 255, 255, 0.05);
        }

        .nav-btn {
            padding: 10px 20px;
            background: var(--gradient-primary);
            color: white;
            text-decoration: none;
            font-size: 0.9rem;
            font-weight: 600;
            border-radius: 10px;
            transition: all 0.3s;
            box-shadow: 0 4px 15px var(--accent-glow);
        }

        .nav-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px var(--accent-glow);
        }

        .back-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 18px;
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            color: white;
            text-decoration: none;
            font-size: 0.9rem;
            font-weight: 500;
            border-radius: 10px;
            transition: all 0.2s;
        }

        .back-btn:hover {
            background: rgba(255, 255, 255, 0.2);
        }

        .demo-indicator {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 16px;
            background: linear-gradient(135deg, #f59e0b 0%, #ef4444 100%);
            color: white;
            font-size: 0.75rem;
            font-weight: 700;
            border-radius: 50px;
            text-transform: uppercase;
            letter-spacing: 0.1em;
            animation: demoGlow 2s ease-in-out infinite;
        }

        .demo-indicator-dot {
            width: 8px;
            height: 8px;
            background: white;
            border-radius: 50%;
            animation: demoPulse 1.5s ease-in-out infinite;
        }

        @keyframes demoGlow {
            0%, 100% { box-shadow: 0 4px 15px rgba(239, 68, 68, 0.4); }
            50% { box-shadow: 0 4px 25px rgba(239, 68, 68, 0.6); }
        }

        @keyframes demoPulse {
            0%, 100% { opacity: 1; transform: scale(1); }
            50% { opacity: 0.5; transform: scale(0.8); }
        }

        /* Demo Banner */
        .demo-banner {
            background: var(--gradient-primary);
            padding: 20px 0;
            position: relative;
            overflow: hidden;
        }

        .demo-banner::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.05'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
            pointer-events: none;
        }

        .demo-banner-content {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 16px;
            flex-wrap: wrap;
            text-align: center;
            position: relative;
            z-index: 1;
        }

        .demo-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 16px;
            background: rgba(0, 0, 0, 0.2);
            border-radius: 50px;
            font-size: 0.9rem;
            font-weight: 600;
        }

        .demo-badge-dot {
            width: 8px;
            height: 8px;
            background: #10b981;
            border-radius: 50%;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0%, 100% { opacity: 1; transform: scale(1); }
            50% { opacity: 0.5; transform: scale(0.8); }
        }

        .demo-text {
            font-size: 0.9rem;
            opacity: 0.95;
        }

        .demo-text a {
            color: white;
            text-decoration: underline;
            font-weight: 600;
        }

        /* Hero Section */
        .hero {
            padding: 80px 0 60px;
            text-align: center;
            position: relative;
        }

        .hero::before {
            content: '';
            position: absolute;
            top: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 600px;
            height: 400px;
            background: radial-gradient(ellipse, var(--accent-glow) 0%, transparent 70%);
            pointer-events: none;
        }

        .hero-content {
            position: relative;
            z-index: 1;
        }

        .hero-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 20px;
            background: rgba(99, 102, 241, 0.1);
            border: 1px solid rgba(99, 102, 241, 0.3);
            border-radius: 50px;
            font-size: 0.875rem;
            font-weight: 600;
            color: var(--accent-light);
            margin-bottom: 24px;
        }

        .hero-title {
            font-size: clamp(2.5rem, 5vw, 4rem);
            font-weight: 800;
            line-height: 1.1;
            margin-bottom: 20px;
            letter-spacing: -0.02em;
        }

        .hero-title span {
            background: var(--gradient-primary);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .hero-desc {
            font-size: 1.2rem;
            color: var(--text-secondary);
            max-width: 600px;
            margin: 0 auto 40px;
        }

        .hero-stats {
            display: flex;
            justify-content: center;
            gap: 48px;
            flex-wrap: wrap;
        }

        .hero-stat {
            text-align: center;
        }

        .hero-stat-value {
            font-size: 2rem;
            font-weight: 800;
            color: var(--accent-light);
        }

        .hero-stat-label {
            font-size: 0.875rem;
            color: var(--text-muted);
            margin-top: 4px;
        }

        /* Section */
        .section {
            padding: 60px 0;
        }

        .section-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 32px;
            flex-wrap: wrap;
            gap: 16px;
        }

        .section-title {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 1.5rem;
            font-weight: 700;
        }

        .section-title-icon {
            width: 48px;
            height: 48px;
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
        }

        .section-subtitle {
            color: var(--text-secondary);
            font-size: 0.95rem;
        }

        /* Products Grid */
        .products-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 24px;
        }

        .product-card {
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: 20px;
            padding: 28px;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .product-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: var(--gradient-primary);
            opacity: 0;
            transition: opacity 0.3s;
        }

        .product-card:hover {
            border-color: var(--accent);
            transform: translateY(-8px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3), 0 0 0 1px var(--accent);
        }

        .product-card:hover::before {
            opacity: 1;
        }

        .product-card.game::before {
            background: var(--gradient-game);
        }

        .product-card.game:hover {
            border-color: var(--game);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3), 0 0 0 1px var(--game);
        }

        .product-header {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            margin-bottom: 16px;
        }

        .product-icon {
            width: 64px;
            height: 64px;
            background: linear-gradient(135deg, rgba(99, 102, 241, 0.2), rgba(139, 92, 246, 0.1));
            border: 1px solid rgba(99, 102, 241, 0.3);
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
        }

        .product-card.game .product-icon {
            background: linear-gradient(135deg, rgba(236, 72, 153, 0.2), rgba(244, 63, 94, 0.1));
            border-color: rgba(236, 72, 153, 0.3);
        }

        .product-badge {
            padding: 6px 14px;
            background: var(--gradient-primary);
            color: white;
            font-size: 0.75rem;
            font-weight: 700;
            border-radius: 50px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .product-badge.topup {
            background: var(--gradient-game);
        }

        .product-name {
            font-size: 1.25rem;
            font-weight: 700;
            margin-bottom: 8px;
        }

        .product-desc {
            font-size: 0.9rem;
            color: var(--text-secondary);
            margin-bottom: 20px;
            line-height: 1.6;
        }

        .product-footer {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 16px;
        }

        .product-price {
            font-size: 1.75rem;
            font-weight: 800;
            background: var(--gradient-primary);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .product-price.manual {
            font-size: 1rem;
            background: var(--gradient-game);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 14px 28px;
            background: var(--gradient-primary);
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 0.95rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            box-shadow: 0 4px 15px var(--accent-glow);
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px var(--accent-glow);
        }

        .btn.game {
            background: var(--gradient-game);
            box-shadow: 0 4px 15px var(--game-glow);
        }

        .btn.game:hover {
            box-shadow: 0 8px 25px var(--game-glow);
        }

        .btn-sm {
            padding: 10px 20px;
            font-size: 0.875rem;
        }

        .btn-full {
            width: 100%;
        }

        .btn-outline {
            background: transparent;
            border: 2px solid var(--border);
            box-shadow: none;
            color: var(--text);
        }

        .btn-outline:hover {
            border-color: var(--accent);
            background: rgba(99, 102, 241, 0.1);
            box-shadow: none;
        }

        /* Modal */
        .modal-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.85);
            backdrop-filter: blur(8px);
            z-index: 1000;
            align-items: center;
            justify-content: center;
            padding: 24px;
        }

        .modal-overlay.active {
            display: flex;
            animation: fadeIn 0.3s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .modal {
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: 24px;
            max-width: 480px;
            width: 100%;
            max-height: 90vh;
            overflow-y: auto;
            animation: slideUp 0.3s ease;
        }

        @keyframes slideUp {
            from { transform: translateY(20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        .modal-header {
            padding: 24px;
            border-bottom: 1px solid var(--border);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .modal-title {
            font-size: 1.25rem;
            font-weight: 700;
        }

        .modal-close {
            width: 40px;
            height: 40px;
            background: var(--bg-input);
            border: 1px solid var(--border);
            border-radius: 10px;
            color: var(--text-secondary);
            font-size: 1.25rem;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s;
        }

        .modal-close:hover {
            background: rgba(239, 68, 68, 0.1);
            border-color: var(--error);
            color: var(--error);
        }

        .modal-body {
            padding: 24px;
        }

        /* Form */
        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 0.9rem;
            font-weight: 500;
            color: var(--text-secondary);
            margin-bottom: 8px;
        }

        .form-input {
            width: 100%;
            padding: 14px 18px;
            background: var(--bg-input);
            border: 1px solid var(--border);
            border-radius: 12px;
            color: var(--text);
            font-size: 1rem;
            font-family: inherit;
            transition: all 0.2s;
        }

        .form-input:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 4px var(--accent-glow);
        }

        .form-input::placeholder {
            color: var(--text-muted);
        }

        .form-hint {
            font-size: 0.8rem;
            color: var(--text-muted);
            margin-top: 6px;
        }

        .amount-input {
            font-size: 1.5rem;
            font-weight: 700;
            text-align: center;
            letter-spacing: 1px;
        }

        /* Order Summary */
        .order-summary {
            background: var(--bg-input);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 20px;
            margin-bottom: 24px;
        }

        .order-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 0;
        }

        .order-item:not(:last-child) {
            border-bottom: 1px dashed var(--border);
        }

        .order-label {
            color: var(--text-secondary);
            font-size: 0.9rem;
        }

        .order-value {
            font-weight: 600;
        }

        .order-total {
            font-size: 1.5rem;
            font-weight: 800;
            background: var(--gradient-primary);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        /* QR Payment */
        .qr-container {
            text-align: center;
        }

        .qr-box {
            background: white;
            border-radius: 20px;
            padding: 24px;
            margin-bottom: 24px;
            display: inline-block;
        }

        .qr-box img {
            max-width: 220px;
            border-radius: 12px;
        }

        .qr-apps {
            display: flex;
            justify-content: center;
            gap: 12px;
            margin-top: 16px;
            flex-wrap: wrap;
        }

        .qr-app {
            padding: 6px 14px;
            background: var(--bg-input);
            border-radius: 50px;
            font-size: 0.8rem;
            color: var(--text-secondary);
        }

        /* Payment Breakdown */
        .payment-breakdown {
            background: var(--bg-input);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 20px;
            margin-bottom: 20px;
        }

        .breakdown-item {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
        }

        .breakdown-item:not(:last-child) {
            border-bottom: 1px dashed var(--border);
        }

        .breakdown-label {
            color: var(--text-secondary);
        }

        .breakdown-value {
            font-weight: 600;
        }

        .breakdown-value.accent {
            color: var(--accent-light);
        }

        .breakdown-total {
            font-size: 1.5rem;
            font-weight: 800;
            color: var(--success);
        }

        /* Warning Box */
        .warning-box {
            background: rgba(245, 158, 11, 0.1);
            border: 1px solid rgba(245, 158, 11, 0.3);
            border-radius: 16px;
            padding: 20px;
            margin-bottom: 20px;
        }

        .warning-header {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 8px;
        }

        .warning-icon {
            font-size: 1.5rem;
        }

        .warning-title {
            font-weight: 700;
            color: var(--warning);
        }

        .warning-text {
            color: var(--text-secondary);
            font-size: 0.9rem;
            line-height: 1.6;
        }

        .warning-text strong {
            color: var(--warning);
        }

        /* Invoice Box */
        .invoice-box {
            background: rgba(16, 185, 129, 0.1);
            border: 1px solid rgba(16, 185, 129, 0.3);
            border-radius: 16px;
            padding: 20px;
            text-align: center;
        }

        .invoice-label {
            font-size: 0.8rem;
            color: var(--text-secondary);
            margin-bottom: 8px;
        }

        .invoice-value {
            font-family: 'Monaco', 'Consolas', monospace;
            font-size: 1.1rem;
            font-weight: 600;
            color: var(--success);
            letter-spacing: 1px;
        }

        /* Footer */
        footer {
            padding: 40px 0;
            border-top: 1px solid var(--border);
            margin-top: 60px;
        }

        .footer-content {
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 20px;
        }

        .footer-brand {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .footer-logo {
            width: 36px;
            height: 36px;
            background: var(--gradient-primary);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.25rem;
        }

        .footer-text {
            color: var(--text-secondary);
            font-size: 0.9rem;
        }

        .footer-text a {
            color: var(--accent-light);
            text-decoration: none;
        }

        .footer-text a:hover {
            text-decoration: underline;
        }

        .footer-links {
            display: flex;
            gap: 24px;
        }

        .footer-link {
            color: var(--text-secondary);
            text-decoration: none;
            font-size: 0.9rem;
            transition: color 0.2s;
        }

        .footer-link:hover {
            color: var(--accent-light);
        }

        /* Responsive */
        @media (max-width: 768px) {
            .header-nav {
                display: none;
            }

            .hero {
                padding: 60px 0 40px;
            }

            .hero-title {
                font-size: 2rem;
            }

            .hero-stats {
                gap: 32px;
            }

            .products-grid {
                grid-template-columns: 1fr;
            }

            .product-footer {
                flex-direction: column;
                align-items: stretch;
            }

            .product-price {
                text-align: center;
                margin-bottom: 12px;
            }

            .footer-content {
                flex-direction: column;
                text-align: center;
            }

            .footer-links {
                flex-wrap: wrap;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header>
        <div class="container">
            <div class="header-content">
                <div style="display: flex; align-items: center; gap: 16px;">
                    <a href="../" class="back-btn">
                        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
                        Kembali
                    </a>
                    <a href="?" class="logo">
                        <div class="logo-icon">🛒</div>
                        <span class="logo-text"><?= STORE_NAME ?></span>
                    </a>
                    <span class="demo-indicator">
                        <span class="demo-indicator-dot"></span>
                        Demo Mode
                    </span>
                </div>
                <nav class="header-nav">
                    <a href="#perbedaan-sdk" class="nav-link">Panduan SDK</a>
                    <a href="#products" class="nav-link">Products</a>
                    <a href="#topup" class="nav-link">Game Top Up</a>
                    <a href="https://wa.me/<?= STORE_WHATSAPP ?>" target="_blank" class="nav-link">Support</a>
                    <a href="../merchant/register.php" class="nav-btn">Daftar Merchant</a>
                </nav>
            </div>
        </div>
    </header>

    <!-- Demo Banner -->
    <div class="demo-banner">
        <div class="container">
            <div class="demo-banner-content">
                <div class="demo-badge">
                    <span class="demo-badge-dot"></span>
                    DEMO SHOWCASE
                </div>
                <span class="demo-text">
                    Ini adalah <strong>DEMO</strong> toko online yang terintegrasi dengan <strong>NEO PGA</strong> Payment Gateway.
                    <a href="../">Klik di sini untuk setup payment gateway serupa</a>
                </span>
            </div>
        </div>
    </div>

    <!-- Tutorial Section -->
    <div style="background: var(--bg-card); border-bottom: 1px solid var(--border); padding: 40px 0;">
        <div class="container">
            <div style="text-align: center; margin-bottom: 32px;">
                <h2 style="font-size: 1.5rem; font-weight: 700; margin-bottom: 8px;">Cara Setup NEO PGA untuk Toko Anda</h2>
                <p style="color: var(--text-secondary);">Ikuti langkah sederhana ini untuk menerima pembayaran otomatis</p>
            </div>

            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 24px;">
                <div style="background: var(--bg-input); border: 1px solid var(--border); border-radius: 16px; padding: 24px;">
                    <div style="width: 48px; height: 48px; background: var(--gradient-primary); border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 1.25rem; font-weight: 800; color: white; margin-bottom: 16px;">1</div>
                    <h3 style="font-size: 1rem; font-weight: 700; margin-bottom: 8px;">Daftar Akun</h3>
                    <p style="color: var(--text-secondary); font-size: 0.9rem; line-height: 1.6;">Kunjungi halaman pendaftaran NEO PGA. Isi nama bisnis, email, dan password. Akun langsung aktif tanpa verifikasi dokumen.</p>
                </div>

                <div style="background: var(--bg-input); border: 1px solid var(--border); border-radius: 16px; padding: 24px;">
                    <div style="width: 48px; height: 48px; background: var(--gradient-primary); border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 1.25rem; font-weight: 800; color: white; margin-bottom: 16px;">2</div>
                    <h3 style="font-size: 1rem; font-weight: 700; margin-bottom: 8px;">Copy API Key</h3>
                    <p style="color: var(--text-secondary); font-size: 0.9rem; line-height: 1.6;">Login ke dashboard, buka menu API Keys. Copy API Key dan Secret Key yang sudah disediakan untuk integrasi.</p>
                </div>

                <div style="background: var(--bg-input); border: 1px solid var(--border); border-radius: 16px; padding: 24px;">
                    <div style="width: 48px; height: 48px; background: var(--gradient-primary); border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 1.25rem; font-weight: 800; color: white; margin-bottom: 16px;">3</div>
                    <h3 style="font-size: 1rem; font-weight: 700; margin-bottom: 8px;">Pasang di Website</h3>
                    <p style="color: var(--text-secondary); font-size: 0.9rem; line-height: 1.6;">Ikuti dokumentasi API untuk integrasi. Atau pilih paket jasa setup Rp 500rb, kami yang kerjakan semua sampai jalan.</p>
                </div>

                <div style="background: var(--bg-input); border: 1px solid var(--border); border-radius: 16px; padding: 24px;">
                    <div style="width: 48px; height: 48px; background: var(--gradient-success); border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 1.25rem; font-weight: 800; color: white; margin-bottom: 16px;">&#10003;</div>
                    <h3 style="font-size: 1rem; font-weight: 700; margin-bottom: 8px;">Selesai!</h3>
                    <p style="color: var(--text-secondary); font-size: 0.9rem; line-height: 1.6;">Customer bayar via QRIS atau Bank Transfer, pembayaran terverifikasi otomatis. Anda tinggal fokus jualan!</p>
                </div>
            </div>

            <div style="text-align: center; margin-top: 32px;">
                <a href="../merchant/register.php" class="btn" style="margin-right: 12px;">Daftar Gratis Sekarang</a>
                <a href="https://wa.me/6289534340757?text=Halo,%20saya%20mau%20tanya%20tentang%20NEO%20PGA" target="_blank" class="btn btn-outline">Chat WhatsApp</a>
            </div>
        </div>
    </div>

    <!-- SDK Comparison Section - Educational -->
    <div style="background: linear-gradient(180deg, var(--bg-card) 0%, var(--bg-dark) 100%); border-bottom: 1px solid var(--border); padding: 60px 0;" id="perbedaan-sdk">
        <div class="container">
            <!-- Section Header -->
            <div style="text-align: center; margin-bottom: 48px;">
                <div style="display: inline-flex; align-items: center; gap: 8px; padding: 8px 20px; background: rgba(16, 185, 129, 0.1); border: 1px solid rgba(16, 185, 129, 0.3); border-radius: 50px; font-size: 0.875rem; font-weight: 600; color: #10b981; margin-bottom: 16px;">
                    <span>📚</span>
                    Panduan Lengkap
                </div>
                <h2 style="font-size: clamp(1.75rem, 4vw, 2.5rem); font-weight: 800; margin-bottom: 16px;">
                    Pilih SDK yang <span style="background: var(--gradient-primary); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;">Sesuai Kebutuhan</span>
                </h2>
                <p style="color: var(--text-secondary); max-width: 700px; margin: 0 auto; font-size: 1.1rem;">
                    NEO PGA menyediakan berbagai pilihan SDK. Baca dengan teliti agar Anda memilih yang TEPAT!
                </p>
            </div>

            <!-- Main Comparison: QRIS Only vs QRIS + Bank -->
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(340px, 1fr)); gap: 32px; margin-bottom: 48px;">

                <!-- QRIS Only Card -->
                <div style="background: var(--bg-card); border: 2px solid rgba(99, 102, 241, 0.3); border-radius: 24px; padding: 32px; position: relative; overflow: hidden;">
                    <div style="position: absolute; top: 0; left: 0; right: 0; height: 4px; background: var(--gradient-primary);"></div>

                    <div style="display: flex; align-items: center; gap: 16px; margin-bottom: 24px;">
                        <div style="width: 64px; height: 64px; background: linear-gradient(135deg, rgba(99, 102, 241, 0.2), rgba(139, 92, 246, 0.1)); border: 2px solid rgba(99, 102, 241, 0.4); border-radius: 16px; display: flex; align-items: center; justify-content: center; font-size: 2rem;">
                            📱
                        </div>
                        <div>
                            <span style="display: inline-block; padding: 4px 12px; background: var(--gradient-primary); color: white; font-size: 0.7rem; font-weight: 700; border-radius: 50px; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px;">POPULER</span>
                            <h3 style="font-size: 1.5rem; font-weight: 800;">QRIS Saja</h3>
                        </div>
                    </div>

                    <p style="color: var(--text-secondary); margin-bottom: 24px; line-height: 1.8;">
                        Pembayaran via <strong style="color: white;">QRIS only</strong>. Customer scan QR pakai e-wallet apapun (GoPay, OVO, DANA, ShopeePay, LinkAja, dll) atau Mobile Banking.
                    </p>

                    <div style="background: var(--bg-input); border-radius: 12px; padding: 16px; margin-bottom: 20px;">
                        <div style="font-size: 0.8rem; color: var(--text-muted); margin-bottom: 8px; text-transform: uppercase; letter-spacing: 0.5px;">Cocok untuk:</div>
                        <ul style="list-style: none; color: var(--text-secondary); font-size: 0.9rem;">
                            <li style="display: flex; align-items: center; gap: 8px; padding: 6px 0;">
                                <span style="color: #10b981;">✓</span> Toko online kecil-menengah
                            </li>
                            <li style="display: flex; align-items: center; gap: 8px; padding: 6px 0;">
                                <span style="color: #10b981;">✓</span> Donasi & deposit manual
                            </li>
                            <li style="display: flex; align-items: center; gap: 8px; padding: 6px 0;">
                                <span style="color: #10b981;">✓</span> Jasa freelance
                            </li>
                            <li style="display: flex; align-items: center; gap: 8px; padding: 6px 0;">
                                <span style="color: #10b981;">✓</span> Top up game
                            </li>
                        </ul>
                    </div>

                    <div style="display: flex; align-items: center; gap: 12px; padding: 16px; background: rgba(16, 185, 129, 0.1); border: 1px solid rgba(16, 185, 129, 0.3); border-radius: 12px;">
                        <span style="font-size: 1.5rem;">💡</span>
                        <span style="font-size: 0.85rem; color: var(--text-secondary);">
                            <strong style="color: #10b981;">Simple & Cepat!</strong><br>
                            Verifikasi otomatis pakai <strong>kode unik</strong> (1-999)
                        </span>
                    </div>
                </div>

                <!-- QRIS + Bank Transfer Card -->
                <div style="background: var(--bg-card); border: 2px solid rgba(236, 72, 153, 0.3); border-radius: 24px; padding: 32px; position: relative; overflow: hidden;">
                    <div style="position: absolute; top: 0; left: 0; right: 0; height: 4px; background: var(--gradient-game);"></div>

                    <div style="display: flex; align-items: center; gap: 16px; margin-bottom: 24px;">
                        <div style="width: 64px; height: 64px; background: linear-gradient(135deg, rgba(236, 72, 153, 0.2), rgba(244, 63, 94, 0.1)); border: 2px solid rgba(236, 72, 153, 0.4); border-radius: 16px; display: flex; align-items: center; justify-content: center; font-size: 2rem;">
                            🏦
                        </div>
                        <div>
                            <span style="display: inline-block; padding: 4px 12px; background: var(--gradient-game); color: white; font-size: 0.7rem; font-weight: 700; border-radius: 50px; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px;">LENGKAP</span>
                            <h3 style="font-size: 1.5rem; font-weight: 800;">QRIS + Bank Transfer</h3>
                        </div>
                    </div>

                    <p style="color: var(--text-secondary); margin-bottom: 24px; line-height: 1.8;">
                        Pembayaran via <strong style="color: white;">QRIS + Bank Transfer</strong>. Customer bisa pilih: scan QRIS ATAU transfer ke Virtual Account bank (BCA, BRI, Mandiri, dll).
                    </p>

                    <div style="background: var(--bg-input); border-radius: 12px; padding: 16px; margin-bottom: 20px;">
                        <div style="font-size: 0.8rem; color: var(--text-muted); margin-bottom: 8px; text-transform: uppercase; letter-spacing: 0.5px;">Cocok untuk:</div>
                        <ul style="list-style: none; color: var(--text-secondary); font-size: 0.9rem;">
                            <li style="display: flex; align-items: center; gap: 8px; padding: 6px 0;">
                                <span style="color: #ec4899;">✓</span> E-commerce besar
                            </li>
                            <li style="display: flex; align-items: center; gap: 8px; padding: 6px 0;">
                                <span style="color: #ec4899;">✓</span> Marketplace
                            </li>
                            <li style="display: flex; align-items: center; gap: 8px; padding: 6px 0;">
                                <span style="color: #ec4899;">✓</span> Transaksi nilai besar
                            </li>
                            <li style="display: flex; align-items: center; gap: 8px; padding: 6px 0;">
                                <span style="color: #ec4899;">✓</span> Corporate / B2B
                            </li>
                        </ul>
                    </div>

                    <div style="display: flex; align-items: center; gap: 12px; padding: 16px; background: rgba(236, 72, 153, 0.1); border: 1px solid rgba(236, 72, 153, 0.3); border-radius: 12px;">
                        <span style="font-size: 1.5rem;">⚡</span>
                        <span style="font-size: 0.85rem; color: var(--text-secondary);">
                            <strong style="color: #ec4899;">Professional!</strong><br>
                            Lebih banyak opsi bayar untuk customer
                        </span>
                    </div>
                </div>
            </div>

            <!-- Visual Comparison Table -->
            <div style="background: var(--bg-card); border: 1px solid var(--border); border-radius: 20px; overflow: hidden; margin-bottom: 48px;">
                <div style="background: var(--bg-input); padding: 20px 24px; border-bottom: 1px solid var(--border);">
                    <h3 style="font-size: 1.1rem; font-weight: 700; display: flex; align-items: center; gap: 8px;">
                        <span>📊</span> Perbandingan Singkat
                    </h3>
                </div>
                <div style="overflow-x: auto;">
                    <table style="width: 100%; border-collapse: collapse; min-width: 500px;">
                        <thead>
                            <tr style="background: var(--bg-input);">
                                <th style="padding: 16px 20px; text-align: left; font-weight: 600; color: var(--text-secondary); font-size: 0.85rem;">FITUR</th>
                                <th style="padding: 16px 20px; text-align: center; font-weight: 600; color: var(--accent-light); font-size: 0.85rem;">QRIS Saja</th>
                                <th style="padding: 16px 20px; text-align: center; font-weight: 600; color: #ec4899; font-size: 0.85rem;">QRIS + Bank</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr style="border-bottom: 1px solid var(--border);">
                                <td style="padding: 16px 20px; color: var(--text-secondary);">Pembayaran QRIS</td>
                                <td style="padding: 16px 20px; text-align: center; color: #10b981; font-size: 1.25rem;">✓</td>
                                <td style="padding: 16px 20px; text-align: center; color: #10b981; font-size: 1.25rem;">✓</td>
                            </tr>
                            <tr style="border-bottom: 1px solid var(--border);">
                                <td style="padding: 16px 20px; color: var(--text-secondary);">Transfer Bank / VA</td>
                                <td style="padding: 16px 20px; text-align: center; color: #ef4444; font-size: 1.25rem;">✗</td>
                                <td style="padding: 16px 20px; text-align: center; color: #10b981; font-size: 1.25rem;">✓</td>
                            </tr>
                            <tr style="border-bottom: 1px solid var(--border);">
                                <td style="padding: 16px 20px; color: var(--text-secondary);">Verifikasi Otomatis</td>
                                <td style="padding: 16px 20px; text-align: center; color: #10b981; font-size: 1.25rem;">✓</td>
                                <td style="padding: 16px 20px; text-align: center; color: #10b981; font-size: 1.25rem;">✓</td>
                            </tr>
                            <tr style="border-bottom: 1px solid var(--border);">
                                <td style="padding: 16px 20px; color: var(--text-secondary);">Kode Unik (1-999)</td>
                                <td style="padding: 16px 20px; text-align: center; color: #10b981; font-size: 1.25rem;">✓</td>
                                <td style="padding: 16px 20px; text-align: center; color: #10b981; font-size: 1.25rem;">✓</td>
                            </tr>
                            <tr>
                                <td style="padding: 16px 20px; color: var(--text-secondary);">Setup Complexity</td>
                                <td style="padding: 16px 20px; text-align: center;"><span style="padding: 4px 12px; background: rgba(16, 185, 129, 0.15); color: #10b981; border-radius: 50px; font-size: 0.8rem; font-weight: 600;">Mudah</span></td>
                                <td style="padding: 16px 20px; text-align: center;"><span style="padding: 4px 12px; background: rgba(245, 158, 11, 0.15); color: #f59e0b; border-radius: 50px; font-size: 0.8rem; font-weight: 600;">Sedang</span></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Form Types Section for QRIS Only -->
            <div style="margin-bottom: 48px;">
                <div style="text-align: center; margin-bottom: 32px;">
                    <h3 style="font-size: 1.5rem; font-weight: 800; margin-bottom: 12px;">
                        🎯 2 Jenis Form untuk <span style="color: var(--accent-light);">QRIS Saja</span>
                    </h3>
                    <p style="color: var(--text-secondary); max-width: 600px; margin: 0 auto;">
                        Untuk SDK QRIS Saja, ada 2 pola form berbeda tergantung kebutuhan bisnis Anda:
                    </p>
                </div>

                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(340px, 1fr)); gap: 32px;">

                    <!-- Form Type 1: Toko Produk (Fixed Price) -->
                    <div style="background: var(--bg-card); border: 1px solid var(--border); border-radius: 20px; overflow: hidden;">
                        <div style="background: linear-gradient(135deg, rgba(16, 185, 129, 0.2), rgba(5, 150, 105, 0.1)); padding: 24px; border-bottom: 1px solid var(--border);">
                            <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 12px;">
                                <span style="font-size: 2rem;">🛍️</span>
                                <div>
                                    <span style="display: inline-block; padding: 4px 10px; background: rgba(16, 185, 129, 0.2); color: #10b981; font-size: 0.7rem; font-weight: 700; border-radius: 50px; text-transform: uppercase;">TYPE 1</span>
                                </div>
                            </div>
                            <h4 style="font-size: 1.25rem; font-weight: 700; margin-bottom: 8px;">Toko Produk / E-commerce</h4>
                            <p style="color: var(--text-secondary); font-size: 0.9rem;">Harga produk sudah FIXED (ditentukan)</p>
                        </div>

                        <div style="padding: 24px;">
                            <div style="background: var(--bg-input); border-radius: 12px; padding: 20px; margin-bottom: 20px;">
                                <div style="font-size: 0.8rem; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 12px;">📋 Alur Pembayaran:</div>
                                <ol style="list-style: decimal inside; color: var(--text-secondary); font-size: 0.9rem; line-height: 2;">
                                    <li>Customer <strong style="color: white;">pilih produk</strong></li>
                                    <li>Klik tombol <strong style="color: white;">"Beli"</strong></li>
                                    <li>Isi form nama, email, WA</li>
                                    <li>Muncul QRIS dengan <strong style="color: #10b981;">harga + kode unik</strong></li>
                                    <li>Customer scan & bayar</li>
                                    <li>Otomatis terverifikasi!</li>
                                </ol>
                            </div>

                            <div style="background: rgba(99, 102, 241, 0.1); border: 1px solid rgba(99, 102, 241, 0.3); border-radius: 12px; padding: 16px;">
                                <div style="font-size: 0.8rem; color: var(--text-muted); margin-bottom: 8px;">Contoh:</div>
                                <div style="display: flex; flex-wrap: wrap; gap: 8px;">
                                    <span style="padding: 6px 12px; background: var(--bg-card); border-radius: 8px; font-size: 0.85rem; color: var(--text-secondary);">Template Website Rp 150.000</span>
                                    <span style="padding: 6px 12px; background: var(--bg-card); border-radius: 8px; font-size: 0.85rem; color: var(--text-secondary);">Ebook Rp 50.000</span>
                                    <span style="padding: 6px 12px; background: var(--bg-card); border-radius: 8px; font-size: 0.85rem; color: var(--text-secondary);">Kursus Online Rp 299.000</span>
                                </div>
                            </div>

                            <div style="margin-top: 16px; padding: 12px; background: rgba(16, 185, 129, 0.1); border-radius: 8px; display: flex; align-items: center; gap: 10px;">
                                <span>👆</span>
                                <span style="font-size: 0.85rem; color: var(--text-secondary);">
                                    <strong style="color: #10b981;">Lihat contoh di bawah!</strong> Section "Digital Products"
                                </span>
                            </div>
                        </div>
                    </div>

                    <!-- Form Type 2: Deposit/Donasi (Manual Input) -->
                    <div style="background: var(--bg-card); border: 1px solid var(--border); border-radius: 20px; overflow: hidden;">
                        <div style="background: linear-gradient(135deg, rgba(236, 72, 153, 0.2), rgba(244, 63, 94, 0.1)); padding: 24px; border-bottom: 1px solid var(--border);">
                            <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 12px;">
                                <span style="font-size: 2rem;">💰</span>
                                <div>
                                    <span style="display: inline-block; padding: 4px 10px; background: rgba(236, 72, 153, 0.2); color: #ec4899; font-size: 0.7rem; font-weight: 700; border-radius: 50px; text-transform: uppercase;">TYPE 2</span>
                                </div>
                            </div>
                            <h4 style="font-size: 1.25rem; font-weight: 700; margin-bottom: 8px;">Deposit / Donasi / Top Up</h4>
                            <p style="color: var(--text-secondary); font-size: 0.9rem;">Customer INPUT SENDIRI nominal yang mau dibayar</p>
                        </div>

                        <div style="padding: 24px;">
                            <div style="background: var(--bg-input); border-radius: 12px; padding: 20px; margin-bottom: 20px;">
                                <div style="font-size: 0.8rem; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 12px;">📋 Alur Pembayaran:</div>
                                <ol style="list-style: decimal inside; color: var(--text-secondary); font-size: 0.9rem; line-height: 2;">
                                    <li>Customer <strong style="color: white;">input nominal</strong> sendiri</li>
                                    <li>Contoh: ketik <strong style="color: white;">Rp 100.000</strong></li>
                                    <li>Isi form nama, email, WA</li>
                                    <li>Muncul QRIS dengan <strong style="color: #ec4899;">nominal + kode unik</strong></li>
                                    <li>Customer scan & bayar</li>
                                    <li>Otomatis terverifikasi!</li>
                                </ol>
                            </div>

                            <div style="background: rgba(236, 72, 153, 0.1); border: 1px solid rgba(236, 72, 153, 0.3); border-radius: 12px; padding: 16px;">
                                <div style="font-size: 0.8rem; color: var(--text-muted); margin-bottom: 8px;">Contoh:</div>
                                <div style="display: flex; flex-wrap: wrap; gap: 8px;">
                                    <span style="padding: 6px 12px; background: var(--bg-card); border-radius: 8px; font-size: 0.85rem; color: var(--text-secondary);">Top Up Game (bebas nominal)</span>
                                    <span style="padding: 6px 12px; background: var(--bg-card); border-radius: 8px; font-size: 0.85rem; color: var(--text-secondary);">Donasi (seikhlasnya)</span>
                                    <span style="padding: 6px 12px; background: var(--bg-card); border-radius: 8px; font-size: 0.85rem; color: var(--text-secondary);">Deposit Saldo</span>
                                </div>
                            </div>

                            <div style="margin-top: 16px; padding: 12px; background: rgba(236, 72, 153, 0.1); border-radius: 8px; display: flex; align-items: center; gap: 10px;">
                                <span>👆</span>
                                <span style="font-size: 0.85rem; color: var(--text-secondary);">
                                    <strong style="color: #ec4899;">Lihat contoh di bawah!</strong> Section "Game Top Up"
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Important Note: Kode Unik -->
            <div style="background: linear-gradient(135deg, rgba(245, 158, 11, 0.15), rgba(234, 88, 12, 0.1)); border: 2px solid rgba(245, 158, 11, 0.3); border-radius: 20px; padding: 32px;">
                <div style="display: flex; align-items: flex-start; gap: 20px; flex-wrap: wrap;">
                    <div style="width: 64px; height: 64px; background: linear-gradient(135deg, #f59e0b, #ea580c); border-radius: 16px; display: flex; align-items: center; justify-content: center; font-size: 2rem; flex-shrink: 0;">
                        🔢
                    </div>
                    <div style="flex: 1; min-width: 280px;">
                        <h4 style="font-size: 1.25rem; font-weight: 800; margin-bottom: 12px; color: #f59e0b;">
                            Apa itu "Kode Unik"?
                        </h4>
                        <p style="color: var(--text-secondary); line-height: 1.8; margin-bottom: 16px;">
                            <strong style="color: white;">Kode unik adalah angka 1-999</strong> yang ditambahkan ke total pembayaran.
                            Contoh: Harga produk <strong style="color: white;">Rp 100.000</strong>, kode unik <strong style="color: #f59e0b;">+123</strong>,
                            maka customer bayar <strong style="color: #10b981;">Rp 100.123</strong>.
                        </p>
                        <div style="display: flex; flex-wrap: wrap; gap: 12px;">
                            <div style="background: rgba(0,0,0,0.2); border-radius: 12px; padding: 16px; flex: 1; min-width: 200px;">
                                <div style="font-size: 0.75rem; color: var(--text-muted); text-transform: uppercase; margin-bottom: 4px;">Fungsi Kode Unik</div>
                                <div style="font-size: 0.9rem; color: var(--text-secondary);">Membedakan setiap transaksi agar sistem bisa <strong style="color: white;">verifikasi otomatis</strong></div>
                            </div>
                            <div style="background: rgba(0,0,0,0.2); border-radius: 12px; padding: 16px; flex: 1; min-width: 200px;">
                                <div style="font-size: 0.75rem; color: var(--text-muted); text-transform: uppercase; margin-bottom: 4px;">Penting!</div>
                                <div style="font-size: 0.9rem; color: var(--text-secondary);">Customer HARUS bayar <strong style="color: #ef4444;">PERSIS</strong> sesuai total (jangan dibulatkan)</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- SDK Package Options: Sudah Punya Form vs Belum -->
            <div style="margin-top: 48px;">
                <div style="text-align: center; margin-bottom: 32px;">
                    <h3 style="font-size: 1.5rem; font-weight: 800; margin-bottom: 12px;">
                        📦 Pilih Paket SDK yang <span style="color: var(--accent-light);">Tepat</span>
                    </h3>
                    <p style="color: var(--text-secondary); max-width: 650px; margin: 0 auto;">
                        Tergantung kondisi website Anda saat ini, pilih paket SDK yang sesuai:
                    </p>
                </div>

                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(340px, 1fr)); gap: 32px;">

                    <!-- Sudah Punya Form -->
                    <div style="background: var(--bg-card); border: 2px solid rgba(34, 197, 94, 0.3); border-radius: 20px; overflow: hidden;">
                        <div style="background: linear-gradient(135deg, rgba(34, 197, 94, 0.2), rgba(22, 163, 74, 0.1)); padding: 24px; border-bottom: 1px solid var(--border);">
                            <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 12px;">
                                <span style="font-size: 2.5rem;">✅</span>
                                <span style="display: inline-block; padding: 6px 14px; background: linear-gradient(135deg, #22c55e, #16a34a); color: white; font-size: 0.75rem; font-weight: 700; border-radius: 50px; text-transform: uppercase;">SDK ONLY</span>
                            </div>
                            <h4 style="font-size: 1.25rem; font-weight: 700; margin-bottom: 8px;">Sudah Punya Form / Website</h4>
                            <p style="color: var(--text-secondary); font-size: 0.9rem;">Website Anda sudah jadi, tinggal tambah fitur pembayaran</p>
                        </div>

                        <div style="padding: 24px;">
                            <!-- Ilustrasi -->
                            <div style="background: var(--bg-input); border-radius: 12px; padding: 20px; margin-bottom: 20px;">
                                <div style="font-size: 0.8rem; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 16px;">🎨 Ilustrasi Kondisi Anda:</div>
                                <div style="background: var(--bg-card); border: 1px dashed rgba(34, 197, 94, 0.5); border-radius: 12px; padding: 16px; text-align: center;">
                                    <div style="font-size: 0.8rem; color: #22c55e; margin-bottom: 8px;">Website Anda Saat Ini</div>
                                    <div style="display: flex; flex-direction: column; gap: 8px;">
                                        <div style="background: rgba(255,255,255,0.1); border-radius: 6px; padding: 8px; font-size: 0.85rem;">📝 Form Checkout (sudah ada)</div>
                                        <div style="background: rgba(255,255,255,0.1); border-radius: 6px; padding: 8px; font-size: 0.85rem;">🛒 Keranjang Belanja (sudah ada)</div>
                                        <div style="background: rgba(239, 68, 68, 0.2); border: 1px dashed #ef4444; border-radius: 6px; padding: 8px; font-size: 0.85rem; color: #fca5a5;">❌ Pembayaran Otomatis (belum ada)</div>
                                    </div>
                                </div>
                            </div>

                            <!-- Yang Anda Dapat -->
                            <div style="background: rgba(34, 197, 94, 0.1); border: 1px solid rgba(34, 197, 94, 0.3); border-radius: 12px; padding: 16px; margin-bottom: 16px;">
                                <div style="font-size: 0.8rem; color: var(--text-muted); margin-bottom: 8px;">📥 Yang Anda Download:</div>
                                <ul style="list-style: none; font-size: 0.9rem; color: var(--text-secondary);">
                                    <li style="padding: 4px 0; display: flex; align-items: center; gap: 8px;">
                                        <span style="color: #22c55e;">✓</span> <code style="background: var(--bg-card); padding: 2px 8px; border-radius: 4px;">NeoPGA.php</code> - Class untuk API
                                    </li>
                                    <li style="padding: 4px 0; display: flex; align-items: center; gap: 8px;">
                                        <span style="color: #22c55e;">✓</span> Dokumentasi integrasi
                                    </li>
                                </ul>
                            </div>

                            <!-- Yang Perlu Dilakukan -->
                            <div style="background: var(--bg-input); border-radius: 12px; padding: 16px;">
                                <div style="font-size: 0.8rem; color: var(--text-muted); margin-bottom: 8px;">🔧 Yang Perlu Anda Lakukan:</div>
                                <ol style="list-style: decimal inside; font-size: 0.85rem; color: var(--text-secondary); line-height: 1.8;">
                                    <li>Include <code style="background: var(--bg-card); padding: 2px 6px; border-radius: 4px;">NeoPGA.php</code> ke project</li>
                                    <li>Panggil API di form checkout Anda</li>
                                    <li>Tampilkan QRIS ke customer</li>
                                    <li>Setup webhook untuk notifikasi</li>
                                </ol>
                            </div>

                            <div style="margin-top: 16px; padding: 12px; background: rgba(34, 197, 94, 0.1); border-radius: 8px; text-align: center;">
                                <span style="font-size: 0.85rem; color: var(--text-secondary);">
                                    <strong style="color: #22c55e;">Cocok untuk:</strong> Developer / yang paham coding
                                </span>
                            </div>
                        </div>
                    </div>

                    <!-- Belum Punya Form -->
                    <div style="background: var(--bg-card); border: 2px solid rgba(168, 85, 247, 0.3); border-radius: 20px; overflow: hidden;">
                        <div style="background: linear-gradient(135deg, rgba(168, 85, 247, 0.2), rgba(139, 92, 246, 0.1)); padding: 24px; border-bottom: 1px solid var(--border);">
                            <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 12px;">
                                <span style="font-size: 2.5rem;">📄</span>
                                <span style="display: inline-block; padding: 6px 14px; background: linear-gradient(135deg, #a855f7, #8b5cf6); color: white; font-size: 0.75rem; font-weight: 700; border-radius: 50px; text-transform: uppercase;">SDK + TEMPLATE</span>
                            </div>
                            <h4 style="font-size: 1.25rem; font-weight: 700; margin-bottom: 8px;">Belum Punya Form / Website Baru</h4>
                            <p style="color: var(--text-secondary); font-size: 0.9rem;">Anda butuh form pembayaran + sistem pembayarannya sekaligus</p>
                        </div>

                        <div style="padding: 24px;">
                            <!-- Ilustrasi -->
                            <div style="background: var(--bg-input); border-radius: 12px; padding: 20px; margin-bottom: 20px;">
                                <div style="font-size: 0.8rem; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 16px;">🎨 Ilustrasi Kondisi Anda:</div>
                                <div style="background: var(--bg-card); border: 1px dashed rgba(168, 85, 247, 0.5); border-radius: 12px; padding: 16px; text-align: center;">
                                    <div style="font-size: 0.8rem; color: #a855f7; margin-bottom: 8px;">Website Anda Saat Ini</div>
                                    <div style="display: flex; flex-direction: column; gap: 8px;">
                                        <div style="background: rgba(239, 68, 68, 0.2); border: 1px dashed #ef4444; border-radius: 6px; padding: 8px; font-size: 0.85rem; color: #fca5a5;">❌ Form Checkout (belum ada)</div>
                                        <div style="background: rgba(239, 68, 68, 0.2); border: 1px dashed #ef4444; border-radius: 6px; padding: 8px; font-size: 0.85rem; color: #fca5a5;">❌ Halaman Pembayaran (belum ada)</div>
                                        <div style="background: rgba(239, 68, 68, 0.2); border: 1px dashed #ef4444; border-radius: 6px; padding: 8px; font-size: 0.85rem; color: #fca5a5;">❌ Pembayaran Otomatis (belum ada)</div>
                                    </div>
                                </div>
                            </div>

                            <!-- Yang Anda Dapat -->
                            <div style="background: rgba(168, 85, 247, 0.1); border: 1px solid rgba(168, 85, 247, 0.3); border-radius: 12px; padding: 16px; margin-bottom: 16px;">
                                <div style="font-size: 0.8rem; color: var(--text-muted); margin-bottom: 8px;">📥 Yang Anda Download:</div>
                                <ul style="list-style: none; font-size: 0.9rem; color: var(--text-secondary);">
                                    <li style="padding: 4px 0; display: flex; align-items: center; gap: 8px;">
                                        <span style="color: #a855f7;">✓</span> <code style="background: var(--bg-card); padding: 2px 8px; border-radius: 4px;">NeoPGA.php</code> - Class untuk API
                                    </li>
                                    <li style="padding: 4px 0; display: flex; align-items: center; gap: 8px;">
                                        <span style="color: #a855f7;">✓</span> <code style="background: var(--bg-card); padding: 2px 8px; border-radius: 4px;">form.php</code> - Form checkout siap pakai
                                    </li>
                                    <li style="padding: 4px 0; display: flex; align-items: center; gap: 8px;">
                                        <span style="color: #a855f7;">✓</span> <code style="background: var(--bg-card); padding: 2px 8px; border-radius: 4px;">payment.php</code> - Halaman QRIS
                                    </li>
                                    <li style="padding: 4px 0; display: flex; align-items: center; gap: 8px;">
                                        <span style="color: #a855f7;">✓</span> <code style="background: var(--bg-card); padding: 2px 8px; border-radius: 4px;">webhook.php</code> - Handler notifikasi
                                    </li>
                                    <li style="padding: 4px 0; display: flex; align-items: center; gap: 8px;">
                                        <span style="color: #a855f7;">✓</span> CSS styling modern
                                    </li>
                                </ul>
                            </div>

                            <!-- Yang Perlu Dilakukan -->
                            <div style="background: var(--bg-input); border-radius: 12px; padding: 16px;">
                                <div style="font-size: 0.8rem; color: var(--text-muted); margin-bottom: 8px;">🔧 Yang Perlu Anda Lakukan:</div>
                                <ol style="list-style: decimal inside; font-size: 0.85rem; color: var(--text-secondary); line-height: 1.8;">
                                    <li>Upload semua file ke hosting</li>
                                    <li>Edit <code style="background: var(--bg-card); padding: 2px 6px; border-radius: 4px;">config.php</code> (API Key)</li>
                                    <li>Selesai! Langsung bisa dipakai</li>
                                </ol>
                            </div>

                            <div style="margin-top: 16px; padding: 12px; background: rgba(168, 85, 247, 0.1); border-radius: 8px; text-align: center;">
                                <span style="font-size: 0.85rem; color: var(--text-secondary);">
                                    <strong style="color: #a855f7;">Cocok untuk:</strong> Pemula / yang tidak paham coding
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Visual: Perbedaan Hasil -->
                <div style="background: var(--bg-card); border: 1px solid var(--border); border-radius: 20px; padding: 24px; margin-top: 32px;">
                    <h4 style="font-size: 1.1rem; font-weight: 700; margin-bottom: 20px; text-align: center;">
                        🔍 Ringkasan Perbedaan
                    </h4>
                    <div style="overflow-x: auto;">
                        <table style="width: 100%; border-collapse: collapse; min-width: 500px;">
                            <thead>
                                <tr style="background: var(--bg-input);">
                                    <th style="padding: 14px 16px; text-align: left; font-weight: 600; color: var(--text-secondary); font-size: 0.85rem; border-radius: 8px 0 0 0;">ASPEK</th>
                                    <th style="padding: 14px 16px; text-align: center; font-weight: 600; color: #22c55e; font-size: 0.85rem;">SDK ONLY</th>
                                    <th style="padding: 14px 16px; text-align: center; font-weight: 600; color: #a855f7; font-size: 0.85rem; border-radius: 0 8px 0 0;">SDK + TEMPLATE</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr style="border-bottom: 1px solid var(--border);">
                                    <td style="padding: 14px 16px; color: var(--text-secondary);">Kondisi Awal</td>
                                    <td style="padding: 14px 16px; text-align: center; font-size: 0.9rem;">Sudah punya form/website</td>
                                    <td style="padding: 14px 16px; text-align: center; font-size: 0.9rem;">Belum punya form</td>
                                </tr>
                                <tr style="border-bottom: 1px solid var(--border);">
                                    <td style="padding: 14px 16px; color: var(--text-secondary);">Yang Didapat</td>
                                    <td style="padding: 14px 16px; text-align: center; font-size: 0.9rem;">Class PHP + Docs</td>
                                    <td style="padding: 14px 16px; text-align: center; font-size: 0.9rem;">Class PHP + Form + UI</td>
                                </tr>
                                <tr style="border-bottom: 1px solid var(--border);">
                                    <td style="padding: 14px 16px; color: var(--text-secondary);">Skill Dibutuhkan</td>
                                    <td style="padding: 14px 16px; text-align: center;"><span style="padding: 4px 12px; background: rgba(245, 158, 11, 0.15); color: #f59e0b; border-radius: 50px; font-size: 0.8rem; font-weight: 600;">Paham Coding</span></td>
                                    <td style="padding: 14px 16px; text-align: center;"><span style="padding: 4px 12px; background: rgba(16, 185, 129, 0.15); color: #10b981; border-radius: 50px; font-size: 0.8rem; font-weight: 600;">Pemula OK</span></td>
                                </tr>
                                <tr>
                                    <td style="padding: 14px 16px; color: var(--text-secondary);">Waktu Setup</td>
                                    <td style="padding: 14px 16px; text-align: center; font-size: 0.9rem;">Tergantung skill</td>
                                    <td style="padding: 14px 16px; text-align: center; font-size: 0.9rem;">5-10 menit</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- CTA -->
            <div style="text-align: center; margin-top: 48px;">
                <p style="color: var(--text-secondary); margin-bottom: 20px;">Sudah paham? Sekarang coba lihat contoh implementasi di bawah ini 👇</p>
                <div style="display: flex; gap: 16px; justify-content: center; flex-wrap: wrap;">
                    <a href="#products" class="btn" style="background: var(--gradient-primary);">
                        <span>🛍️</span> Lihat Contoh Toko Produk
                    </a>
                    <a href="#topup" class="btn" style="background: var(--gradient-game);">
                        <span>🎮</span> Lihat Contoh Top Up
                    </a>
                </div>
            </div>

            <!-- SDK Package Live Demo Section -->
            <div style="margin-top: 64px; padding-top: 48px; border-top: 1px solid var(--border);">
                <div style="text-align: center; margin-bottom: 40px;">
                    <div style="display: inline-flex; align-items: center; gap: 8px; padding: 8px 20px; background: rgba(168, 85, 247, 0.1); border: 1px solid rgba(168, 85, 247, 0.3); border-radius: 50px; font-size: 0.875rem; font-weight: 600; color: #a855f7; margin-bottom: 16px;">
                        <span>🎮</span>
                        Interactive Demo
                    </div>
                    <h3 style="font-size: 1.5rem; font-weight: 800; margin-bottom: 12px;">
                        Coba Sendiri: <span style="color: var(--accent-light);">SDK Only vs SDK + Template</span>
                    </h3>
                    <p style="color: var(--text-secondary); max-width: 650px; margin: 0 auto;">
                        Rasakan perbedaan alur pembayaran antara merchant yang sudah punya form vs yang pakai template NEO PGA
                    </p>
                </div>

                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(380px, 1fr)); gap: 32px;">

                    <!-- SDK + Template Demo -->
                    <div style="background: var(--bg-card); border: 2px solid rgba(168, 85, 247, 0.3); border-radius: 24px; overflow: hidden;" id="demo-sdk-template">
                        <!-- Header -->
                        <div style="background: linear-gradient(135deg, rgba(168, 85, 247, 0.2), rgba(139, 92, 246, 0.1)); padding: 20px; border-bottom: 1px solid var(--border);">
                            <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 12px;">
                                <div style="display: flex; align-items: center; gap: 12px;">
                                    <span style="font-size: 2rem;">📄</span>
                                    <div>
                                        <span style="display: inline-block; padding: 4px 12px; background: linear-gradient(135deg, #a855f7, #8b5cf6); color: white; font-size: 0.7rem; font-weight: 700; border-radius: 50px; text-transform: uppercase;">SDK + TEMPLATE</span>
                                        <div style="font-size: 0.85rem; color: var(--text-secondary); margin-top: 4px;">Belum punya form</div>
                                    </div>
                                </div>
                                <span style="padding: 6px 12px; background: rgba(168, 85, 247, 0.2); color: #a855f7; font-size: 0.75rem; font-weight: 600; border-radius: 50px; animation: pulse 2s infinite;">🔴 LIVE DEMO</span>
                            </div>
                        </div>

                        <!-- Demo Content -->
                        <div style="padding: 24px;">
                            <div style="background: rgba(168, 85, 247, 0.1); border: 1px solid rgba(168, 85, 247, 0.2); border-radius: 12px; padding: 16px; margin-bottom: 20px;">
                                <div style="font-size: 0.8rem; color: #a855f7; font-weight: 600; margin-bottom: 8px;">📋 Skenario:</div>
                                <p style="font-size: 0.85rem; color: var(--text-secondary); line-height: 1.6;">
                                    Anda adalah merchant yang <strong style="color: white;">belum punya form</strong>.
                                    Form di bawah ini adalah <strong style="color: #a855f7;">dari template NEO PGA</strong>.
                                    Isi form → klik bayar → muncul QRIS.
                                </p>
                            </div>

                            <!-- Simulated Form from NEO PGA Template -->
                            <div style="background: var(--bg-input); border: 1px dashed rgba(168, 85, 247, 0.4); border-radius: 16px; padding: 20px;">
                                <div style="text-align: center; margin-bottom: 16px;">
                                    <span style="font-size: 0.7rem; color: #a855f7; background: rgba(168, 85, 247, 0.2); padding: 4px 10px; border-radius: 50px;">📄 FORM DARI NEO PGA TEMPLATE</span>
                                </div>

                                <form id="demoFormTemplate" style="display: flex; flex-direction: column; gap: 12px;">
                                    <div>
                                        <label style="font-size: 0.8rem; color: var(--text-secondary); display: block; margin-bottom: 6px;">Nama Lengkap</label>
                                        <input type="text" placeholder="John Doe" style="width: 100%; padding: 12px 14px; background: var(--bg-card); border: 1px solid var(--border); border-radius: 10px; color: white; font-size: 0.9rem;" required>
                                    </div>
                                    <div>
                                        <label style="font-size: 0.8rem; color: var(--text-secondary); display: block; margin-bottom: 6px;">Email</label>
                                        <input type="email" placeholder="john@example.com" style="width: 100%; padding: 12px 14px; background: var(--bg-card); border: 1px solid var(--border); border-radius: 10px; color: white; font-size: 0.9rem;" required>
                                    </div>
                                    <div>
                                        <label style="font-size: 0.8rem; color: var(--text-secondary); display: block; margin-bottom: 6px;">Nominal Pembayaran</label>
                                        <input type="text" placeholder="100.000" id="demoAmountTemplate" style="width: 100%; padding: 12px 14px; background: var(--bg-card); border: 1px solid var(--border); border-radius: 10px; color: white; font-size: 0.9rem; text-align: center; font-weight: 600;" required>
                                    </div>
                                    <button type="button" onclick="showDemoQRIS('template')" style="width: 100%; padding: 14px; background: linear-gradient(135deg, #a855f7, #8b5cf6); color: white; border: none; border-radius: 12px; font-size: 0.95rem; font-weight: 600; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 8px; margin-top: 8px;">
                                        <span>📱</span> Bayar dengan QRIS
                                    </button>
                                </form>
                            </div>

                            <!-- Flow Indicator -->
                            <div style="display: flex; align-items: center; justify-content: center; gap: 8px; margin-top: 16px; color: var(--text-muted); font-size: 0.8rem;">
                                <span style="padding: 4px 10px; background: var(--bg-input); border-radius: 6px;">Form NEO PGA</span>
                                <span>→</span>
                                <span style="padding: 4px 10px; background: var(--bg-input); border-radius: 6px;">QRIS</span>
                                <span>→</span>
                                <span style="padding: 4px 10px; background: var(--bg-input); border-radius: 6px;">Bayar</span>
                            </div>
                        </div>
                    </div>

                    <!-- SDK Only Demo -->
                    <div style="background: var(--bg-card); border: 2px solid rgba(34, 197, 94, 0.3); border-radius: 24px; overflow: hidden;" id="demo-sdk-only">
                        <!-- Header -->
                        <div style="background: linear-gradient(135deg, rgba(34, 197, 94, 0.2), rgba(22, 163, 74, 0.1)); padding: 20px; border-bottom: 1px solid var(--border);">
                            <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 12px;">
                                <div style="display: flex; align-items: center; gap: 12px;">
                                    <span style="font-size: 2rem;">✅</span>
                                    <div>
                                        <span style="display: inline-block; padding: 4px 12px; background: linear-gradient(135deg, #22c55e, #16a34a); color: white; font-size: 0.7rem; font-weight: 700; border-radius: 50px; text-transform: uppercase;">SDK ONLY</span>
                                        <div style="font-size: 0.85rem; color: var(--text-secondary); margin-top: 4px;">Sudah punya form sendiri</div>
                                    </div>
                                </div>
                                <span style="padding: 6px 12px; background: rgba(34, 197, 94, 0.2); color: #22c55e; font-size: 0.75rem; font-weight: 600; border-radius: 50px; animation: pulse 2s infinite;">🔴 LIVE DEMO</span>
                            </div>
                        </div>

                        <!-- Demo Content -->
                        <div style="padding: 24px;">
                            <div style="background: rgba(34, 197, 94, 0.1); border: 1px solid rgba(34, 197, 94, 0.2); border-radius: 12px; padding: 16px; margin-bottom: 20px;">
                                <div style="font-size: 0.8rem; color: #22c55e; font-weight: 600; margin-bottom: 8px;">📋 Skenario:</div>
                                <p style="font-size: 0.85rem; color: var(--text-secondary); line-height: 1.6;">
                                    Anda adalah merchant yang <strong style="color: white;">sudah punya form sendiri</strong>.
                                    Form Anda sudah proses data customer. Tinggal panggil API NEO PGA untuk <strong style="color: #22c55e;">langsung tampilkan QRIS</strong>.
                                </p>
                            </div>

                            <!-- Simulated: Merchant's Own Form (Already Processed) -->
                            <div style="background: var(--bg-input); border: 1px dashed rgba(34, 197, 94, 0.4); border-radius: 16px; padding: 20px;">
                                <div style="text-align: center; margin-bottom: 16px;">
                                    <span style="font-size: 0.7rem; color: #22c55e; background: rgba(34, 197, 94, 0.2); padding: 4px 10px; border-radius: 50px;">✅ FORM MILIK MERCHANT (SUDAH DIPROSES)</span>
                                </div>

                                <!-- Show that form is already filled/processed -->
                                <div style="background: var(--bg-card); border: 1px solid var(--border); border-radius: 12px; padding: 16px; margin-bottom: 16px;">
                                    <div style="font-size: 0.75rem; color: var(--text-muted); margin-bottom: 12px; text-transform: uppercase;">Data dari Form Anda:</div>
                                    <div style="display: flex; flex-direction: column; gap: 8px; font-size: 0.85rem;">
                                        <div style="display: flex; justify-content: space-between; padding: 8px 12px; background: var(--bg-input); border-radius: 8px;">
                                            <span style="color: var(--text-secondary);">Nama:</span>
                                            <span style="color: white; font-weight: 500;">Ahmad Merchant</span>
                                        </div>
                                        <div style="display: flex; justify-content: space-between; padding: 8px 12px; background: var(--bg-input); border-radius: 8px;">
                                            <span style="color: var(--text-secondary);">Email:</span>
                                            <span style="color: white; font-weight: 500;">ahmad@toko.com</span>
                                        </div>
                                        <div style="display: flex; justify-content: space-between; padding: 8px 12px; background: var(--bg-input); border-radius: 8px;">
                                            <span style="color: var(--text-secondary);">Produk:</span>
                                            <span style="color: white; font-weight: 500;">Paket Premium</span>
                                        </div>
                                        <div style="display: flex; justify-content: space-between; padding: 8px 12px; background: rgba(34, 197, 94, 0.1); border: 1px solid rgba(34, 197, 94, 0.3); border-radius: 8px;">
                                            <span style="color: var(--text-secondary);">Total:</span>
                                            <span style="color: #22c55e; font-weight: 700;">Rp 250.000</span>
                                        </div>
                                    </div>
                                </div>

                                <!-- Direct to QRIS Button -->
                                <div style="text-align: center; padding: 12px; background: rgba(34, 197, 94, 0.05); border-radius: 12px; margin-bottom: 16px;">
                                    <div style="font-size: 0.75rem; color: var(--text-muted); margin-bottom: 8px;">Data sudah diproses form Anda, tinggal:</div>
                                    <code style="background: var(--bg-card); padding: 8px 12px; border-radius: 6px; font-size: 0.8rem; color: #22c55e;">$neoPGA->createPayment($data);</code>
                                </div>

                                <button type="button" onclick="showDemoQRIS('sdkonly')" style="width: 100%; padding: 14px; background: linear-gradient(135deg, #22c55e, #16a34a); color: white; border: none; border-radius: 12px; font-size: 0.95rem; font-weight: 600; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 8px;">
                                    <span>⚡</span> Langsung Tampilkan QRIS
                                </button>
                            </div>

                            <!-- Flow Indicator -->
                            <div style="display: flex; align-items: center; justify-content: center; gap: 8px; margin-top: 16px; color: var(--text-muted); font-size: 0.8rem;">
                                <span style="padding: 4px 10px; background: rgba(34, 197, 94, 0.1); border: 1px solid rgba(34, 197, 94, 0.3); border-radius: 6px; color: #22c55e;">Form Anda ✓</span>
                                <span>→</span>
                                <span style="padding: 4px 10px; background: var(--bg-input); border-radius: 6px;">API Call</span>
                                <span>→</span>
                                <span style="padding: 4px 10px; background: var(--bg-input); border-radius: 6px;">QRIS</span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Key Difference Highlight -->
                <div style="background: linear-gradient(135deg, rgba(99, 102, 241, 0.1), rgba(139, 92, 246, 0.05)); border: 1px solid rgba(99, 102, 241, 0.2); border-radius: 16px; padding: 24px; margin-top: 32px; text-align: center;">
                    <h4 style="font-size: 1.1rem; font-weight: 700; margin-bottom: 16px;">🎯 Perbedaan Utama</h4>
                    <div style="display: flex; justify-content: center; gap: 32px; flex-wrap: wrap;">
                        <div style="text-align: center;">
                            <div style="font-size: 2rem; margin-bottom: 8px;">📄</div>
                            <div style="font-size: 0.85rem; color: #a855f7; font-weight: 600;">SDK + Template</div>
                            <div style="font-size: 0.8rem; color: var(--text-secondary);">Form dari NEO PGA</div>
                        </div>
                        <div style="display: flex; align-items: center; font-size: 1.5rem; color: var(--text-muted);">vs</div>
                        <div style="text-align: center;">
                            <div style="font-size: 2rem; margin-bottom: 8px;">✅</div>
                            <div style="font-size: 0.85rem; color: #22c55e; font-weight: 600;">SDK Only</div>
                            <div style="font-size: 0.8rem; color: var(--text-secondary);">Form milik Anda sendiri</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Demo QRIS Modal -->
    <div class="modal-overlay" id="demoQrisModal">
        <div class="modal" style="max-width: 420px;">
            <div class="modal-header">
                <h2 class="modal-title">📱 <span id="demoQrisTitle">Demo QRIS</span></h2>
                <button class="modal-close" onclick="closeDemoQris()">&times;</button>
            </div>
            <div class="modal-body">
                <!-- Source Indicator -->
                <div id="demoQrisSource" style="text-align: center; margin-bottom: 20px;"></div>

                <!-- Demo QR Code -->
                <div style="text-align: center;">
                    <div style="background: white; border-radius: 20px; padding: 24px; display: inline-block; margin-bottom: 20px;">
                        <svg width="180" height="180" viewBox="0 0 180 180" style="display: block;">
                            <!-- Simplified QR Code Pattern -->
                            <rect fill="#000" x="10" y="10" width="40" height="40"/>
                            <rect fill="#fff" x="18" y="18" width="24" height="24"/>
                            <rect fill="#000" x="22" y="22" width="16" height="16"/>

                            <rect fill="#000" x="130" y="10" width="40" height="40"/>
                            <rect fill="#fff" x="138" y="18" width="24" height="24"/>
                            <rect fill="#000" x="142" y="22" width="16" height="16"/>

                            <rect fill="#000" x="10" y="130" width="40" height="40"/>
                            <rect fill="#fff" x="18" y="138" width="24" height="24"/>
                            <rect fill="#000" x="22" y="142" width="16" height="16"/>

                            <!-- Random pattern -->
                            <rect fill="#000" x="60" y="10" width="10" height="10"/>
                            <rect fill="#000" x="80" y="10" width="10" height="10"/>
                            <rect fill="#000" x="100" y="10" width="10" height="10"/>
                            <rect fill="#000" x="60" y="30" width="10" height="10"/>
                            <rect fill="#000" x="90" y="30" width="10" height="10"/>
                            <rect fill="#000" x="110" y="30" width="10" height="10"/>

                            <rect fill="#000" x="10" y="60" width="10" height="10"/>
                            <rect fill="#000" x="30" y="60" width="10" height="10"/>
                            <rect fill="#000" x="10" y="80" width="10" height="10"/>
                            <rect fill="#000" x="40" y="80" width="10" height="10"/>
                            <rect fill="#000" x="10" y="100" width="10" height="10"/>
                            <rect fill="#000" x="30" y="100" width="10" height="10"/>

                            <rect fill="#000" x="60" y="60" width="60" height="60" rx="8"/>
                            <rect fill="#fff" x="70" y="70" width="40" height="40" rx="4"/>
                            <text x="90" y="95" font-size="12" font-weight="bold" fill="#6366f1" text-anchor="middle">DEMO</text>

                            <rect fill="#000" x="130" y="60" width="10" height="10"/>
                            <rect fill="#000" x="150" y="60" width="10" height="10"/>
                            <rect fill="#000" x="160" y="80" width="10" height="10"/>
                            <rect fill="#000" x="130" y="100" width="10" height="10"/>
                            <rect fill="#000" x="150" y="100" width="10" height="10"/>

                            <rect fill="#000" x="60" y="130" width="10" height="10"/>
                            <rect fill="#000" x="80" y="130" width="10" height="10"/>
                            <rect fill="#000" x="100" y="130" width="10" height="10"/>
                            <rect fill="#000" x="60" y="150" width="10" height="10"/>
                            <rect fill="#000" x="90" y="150" width="10" height="10"/>
                            <rect fill="#000" x="110" y="150" width="10" height="10"/>
                            <rect fill="#000" x="70" y="160" width="10" height="10"/>
                            <rect fill="#000" x="100" y="160" width="10" height="10"/>

                            <rect fill="#000" x="130" y="130" width="10" height="10"/>
                            <rect fill="#000" x="150" y="140" width="10" height="10"/>
                            <rect fill="#000" x="160" y="150" width="10" height="10"/>
                            <rect fill="#000" x="140" y="160" width="10" height="10"/>
                        </svg>
                    </div>
                </div>

                <!-- Payment Details -->
                <div style="background: var(--bg-input); border-radius: 12px; padding: 16px; margin-bottom: 16px;">
                    <div style="display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px dashed var(--border);">
                        <span style="color: var(--text-secondary);">Harga</span>
                        <span id="demoQrisAmount">Rp 100.000</span>
                    </div>
                    <div style="display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px dashed var(--border);">
                        <span style="color: var(--text-secondary);">Kode Unik</span>
                        <span style="color: var(--accent-light);" id="demoQrisUnique">+247</span>
                    </div>
                    <div style="display: flex; justify-content: space-between; padding: 8px 0;">
                        <span style="font-weight: 600;">TOTAL BAYAR</span>
                        <span style="font-size: 1.25rem; font-weight: 800; color: var(--success);" id="demoQrisTotal">Rp 100.247</span>
                    </div>
                </div>

                <!-- Warning -->
                <div style="background: rgba(245, 158, 11, 0.1); border: 1px solid rgba(245, 158, 11, 0.3); border-radius: 12px; padding: 16px; text-align: center;">
                    <div style="font-size: 0.85rem; color: var(--text-secondary);">
                        <strong style="color: #f59e0b;">⚠️ INI DEMO!</strong><br>
                        QR Code ini tidak berfungsi untuk pembayaran nyata
                    </div>
                </div>

                <!-- Apps -->
                <div style="display: flex; justify-content: center; gap: 8px; margin-top: 16px; flex-wrap: wrap;">
                    <span style="padding: 6px 12px; background: var(--bg-input); border-radius: 50px; font-size: 0.75rem; color: var(--text-secondary);">GoPay</span>
                    <span style="padding: 6px 12px; background: var(--bg-input); border-radius: 50px; font-size: 0.75rem; color: var(--text-secondary);">OVO</span>
                    <span style="padding: 6px 12px; background: var(--bg-input); border-radius: 50px; font-size: 0.75rem; color: var(--text-secondary);">DANA</span>
                    <span style="padding: 6px 12px; background: var(--bg-input); border-radius: 50px; font-size: 0.75rem; color: var(--text-secondary);">ShopeePay</span>
                </div>
            </div>
        </div>
    </div>

    <!-- Hero -->
    <section class="hero">
        <div class="container">
            <div class="hero-content">
                <div class="hero-badge">
                    <span>🚀</span>
                    Digital Products & Game Top Up
                </div>
                <h1 class="hero-title">
                    Produk Digital <span>Premium</span><br>
                    Instant Delivery
                </h1>
                <p class="hero-desc">
                    Template, source code, UI kit, dan layanan top up game terpercaya.
                    Pembayaran aman via QRIS dengan verifikasi otomatis!
                </p>
                <div class="hero-stats">
                    <div class="hero-stat">
                        <div class="hero-stat-value">500+</div>
                        <div class="hero-stat-label">Produk Terjual</div>
                    </div>
                    <div class="hero-stat">
                        <div class="hero-stat-value">100%</div>
                        <div class="hero-stat-label">Instant Delivery</div>
                    </div>
                    <div class="hero-stat">
                        <div class="hero-stat-value">24/7</div>
                        <div class="hero-stat-label">Auto Process</div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <main>
        <div class="container">
            <!-- Digital Products Section -->
            <?php if (!empty($digitalProducts)): ?>
            <section class="section" id="products">
                <!-- TYPE 1 Indicator -->
                <div style="background: linear-gradient(135deg, rgba(16, 185, 129, 0.15), rgba(5, 150, 105, 0.1)); border: 2px solid rgba(16, 185, 129, 0.3); border-radius: 16px; padding: 20px; margin-bottom: 24px;">
                    <div style="display: flex; align-items: center; gap: 16px; flex-wrap: wrap;">
                        <span style="display: inline-flex; align-items: center; gap: 8px; padding: 8px 16px; background: linear-gradient(135deg, #10b981, #059669); color: white; font-size: 0.8rem; font-weight: 700; border-radius: 50px; text-transform: uppercase; letter-spacing: 0.5px;">
                            <span>🛍️</span> TYPE 1 - CONTOH LIVE
                        </span>
                        <div style="flex: 1; min-width: 200px;">
                            <div style="font-weight: 700; color: #10b981; margin-bottom: 4px;">Toko Produk (Harga Fixed)</div>
                            <div style="font-size: 0.85rem; color: var(--text-secondary);">
                                Customer <strong style="color: white;">pilih produk</strong> → harga sudah ditentukan → bayar dengan QRIS
                            </div>
                        </div>
                    </div>
                </div>

                <div class="section-header">
                    <div>
                        <h2 class="section-title">
                            <span class="section-title-icon">🛍️</span>
                            Digital Products
                        </h2>
                        <p class="section-subtitle">Template, source code, dan aset digital premium</p>
                    </div>
                </div>

                <div class="products-grid">
                    <?php foreach ($digitalProducts as $id => $product): ?>
                    <div class="product-card">
                        <div class="product-header">
                            <div class="product-icon"><?= $product['icon'] ?></div>
                            <?php if (!empty($product['badge'])): ?>
                            <span class="product-badge"><?= $product['badge'] ?></span>
                            <?php endif; ?>
                        </div>
                        <h3 class="product-name"><?= htmlspecialchars($product['name']) ?></h3>
                        <p class="product-desc"><?= htmlspecialchars($product['description']) ?></p>
                        <div class="product-footer">
                            <div class="product-price"><?= formatRupiah($product['price']) ?></div>
                            <button class="btn btn-sm" onclick="openCheckout('<?= $id ?>', '<?= htmlspecialchars($product['name']) ?>', <?= $product['price'] ?>, 'digital')">
                                Beli Sekarang
                            </button>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </section>
            <?php endif; ?>

            <!-- Top Up Game Section -->
            <?php if (!empty($topupProducts)): ?>
            <section class="section" id="topup">
                <!-- TYPE 2 Indicator -->
                <div style="background: linear-gradient(135deg, rgba(236, 72, 153, 0.15), rgba(244, 63, 94, 0.1)); border: 2px solid rgba(236, 72, 153, 0.3); border-radius: 16px; padding: 20px; margin-bottom: 24px;">
                    <div style="display: flex; align-items: center; gap: 16px; flex-wrap: wrap;">
                        <span style="display: inline-flex; align-items: center; gap: 8px; padding: 8px 16px; background: linear-gradient(135deg, #ec4899, #f43f5e); color: white; font-size: 0.8rem; font-weight: 700; border-radius: 50px; text-transform: uppercase; letter-spacing: 0.5px;">
                            <span>💰</span> TYPE 2 - CONTOH LIVE
                        </span>
                        <div style="flex: 1; min-width: 200px;">
                            <div style="font-weight: 700; color: #ec4899; margin-bottom: 4px;">Deposit / Donasi / Top Up (Input Manual)</div>
                            <div style="font-size: 0.85rem; color: var(--text-secondary);">
                                Customer <strong style="color: white;">input nominal sendiri</strong> → bebas mau bayar berapa → bayar dengan QRIS
                            </div>
                        </div>
                    </div>
                </div>

                <div class="section-header">
                    <div>
                        <h2 class="section-title">
                            <span class="section-title-icon">🎮</span>
                            Game Top Up
                        </h2>
                        <p class="section-subtitle">Top up diamond & UC untuk game favoritmu</p>
                    </div>
                </div>

                <div class="products-grid">
                    <?php foreach ($topupProducts as $id => $product): ?>
                    <div class="product-card game">
                        <div class="product-header">
                            <div class="product-icon"><?= $product['icon'] ?></div>
                            <span class="product-badge topup"><?= $product['badge'] ?></span>
                        </div>
                        <h3 class="product-name"><?= htmlspecialchars($product['name']) ?></h3>
                        <p class="product-desc"><?= htmlspecialchars($product['description']) ?></p>
                        <div class="product-footer">
                            <div class="product-price manual">Min. <?= formatRupiah($product['min_amount'] ?? 5000) ?></div>
                            <button class="btn btn-sm game" onclick="openCheckout('<?= $id ?>', '<?= htmlspecialchars($product['name']) ?>', 0, 'topup', <?= $product['min_amount'] ?? 5000 ?>, <?= $product['max_amount'] ?? 5000000 ?>)">
                                Top Up
                            </button>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </section>
            <?php endif; ?>
        </div>
    </main>

    <!-- Checkout Modal -->
    <div class="modal-overlay" id="checkoutModal">
        <div class="modal">
            <div class="modal-header">
                <h2 class="modal-title">🛒 Checkout</h2>
                <button class="modal-close" onclick="closeModal()">&times;</button>
            </div>
            <div class="modal-body">
                <div class="order-summary">
                    <div class="order-item">
                        <span class="order-label">Produk</span>
                        <span class="order-value" id="orderProduct">-</span>
                    </div>
                    <div class="order-item">
                        <span class="order-label">Total Bayar</span>
                        <span class="order-total" id="orderTotal">Rp 0</span>
                    </div>
                </div>

                <form id="checkoutForm" method="POST">
                    <input type="hidden" name="action" value="create_payment">
                    <input type="hidden" name="product_id" id="inputProductId">
                    <input type="hidden" name="product_type" id="inputProductType">

                    <!-- Custom Amount for Top Up -->
                    <div class="form-group" id="customAmountGroup" style="display:none;">
                        <label class="form-label">
                            <span>💰</span>
                            Nominal Top Up
                        </label>
                        <input type="text" class="form-input amount-input" name="custom_amount" id="inputCustomAmount" placeholder="50.000">
                        <div class="form-hint">
                            Min: <span id="minAmount">Rp 5.000</span> - Max: <span id="maxAmount">Rp 5.000.000</span>
                        </div>
                    </div>

                    <!-- Game ID for Top Up -->
                    <div class="form-group" id="gameIdGroup" style="display:none;">
                        <label class="form-label">
                            <span>🎮</span>
                            Game ID / User ID
                        </label>
                        <input type="text" class="form-input" name="game_id" placeholder="Masukkan Game ID">
                    </div>
                    <div class="form-group" id="serverIdGroup" style="display:none;">
                        <label class="form-label">
                            <span>🌐</span>
                            Server ID (Opsional)
                        </label>
                        <input type="text" class="form-input" name="server_id" placeholder="Masukkan Server ID">
                    </div>

                    <div class="form-group">
                        <label class="form-label">
                            <span>👤</span>
                            Nama Lengkap
                        </label>
                        <input type="text" class="form-input" name="customer_name" required placeholder="John Doe">
                    </div>
                    <div class="form-group">
                        <label class="form-label">
                            <span>📧</span>
                            Email
                        </label>
                        <input type="email" class="form-input" name="customer_email" required placeholder="john@example.com">
                    </div>
                    <div class="form-group">
                        <label class="form-label">
                            <span>📱</span>
                            No. WhatsApp
                        </label>
                        <input type="tel" class="form-input" name="customer_phone" required placeholder="08123456789">
                    </div>

                    <button type="submit" class="btn btn-full">
                        🔒 Bayar dengan QRIS
                    </button>
                </form>
            </div>
        </div>
    </div>

    <!-- Payment QR Modal -->
    <?php if ($showPayment && isset($paymentResult['data'])): ?>
    <?php
        $payData = $paymentResult['data'];
        $baseAmount = $payData['amount'] ?? 0;
        $uniqueCode = $payData['unique_code'] ?? 0;
        $totalAmount = $payData['total_amount'] ?? 0;
    ?>
    <div class="modal-overlay active" id="paymentModal">
        <div class="modal">
            <div class="modal-header">
                <h2 class="modal-title">📱 Scan QR untuk Bayar</h2>
                <button class="modal-close" onclick="location.href='?'">&times;</button>
            </div>
            <div class="modal-body">
                <div class="qr-container">
                    <div class="qr-box">
                        <?php
                        $qrUrl = NEOPGA_URL . '/public/qr.php?invoice=' . urlencode($payData['invoice_number'] ?? '');
                        ?>
                        <img src="<?= htmlspecialchars($qrUrl) ?>" alt="QR Code">
                    </div>
                    <div class="qr-apps">
                        <span class="qr-app">GoPay</span>
                        <span class="qr-app">OVO</span>
                        <span class="qr-app">DANA</span>
                        <span class="qr-app">ShopeePay</span>
                    </div>
                </div>

                <div class="payment-breakdown">
                    <div class="breakdown-item">
                        <span class="breakdown-label">Harga Produk</span>
                        <span class="breakdown-value"><?= formatRupiah($baseAmount) ?></span>
                    </div>
                    <div class="breakdown-item">
                        <span class="breakdown-label">Kode Unik</span>
                        <span class="breakdown-value accent">+<?= number_format($uniqueCode, 0, ',', '.') ?></span>
                    </div>
                    <div class="breakdown-item">
                        <span class="breakdown-label"><strong>TOTAL BAYAR</strong></span>
                        <span class="breakdown-total"><?= formatRupiah($totalAmount) ?></span>
                    </div>
                </div>

                <div class="warning-box">
                    <div class="warning-header">
                        <span class="warning-icon">⚠️</span>
                        <span class="warning-title">PENTING!</span>
                    </div>
                    <p class="warning-text">
                        Transfer <strong>PERSIS <?= formatRupiah($totalAmount) ?></strong><br>
                        Jangan dibulatkan! Kode unik <strong>+<?= $uniqueCode ?></strong> diperlukan untuk verifikasi otomatis.
                    </p>
                </div>

                <div class="invoice-box">
                    <div class="invoice-label">Invoice Number</div>
                    <div class="invoice-value"><?= htmlspecialchars($payData['invoice_number'] ?? '-') ?></div>
                </div>

                <a href="success.php?order_id=<?= urlencode($payData['reference_id'] ?? '') ?>&invoice=<?= urlencode($payData['invoice_number'] ?? '') ?>" class="btn btn-outline btn-full" style="margin-top: 20px;">
                    Cek Status Pembayaran →
                </a>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Error Modal -->
    <?php if ($paymentResult && !($paymentResult['success'] ?? false) && !$showPayment): ?>
    <div class="modal-overlay active">
        <div class="modal">
            <div class="modal-header">
                <h2 class="modal-title">❌ Gagal</h2>
                <button class="modal-close" onclick="location.href='?'">&times;</button>
            </div>
            <div class="modal-body">
                <div style="text-align: center; padding: 20px 0;">
                    <div style="font-size: 4rem; margin-bottom: 16px;">😔</div>
                    <p style="color: var(--error); font-size: 1.1rem; margin-bottom: 24px;">
                        <?= htmlspecialchars($paymentResult['message'] ?? 'Terjadi kesalahan') ?>
                    </p>
                    <button onclick="location.href='?'" class="btn">Coba Lagi</button>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Footer -->
    <footer>
        <div class="container">
            <div style="background: linear-gradient(135deg, rgba(99, 102, 241, 0.1), rgba(139, 92, 246, 0.05)); border: 1px solid rgba(99, 102, 241, 0.2); border-radius: 20px; padding: 32px; text-align: center; margin-bottom: 40px;">
                <h3 style="font-size: 1.5rem; margin-bottom: 12px;">Mau punya toko seperti ini?</h3>
                <p style="color: var(--text-secondary); margin-bottom: 24px;">Daftar NEO PGA sekarang dan mulai terima pembayaran otomatis dalam 5 menit!</p>
                <div style="display: flex; gap: 16px; justify-content: center; flex-wrap: wrap;">
                    <a href="../merchant/register.php" class="btn">Daftar Gratis</a>
                    <a href="../" class="btn btn-outline">Pelajari Lebih Lanjut</a>
                </div>
            </div>
            <div class="footer-content">
                <div class="footer-brand">
                    <div class="footer-logo">🛒</div>
                    <div class="footer-text">
                        <strong>DEMO</strong> - © <?= date('Y') ?> <?= STORE_NAME ?>. Powered by <a href="../">NEO PGA</a>
                    </div>
                </div>
                <div class="footer-links">
                    <a href="../" class="footer-link">NEO PGA Home</a>
                    <a href="../merchant/register.php" class="footer-link">Daftar Merchant</a>
                    <a href="https://wa.me/<?= STORE_WHATSAPP ?>" target="_blank" class="footer-link">WhatsApp</a>
                </div>
            </div>
        </div>
    </footer>

    <script>
        let currentMinAmount = 5000;
        let currentMaxAmount = 5000000;

        function openCheckout(productId, productName, amount, type, minAmount = 5000, maxAmount = 5000000) {
            document.getElementById('orderProduct').textContent = productName;
            document.getElementById('inputProductId').value = productId;
            document.getElementById('inputProductType').value = type;

            currentMinAmount = minAmount;
            currentMaxAmount = maxAmount;

            if (type === 'topup') {
                document.getElementById('customAmountGroup').style.display = 'block';
                document.getElementById('gameIdGroup').style.display = 'block';
                document.getElementById('serverIdGroup').style.display = 'block';
                document.getElementById('orderTotal').textContent = 'Input nominal';
                document.getElementById('minAmount').textContent = formatRupiah(minAmount);
                document.getElementById('maxAmount').textContent = formatRupiah(maxAmount);
                document.getElementById('inputCustomAmount').value = '';
            } else {
                document.getElementById('customAmountGroup').style.display = 'none';
                document.getElementById('gameIdGroup').style.display = 'none';
                document.getElementById('serverIdGroup').style.display = 'none';
                document.getElementById('orderTotal').textContent = formatRupiah(amount);
            }

            document.getElementById('checkoutModal').classList.add('active');
            document.body.style.overflow = 'hidden';
        }

        function closeModal() {
            document.getElementById('checkoutModal').classList.remove('active');
            document.body.style.overflow = '';
        }

        function formatRupiah(amount) {
            return 'Rp ' + amount.toLocaleString('id-ID');
        }

        // Format input nominal
        document.getElementById('inputCustomAmount')?.addEventListener('input', function(e) {
            let v = this.value.replace(/[^0-9]/g, '');
            if (v) {
                this.value = new Intl.NumberFormat('id-ID').format(v);
                document.getElementById('orderTotal').textContent = formatRupiah(parseInt(v));
            } else {
                document.getElementById('orderTotal').textContent = 'Input nominal';
            }
        });

        // Form validation
        document.getElementById('checkoutForm')?.addEventListener('submit', function(e) {
            const amountInput = document.getElementById('inputCustomAmount');
            if (amountInput && amountInput.value) {
                const cleanAmount = parseInt(amountInput.value.replace(/[^0-9]/g, ''));
                if (cleanAmount < currentMinAmount || cleanAmount > currentMaxAmount) {
                    e.preventDefault();
                    alert('Nominal harus antara ' + formatRupiah(currentMinAmount) + ' - ' + formatRupiah(currentMaxAmount));
                    return false;
                }
                amountInput.value = cleanAmount;
            }
        });

        // Close modal on escape
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') closeModal();
        });

        // Close modal on overlay click
        document.getElementById('checkoutModal')?.addEventListener('click', function(e) {
            if (e.target === this) closeModal();
        });

        // Smooth scroll
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
            });
        });

        // ========================
        // SDK DEMO FUNCTIONS
        // ========================

        // Format demo amount input
        document.getElementById('demoAmountTemplate')?.addEventListener('input', function(e) {
            let v = this.value.replace(/[^0-9]/g, '');
            if (v) {
                this.value = new Intl.NumberFormat('id-ID').format(v);
            }
        });

        // Show Demo QRIS Modal
        function showDemoQRIS(type) {
            const modal = document.getElementById('demoQrisModal');
            const titleEl = document.getElementById('demoQrisTitle');
            const sourceEl = document.getElementById('demoQrisSource');
            const amountEl = document.getElementById('demoQrisAmount');
            const uniqueEl = document.getElementById('demoQrisUnique');
            const totalEl = document.getElementById('demoQrisTotal');

            // Generate random unique code (1-999)
            const uniqueCode = Math.floor(Math.random() * 999) + 1;

            if (type === 'template') {
                // SDK + Template Demo
                titleEl.textContent = 'Demo QRIS (SDK + Template)';
                sourceEl.innerHTML = '<span style="padding: 8px 16px; background: linear-gradient(135deg, rgba(168, 85, 247, 0.2), rgba(139, 92, 246, 0.1)); border: 1px solid rgba(168, 85, 247, 0.3); border-radius: 50px; font-size: 0.8rem; color: #a855f7;"><strong>📄 SDK + TEMPLATE</strong> - Form dari NEO PGA</span>';

                // Get amount from form
                const amountInput = document.getElementById('demoAmountTemplate');
                let amount = 100000; // default
                if (amountInput && amountInput.value) {
                    amount = parseInt(amountInput.value.replace(/[^0-9]/g, '')) || 100000;
                }

                amountEl.textContent = formatRupiah(amount);
                uniqueEl.textContent = '+' + uniqueCode;
                totalEl.textContent = formatRupiah(amount + uniqueCode);

            } else if (type === 'sdkonly') {
                // SDK Only Demo
                titleEl.textContent = 'Demo QRIS (SDK Only)';
                sourceEl.innerHTML = '<span style="padding: 8px 16px; background: linear-gradient(135deg, rgba(34, 197, 94, 0.2), rgba(22, 163, 74, 0.1)); border: 1px solid rgba(34, 197, 94, 0.3); border-radius: 50px; font-size: 0.8rem; color: #22c55e;"><strong>✅ SDK ONLY</strong> - Form milik Anda sendiri</span>';

                // Fixed amount from the pre-filled data
                const amount = 250000;
                amountEl.textContent = formatRupiah(amount);
                uniqueEl.textContent = '+' + uniqueCode;
                totalEl.textContent = formatRupiah(amount + uniqueCode);
            }

            modal.classList.add('active');
            document.body.style.overflow = 'hidden';
        }

        // Close Demo QRIS Modal
        function closeDemoQris() {
            const modal = document.getElementById('demoQrisModal');
            modal.classList.remove('active');
            document.body.style.overflow = '';
        }

        // Close demo modal on overlay click
        document.getElementById('demoQrisModal')?.addEventListener('click', function(e) {
            if (e.target === this) closeDemoQris();
        });

        // Close demo modal on escape
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                closeDemoQris();
                closeModal();
            }
        });
    </script>
</body>
</html>

# PANDUAN LENGKAP NEO PGA
## Untuk Pemula & Non-Programmer

Panduan ini dibuat untuk orang awam yang tidak mengerti coding. Ikuti langkah-langkah dengan teliti.

---

# DAFTAR ISI

1. [Pengenalan NEO PGA](#1-pengenalan-neo-pga)
2. [Panduan Admin (Pemilik Sistem)](#2-panduan-admin-pemilik-sistem)
3. [Panduan Merchant (Pengguna)](#3-panduan-merchant-pengguna)
4. [Alur Pembayaran](#4-alur-pembayaran)
5. [Troubleshooting (Solusi Masalah)](#5-troubleshooting-solusi-masalah)
6. [FAQ (Pertanyaan Umum)](#6-faq-pertanyaan-umum)

---

# 1. PENGENALAN NEO PGA

## Apa itu NEO PGA?

NEO PGA adalah sistem payment gateway (gerbang pembayaran) yang membantu bisnis menerima pembayaran online via:
- **QRIS** - Scan QR code dari semua aplikasi (GoPay, OVO, Dana, ShopeePay, dll)
- **Transfer Bank** - BCA, Mandiri, BNI, BRI, dll

## Siapa yang Menggunakan?

| Role | Penjelasan |
|------|------------|
| **Admin** | Pemilik sistem NEO PGA (Anda) |
| **Merchant** | Penjual/bisnis yang menggunakan NEO PGA untuk terima pembayaran |
| **Customer** | Pembeli yang membayar ke merchant |

## Alur Sederhana

```
Customer beli barang → Scan QRIS → Bayar → Admin verifikasi → Merchant dapat uang
```

---

# 2. PANDUAN ADMIN (PEMILIK SISTEM)

## 2.1 Cara Login Admin

1. Buka browser (Chrome/Firefox)
2. Ketik: `https://domain-anda.com/admin`
3. Masukkan:
   - Email: `admin@neopga.com` (default)
   - Password: `admin123` (default)
4. Klik tombol **Login**

⚠️ **PENTING:** Segera ganti password setelah login pertama!

---

## 2.2 Dashboard Admin

Setelah login, Anda akan melihat dashboard dengan informasi:

| Bagian | Penjelasan |
|--------|------------|
| **Total Transaksi** | Jumlah semua transaksi hari ini |
| **Transaksi Sukses** | Transaksi yang sudah dibayar |
| **Pending** | Transaksi menunggu pembayaran |
| **Total Volume** | Total uang yang masuk hari ini |

Dashboard akan **refresh otomatis setiap 2 detik** - tidak perlu refresh manual!

---

## 2.3 Verifikasi Pembayaran

Ini adalah tugas UTAMA admin - memverifikasi pembayaran yang masuk.

### Langkah-langkah:

1. Klik menu **Verifikasi** di sidebar
2. Anda akan melihat daftar transaksi pending
3. Cek mutasi rekening/QRIS Anda
4. Cari nominal yang **PERSIS SAMA** dengan yang tertera
   - Contoh: Jika tertulis Rp 100.123, cari mutasi Rp 100.123
5. Jika ditemukan, klik tombol **Verifikasi**
6. Konfirmasi dengan klik **Ya, Verifikasi**

### Tips Penting:

- Nominal harus **PERSIS** - Rp 100.123 ≠ Rp 100.000
- Angka 123 adalah **kode unik** untuk identifikasi
- Sistem akan otomatis menambah saldo merchant

---

## 2.4 Kelola Merchant

### Melihat Daftar Merchant
1. Klik menu **Merchants** di sidebar
2. Anda akan melihat semua merchant yang terdaftar

### Approve Merchant Baru
1. Merchant baru statusnya **Pending**
2. Klik nama merchant untuk lihat detail
3. Periksa data bisnis mereka
4. Klik **Approve** jika valid, atau **Reject** jika tidak

### Suspend/Ban Merchant
1. Klik merchant yang bermasalah
2. Klik **Suspend** untuk nonaktifkan sementara
3. Klik **Ban** untuk blokir permanen

---

## 2.5 Kelola Settlement (Pencairan Dana)

Merchant akan request pencairan dana dari saldo mereka.

### Proses Settlement:
1. Klik menu **Settlements** di sidebar
2. Lihat daftar request settlement
3. Periksa:
   - Nama merchant
   - Jumlah yang diminta
   - Rekening tujuan
4. Transfer manual ke rekening merchant
5. Klik **Approve** dan masukkan bukti transfer
6. Atau klik **Reject** jika ada masalah

---

## 2.6 Kelola Bank Accounts

Bank account adalah rekening yang ditampilkan untuk pembayaran transfer bank.

### Menambah Rekening:
1. Klik menu **Bank Accounts**
2. Klik tombol **Tambah Bank**
3. Isi:
   - Nama Bank (contoh: Bank BCA)
   - Kode Bank (contoh: BCA)
   - Nomor Rekening
   - Nama Pemilik Rekening
4. Klik **Simpan**

### Mengubah/Menghapus:
1. Klik ikon pensil untuk edit
2. Klik ikon tempat sampah untuk hapus

---

## 2.7 Kelola Payment Codes (Kode Unik)

Kode unik adalah angka 1-999 yang ditambahkan ke nominal pembayaran untuk identifikasi.

### Cara Kerja:
- Customer bayar Rp 100.000
- Sistem tambahkan kode unik, misal 123
- Total yang dibayar: Rp 100.123
- Admin cari mutasi Rp 100.123 untuk verifikasi

### Mengelola Kode:
1. Klik menu **Payment Codes**
2. Anda bisa:
   - Lihat status setiap kode (Available/Reserved/Used)
   - Reset kode secara manual jika diperlukan
   - Sistem akan **auto-reset** kode yang sudah dipakai

⚠️ Kode unik akan **otomatis di-reset** ketika:
- Tersisa ≤5 kode available
- Kode sudah dipakai >24 jam
- Transaksi expired/cancelled

---

## 2.8 Melihat Laporan

### Laporan Transaksi:
1. Klik menu **Reports**
2. Pilih rentang tanggal
3. Filter berdasarkan status/merchant
4. Klik **Export Excel** untuk download

### Laporan yang Tersedia:
- Total transaksi per hari
- Volume per merchant
- Success rate
- Grafik trend

---

## 2.9 Pengaturan Sistem

1. Klik menu **Settings**
2. Anda bisa mengubah:
   - Nama aplikasi
   - Commission rate default
   - Waktu expired transaksi
   - Enable/disable QRIS
   - Enable/disable Bank Transfer

---

## 2.10 QRIS Settings

Untuk mengatur QRIS yang digunakan:

1. Klik menu **QRIS Settings**
2. Upload gambar QRIS dari aplikasi bank/e-wallet Anda
3. Atau paste QRIS string jika punya
4. Sistem akan otomatis parse dan gunakan

---

# 3. PANDUAN MERCHANT (PENGGUNA)

## 3.1 Registrasi Merchant

1. Buka `https://domain-anda.com/merchant/register`
2. Isi formulir:
   - Email (untuk login)
   - Password
   - Nama Bisnis
   - Jenis Bisnis
   - Nama Pemilik
   - Nomor HP
   - Alamat
3. Klik **Daftar**
4. Tunggu approval dari Admin

---

## 3.2 Login Merchant

1. Buka `https://domain-anda.com/merchant`
2. Masukkan email dan password
3. Klik **Login**

---

## 3.3 Dashboard Merchant

Setelah login, merchant melihat:

| Bagian | Penjelasan |
|--------|------------|
| **Saldo** | Uang yang bisa dicairkan |
| **Transaksi Hari Ini** | Jumlah transaksi |
| **Pending** | Menunggu pembayaran |
| **Sukses** | Sudah terbayar |

Dashboard **refresh otomatis setiap 2 detik**!

---

## 3.4 Mendapatkan API Keys

API Keys diperlukan untuk integrasi dengan website/aplikasi merchant.

### Langkah:
1. Klik menu **API Keys**
2. Anda akan melihat:
   - **API Key** - untuk identifikasi
   - **Secret Key** - untuk keamanan (JANGAN BAGIKAN!)
3. Klik **Copy** untuk menyalin
4. Klik **Refresh** untuk generate key baru (key lama tidak berlaku)

---

## 3.5 Membuat Pembayaran Manual

Jika tidak punya website, merchant bisa buat pembayaran manual:

1. Klik menu **Buat Pembayaran**
2. Isi:
   - Nominal (contoh: 100000)
   - Nama Customer
   - Email Customer (opsional)
   - Deskripsi
3. Klik **Buat**
4. Akan muncul QR Code
5. Kirim QR Code ke customer untuk dibayar

---

## 3.6 Melihat Transaksi

1. Klik menu **Transaksi**
2. Lihat semua transaksi
3. Filter berdasarkan:
   - Status (Pending/Success/Expired)
   - Tanggal
   - Metode pembayaran
4. Klik transaksi untuk lihat detail

---

## 3.7 Request Settlement (Cairkan Dana)

Untuk mencairkan saldo ke rekening bank:

1. Klik menu **Settlement**
2. Klik **Request Settlement**
3. Masukkan jumlah yang ingin dicairkan
4. Pastikan data rekening benar
5. Klik **Request**
6. Tunggu Admin memproses (biasanya 1x24 jam)

### Status Settlement:
- **Pending** - Menunggu diproses
- **Processing** - Sedang ditransfer
- **Completed** - Sudah masuk rekening
- **Rejected** - Ditolak (lihat alasan)

---

## 3.8 Pengaturan Akun

1. Klik menu **Settings**
2. Anda bisa mengubah:
   - Password
   - Data bisnis
   - Rekening bank untuk settlement
   - Webhook URL (untuk programmer)

---

## 3.9 Integrasi ke Website (Tab Integration)

Di menu Settings, ada tab **Integration** yang berisi:

1. **API Keys** - Untuk integrasi
2. **Webhook URL** - URL yang akan dipanggil saat pembayaran sukses
3. **Panduan Integrasi** - Contoh kode lengkap

### Untuk Non-Programmer:

Jika Anda tidak bisa coding, gunakan **Panduan Simpel**:
1. Klik menu **Panduan Simpel**
2. Copy code yang diberikan
3. Paste ke file `index.php` di website Anda
4. Ganti API_KEY dan SECRET_KEY dengan milik Anda
5. Upload ke hosting
6. Selesai!

---

## 3.10 Push Notification

Merchant akan dapat notifikasi di browser saat ada pembayaran.

### Mengaktifkan:
1. Pertama kali login, browser akan minta izin notifikasi
2. Klik **Allow/Izinkan**
3. Sekarang Anda akan dapat notifikasi real-time

### Jika Tidak Dapat Notifikasi:
1. Cek apakah browser support (Chrome/Firefox/Edge)
2. Pastikan notifikasi tidak diblokir
3. Buka Settings browser → Site Settings → Notifications

---

# 4. ALUR PEMBAYARAN

## 4.1 Alur Lengkap (Step by Step)

```
┌─────────────────────────────────────────────────────────────────┐
│                     ALUR PEMBAYARAN NEO PGA                      │
└─────────────────────────────────────────────────────────────────┘

1. CUSTOMER CHECKOUT
   └── Customer klik "Bayar" di website merchant

2. SISTEM BUAT TRANSAKSI
   └── NEO PGA generate QR Code + kode unik
   └── Contoh: Rp 100.000 + 123 = Rp 100.123

3. CUSTOMER BAYAR
   └── Scan QR pakai GoPay/OVO/Dana/dll
   └── ATAU transfer ke rekening dengan nominal PERSIS

4. UANG MASUK KE REKENING ADMIN
   └── Mutasi masuk: Rp 100.123

5. ADMIN VERIFIKASI
   └── Cek mutasi
   └── Cari nominal Rp 100.123
   └── Klik Verifikasi

6. SISTEM UPDATE STATUS
   └── Transaksi jadi "Success"
   └── Saldo merchant bertambah
   └── Webhook dikirim ke merchant
   └── Notifikasi ke merchant

7. MERCHANT DAPAT UANG
   └── Saldo bertambah (dikurangi komisi)
   └── Bisa request settlement kapan saja
```

---

## 4.2 Cara Verifikasi Cepat (Untuk Admin)

### Metode 1: Verifikasi Manual
1. Buka halaman Verifikasi
2. Lihat nominal yang pending
3. Buka aplikasi bank/QRIS
4. Cari mutasi dengan nominal yang sama
5. Jika ketemu, klik Verifikasi

### Metode 2: Auto-Verify dengan MacroDroid (Android)
1. Install aplikasi MacroDroid di HP
2. Setup trigger: saat ada SMS dari bank
3. Kirim request ke NEO PGA API
4. Sistem otomatis verifikasi

*(Panduan MacroDroid tersedia terpisah)*

---

## 4.3 Penjelasan Kode Unik

### Apa itu Kode Unik?

Kode unik adalah angka 1-999 yang ditambahkan ke nominal pembayaran.

### Kenapa Perlu?

Karena banyak orang bisa bayar nominal yang sama. Kode unik membedakan setiap transaksi.

### Contoh:

| Customer | Harga Barang | Kode Unik | Total Bayar |
|----------|--------------|-----------|-------------|
| Budi | Rp 100.000 | 123 | Rp 100.123 |
| Ani | Rp 100.000 | 456 | Rp 100.456 |
| Citra | Rp 100.000 | 789 | Rp 100.789 |

Semua bayar barang Rp 100.000, tapi total berbeda karena kode unik berbeda.

### Kode Unik Habis?

Tidak perlu khawatir! Sistem otomatis:
- Reset kode yang sudah dipakai setelah 24 jam
- Reset semua kode jika tersisa <5

---

# 5. TROUBLESHOOTING (SOLUSI MASALAH)

## 5.1 Masalah Login

### "Email tidak terdaftar"
- Pastikan email benar
- Cek huruf besar/kecil
- Hubungi admin jika lupa email

### "Password salah"
- Pastikan password benar
- Cek Caps Lock
- Klik "Lupa Password" untuk reset

### "Akun belum diverifikasi"
- Tunggu admin approve akun Anda
- Hubungi admin untuk percepat proses

---

## 5.2 Masalah Pembayaran

### "QR Code tidak bisa di-scan"
- Pastikan gambar jelas, tidak blur
- Coba zoom in
- Pastikan aplikasi e-wallet terupdate

### "Nominal tidak sesuai"
- Pastikan bayar PERSIS sesuai yang tertera
- Termasuk kode unik (angka di belakang)
- Contoh: Rp 100.123 bukan Rp 100.000

### "Transaksi expired"
- Buat transaksi baru
- Bayar dalam waktu 1 jam (default)

### "Sudah bayar tapi status masih pending"
- Tunggu admin verifikasi (max 5-10 menit)
- Hubungi admin jika >30 menit
- Siapkan bukti transfer

---

## 5.3 Masalah Settlement

### "Request settlement ditolak"
- Cek alasan penolakan
- Pastikan data rekening benar
- Saldo harus cukup

### "Settlement lama diproses"
- Biasanya 1x24 jam kerja
- Weekend/hari libur bisa lebih lama
- Hubungi admin jika >3 hari

---

## 5.4 Masalah Dashboard

### "Dashboard tidak update"
- Cek koneksi internet
- Refresh halaman (Ctrl+R)
- Clear cache browser

### "Notifikasi tidak muncul"
- Cek izin notifikasi browser
- Pastikan tidak dalam mode incognito
- Coba browser lain

---

## 5.5 Masalah Teknis

### "Error 500"
- Server sedang bermasalah
- Tunggu beberapa menit
- Hubungi admin

### "Error 404"
- Halaman tidak ditemukan
- Cek URL yang diketik
- Kembali ke dashboard

### "Session expired"
- Login ulang
- Jangan biarkan browser idle terlalu lama

---

# 6. FAQ (PERTANYAAN UMUM)

## Umum

**Q: Berapa biaya menggunakan NEO PGA?**
A: Tergantung komisi yang ditetapkan admin. Default 2.5% per transaksi.

**Q: Minimal transaksi berapa?**
A: Default Rp 10.000 (bisa diubah admin).

**Q: Maksimal transaksi berapa?**
A: Default Rp 100.000.000 (bisa diubah admin).

---

## Untuk Merchant

**Q: Berapa lama saldo bisa dicairkan?**
A: Biasanya 1x24 jam kerja setelah request.

**Q: Apakah bisa langsung ke rekening customer?**
A: Tidak. Uang masuk ke rekening admin dulu, baru dicairkan ke merchant.

**Q: Bagaimana jika customer komplain?**
A: Hubungi admin dengan bukti transaksi.

---

## Untuk Admin

**Q: Bagaimana jika salah verifikasi?**
A: Hubungi developer untuk koreksi manual di database.

**Q: Bagaimana jika kode unik habis?**
A: Sistem otomatis reset. Jika masih habis, reset manual di Payment Codes.

**Q: Berapa lama data transaksi disimpan?**
A: Selamanya. Log activity dihapus setelah 30 hari.

---

## Keamanan

**Q: Apakah aman?**
A: Ya. Menggunakan:
- HTTPS/SSL encryption
- Password bcrypt hashing
- CSRF protection
- Rate limiting

**Q: Bagaimana jika API Key bocor?**
A: Segera generate key baru di menu API Keys.

**Q: Siapa yang bisa akses data?**
A: Hanya admin dan merchant terkait.

---

# 7. PANDUAN TEKNIS WEBSITE (UNTUK OWNER)

Bagian ini khusus untuk pemilik website NEO PGA untuk menangani masalah teknis.

## 7.1 Struktur Folder Website

```
neopga/
├── admin/          → Halaman admin panel
├── merchant/       → Halaman merchant dashboard
├── demo/           → Demo store contoh
├── public/         → Halaman payment customer
├── api/            → API endpoints
├── includes/       → Core classes & functions
├── config/         → File konfigurasi
├── assets/         → CSS, JS, images
├── uploads/        → File upload (logo, bukti)
├── logs/           → Log error & activity
├── sdk/            → SDK untuk integrasi
├── DATABASE.sql    → Struktur database
├── cron.php        → Auto-expire & cleanup
├── PANDUAN-LENGKAP.md  → File ini
├── GO-LIVE-CHECKLIST.md → Checklist go live
└── ROADMAP.md      → Ide pengembangan
```

---

## 7.2 Cara Cek Error Log

### Lokasi File Log:
```
logs/php_errors.log    → Error PHP
logs/rate_limit/       → Rate limiting data
```

### Cara Lihat Error di cPanel:
1. Login cPanel
2. Klik **File Manager**
3. Buka folder `logs`
4. Klik kanan `php_errors.log` → **View**
5. Lihat error terbaru di bagian bawah

### Cara Lihat Error via FTP:
1. Connect FTP (FileZilla/WinSCP)
2. Download file `logs/php_errors.log`
3. Buka dengan Notepad

### Contoh Error & Artinya:

| Error | Artinya | Solusi |
|-------|---------|--------|
| `SQLSTATE[HY000] [1045]` | Password database salah | Cek config/config.php |
| `SQLSTATE[HY000] [2002]` | Database tidak bisa connect | Cek host database |
| `Class 'Database' not found` | File include hilang | Upload ulang file includes/ |
| `Permission denied` | Folder tidak bisa ditulis | chmod 755 folder |
| `Maximum execution time` | Script terlalu lama | Optimasi query atau naikkan limit |

---

## 7.3 Masalah Database

### Database Tidak Connect

**Gejala:** Halaman blank/error 500

**Cek:**
1. Buka `config/config.php`
2. Periksa:
   ```php
   define('DB_HOST', 'localhost');    // Biasanya localhost
   define('DB_NAME', 'nama_database');
   define('DB_USER', 'username_db');
   define('DB_PASS', 'password_db');
   ```
3. Pastikan database sudah dibuat di cPanel → MySQL Databases

### Cara Cek Database di phpMyAdmin:
1. Login cPanel
2. Klik **phpMyAdmin**
3. Pilih database di sidebar kiri
4. Cek apakah semua tabel ada (harus 13 tabel)

### Tabel yang Harus Ada:
1. admins
2. merchants
3. bank_accounts
4. payment_codes
5. transactions
6. settlements
7. balance_logs
8. notifications
9. activity_logs
10. system_settings
11. api_logs
12. webhook_logs
13. password_resets

### Jika Tabel Hilang:
1. Buka phpMyAdmin
2. Klik tab **Import**
3. Pilih file `DATABASE.sql`
4. Klik **Go**

⚠️ **PERINGATAN:** Import akan HAPUS data lama!

---

## 7.4 Masalah File Permission

### Gejala:
- Upload foto gagal
- Log tidak tertulis
- Error "Permission denied"

### Solusi via cPanel:
1. Buka **File Manager**
2. Klik kanan folder `uploads` → **Change Permissions**
3. Set ke `755`
4. Lakukan sama untuk folder `logs`

### Solusi via FTP:
1. Klik kanan folder
2. **File Permissions** atau **Properties**
3. Set Numeric value: `755`

### Permission yang Benar:
```
uploads/    → 755
logs/       → 755
config/     → 644 (read only)
*.php       → 644
```

---

## 7.5 Website Blank/Error 500

### Langkah Diagnosa:

**Step 1: Aktifkan Error Display (Sementara)**
1. Buka `config/config.php`
2. Ubah:
   ```php
   ini_set('display_errors', 1);
   define('APP_DEBUG', true);
   ```
3. Refresh halaman
4. Lihat error yang muncul

**Step 2: Cek Error Log**
1. Buka `logs/php_errors.log`
2. Lihat error terakhir

**Step 3: Cek PHP Version**
- NEO PGA butuh PHP 7.4 atau lebih baru
- Cek di cPanel → Select PHP Version

**Step 4: Cek Ekstensi PHP**
Ekstensi yang diperlukan:
- pdo_mysql
- json
- curl
- mbstring
- openssl

⚠️ **PENTING:** Setelah selesai debug, kembalikan ke:
```php
ini_set('display_errors', 0);
define('APP_DEBUG', false);
```

---

## 7.6 Masalah Cron Job

### Cek Apakah Cron Berjalan:
1. Login cPanel
2. Klik **Cron Jobs**
3. Lihat apakah ada entry untuk cron.php

### Setup Cron Job:
1. Di cPanel → Cron Jobs
2. Common Settings: **Every 5 minutes**
3. Command:
   ```
   /usr/bin/php /home/username/public_html/neopga/cron.php
   ```
4. Klik **Add New Cron Job**

### Test Cron Manual:
1. Buka di browser: `https://domain.com/cron.php?key=neobayar_cron_2024`
2. Jika berhasil, akan tampil log output

### Jika Cron Tidak Jalan:
- Transaksi tidak auto-expire
- Payment codes tidak auto-reset
- Webhook tidak retry

---

## 7.7 Restore dari Backup

### Backup Database:
1. phpMyAdmin → pilih database
2. Klik **Export**
3. Format: SQL
4. Klik **Go**
5. Simpan file .sql

### Restore Database:
1. phpMyAdmin → pilih database
2. Klik **Import**
3. Pilih file backup .sql
4. Klik **Go**

### Backup Files:
1. cPanel → **Backup Wizard**
2. Atau download seluruh folder via FTP

---

## 7.8 Reset Password Admin (Lupa Password)

### Via phpMyAdmin:
1. Buka phpMyAdmin
2. Pilih tabel `admins`
3. Klik **Edit** pada baris admin
4. Di field `password`, masukkan:
   ```
   $2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi
   ```
   (Ini adalah hash untuk password "admin123")
5. Klik **Go**
6. Login dengan password: `admin123`
7. **SEGERA GANTI PASSWORD!**

---

## 7.9 Clear Cache

### Clear Browser Cache:
- Chrome: Ctrl + Shift + Delete
- Firefox: Ctrl + Shift + Delete
- Pilih "Cached images and files"
- Klik Clear

### Clear Server Cache (jika pakai):
1. Cek apakah ada folder `cache/`
2. Hapus isi folder tersebut

---

## 7.10 Update/Upgrade Website

### Sebelum Update:
1. ✅ Backup database (Export via phpMyAdmin)
2. ✅ Backup files (Download via FTP)
3. ✅ Catat versi sekarang

### Proses Update:
1. Download file update
2. Upload via FTP (overwrite file lama)
3. Jika ada update database, jalankan SQL di phpMyAdmin
4. Test semua fitur

### Jika Gagal:
1. Restore file dari backup
2. Restore database dari backup

---

## 7.11 Monitoring Website

### Cek Website Hidup:
- Buka `https://domain.com/api/health.php`
- Jika tampil "OK", website berjalan

### Setup Uptime Monitoring (Gratis):
1. Daftar di https://uptimerobot.com
2. Add New Monitor
3. Monitor Type: HTTP(s)
4. URL: `https://domain.com/api/health.php`
5. Monitoring Interval: 5 minutes
6. Anda akan dapat email jika website down

---

## 7.12 Kontak Developer

Jika masalah tidak bisa diselesaikan sendiri:

**Informasi yang Harus Disiapkan:**
1. Screenshot error
2. Isi file `logs/php_errors.log` (10 baris terakhir)
3. Langkah untuk reproduce error
4. Kapan mulai error

**Cara Kirim Log:**
1. Buka File Manager
2. Download `logs/php_errors.log`
3. Kirim via WhatsApp/Email

---

# KONTAK SUPPORT

Jika ada pertanyaan atau masalah:

- **WhatsApp:** 0895-3434-07575
- **Email:** support@neopga.com

---

# CATATAN PENTING

1. **Selalu backup database** secara berkala
2. **Ganti password default** segera setelah install
3. **Jangan bagikan Secret Key** ke siapapun
4. **Verifikasi pembayaran dengan teliti** - cek nominal PERSIS
5. **Monitor mutasi rekening** secara rutin

---

*Panduan dibuat: 15 Desember 2025*
*NEO PGA Version: 2.0.0*

**Semoga sukses dengan bisnis Anda!** 🚀

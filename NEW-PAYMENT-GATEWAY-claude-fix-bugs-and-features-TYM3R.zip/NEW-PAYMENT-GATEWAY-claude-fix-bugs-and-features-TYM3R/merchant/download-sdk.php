<?php
/**
 * NEO PGA - SDK Download Handler
 * Download SDK dengan kredensial merchant yang sudah terisi
 */

require_once __DIR__ . '/../includes/init.php';

// Check login
if (!isset($_SESSION['merchant_user']['id'])) {
    header('Location: login.php');
    exit;
}

$db = Database::getInstance();
$merchantId = (int)$_SESSION['merchant_user']['id'];
$merchant = $db->fetch("SELECT * FROM merchants WHERE id = ?", [$merchantId]);

if (!$merchant || $merchant['status'] !== 'active') {
    header('Location: index.php');
    exit;
}

$type = $_GET['type'] ?? 'qris-sdk';
$validTypes = ['qris-sdk', 'simple', 'full'];

if (!in_array($type, $validTypes)) {
    $type = 'qris-sdk';
}

// Map type to file path
$sdkFiles = [
    'qris-sdk' => 'neopga-qris-sdk.php',   // SDK saja (merchant sudah punya form)
    'simple'   => 'neopga-simple.php',      // SDK + template form (merchant belum punya form)
    'full'     => 'neopga-full.php',        // SDK QRIS + Bank Transfer
];

// Get SDK template
$sdkPath = __DIR__ . '/../sdk/' . $sdkFiles[$type];

if (!file_exists($sdkPath)) {
    die('SDK file not found');
}

$sdkContent = file_get_contents($sdkPath);

// Replace placeholders with merchant credentials
$apiKey = $merchant['api_key'] ?? '';
$secretKey = $merchant['secret_key'] ?? '';
$baseUrl = APP_URL;

$sdkContent = str_replace(
    [
        "const API_KEY    = 'GANTI_DENGAN_API_KEY_ANDA';",
        "const SECRET_KEY = 'GANTI_DENGAN_SECRET_KEY_ANDA';",
        "const BASE_URL   = 'https://DOMAIN_NEOPGA_ANDA.com';",
    ],
    [
        "const API_KEY    = '" . addslashes($apiKey) . "';",
        "const SECRET_KEY = '" . addslashes($secretKey) . "';",
        "const BASE_URL   = '" . addslashes($baseUrl) . "';",
    ],
    $sdkContent
);

// Add merchant info in header
$merchantInfo = "
/**
 * SDK ini di-generate khusus untuk:
 * Merchant: " . $merchant['business_name'] . "
 * Code: " . $merchant['merchant_code'] . "
 * Generated: " . date('Y-m-d H:i:s') . "
 *
 * JANGAN SHARE FILE INI KE ORANG LAIN!
 * File ini berisi kredensial rahasia Anda.
 */

";

$sdkContent = str_replace("<?php\n", "<?php\n" . $merchantInfo, $sdkContent);

// Set filename based on type
$filenameMap = [
    'qris-sdk' => 'neopga-qris-sdk',        // SDK saja
    'simple'   => 'neopga-qris-template',   // SDK + template form
    'full'     => 'neopga-full',            // QRIS + Bank
];
$filename = ($filenameMap[$type] ?? 'neopga-sdk') . '-' . $merchant['merchant_code'] . '.php';

// Set headers for download
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Content-Length: ' . strlen($sdkContent));
header('Cache-Control: no-cache, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// Output SDK content
echo $sdkContent;
exit;

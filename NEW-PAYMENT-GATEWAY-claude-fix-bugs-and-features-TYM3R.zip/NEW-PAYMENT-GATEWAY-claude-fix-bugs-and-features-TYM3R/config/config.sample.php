<?php
/**
 * NEO PGA Configuration Template
 * 
 * Copy file ini ke config.php dan sesuaikan dengan server Anda
 * Atau gunakan install.php untuk setup otomatis
 */

// ============================================
// ENVIRONMENT
// ============================================
define('APP_ENV', 'production'); // development | production
define('APP_DEBUG', false); // Set true untuk debugging
define('APP_VERSION', '2.0.0');

// ============================================
// APPLICATION
// ============================================
define('APP_NAME', 'NEO PGA');
define('APP_TAGLINE', 'Modern Payment Gateway');
define('APP_URL', 'https://pay.yourdomain.com'); // Ganti dengan URL Anda
define('APP_TIMEZONE', 'Asia/Jakarta');

// ============================================
// DATABASE
// ============================================
define('DB_HOST', 'localhost');
define('DB_PORT', 3306);
define('DB_NAME', 'neobayar_db'); // Ganti dengan nama database Anda
define('DB_USER', 'your_db_user'); // Ganti dengan username database
define('DB_PASS', 'your_db_password'); // Ganti dengan password database
define('DB_CHARSET', 'utf8mb4');

// ============================================
// PATHS (Jangan diubah)
// ============================================
define('ROOT_PATH', dirname(__DIR__));
define('CONFIG_PATH', ROOT_PATH . '/config');
define('INCLUDES_PATH', ROOT_PATH . '/includes');
define('ASSETS_PATH', ROOT_PATH . '/assets');
define('UPLOADS_PATH', ROOT_PATH . '/uploads');
define('LOGS_PATH', ROOT_PATH . '/logs');

// ============================================
// URLS (Jangan diubah)
// ============================================
define('ASSETS_URL', APP_URL . '/assets');
define('UPLOADS_URL', APP_URL . '/uploads');
define('ADMIN_URL', APP_URL . '/admin');
define('MERCHANT_URL', APP_URL . '/merchant');
define('API_URL', APP_URL . '/api');
define('PUBLIC_URL', APP_URL . '/public');

// ============================================
// SECURITY
// ============================================
define('HASH_COST', 12);
define('SESSION_LIFETIME', 7200); // 2 jam
if (!defined('CSRF_TOKEN_NAME')) {
    define('CSRF_TOKEN_NAME', '_neobayar_token');
}
define('API_RATE_LIMIT', 100); // requests per menit

// Encryption key - WAJIB DIGANTI!
define('ENCRYPTION_KEY', 'GANTI_DENGAN_STRING_RANDOM_32_KARAKTER_ATAU_LEBIH');

// ============================================
// PAYMENT SETTINGS
// ============================================
define('PAYMENT_EXPIRY_MINUTES', 60); // Waktu expired transaksi
define('MIN_AMOUNT', 10000); // Minimum pembayaran
define('MAX_AMOUNT', 100000000); // Maximum pembayaran
define('DEFAULT_COMMISSION_RATE', 2.50); // Komisi default (%)

// Kode unik settings
define('UNIQUE_CODE_MIN', 1);
define('UNIQUE_CODE_MAX', 999);
define('UNIQUE_CODE_TYPE', 'last_digits'); // last_digits | additional

// ============================================
// QRIS SETTINGS
// ============================================
define('QRIS_ENABLED', true);
define('QRIS_MERCHANT_NAME', 'NEO PGA');
define('QRIS_MERCHANT_CITY', 'JAKARTA');
define('QRIS_POSTAL_CODE', '10340');
define('QRIS_COUNTRY_CODE', 'ID');
define('QRIS_CURRENCY', '360'); // IDR

// Static QRIS - Dapatkan dari bank/provider Anda
define('QRIS_STATIC_CODE', 'PASTE_KODE_QRIS_ANDA_DISINI');

// ============================================
// WEBHOOK SETTINGS
// ============================================
define('WEBHOOK_ENABLED', true);
define('WEBHOOK_RETRY_ATTEMPTS', 3);
define('WEBHOOK_RETRY_DELAY', 60); // detik
define('WEBHOOK_TIMEOUT', 30); // detik

// Cron Job Security Key (ganti dengan key random yang unik)
define('CRON_SECRET_KEY', 'GANTI_DENGAN_KEY_RAHASIA_UNIK_ANDA');

// ============================================
// EMAIL SETTINGS (Opsional)
// ============================================
define('MAIL_ENABLED', false); // Set true untuk aktifkan email
define('MAIL_DRIVER', 'smtp');
define('MAIL_HOST', 'smtp.gmail.com');
define('MAIL_PORT', 587);
define('MAIL_USERNAME', '');
define('MAIL_PASSWORD', '');
define('MAIL_ENCRYPTION', 'tls');
define('MAIL_FROM_ADDRESS', 'noreply@yourdomain.com');
define('MAIL_FROM_NAME', 'NEO PGA');

// ============================================
// FILE UPLOAD
// ============================================
define('MAX_UPLOAD_SIZE', 5 * 1024 * 1024); // 5MB
define('ALLOWED_IMAGE_TYPES', ['jpg', 'jpeg', 'png', 'gif', 'webp']);
define('ALLOWED_DOCUMENT_TYPES', ['pdf', 'doc', 'docx']);

// ============================================
// ERROR HANDLING
// ============================================
if (APP_DEBUG) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

// Set timezone
date_default_timezone_set(APP_TIMEZONE);

// Start session if not started
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.cookie_secure', APP_ENV === 'production' ? 1 : 0);
    ini_set('session.gc_maxlifetime', SESSION_LIFETIME);
    session_start();
}

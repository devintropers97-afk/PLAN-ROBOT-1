<?php
/**
 * NEO PGA Configuration
 * Payment Gateway Configuration File
 *
 * LENGKAP - Semua konstanta yang dibutuhkan
 */

// ============================================
// ERROR REPORTING
// ============================================
error_reporting(E_ALL);
ini_set('display_errors', 0);  // JANGAN tampilkan error ke user (security)
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/../logs/php_errors.log');

// ============================================
// SESSION - Handled in includes/init.php
// DO NOT start session here to avoid duplication
// ============================================

// ============================================
// APPLICATION SETTINGS
// ============================================
define('APP_ENV', 'production');  // Ganti ke 'development' untuk debugging
define('APP_DEBUG', false);  // Ganti ke true untuk debugging (JANGAN di production!)
define('APP_VERSION', '2.0.0');
define('APP_NAME', 'NEO PGA');
define('APP_TAGLINE', 'Modern Payment Gateway for Indonesia');
define('APP_URL', 'https://your-domain.com');  // GANTI INI!
define('APP_TIMEZONE', 'Asia/Jakarta');

// Set timezone
date_default_timezone_set(APP_TIMEZONE);

// ============================================
// DATABASE SETTINGS
// ============================================
// PENTING: Ganti dengan kredensial database Anda!
define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_NAME', 'your_database_name');  // GANTI INI!
define('DB_USER', 'your_database_user');  // GANTI INI!
define('DB_PASS', 'your_database_password');  // GANTI INI!
define('DB_CHARSET', 'utf8mb4');

// ============================================
// PATH CONSTANTS
// ============================================
define('ROOT_PATH', dirname(__DIR__));
define('CONFIG_PATH', __DIR__);
define('INCLUDES_PATH', ROOT_PATH . '/includes');
define('ASSETS_PATH', ROOT_PATH . '/assets');
define('UPLOADS_PATH', ROOT_PATH . '/uploads');
define('LOGS_PATH', ROOT_PATH . '/logs');
define('ADMIN_PATH', ROOT_PATH . '/admin');
define('MERCHANT_PATH', ROOT_PATH . '/merchant');
define('PUBLIC_PATH', ROOT_PATH . '/public');

// ============================================
// URL CONSTANTS
// ============================================
define('ASSETS_URL', APP_URL . '/assets');
define('UPLOADS_URL', APP_URL . '/uploads');
define('ADMIN_URL', APP_URL . '/admin');
define('MERCHANT_URL', APP_URL . '/merchant');
define('API_URL', APP_URL . '/api');
define('PUBLIC_URL', APP_URL . '/public');

// ============================================
// SECURITY SETTINGS
// ============================================
define('HASH_ALGO', PASSWORD_BCRYPT);  // PHP 8.1 compatible
define('HASH_COST', 12);
define('SESSION_LIFETIME', 7200);
define('API_RATE_LIMIT', 100);
// PENTING: Ganti dengan string random minimal 32 karakter!
// Gunakan: php -r "echo bin2hex(random_bytes(32));"
define('ENCRYPTION_KEY', 'GANTI_DENGAN_STRING_RANDOM_32_KARAKTER_ATAU_LEBIH');

if (!defined('CSRF_TOKEN_NAME')) {
    define('CSRF_TOKEN_NAME', 'neopga_csrf');
}

// ============================================
// PAYMENT SETTINGS
// ============================================
define('PAYMENT_EXPIRY_MINUTES', 60);
define('MIN_AMOUNT', 1000);
define('MAX_AMOUNT', 100000000);
define('DEFAULT_COMMISSION_RATE', 2.5);

// Unique code settings
define('UNIQUE_CODE_MIN', 1);
define('UNIQUE_CODE_MAX', 999);
define('UNIQUE_CODE_TYPE', 'addition');

// ============================================
// QRIS SETTINGS
// ============================================
define('QRIS_ENABLED', true);
define('QRIS_UNIQUE_CODE_ENABLED', true);  // Enable unique code for QRIS verification
define('QRIS_MERCHANT_ID', 'ID1234567890');
define('QRIS_NMID', 'ID1234567890123');
define('QRIS_MERCHANT_NAME', 'NEO PGA');
define('QRIS_MERCHANT_CITY', 'JAKARTA');
define('QRIS_POSTAL_CODE', '10340');
define('QRIS_COUNTRY_CODE', 'ID');
define('QRIS_CURRENCY', '360');
define('QRIS_STATIC_CODE', '00020101021226670016COM.NOBUBANK.WWW01189360050300000879140214149391087891410303UMI51440014ID.CO.QRIS.WWW0215ID20232889835970303UMI5204481253033605802ID5910NEO PGA6013JAKARTA PUSAT61051034062070703A016304');

// ============================================
// WEBHOOK SETTINGS
// ============================================
define('WEBHOOK_ENABLED', true);
define('WEBHOOK_RETRY_ATTEMPTS', 3);
define('WEBHOOK_RETRY_DELAY', 60);
define('WEBHOOK_TIMEOUT', 30);

// Cron Job Security Key (ganti dengan key random yang unik)
define('CRON_SECRET_KEY', 'CHANGE_THIS_TO_RANDOM_SECRET_KEY_' . substr(md5(__FILE__), 0, 16));

// ============================================
// EMAIL SETTINGS (Optional)
// ============================================
define('MAIL_ENABLED', false);
define('MAIL_DRIVER', 'smtp');
define('MAIL_HOST', 'smtp.gmail.com');
define('MAIL_PORT', 587);
define('MAIL_USERNAME', '');
define('MAIL_PASSWORD', '');
define('MAIL_ENCRYPTION', 'tls');
define('MAIL_FROM_ADDRESS', 'noreply@neopga.com');
define('MAIL_FROM_NAME', 'NEO PGA');

// ============================================
// FILE UPLOAD SETTINGS
// ============================================
define('MAX_UPLOAD_SIZE', 5242880);
define('UPLOAD_PATH', ROOT_PATH . '/uploads/');
define('ALLOWED_IMAGE_TYPES', ['jpg', 'jpeg', 'png', 'gif', 'webp']);
define('ALLOWED_DOCUMENT_TYPES', ['pdf', 'doc', 'docx', 'xls', 'xlsx']);
define('ALLOWED_EXTENSIONS', 'jpg,jpeg,png,gif,pdf');

// ============================================
// API SETTINGS
// ============================================
define('API_VERSION', 'v1');

// ============================================
// DATABASE CONNECTION
// ============================================
// Note: Database connection is handled by Database.php singleton class
// The db() helper function provides access to the database instance
// This avoids duplicate connections and centralizes database management

<?php
/**
 * NEO PGA - Cron Jobs
 * 
 * Setup cron job di cPanel (jalankan setiap 5 menit):
 * Command: /usr/bin/php /path/to/neobayar/cron.php
 * 
 * Atau via URL (kurang disarankan):
 * wget -q -O /dev/null "https://domain.com/cron.php?key=CRON_SECRET_KEY"
 */

// Allow CLI or authenticated web request
// PENTING: Ganti key ini dengan string random yang unik!
$cronKey = defined('CRON_SECRET_KEY') ? CRON_SECRET_KEY : 'GANTI_DENGAN_KEY_RAHASIA_ANDA';

if (php_sapi_name() !== 'cli') {
    // Web access - check key
    if (!isset($_GET['key']) || $_GET['key'] !== $cronKey) {
        http_response_code(403);
        die('Access denied');
    }
    header('Content-Type: text/plain');
}

require_once __DIR__ . '/includes/init.php';

$db = Database::getInstance();
$now = date('Y-m-d H:i:s');

echo "[{$now}] Starting cron jobs...\n";

// =========================================
// 1. Auto-expire pending transactions
// =========================================
echo "\n=== 1. EXPIRED TRANSACTIONS ===\n";

$expiredTransactions = $db->fetchAll(
    "SELECT * FROM transactions WHERE status IN ('pending', 'waiting') AND expired_at < NOW()"
);

$expiredCount = 0;
foreach ($expiredTransactions as $trx) {
    // Update status to expired
    $db->query(
        "UPDATE transactions SET status = 'expired', updated_at = NOW() WHERE id = ?",
        [$trx['id']]
    );
    
    // Release payment code
    if ($trx['payment_code_id']) {
        $db->query(
            "UPDATE payment_codes SET status = 'available', transaction_id = NULL, reserved_at = NULL, expires_at = NULL, used_at = NULL WHERE id = ?",
            [$trx['payment_code_id']]
        );
    }
    
    $expiredCount++;
    echo "  [EXPIRED] {$trx['invoice_number']}\n";
}

echo "Total expired: $expiredCount transactions\n";

// =========================================
// 2. AUTO-RESET Payment Codes
// =========================================
echo "\n=== 2. PAYMENT CODES AUTO-RESET ===\n";

// 2a. Reset reserved codes yang expired (transaksi timeout)
$resetReserved = $db->query(
    "UPDATE payment_codes 
     SET status = 'available', 
         transaction_id = NULL, 
         reserved_at = NULL, 
         expires_at = NULL,
         used_at = NULL
     WHERE status = 'reserved' 
     AND expires_at < NOW()"
);
$reservedReset = $db->rowCount();
echo "  [RESET] $reservedReset reserved codes (expired)\n";

// 2b. Reset used codes yang sudah > 24 jam (recycle untuk dipakai lagi)
$resetUsed = $db->query(
    "UPDATE payment_codes 
     SET status = 'available', 
         transaction_id = NULL, 
         reserved_at = NULL, 
         expires_at = NULL,
         used_at = NULL
     WHERE status = 'used' 
     AND used_at < DATE_SUB(NOW(), INTERVAL 24 HOUR)"
);
$usedReset = $db->rowCount();
echo "  [RECYCLE] $usedReset used codes (>24h old)\n";

// 2c. Reset codes dari transaksi yang gagal/expired
$resetFailed = $db->query(
    "UPDATE payment_codes pc
     LEFT JOIN transactions t ON pc.transaction_id = t.id
     SET pc.status = 'available', 
         pc.transaction_id = NULL, 
         pc.reserved_at = NULL, 
         pc.expires_at = NULL,
         pc.used_at = NULL
     WHERE pc.status IN ('reserved', 'used')
     AND t.status IN ('expired', 'cancelled', 'failed')"
);
$failedReset = $db->rowCount();
echo "  [CLEANUP] $failedReset codes from failed/expired transactions\n";

// 2d. Check available codes per merchant
$merchants = $db->fetchAll("SELECT id, business_name FROM merchants WHERE status = 'active'");
foreach ($merchants as $m) {
    $availableCount = $db->fetch(
        "SELECT COUNT(*) as c FROM payment_codes WHERE merchant_id = ? AND status = 'available'",
        [$m['id']]
    )['c'] ?? 0;
    
    $totalCount = $db->fetch(
        "SELECT COUNT(*) as c FROM payment_codes WHERE merchant_id = ?",
        [$m['id']]
    )['c'] ?? 0;
    
    // Jika available < 20% dari total, force reset semua used codes
    if ($totalCount > 0 && $availableCount < ($totalCount * 0.2)) {
        $forceReset = $db->query(
            "UPDATE payment_codes 
             SET status = 'available', 
                 transaction_id = NULL, 
                 reserved_at = NULL, 
                 expires_at = NULL,
                 used_at = NULL
             WHERE merchant_id = ? 
             AND status = 'used'",
            [$m['id']]
        );
        $forceCount = $db->rowCount();
        echo "  [FORCE RESET] Merchant #{$m['id']} - {$forceCount} codes (low availability: {$availableCount}/{$totalCount})\n";
        
        logActivity('system', null, 'payment_code_force_reset', 'payment_codes', 
            "Force reset {$forceCount} codes for merchant #{$m['id']} ({$m['business_name']}) - low availability");
    }
    
    // Jika tidak ada kode sama sekali, generate pool baru
    if ($totalCount == 0) {
        echo "  [GENERATE] Creating code pool for Merchant #{$m['id']}...\n";
        
        $min = defined('UNIQUE_CODE_MIN') ? UNIQUE_CODE_MIN : 1;
        $max = defined('UNIQUE_CODE_MAX') ? UNIQUE_CODE_MAX : 999;
        
        for ($code = $min; $code <= $max; $code++) {
            $db->query(
                "INSERT IGNORE INTO payment_codes (merchant_id, code, status) VALUES (?, ?, 'available')",
                [$m['id'], $code]
            );
        }
        
        echo "  [GENERATED] " . ($max - $min + 1) . " codes for Merchant #{$m['id']}\n";
    }
}

// =========================================
// 3. Retry failed webhooks
// =========================================
echo "\n=== 3. WEBHOOK RETRIES ===\n";

$failedWebhooks = $db->fetchAll(
    "SELECT t.*, m.webhook_url, m.secret_key 
     FROM transactions t 
     JOIN merchants m ON t.merchant_id = m.id 
     WHERE t.status = 'success' 
     AND t.webhook_status IN ('failed', 'pending')
     AND t.webhook_attempts < ?
     AND m.webhook_url IS NOT NULL
     AND m.webhook_url != ''",
    [WEBHOOK_RETRY_ATTEMPTS]
);

$webhookCount = 0;
foreach ($failedWebhooks as $trx) {
    // Check retry delay
    $lastAttempt = $db->fetch(
        "SELECT created_at FROM webhook_logs WHERE transaction_id = ? ORDER BY created_at DESC LIMIT 1",
        [$trx['id']]
    );
    
    if ($lastAttempt) {
        $lastTime = strtotime($lastAttempt['created_at']);
        if (time() - $lastTime < WEBHOOK_RETRY_DELAY) {
            continue; // Skip, not yet time to retry
        }
    }
    
    // Send webhook
    $payload = [
        'event' => 'payment.success',
        'data' => [
            'invoice_number' => $trx['invoice_number'],
            'reference_id' => $trx['reference_id'],
            'amount' => (int)$trx['amount'],
            'total_amount' => (int)$trx['total_amount'],
            'status' => 'success',
            'paid_at' => $trx['paid_at']
        ],
        'timestamp' => date('c')
    ];
    
    $result = sendWebhook($trx['id'], $payload);
    $webhookCount++;
    
    echo "  [WEBHOOK] {$trx['invoice_number']}: " . ($result ? 'SUCCESS' : 'FAILED') . "\n";
}

echo "Total webhook retries: $webhookCount\n";

// =========================================
// 4. Clean old logs (keep 30 days)
// =========================================
echo "\n=== 4. LOG CLEANUP ===\n";

$cleanupDate = date('Y-m-d H:i:s', strtotime('-30 days'));

// Activity logs
$db->query("DELETE FROM activity_logs WHERE created_at < ?", [$cleanupDate]);
$activityDeleted = $db->rowCount();

// API logs
$db->query("DELETE FROM api_logs WHERE created_at < ?", [$cleanupDate]);
$apiDeleted = $db->rowCount();

// Webhook logs
$db->query("DELETE FROM webhook_logs WHERE created_at < ?", [$cleanupDate]);
$webhookDeleted = $db->rowCount();

echo "  Deleted: $activityDeleted activity, $apiDeleted api, $webhookDeleted webhook logs\n";

// =========================================
// 5. Summary Stats
// =========================================
echo "\n=== 5. SYSTEM STATS ===\n";

$stats = $db->fetch(
    "SELECT 
        (SELECT COUNT(*) FROM payment_codes WHERE status = 'available') as codes_available,
        (SELECT COUNT(*) FROM payment_codes WHERE status = 'reserved') as codes_reserved,
        (SELECT COUNT(*) FROM payment_codes WHERE status = 'used') as codes_used,
        (SELECT COUNT(*) FROM payment_codes) as codes_total,
        (SELECT COUNT(*) FROM transactions WHERE status = 'pending') as trx_pending,
        (SELECT COUNT(*) FROM transactions WHERE status = 'success' AND DATE(paid_at) = CURDATE()) as trx_today
    "
);

echo "  Payment Codes: {$stats['codes_available']} available / {$stats['codes_reserved']} reserved / {$stats['codes_used']} used (Total: {$stats['codes_total']})\n";
echo "  Transactions: {$stats['trx_pending']} pending, {$stats['trx_today']} success today\n";

// =========================================
// Done
// =========================================
$endTime = date('Y-m-d H:i:s');
echo "\n[{$endTime}] Cron jobs completed!\n";
echo str_repeat('=', 50) . "\n";

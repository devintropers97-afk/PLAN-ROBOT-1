-- ============================================
-- NEO PGA PAYMENT GATEWAY
-- Complete Database Schema
-- Version: 2.4.0 (Enhanced Foreign Keys & Indexes)
-- ============================================
--
-- OPTIMIZED FOR:
-- - 100+ merchants with concurrent transactions
-- - Race condition prevention with FOR UPDATE locks
-- - Atomic balance updates
-- - High-volume transaction processing
-- ============================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+07:00";
SET FOREIGN_KEY_CHECKS = 0;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

-- ============================================
-- DROP EXISTING TABLES (for clean install)
-- ============================================
DROP TABLE IF EXISTS `webhook_logs`;
DROP TABLE IF EXISTS `api_logs`;
DROP TABLE IF EXISTS `activity_logs`;
DROP TABLE IF EXISTS `settlements`;
DROP TABLE IF EXISTS `transactions`;
DROP TABLE IF EXISTS `payment_codes`;
DROP TABLE IF EXISTS `balance_logs`;
DROP TABLE IF EXISTS `merchants`;
DROP TABLE IF EXISTS `bank_accounts`;
DROP TABLE IF EXISTS `system_settings`;
DROP TABLE IF EXISTS `admins`;
DROP TABLE IF EXISTS `notifications`;
DROP TABLE IF EXISTS `password_resets`;

SET FOREIGN_KEY_CHECKS = 1;

-- ============================================
-- TABLE: admins
-- ============================================
CREATE TABLE IF NOT EXISTS `admins` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `username` VARCHAR(50) NOT NULL UNIQUE,
    `email` VARCHAR(255) NOT NULL UNIQUE,
    `password` VARCHAR(255) NOT NULL,
    `full_name` VARCHAR(255) NOT NULL,
    `phone` VARCHAR(20) NULL,
    `avatar` VARCHAR(255) NULL,
    `role` ENUM('super_admin', 'admin', 'operator') NOT NULL DEFAULT 'admin',
    `is_active` TINYINT(1) NOT NULL DEFAULT 1,
    `last_login` DATETIME NULL,
    `login_ip` VARCHAR(45) NULL,
    `two_factor_secret` VARCHAR(255) NULL,
    `two_factor_enabled` TINYINT(1) NOT NULL DEFAULT 0,
    `password_changed_at` DATETIME NULL,
    `remember_token` VARCHAR(100) NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_email` (`email`),
    INDEX `idx_role` (`role`),
    INDEX `idx_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- TABLE: merchants
-- ============================================
CREATE TABLE IF NOT EXISTS `merchants` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `merchant_code` VARCHAR(20) NOT NULL UNIQUE,
    `email` VARCHAR(255) NOT NULL UNIQUE,
    `password` VARCHAR(255) NOT NULL,
    `business_name` VARCHAR(255) NOT NULL,
    `business_type` VARCHAR(100) NOT NULL DEFAULT 'individual',
    `business_description` TEXT NULL,
    `expected_volume` VARCHAR(50) NULL,
    `owner_name` VARCHAR(255) NOT NULL,
    `phone` VARCHAR(20) NOT NULL,
    `address` TEXT NULL,
    `city` VARCHAR(100) NULL,
    `province` VARCHAR(100) NULL,
    `postal_code` VARCHAR(10) NULL,
    `website` VARCHAR(255) NULL,
    `logo` VARCHAR(255) NULL,
    `api_key` VARCHAR(64) NULL,
    `secret_key` VARCHAR(64) NULL,
    `webhook_url` VARCHAR(500) NULL,
    `callback_url` VARCHAR(500) NULL,
    `balance` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `pending_balance` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `commission_rate` DECIMAL(5,2) NOT NULL DEFAULT 2.50,
    `status` ENUM('pending', 'active', 'suspended', 'banned') NOT NULL DEFAULT 'pending',
    `verification_status` ENUM('unverified', 'pending', 'verified', 'rejected') NOT NULL DEFAULT 'unverified',
    `verification_documents` JSON NULL,
    `bank_name` VARCHAR(100) NULL,
    `bank_account_number` VARCHAR(50) NULL,
    `bank_account_name` VARCHAR(255) NULL,
    `is_qris_enabled` TINYINT(1) NOT NULL DEFAULT 1,
    `is_bank_transfer_enabled` TINYINT(1) NOT NULL DEFAULT 1,
    `last_login` DATETIME NULL,
    `login_ip` VARCHAR(45) NULL,
    `email_verified_at` DATETIME NULL,
    `remember_token` VARCHAR(100) NULL,
    `notes` TEXT NULL,
    `reject_reason` TEXT NULL,
    `rejected_at` DATETIME NULL,
    `approved_at` DATETIME NULL,
    `approved_by` INT UNSIGNED NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_merchant_code` (`merchant_code`),
    INDEX `idx_api_key` (`api_key`),
    INDEX `idx_status` (`status`),
    INDEX `idx_email` (`email`),
    -- Concurrent optimization indexes
    INDEX `idx_status_balance` (`status`, `balance`),
    INDEX `idx_id_status` (`id`, `status`),
    CONSTRAINT `fk_merchants_approved_by` FOREIGN KEY (`approved_by`) REFERENCES `admins`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- TABLE: bank_accounts
-- ============================================
CREATE TABLE IF NOT EXISTS `bank_accounts` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `bank_name` VARCHAR(100) NOT NULL,
    `bank_code` VARCHAR(10) NOT NULL,
    `bank_logo` VARCHAR(255) NULL,
    `account_number` VARCHAR(50) NOT NULL,
    `account_name` VARCHAR(255) NOT NULL,
    `account_type` ENUM('regular', 'virtual_account') NOT NULL DEFAULT 'regular',
    `branch` VARCHAR(255) NULL,
    `swift_code` VARCHAR(20) NULL,
    `is_active` TINYINT(1) NOT NULL DEFAULT 1,
    `display_order` INT NOT NULL DEFAULT 0,
    `min_amount` DECIMAL(15,2) NOT NULL DEFAULT 10000,
    `max_amount` DECIMAL(15,2) NOT NULL DEFAULT 100000000,
    `admin_fee` DECIMAL(10,2) NOT NULL DEFAULT 0,
    `description` TEXT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_bank_code` (`bank_code`),
    INDEX `idx_active` (`is_active`),
    INDEX `idx_order` (`display_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- TABLE: payment_codes
-- ============================================
CREATE TABLE IF NOT EXISTS `payment_codes` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `code` INT NOT NULL,
    `merchant_id` INT UNSIGNED NOT NULL,
    `transaction_id` INT UNSIGNED NULL,
    `status` ENUM('available', 'reserved', 'used', 'expired') NOT NULL DEFAULT 'available',
    `reserved_at` DATETIME NULL,
    `used_at` DATETIME NULL,
    `expires_at` DATETIME NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_code` (`code`),
    INDEX `idx_merchant` (`merchant_id`),
    INDEX `idx_status` (`status`),
    INDEX `idx_expires` (`expires_at`),
    -- Concurrent optimization indexes (critical for FOR UPDATE queries)
    INDEX `idx_merchant_status` (`merchant_id`, `status`),
    INDEX `idx_merchant_status_expires` (`merchant_id`, `status`, `expires_at`),
    INDEX `idx_status_expires_used` (`status`, `expires_at`, `used_at`),
    UNIQUE INDEX `idx_merchant_code_unique` (`merchant_id`, `code`),
    CONSTRAINT `fk_payment_codes_merchant` FOREIGN KEY (`merchant_id`) REFERENCES `merchants`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- TABLE: transactions
-- ============================================
CREATE TABLE IF NOT EXISTS `transactions` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `invoice_number` VARCHAR(50) NOT NULL UNIQUE,
    `merchant_id` INT UNSIGNED NOT NULL,
    `payment_code_id` INT UNSIGNED NULL,
    `reference_id` VARCHAR(100) NULL,
    `customer_name` VARCHAR(255) NULL,
    `customer_email` VARCHAR(255) NULL,
    `customer_phone` VARCHAR(20) NULL,
    `description` TEXT NULL,
    `amount` DECIMAL(15,2) NOT NULL,
    `unique_code` INT NOT NULL DEFAULT 0,
    `admin_fee` DECIMAL(10,2) NOT NULL DEFAULT 0,
    `total_amount` DECIMAL(15,2) NOT NULL,
    `commission_amount` DECIMAL(10,2) NOT NULL DEFAULT 0,
    `net_amount` DECIMAL(15,2) NOT NULL DEFAULT 0,
    `payment_method` ENUM('qris', 'bank_transfer', 'virtual_account', 'ewallet') NOT NULL,
    `payment_channel` VARCHAR(50) NULL,
    `bank_account_id` INT UNSIGNED NULL,
    `qris_string` TEXT NULL,
    `qris_image_url` VARCHAR(500) NULL,
    `status` ENUM('pending', 'waiting', 'processing', 'success', 'failed', 'expired', 'refunded', 'cancelled') NOT NULL DEFAULT 'pending',
    `payment_proof` VARCHAR(255) NULL,
    `paid_at` DATETIME NULL,
    `expired_at` DATETIME NOT NULL,
    `verified_by` INT UNSIGNED NULL,
    `verified_at` DATETIME NULL,
    `verification_notes` TEXT NULL,
    `webhook_status` ENUM('pending', 'sent', 'failed', 'success') NOT NULL DEFAULT 'pending',
    `webhook_attempts` INT NOT NULL DEFAULT 0,
    `webhook_last_attempt` DATETIME NULL,
    `webhook_response` TEXT NULL,
    `ip_address` VARCHAR(45) NULL,
    `user_agent` TEXT NULL,
    `metadata` JSON NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_invoice` (`invoice_number`),
    INDEX `idx_merchant` (`merchant_id`),
    INDEX `idx_reference` (`reference_id`),
    INDEX `idx_status` (`status`),
    INDEX `idx_method` (`payment_method`),
    INDEX `idx_created` (`created_at`),
    INDEX `idx_expired` (`expired_at`),
    INDEX `idx_paid_at` (`paid_at`),
    INDEX `idx_unique_amount` (`total_amount`, `status`),
    -- Concurrent optimization indexes (critical for auto-verify and FOR UPDATE)
    INDEX `idx_amount_status_method_created` (`total_amount`, `status`, `payment_method`, `created_at`),
    INDEX `idx_unique_code_status_method` (`unique_code`, `status`, `payment_method`),
    INDEX `idx_merchant_status_created` (`merchant_id`, `status`, `created_at`),
    INDEX `idx_status_method_created` (`status`, `payment_method`, `created_at`),
    INDEX `idx_webhook_status_attempts` (`webhook_status`, `webhook_attempts`),
    INDEX `idx_id_status` (`id`, `status`),
    -- Reporting indexes
    INDEX `idx_merchant_paid_at` (`merchant_id`, `paid_at`),
    INDEX `idx_status_paid_at` (`status`, `paid_at`),
    CONSTRAINT `fk_transactions_merchant` FOREIGN KEY (`merchant_id`) REFERENCES `merchants`(`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_transactions_bank` FOREIGN KEY (`bank_account_id`) REFERENCES `bank_accounts`(`id`) ON DELETE SET NULL,
    CONSTRAINT `fk_transactions_payment_code` FOREIGN KEY (`payment_code_id`) REFERENCES `payment_codes`(`id`) ON DELETE SET NULL,
    CONSTRAINT `fk_transactions_verified_by` FOREIGN KEY (`verified_by`) REFERENCES `admins`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- TABLE: settlements
-- ============================================
CREATE TABLE IF NOT EXISTS `settlements` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `settlement_number` VARCHAR(50) NOT NULL UNIQUE,
    `merchant_id` INT UNSIGNED NOT NULL,
    `amount` DECIMAL(15,2) NOT NULL,
    `admin_fee` DECIMAL(10,2) NOT NULL DEFAULT 0,
    `net_amount` DECIMAL(15,2) NOT NULL,
    `bank_name` VARCHAR(100) NOT NULL,
    `bank_account_number` VARCHAR(50) NOT NULL,
    `bank_account_name` VARCHAR(255) NOT NULL,
    `status` ENUM('pending', 'processing', 'completed', 'rejected', 'cancelled') NOT NULL DEFAULT 'pending',
    `processed_by` INT UNSIGNED NULL,
    `processed_at` DATETIME NULL,
    `transfer_proof` VARCHAR(255) NULL,
    `transfer_reference` VARCHAR(100) NULL,
    `rejection_reason` TEXT NULL,
    `notes` TEXT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_settlement_number` (`settlement_number`),
    INDEX `idx_merchant` (`merchant_id`),
    INDEX `idx_status` (`status`),
    INDEX `idx_created` (`created_at`),
    -- Concurrent optimization indexes (critical for pending settlement check)
    INDEX `idx_merchant_status_created` (`merchant_id`, `status`, `created_at`),
    INDEX `idx_merchant_status` (`merchant_id`, `status`),
    CONSTRAINT `fk_settlements_merchant` FOREIGN KEY (`merchant_id`) REFERENCES `merchants`(`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_settlements_processed_by` FOREIGN KEY (`processed_by`) REFERENCES `admins`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- TABLE: balance_logs
-- ============================================
CREATE TABLE IF NOT EXISTS `balance_logs` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `merchant_id` INT UNSIGNED NOT NULL,
    `transaction_id` INT UNSIGNED NULL,
    `settlement_id` INT UNSIGNED NULL,
    `type` ENUM('credit', 'debit', 'adjustment', 'refund', 'fee') NOT NULL,
    `amount` DECIMAL(15,2) NOT NULL,
    `balance_before` DECIMAL(15,2) NOT NULL,
    `balance_after` DECIMAL(15,2) NOT NULL,
    `description` VARCHAR(500) NOT NULL,
    `reference` VARCHAR(100) NULL,
    `created_by` INT UNSIGNED NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_merchant` (`merchant_id`),
    INDEX `idx_type` (`type`),
    INDEX `idx_created` (`created_at`),
    -- Concurrent optimization indexes
    INDEX `idx_merchant_created_type` (`merchant_id`, `created_at`, `type`),
    INDEX `idx_transaction_type` (`transaction_id`, `type`),
    INDEX `idx_settlement_type` (`settlement_id`, `type`),
    CONSTRAINT `fk_balance_logs_merchant` FOREIGN KEY (`merchant_id`) REFERENCES `merchants`(`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_balance_logs_created_by` FOREIGN KEY (`created_by`) REFERENCES `admins`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- TABLE: notifications
-- ============================================
CREATE TABLE IF NOT EXISTS `notifications` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `merchant_id` INT UNSIGNED NOT NULL,
    `type` ENUM('payment', 'settlement', 'system', 'alert', 'promotion') NOT NULL,
    `title` VARCHAR(255) NOT NULL,
    `message` TEXT NOT NULL,
    `action_url` VARCHAR(500) NULL,
    `icon` VARCHAR(50) NULL,
    `is_read` TINYINT(1) NOT NULL DEFAULT 0,
    `read_at` DATETIME NULL,
    `metadata` JSON NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_merchant` (`merchant_id`),
    INDEX `idx_read` (`is_read`),
    INDEX `idx_type` (`type`),
    INDEX `idx_created` (`created_at`),
    -- Composite index for unread notifications per merchant (common query)
    INDEX `idx_merchant_read` (`merchant_id`, `is_read`),
    INDEX `idx_merchant_created` (`merchant_id`, `created_at`),
    CONSTRAINT `fk_notifications_merchant` FOREIGN KEY (`merchant_id`) REFERENCES `merchants`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- TABLE: activity_logs
-- ============================================
CREATE TABLE IF NOT EXISTS `activity_logs` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_type` ENUM('admin', 'merchant', 'system', 'api') NOT NULL,
    `user_id` INT UNSIGNED NULL,
    `action` VARCHAR(100) NOT NULL,
    `module` VARCHAR(50) NOT NULL,
    `description` TEXT NULL,
    `old_values` JSON NULL,
    `new_values` JSON NULL,
    `ip_address` VARCHAR(45) NULL,
    `user_agent` TEXT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_user` (`user_type`, `user_id`),
    INDEX `idx_action` (`action`),
    INDEX `idx_module` (`module`),
    INDEX `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- TABLE: system_settings
-- ============================================
CREATE TABLE IF NOT EXISTS `system_settings` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `setting_key` VARCHAR(100) NOT NULL UNIQUE,
    `setting_value` TEXT NULL,
    `setting_type` ENUM('string', 'integer', 'boolean', 'json', 'text') NOT NULL DEFAULT 'string',
    `category` VARCHAR(50) NOT NULL DEFAULT 'general',
    `description` VARCHAR(500) NULL,
    `is_public` TINYINT(1) NOT NULL DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_key` (`setting_key`),
    INDEX `idx_category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- TABLE: api_logs
-- ============================================
CREATE TABLE IF NOT EXISTS `api_logs` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `merchant_id` INT UNSIGNED NULL,
    `endpoint` VARCHAR(255) NOT NULL,
    `method` VARCHAR(10) NOT NULL,
    `request_headers` JSON NULL,
    `request_body` JSON NULL,
    `response_code` INT NULL,
    `response_body` JSON NULL,
    `ip_address` VARCHAR(45) NULL,
    `execution_time` DECIMAL(8,4) NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_merchant` (`merchant_id`),
    INDEX `idx_endpoint` (`endpoint`),
    INDEX `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- TABLE: webhook_logs
-- ============================================
CREATE TABLE IF NOT EXISTS `webhook_logs` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `transaction_id` INT UNSIGNED NOT NULL,
    `merchant_id` INT UNSIGNED NOT NULL,
    `webhook_url` VARCHAR(500) NOT NULL,
    `request_payload` JSON NOT NULL,
    `response_code` INT NULL,
    `response_body` TEXT NULL,
    `status` ENUM('pending', 'success', 'failed') NOT NULL DEFAULT 'pending',
    `attempt_number` INT NOT NULL DEFAULT 1,
    `error_message` TEXT NULL,
    `execution_time` DECIMAL(8,4) NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_transaction` (`transaction_id`),
    INDEX `idx_merchant` (`merchant_id`),
    INDEX `idx_status` (`status`),
    INDEX `idx_created` (`created_at`),
    -- Concurrent optimization indexes (for idempotency checks)
    INDEX `idx_transaction_status_created` (`transaction_id`, `status`, `created_at`),
    CONSTRAINT `fk_webhook_logs_transaction` FOREIGN KEY (`transaction_id`) REFERENCES `transactions`(`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_webhook_logs_merchant` FOREIGN KEY (`merchant_id`) REFERENCES `merchants`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- TABLE: password_resets
-- ============================================
CREATE TABLE IF NOT EXISTS `password_resets` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `email` VARCHAR(255) NOT NULL,
    `token` VARCHAR(255) NOT NULL,
    `user_type` ENUM('admin', 'merchant') NOT NULL,
    `expires_at` DATETIME NOT NULL,
    `used_at` DATETIME NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_email` (`email`),
    INDEX `idx_token` (`token`),
    INDEX `idx_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- INSERT DEFAULT DATA
-- ============================================

-- Default Admin (password: admin123)
INSERT INTO `admins` (`username`, `email`, `password`, `full_name`, `role`, `is_active`) VALUES
('admin', 'admin@neopga.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Super Administrator', 'super_admin', 1);

-- Bank Accounts
INSERT INTO `bank_accounts` (`bank_name`, `bank_code`, `account_number`, `account_name`, `is_active`, `display_order`, `admin_fee`) VALUES
('Bank Central Asia (BCA)', 'BCA', '1234567890', 'PT NEO PGA INDONESIA', 1, 1, 0),
('Bank Mandiri', 'MANDIRI', '1234567890123', 'PT NEO PGA INDONESIA', 1, 2, 0),
('Bank Negara Indonesia (BNI)', 'BNI', '0123456789', 'PT NEO PGA INDONESIA', 1, 3, 0),
('Bank Rakyat Indonesia (BRI)', 'BRI', '012345678901234', 'PT NEO PGA INDONESIA', 1, 4, 0),
('Bank CIMB Niaga', 'CIMB', '760123456789', 'PT NEO PGA INDONESIA', 1, 5, 0);

-- Demo Merchant (password: admin123)
-- PENTING: Ganti kredensial demo ini setelah setup production!
INSERT INTO `merchants` (`merchant_code`, `email`, `password`, `business_name`, `business_type`, `owner_name`, `phone`, `api_key`, `secret_key`, `status`, `commission_rate`, `balance`) VALUES
('DEMO001', 'demo@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Demo Store', 'individual', 'Demo User', '081234567890', 'nb_live_REPLACE_THIS_API_KEY', 'nb_secret_REPLACE_THIS_SECRET_KEY', 'active', 2.50, 0.00);

-- System Settings
INSERT INTO `system_settings` (`setting_key`, `setting_value`, `setting_type`, `category`, `description`, `is_public`) VALUES
-- General
('app_name', 'NEO PGA', 'string', 'general', 'Application name', 1),
('app_tagline', 'Modern Payment Gateway for Indonesia', 'string', 'general', 'Application tagline', 1),
('app_version', '2.0.0', 'string', 'general', 'Application version', 1),
('app_logo', '/assets/images/logo.png', 'string', 'general', 'Logo path', 1),
('app_favicon', '/assets/images/favicon.ico', 'string', 'general', 'Favicon path', 1),
('company_name', 'PT NEO PGA Indonesia', 'string', 'general', 'Company name', 1),
('company_address', 'Jakarta, Indonesia', 'string', 'general', 'Company address', 1),
('company_phone', '+62 21 1234567', 'string', 'general', 'Company phone', 1),
('company_email', 'info@neopga.com', 'string', 'general', 'Company email', 1),
('support_email', 'support@neopga.com', 'string', 'general', 'Support email', 1),

-- Payment Settings
('default_commission_rate', '2.50', 'string', 'payment', 'Default commission rate (%)', 0),
('payment_expiry_minutes', '60', 'integer', 'payment', 'Payment expiry (minutes)', 0),
('min_transaction_amount', '10000', 'integer', 'payment', 'Minimum amount', 0),
('max_transaction_amount', '100000000', 'integer', 'payment', 'Maximum amount', 0),
('auto_settlement_enabled', '0', 'boolean', 'payment', 'Auto settlement', 0),
('settlement_min_amount', '100000', 'integer', 'payment', 'Min settlement amount', 0),

-- QRIS Settings
('qris_enabled', '1', 'boolean', 'qris', 'Enable QRIS', 0),
('qris_dynamic_enabled', '1', 'boolean', 'qris', 'Enable dynamic QRIS', 0),
('qris_unique_code_enabled', '1', 'boolean', 'qris', 'Enable unique code', 0),
('qris_unique_code_min', '1', 'integer', 'qris', 'Min unique code', 0),
('qris_unique_code_max', '999', 'integer', 'qris', 'Max unique code', 0),
('qris_merchant_name', 'NEO PGA', 'string', 'qris', 'QRIS merchant name', 0),
('qris_merchant_city', 'JAKARTA', 'string', 'qris', 'QRIS merchant city', 0),
('qris_static_code', '00020101021126670016COM.NOBUBANK.WWW01189360050300000898240214149391352416240303UMI51440014ID.CO.QRIS.WWW0215ID20232915461850303UMI5204541153033605802ID5910NEO PGA6007JAKARTA61051034062070703A016304', 'text', 'qris', 'Static QRIS code', 0),
('qris_nmid', '', 'string', 'qris', 'QRIS NMID', 0),
('qris_gopay_id', '', 'string', 'qris', 'GoPay ID untuk QRIS', 0),
('qris_gopay_short', '', 'string', 'qris', 'GoPay Short ID', 0),
('qris_acquirer', 'GOPAY', 'string', 'qris', 'QRIS Acquirer', 0),
('qris_display_name', 'NEO PGA', 'string', 'qris', 'QRIS Display Name', 0),
('qris_city', 'JAKARTA', 'string', 'qris', 'QRIS City', 0),
('qris_mcc', '5411', 'string', 'qris', 'QRIS MCC Code', 0),

-- Bank Transfer Settings
('bank_transfer_enabled', '1', 'boolean', 'bank', 'Enable bank transfer', 0),
('unique_code_type', 'last_digits', 'string', 'bank', 'Unique code type', 0),

-- Webhook Settings
('webhook_enabled', '1', 'boolean', 'webhook', 'Enable webhook', 0),
('webhook_retry_attempts', '3', 'integer', 'webhook', 'Retry attempts', 0),
('webhook_retry_delay', '60', 'integer', 'webhook', 'Retry delay (seconds)', 0),
('webhook_timeout', '30', 'integer', 'webhook', 'Timeout (seconds)', 0),

-- Security Settings
('maintenance_mode', '0', 'boolean', 'security', 'Maintenance mode', 0),
('api_rate_limit', '100', 'integer', 'security', 'API rate limit/minute', 0),
('session_lifetime', '120', 'integer', 'security', 'Session lifetime (minutes)', 0),
('force_https', '1', 'boolean', 'security', 'Force HTTPS', 0);

-- Initialize payment codes for demo merchant
INSERT INTO `payment_codes` (`code`, `merchant_id`, `status`) VALUES
(1, 1, 'available'), (2, 1, 'available'), (3, 1, 'available'), (4, 1, 'available'), (5, 1, 'available'),
(6, 1, 'available'), (7, 1, 'available'), (8, 1, 'available'), (9, 1, 'available'), (10, 1, 'available'),
(11, 1, 'available'), (12, 1, 'available'), (13, 1, 'available'), (14, 1, 'available'), (15, 1, 'available'),
(16, 1, 'available'), (17, 1, 'available'), (18, 1, 'available'), (19, 1, 'available'), (20, 1, 'available'),
(100, 1, 'available'), (200, 1, 'available'), (300, 1, 'available'), (400, 1, 'available'), (500, 1, 'available'),
(600, 1, 'available'), (700, 1, 'available'), (800, 1, 'available'), (900, 1, 'available'), (999, 1, 'available');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

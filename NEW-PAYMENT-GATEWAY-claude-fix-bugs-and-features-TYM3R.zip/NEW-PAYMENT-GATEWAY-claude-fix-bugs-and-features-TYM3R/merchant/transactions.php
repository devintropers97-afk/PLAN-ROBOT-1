<?php
/**
 * NEO PGA - Merchant Transactions
 * Using Layout Template v2
 */
require_once __DIR__ . '/../includes/init.php';

// Page settings for layout
$pageTitle = 'Transaksi';
$currentPage = 'transactions';

// Include layout header (handles auth check)
include 'layout_header.php';

// Filters
$status = $_GET['status'] ?? '';
$method = $_GET['method'] ?? '';
$search = $_GET['search'] ?? '';
$dateFrom = $_GET['date_from'] ?? '';
$dateTo = $_GET['date_to'] ?? '';

$where = "merchant_id = ?";
$params = [$merchantId];

if ($status) {
    $where .= " AND status = ?";
    $params[] = $status;
}

if ($method) {
    $where .= " AND payment_method = ?";
    $params[] = $method;
}

if ($search) {
    $where .= " AND (invoice_number LIKE ? OR reference_id LIKE ? OR customer_name LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if ($dateFrom) {
    $where .= " AND DATE(created_at) >= ?";
    $params[] = $dateFrom;
}

if ($dateTo) {
    $where .= " AND DATE(created_at) <= ?";
    $params[] = $dateTo;
}

// Pagination
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 20;
$offset = ($page - 1) * $perPage;

$totalTransactions = $db->fetch("SELECT COUNT(*) as count FROM transactions WHERE $where", $params)['count'];
$totalPages = ceil($totalTransactions / $perPage);

$transactions = $db->fetchAll(
    "SELECT * FROM transactions WHERE $where ORDER BY created_at DESC LIMIT $perPage OFFSET $offset",
    $params
);

// Stats
$stats = [
    'total' => $db->fetch("SELECT COUNT(*) as c FROM transactions WHERE merchant_id = ?", [$merchantId])['c'],
    'success' => $db->fetch("SELECT COUNT(*) as c FROM transactions WHERE merchant_id = ? AND status = 'success'", [$merchantId])['c'],
    'pending' => $db->fetch("SELECT COUNT(*) as c FROM transactions WHERE merchant_id = ? AND status = 'pending'", [$merchantId])['c'],
    'total_amount' => $db->fetch("SELECT COALESCE(SUM(total_amount), 0) as s FROM transactions WHERE merchant_id = ? AND status = 'success'", [$merchantId])['s'],
];

// Build query string for pagination (excluding page param)
$queryParams = $_GET;
unset($queryParams['page']);
$queryString = http_build_query($queryParams);
?>

<style>
    /* Transaction page specific styles */
    .mini-stats {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 1rem;
        margin-bottom: 1.5rem;
    }

    .mini-stat {
        background: white;
        border-radius: 12px;
        padding: 1.25rem;
        border: 1px solid var(--gray-200);
    }

    .mini-stat-label {
        font-size: 0.8rem;
        color: var(--gray-500);
        margin-bottom: 0.5rem;
    }

    .mini-stat-value {
        font-size: 1.5rem;
        font-weight: 700;
        color: var(--gray-900);
    }

    .mini-stat-value.success { color: var(--success); }
    .mini-stat-value.warning { color: var(--warning); }
    .mini-stat-value.primary { color: var(--primary); }

    /* Filter Card */
    .filter-card {
        background: white;
        border-radius: 12px;
        padding: 1.25rem;
        border: 1px solid var(--gray-200);
        margin-bottom: 1.5rem;
    }

    .filter-form {
        display: grid;
        grid-template-columns: 2fr 1fr 1fr 1fr 1fr auto;
        gap: 1rem;
        align-items: end;
    }

    .form-group {
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
    }

    .form-label {
        font-size: 0.75rem;
        font-weight: 600;
        color: var(--gray-600);
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }

    .form-input,
    .form-select {
        width: 100%;
        padding: 0.625rem 0.875rem;
        border: 1px solid var(--gray-300);
        border-radius: 8px;
        font-size: 0.9rem;
        font-family: inherit;
        background: white;
        color: var(--gray-900);
        transition: all 0.2s;
    }

    .form-input:focus,
    .form-select:focus {
        outline: none;
        border-color: var(--primary);
        box-shadow: 0 0 0 3px rgba(13, 148, 136, 0.1);
    }

    /* Table Card */
    .table-card {
        background: white;
        border-radius: 12px;
        border: 1px solid var(--gray-200);
        overflow: hidden;
    }

    .table-wrapper {
        overflow-x: auto;
    }

    .table {
        width: 100%;
        border-collapse: collapse;
    }

    .table th {
        background: var(--gray-50);
        padding: 0.875rem 1rem;
        text-align: left;
        font-size: 0.75rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: var(--gray-600);
        border-bottom: 1px solid var(--gray-200);
    }

    .table td {
        padding: 1rem;
        border-bottom: 1px solid var(--gray-100);
        font-size: 0.875rem;
        color: var(--gray-700);
        vertical-align: middle;
    }

    .table tbody tr:hover {
        background: var(--gray-50);
    }

    .table code {
        font-family: var(--font-mono);
        font-size: 0.8rem;
        background: var(--gray-100);
        padding: 0.25rem 0.5rem;
        border-radius: 6px;
        color: var(--primary);
    }

    .customer-info {
        line-height: 1.4;
    }

    .customer-name {
        font-weight: 500;
        color: var(--gray-800);
    }

    .customer-email {
        font-size: 0.75rem;
        color: var(--gray-500);
    }

    .amount-cell {
        font-family: var(--font-mono);
        font-weight: 600;
        color: var(--gray-900);
    }

    .amount-unique {
        font-size: 0.75rem;
        color: var(--gray-500);
    }

    .time-cell {
        line-height: 1.4;
    }

    .time-date {
        font-weight: 500;
        color: var(--gray-700);
    }

    .time-hour {
        font-size: 0.75rem;
        color: var(--gray-500);
    }

    /* Badges */
    .badge {
        display: inline-flex;
        align-items: center;
        padding: 0.25rem 0.625rem;
        font-size: 0.7rem;
        font-weight: 600;
        border-radius: 6px;
        text-transform: uppercase;
        letter-spacing: 0.02em;
    }

    .badge-primary {
        background: var(--primary-50);
        color: var(--primary);
    }

    .badge-success {
        background: var(--success-light);
        color: #065f46;
    }

    .badge-warning {
        background: var(--warning-light);
        color: #92400e;
    }

    .badge-danger {
        background: var(--danger-light);
        color: #991b1b;
    }

    .badge-neutral {
        background: var(--gray-100);
        color: var(--gray-600);
    }

    /* Action Buttons */
    .action-btns {
        display: flex;
        gap: 0.5rem;
    }

    .btn-icon {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 32px;
        height: 32px;
        border-radius: 8px;
        border: none;
        cursor: pointer;
        text-decoration: none;
        transition: all 0.2s;
    }

    .btn-icon svg {
        width: 16px;
        height: 16px;
    }

    .btn-icon-ghost {
        background: transparent;
        color: var(--gray-500);
    }

    .btn-icon-ghost:hover {
        background: var(--gray-100);
        color: var(--gray-700);
    }

    .btn-icon-primary {
        background: var(--primary);
        color: white;
    }

    .btn-icon-primary:hover {
        background: var(--primary-dark);
    }

    /* Buttons */
    .btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 0.5rem;
        padding: 0.625rem 1.25rem;
        border-radius: 8px;
        font-size: 0.875rem;
        font-weight: 500;
        text-decoration: none;
        cursor: pointer;
        border: none;
        transition: all 0.2s;
        font-family: inherit;
    }

    .btn-primary {
        background: var(--primary);
        color: white;
    }

    .btn-primary:hover {
        background: var(--primary-dark);
    }

    .btn-secondary {
        background: var(--gray-100);
        color: var(--gray-700);
        border: 1px solid var(--gray-300);
    }

    .btn-secondary:hover {
        background: var(--gray-200);
    }

    .btn-sm {
        padding: 0.5rem 0.875rem;
        font-size: 0.8rem;
    }

    /* Pagination */
    .table-footer {
        padding: 1rem 1.5rem;
        border-top: 1px solid var(--gray-200);
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .pagination-info {
        font-size: 0.875rem;
        color: var(--gray-500);
    }

    .pagination-btns {
        display: flex;
        gap: 0.5rem;
    }

    /* Empty State */
    .empty-state {
        padding: 3rem;
        text-align: center;
        color: var(--gray-400);
    }

    .empty-state svg {
        width: 48px;
        height: 48px;
        margin-bottom: 1rem;
        opacity: 0.5;
    }

    /* Responsive */
    @media (max-width: 1200px) {
        .mini-stats {
            grid-template-columns: repeat(2, 1fr);
        }

        .filter-form {
            grid-template-columns: 1fr 1fr;
        }
    }

    @media (max-width: 768px) {
        .mini-stats {
            grid-template-columns: 1fr;
        }

        .filter-form {
            grid-template-columns: 1fr;
        }
    }
</style>

<!-- Mini Stats -->
<div class="mini-stats">
    <div class="mini-stat">
        <div class="mini-stat-label">Total Transaksi</div>
        <div class="mini-stat-value"><?= number_format($stats['total']) ?></div>
    </div>
    <div class="mini-stat">
        <div class="mini-stat-label">Sukses</div>
        <div class="mini-stat-value success"><?= number_format($stats['success']) ?></div>
    </div>
    <div class="mini-stat">
        <div class="mini-stat-label">Pending</div>
        <div class="mini-stat-value warning"><?= number_format($stats['pending']) ?></div>
    </div>
    <div class="mini-stat">
        <div class="mini-stat-label">Total Volume</div>
        <div class="mini-stat-value primary"><?= formatRupiah($stats['total_amount']) ?></div>
    </div>
</div>

<!-- Filter -->
<div class="filter-card">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
        <h3 style="margin: 0; font-size: 1rem; color: var(--gray-700);">Filter & Export</h3>
        <div class="export-btns" style="display: flex; gap: 0.5rem;">
            <a href="export.php?format=csv<?= $queryString ? '&' . $queryString : '' ?>" class="btn btn-sm btn-secondary" title="Export ke CSV">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="16" height="16"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                CSV
            </a>
            <a href="export.php?format=excel<?= $queryString ? '&' . $queryString : '' ?>" class="btn btn-sm btn-success" title="Export ke Excel" style="background: #059669; color: white;">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="16" height="16"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                Excel
            </a>
        </div>
    </div>
    <form method="GET" class="filter-form">
        <div class="form-group">
            <label class="form-label">Pencarian</label>
            <input type="text" name="search" placeholder="Invoice / Reference / Nama..." value="<?= htmlspecialchars($search) ?>" class="form-input">
        </div>
        <div class="form-group">
            <label class="form-label">Status</label>
            <select name="status" class="form-select">
                <option value="">Semua Status</option>
                <option value="pending" <?= $status === 'pending' ? 'selected' : '' ?>>Pending</option>
                <option value="success" <?= $status === 'success' ? 'selected' : '' ?>>Success</option>
                <option value="failed" <?= $status === 'failed' ? 'selected' : '' ?>>Failed</option>
                <option value="expired" <?= $status === 'expired' ? 'selected' : '' ?>>Expired</option>
            </select>
        </div>
        <div class="form-group">
            <label class="form-label">Metode</label>
            <select name="method" class="form-select">
                <option value="">Semua Metode</option>
                <option value="qris" <?= $method === 'qris' ? 'selected' : '' ?>>QRIS</option>
                <option value="bank_transfer" <?= $method === 'bank_transfer' ? 'selected' : '' ?>>Bank Transfer</option>
            </select>
        </div>
        <div class="form-group">
            <label class="form-label">Dari Tanggal</label>
            <input type="date" name="date_from" value="<?= $dateFrom ?>" class="form-input">
        </div>
        <div class="form-group">
            <label class="form-label">Sampai Tanggal</label>
            <input type="date" name="date_to" value="<?= $dateTo ?>" class="form-input">
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-primary">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="16" height="16"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
                Filter
            </button>
        </div>
    </form>
</div>

<!-- Transactions Table -->
<div class="table-card">
    <div class="table-wrapper">
        <table class="table">
            <thead>
                <tr>
                    <th>Invoice</th>
                    <th>Reference</th>
                    <th>Customer</th>
                    <th>Jumlah</th>
                    <th>Metode</th>
                    <th>Status</th>
                    <th>Waktu</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($transactions)): ?>
                <tr>
                    <td colspan="8">
                        <div class="empty-state">
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/>
                            </svg>
                            <p>Tidak ada transaksi ditemukan</p>
                        </div>
                    </td>
                </tr>
                <?php else: ?>
                <?php foreach ($transactions as $trx): ?>
                <tr>
                    <td><code><?= htmlspecialchars($trx['invoice_number']) ?></code></td>
                    <td style="font-size: 0.8rem; color: var(--gray-500);"><?= htmlspecialchars($trx['reference_id'] ?: '-') ?></td>
                    <td>
                        <div class="customer-info">
                            <div class="customer-name"><?= htmlspecialchars($trx['customer_name'] ?: '-') ?></div>
                            <?php if (!empty($trx['customer_email'])): ?>
                            <div class="customer-email"><?= htmlspecialchars($trx['customer_email']) ?></div>
                            <?php endif; ?>
                        </div>
                    </td>
                    <td>
                        <div class="amount-cell"><?= formatRupiah($trx['total_amount']) ?></div>
                        <?php if ($trx['unique_code'] > 0): ?>
                        <div class="amount-unique">+<?= number_format($trx['unique_code']) ?></div>
                        <?php endif; ?>
                    </td>
                    <td><span class="badge badge-primary"><?= strtoupper($trx['payment_method']) ?></span></td>
                    <td>
                        <?php 
                        $statusBadge = [
                            'pending' => 'badge-warning',
                            'success' => 'badge-success',
                            'failed' => 'badge-danger',
                            'expired' => 'badge-neutral',
                            'cancelled' => 'badge-neutral',
                        ][$trx['status']] ?? 'badge-neutral';
                        ?>
                        <span class="badge <?= $statusBadge ?>"><?= ucfirst($trx['status']) ?></span>
                    </td>
                    <td>
                        <div class="time-cell">
                            <div class="time-date"><?= date('d/m/Y', strtotime($trx['created_at'])) ?></div>
                            <div class="time-hour"><?= date('H:i', strtotime($trx['created_at'])) ?></div>
                        </div>
                    </td>
                    <td>
                        <div class="action-btns">
                            <a href="transaction-detail.php?id=<?= $trx['id'] ?>" class="btn-icon btn-icon-ghost" title="Detail">
                                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                                </svg>
                            </a>
                            <?php if ($trx['status'] === 'pending'): ?>
                            <a href="<?= PUBLIC_URL ?>/pay.php?invoice=<?= $trx['invoice_number'] ?>" target="_blank" class="btn-icon btn-icon-primary" title="Payment Link">
                                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/>
                                </svg>
                            </a>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    
    <?php if ($totalPages > 1): ?>
    <div class="table-footer">
        <div class="pagination-info">
            Halaman <?= $page ?> dari <?= $totalPages ?> (<?= number_format($totalTransactions) ?> transaksi)
        </div>
        <div class="pagination-btns">
            <?php if ($page > 1): ?>
            <a href="?page=<?= $page - 1 ?><?= $queryString ? '&' . $queryString : '' ?>" class="btn btn-sm btn-secondary">← Prev</a>
            <?php endif; ?>
            <?php if ($page < $totalPages): ?>
            <a href="?page=<?= $page + 1 ?><?= $queryString ? '&' . $queryString : '' ?>" class="btn btn-sm btn-secondary">Next →</a>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php include 'layout_footer.php'; ?>

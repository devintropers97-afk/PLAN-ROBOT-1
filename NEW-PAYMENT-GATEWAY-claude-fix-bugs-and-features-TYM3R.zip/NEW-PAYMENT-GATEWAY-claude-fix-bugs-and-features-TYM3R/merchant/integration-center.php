<?php
/**
 * NEO PGA Merchant Dashboard - Integration Center
 * Pusat integrasi untuk merchant dengan download SDK dan dokumentasi
 */

$pageTitle = 'Integration Center';
$currentPage = 'integration-center';
require_once 'layout_header.php';

// Get API credentials for display
$apiKey = $merchant['api_key'] ?? '';
$secretKey = $merchant['secret_key'] ?? '';
$webhookUrl = $merchant['webhook_url'] ?? '';
$baseUrl = APP_URL;
?>

<style>
    .integration-hero {
        background: linear-gradient(135deg, var(--primary-600) 0%, var(--primary-800) 100%);
        border-radius: 20px;
        padding: 32px 24px;
        color: white;
        margin-bottom: 24px;
        position: relative;
        overflow: hidden;
    }
    .integration-hero::before {
        content: '';
        position: absolute;
        top: -50%;
        right: -20%;
        width: 400px;
        height: 400px;
        background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
        pointer-events: none;
    }
    .integration-hero h2 {
        font-size: 1.5rem;
        font-weight: 700;
        margin-bottom: 8px;
        position: relative;
    }
    .integration-hero p {
        opacity: 0.9;
        font-size: 0.9375rem;
        position: relative;
    }

    .option-grid {
        display: grid;
        grid-template-columns: 1fr;
        gap: 20px;
        margin-bottom: 32px;
    }
    @media (min-width: 768px) {
        .option-grid {
            grid-template-columns: repeat(2, 1fr);
        }
    }

    .option-card {
        background: #fff;
        border-radius: 16px;
        border: 2px solid var(--gray-200);
        padding: 24px;
        transition: all 0.3s;
        cursor: pointer;
        position: relative;
    }
    .option-card:hover {
        border-color: var(--primary-500);
        box-shadow: 0 8px 25px rgba(16, 185, 129, 0.15);
        transform: translateY(-2px);
    }
    .option-card.recommended {
        border-color: var(--primary-500);
    }
    .option-card.recommended::before {
        content: 'POPULER';
        position: absolute;
        top: -1px;
        right: 20px;
        background: linear-gradient(135deg, var(--primary-500), var(--primary-600));
        color: white;
        font-size: 0.6875rem;
        font-weight: 700;
        padding: 4px 12px;
        border-radius: 0 0 8px 8px;
    }

    .option-icon {
        width: 56px;
        height: 56px;
        border-radius: 14px;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-bottom: 16px;
    }
    .option-icon svg {
        width: 28px;
        height: 28px;
    }
    .option-icon.primary {
        background: var(--primary-100);
        color: var(--primary-600);
    }
    .option-icon.blue {
        background: var(--info-light);
        color: var(--info);
    }
    .option-icon.orange {
        background: var(--warning-light);
        color: var(--warning);
    }
    .option-icon.purple {
        background: #f3e8ff;
        color: #9333ea;
    }

    .option-title {
        font-size: 1.125rem;
        font-weight: 700;
        color: var(--gray-900);
        margin-bottom: 8px;
    }
    .option-desc {
        font-size: 0.875rem;
        color: var(--gray-500);
        line-height: 1.6;
        margin-bottom: 16px;
    }
    .option-features {
        list-style: none;
        margin-bottom: 20px;
    }
    .option-features li {
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 0.8125rem;
        color: var(--gray-600);
        margin-bottom: 8px;
    }
    .option-features li svg {
        width: 16px;
        height: 16px;
        color: var(--success);
        flex-shrink: 0;
    }

    .option-price {
        display: flex;
        align-items: baseline;
        gap: 4px;
        margin-bottom: 16px;
    }
    .option-price .amount {
        font-size: 1.5rem;
        font-weight: 800;
        color: var(--gray-900);
    }
    .option-price .label {
        font-size: 0.8125rem;
        color: var(--gray-500);
    }
    .option-price.free .amount {
        color: var(--success);
    }

    .sdk-grid {
        display: grid;
        grid-template-columns: 1fr;
        gap: 16px;
    }
    @media (min-width: 768px) {
        .sdk-grid {
            grid-template-columns: repeat(2, 1fr);
        }
    }

    .sdk-card {
        background: #fff;
        border-radius: 16px;
        border: 1px solid var(--gray-200);
        padding: 20px;
    }
    .sdk-header {
        display: flex;
        align-items: center;
        gap: 12px;
        margin-bottom: 12px;
    }
    .sdk-badge {
        font-size: 0.6875rem;
        font-weight: 600;
        padding: 4px 10px;
        border-radius: 100px;
        background: var(--primary-100);
        color: var(--primary-700);
    }
    .sdk-badge.full {
        background: var(--info-light);
        color: #1e40af;
    }
    .sdk-name {
        font-size: 1rem;
        font-weight: 700;
        color: var(--gray-900);
    }
    .sdk-desc {
        font-size: 0.8125rem;
        color: var(--gray-500);
        margin-bottom: 16px;
        line-height: 1.5;
    }
    .sdk-use-case {
        background: var(--gray-50);
        border-radius: 10px;
        padding: 12px;
        margin-bottom: 16px;
    }
    .sdk-use-case h5 {
        font-size: 0.75rem;
        font-weight: 600;
        color: var(--gray-500);
        text-transform: uppercase;
        letter-spacing: 0.05em;
        margin-bottom: 8px;
    }
    .sdk-use-case ul {
        list-style: none;
    }
    .sdk-use-case li {
        font-size: 0.8125rem;
        color: var(--gray-700);
        padding: 4px 0;
        display: flex;
        align-items: center;
        gap: 6px;
    }
    .sdk-use-case li::before {
        content: '•';
        color: var(--primary-500);
        font-weight: bold;
    }

    .download-btn {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        width: 100%;
        padding: 12px 20px;
        background: linear-gradient(135deg, var(--primary-500), var(--primary-600));
        color: white;
        border: none;
        border-radius: 10px;
        font-size: 0.875rem;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.2s;
    }
    .download-btn:hover {
        box-shadow: 0 4px 15px rgba(16, 185, 129, 0.35);
        transform: translateY(-1px);
    }
    .download-btn svg {
        width: 18px;
        height: 18px;
    }

    .section-title {
        font-size: 1.125rem;
        font-weight: 700;
        color: var(--gray-900);
        margin-bottom: 16px;
        display: flex;
        align-items: center;
        gap: 10px;
    }
    .section-title svg {
        width: 24px;
        height: 24px;
        color: var(--primary-600);
    }

    .step-list {
        counter-reset: step;
    }
    .step-item {
        display: flex;
        gap: 16px;
        margin-bottom: 24px;
        padding-bottom: 24px;
        border-bottom: 1px solid var(--gray-100);
    }
    .step-item:last-child {
        border-bottom: none;
        margin-bottom: 0;
        padding-bottom: 0;
    }
    .step-number {
        width: 32px;
        height: 32px;
        background: var(--primary-100);
        color: var(--primary-700);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 0.875rem;
        font-weight: 700;
        flex-shrink: 0;
    }
    .step-content h4 {
        font-size: 0.9375rem;
        font-weight: 600;
        color: var(--gray-900);
        margin-bottom: 6px;
    }
    .step-content p {
        font-size: 0.8125rem;
        color: var(--gray-500);
        line-height: 1.6;
    }
    .step-content code {
        font-family: 'JetBrains Mono', monospace;
        font-size: 0.75rem;
        background: var(--gray-100);
        padding: 2px 6px;
        border-radius: 4px;
        color: var(--gray-700);
    }

    .file-list {
        background: var(--gray-50);
        border-radius: 12px;
        padding: 16px;
        margin-top: 12px;
    }
    .file-item {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 8px 0;
        font-size: 0.8125rem;
        color: var(--gray-700);
    }
    .file-item svg {
        width: 18px;
        height: 18px;
        color: var(--gray-400);
    }
    .file-item strong {
        color: var(--gray-900);
    }

    .admin-setup-card {
        background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
        border: 2px solid #f59e0b;
    }
    .admin-setup-card .option-title {
        color: #92400e;
    }

    .credentials-box {
        background: var(--gray-900);
        border-radius: 12px;
        padding: 16px;
        margin-top: 16px;
    }
    .credentials-box h5 {
        font-size: 0.75rem;
        font-weight: 600;
        color: var(--gray-400);
        text-transform: uppercase;
        letter-spacing: 0.05em;
        margin-bottom: 12px;
    }
    .credential-item {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 10px 12px;
        background: rgba(255,255,255,0.05);
        border-radius: 8px;
        margin-bottom: 8px;
    }
    .credential-item:last-child {
        margin-bottom: 0;
    }
    .credential-label {
        font-size: 0.75rem;
        color: var(--gray-400);
    }
    .credential-value {
        font-family: 'JetBrains Mono', monospace;
        font-size: 0.75rem;
        color: var(--primary-400);
    }
    .copy-btn {
        background: transparent;
        border: none;
        padding: 4px;
        cursor: pointer;
        color: var(--gray-400);
        transition: color 0.2s;
    }
    .copy-btn:hover {
        color: var(--primary-400);
    }

    .tabs {
        display: flex;
        gap: 4px;
        background: var(--gray-100);
        padding: 4px;
        border-radius: 10px;
        margin-bottom: 20px;
    }
    .tab {
        flex: 1;
        padding: 10px 16px;
        background: transparent;
        border: none;
        border-radius: 8px;
        font-size: 0.8125rem;
        font-weight: 600;
        color: var(--gray-500);
        cursor: pointer;
        transition: all 0.2s;
    }
    .tab.active {
        background: white;
        color: var(--gray-900);
        box-shadow: var(--shadow-sm);
    }

    .tab-content {
        display: none;
    }
    .tab-content.active {
        display: block;
    }

    .warning-box {
        background: var(--warning-light);
        border: 1px solid #fbbf24;
        border-radius: 12px;
        padding: 16px;
        margin-bottom: 20px;
        display: flex;
        gap: 12px;
    }
    .warning-box svg {
        width: 20px;
        height: 20px;
        color: #d97706;
        flex-shrink: 0;
    }
    .warning-box p {
        font-size: 0.8125rem;
        color: #92400e;
        line-height: 1.5;
    }

    .contact-box {
        background: linear-gradient(135deg, var(--gray-800), var(--gray-900));
        border-radius: 16px;
        padding: 24px;
        color: white;
        text-align: center;
    }
    .contact-box h4 {
        font-size: 1rem;
        font-weight: 600;
        margin-bottom: 8px;
    }
    .contact-box p {
        font-size: 0.8125rem;
        color: var(--gray-400);
        margin-bottom: 16px;
    }
    .contact-btn {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 12px 24px;
        background: #25D366;
        color: white;
        border-radius: 10px;
        font-size: 0.875rem;
        font-weight: 600;
        transition: all 0.2s;
    }
    .contact-btn:hover {
        background: #128C7E;
        transform: translateY(-2px);
    }
</style>

<!-- Hero Section -->
<div class="integration-hero">
    <h2>Integration Center</h2>
    <p>Hubungkan website Anda dengan NEO PGA dalam hitungan menit. Download SDK dan ikuti panduan integrasi.</p>
</div>

<!-- Option: Admin Setup vs Self Setup -->
<h3 class="section-title">
    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
    Pilih Metode Setup
</h3>

<div class="option-grid">
    <!-- Option 1: Admin Setup -->
    <div class="option-card admin-setup-card" onclick="showTab('admin-setup')">
        <div class="option-icon orange">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
        </div>
        <h4 class="option-title">Setup oleh Admin NEO PGA</h4>
        <p class="option-desc">Tim kami yang akan setup integrasi ke website Anda. Cocok untuk yang tidak punya waktu atau tidak paham coding.</p>
        <ul class="option-features">
            <li>
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                Setup langsung oleh tim ahli
            </li>
            <li>
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                Testing sampai berjalan sempurna
            </li>
            <li>
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                Support 7 hari pasca setup
            </li>
            <li>
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                Selesai dalam 1-2 hari kerja
            </li>
        </ul>
        <div class="option-price">
            <span class="amount">Rp 500.000</span>
            <span class="label">/ sekali setup</span>
        </div>
        <button class="btn btn-primary btn-block">Lihat Detail</button>
    </div>

    <!-- Option 2: Self Setup -->
    <div class="option-card recommended" onclick="showTab('self-setup')">
        <div class="option-icon primary">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4"/></svg>
        </div>
        <h4 class="option-title">Setup Sendiri (Self Setup)</h4>
        <p class="option-desc">Download SDK dan ikuti panduan step-by-step. Cocok untuk developer atau yang punya tim teknis.</p>
        <ul class="option-features">
            <li>
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                SDK siap pakai (copy-paste)
            </li>
            <li>
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                Dokumentasi lengkap
            </li>
            <li>
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                Contoh kode real-world
            </li>
            <li>
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                Support via WhatsApp
            </li>
        </ul>
        <div class="option-price free">
            <span class="amount">GRATIS</span>
        </div>
        <button class="btn btn-primary btn-block">Lihat Panduan</button>
    </div>
</div>

<!-- Tabs -->
<div class="tabs">
    <button class="tab active" onclick="showTab('self-setup')">Self Setup (Gratis)</button>
    <button class="tab" onclick="showTab('admin-setup')">Admin Setup (Rp 500rb)</button>
</div>

<!-- Tab Content: Self Setup -->
<div id="self-setup" class="tab-content active">

    <!-- Alur Pembayaran -->
    <div class="card mb-4">
        <div class="card-header">
            <h3>
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="20" height="20"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
                Alur Pembayaran QRIS
            </h3>
        </div>
        <div class="card-body">
            <div style="background: linear-gradient(135deg, #1a2634 0%, #0d1521 100%); border-radius: 12px; padding: 20px; color: #fff; font-family: 'JetBrains Mono', monospace; font-size: 0.75rem; line-height: 1.8; overflow-x: auto;">
<pre style="margin: 0; white-space: pre;">
┌─────────────────┐      ┌─────────────────┐      ┌─────────────────┐
│  FORM DEPOSIT   │      │    NEO PGA      │      │   CALLBACK      │
│  (Website Anda) │      │    (Server)     │      │   (Website Anda)│
└────────┬────────┘      └────────┬────────┘      └────────┬────────┘
         │                        │                        │
    User isi nominal              │                        │
    (misal: Rp 50.000)            │                        │
         │                        │                        │
    Klik "Kirim/Bayar"            │                        │
         │                        │                        │
         ├───── Request ─────────>│                        │
         │   (nominal + order_id) │                        │
         │                        │                        │
         │<──── Redirect ─────────┤                        │
         │   (halaman QRIS)       │                        │
         │                        │                        │
    User scan QRIS                │                        │
    dengan GoPay/OVO/DANA         │                        │
         │                        │                        │
         │                        ├───── Webhook ─────────>│
         │                        │   (pembayaran sukses)  │
         │                        │                        │
         │                        │               Update saldo user
         │                        │               di database Anda
         │                        │                        │
    Redirect ke sukses.php <──────┤                        │
         │                        │                        │
      SELESAI                     │                        │
</pre>
            </div>
        </div>
    </div>

    <!-- SDK Download Section -->
    <div class="card mb-4">
        <div class="card-header">
            <h3>
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="20" height="20"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
                Download SDK
            </h3>
        </div>
        <div class="card-body">
            <p style="font-size: 0.875rem; color: var(--gray-600); margin-bottom: 20px;">
                Pilih SDK sesuai kebutuhan website Anda.
            </p>

            <!-- Info Kode Unik -->
            <div style="background: linear-gradient(135deg, #fef3c7, #fde68a); border: 1px solid #f59e0b; border-radius: 12px; padding: 16px; margin-bottom: 20px; display: flex; gap: 12px; align-items: flex-start;">
                <div style="width: 32px; height: 32px; background: #f59e0b; border-radius: 8px; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                    <svg width="16" height="16" fill="white" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg>
                </div>
                <div>
                    <h5 style="font-size: 0.875rem; font-weight: 600; color: #92400e; margin: 0 0 4px 0;">Semua Pembayaran NEO PGA Menggunakan Kode Unik</h5>
                    <p style="font-size: 0.8125rem; color: #92400e; margin: 0; line-height: 1.5;">
                        Setiap transaksi akan ditambahkan <strong>kode unik (1-999)</strong> untuk identifikasi pembayaran otomatis.
                        Contoh: Deposit Rp 50.000 → User bayar Rp 50.123 (123 = kode unik).
                    </p>
                </div>
            </div>

            <!-- QRIS ONLY Section -->
            <div style="background: linear-gradient(135deg, var(--primary-50), #ecfdf5); border: 2px solid var(--primary-300); border-radius: 16px; padding: 20px; margin-bottom: 20px;">
                <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 12px;">
                    <div style="width: 40px; height: 40px; background: var(--primary-500); border-radius: 10px; display: flex; align-items: center; justify-content: center;">
                        <svg width="20" height="20" fill="white" viewBox="0 0 24 24"><path d="M3 11h8V3H3v8zm2-6h4v4H5V5zm8-2v8h8V3h-8zm6 6h-4V5h4v4zM3 21h8v-8H3v8zm2-6h4v4H5v-4zm13 0h-2v2h2v-2zm0 4h-2v2h2v-2zm-4-4h-2v2h2v-2zm0 4h-2v2h2v-2zm4-8h-2v2h2v-2zm-4 0h-2v2h2v-2z"/></svg>
                    </div>
                    <div>
                        <h4 style="font-size: 1.125rem; font-weight: 700; color: var(--gray-900); margin: 0;">QRIS Only</h4>
                        <p style="font-size: 0.75rem; color: var(--gray-500); margin: 0;">Pembayaran via QRIS saja (tanpa Bank Transfer)</p>
                    </div>
                </div>

                <!-- Use Cases -->
                <div style="background: rgba(255,255,255,0.7); border-radius: 10px; padding: 14px; margin-bottom: 16px;">
                    <h5 style="font-size: 0.75rem; font-weight: 600; color: var(--gray-500); text-transform: uppercase; letter-spacing: 0.05em; margin: 0 0 10px 0;">Cocok untuk:</h5>
                    <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px;">
                        <div style="display: flex; align-items: center; gap: 8px; font-size: 0.8125rem; color: var(--gray-700);">
                            <span style="width: 6px; height: 6px; background: var(--primary-500); border-radius: 50%;"></span>
                            <strong>Deposit Manual</strong> - User isi nominal sendiri
                        </div>
                        <div style="display: flex; align-items: center; gap: 8px; font-size: 0.8125rem; color: var(--gray-700);">
                            <span style="width: 6px; height: 6px; background: var(--primary-500); border-radius: 50%;"></span>
                            <strong>Toko Produk</strong> - Harga fix sesuai produk
                        </div>
                        <div style="display: flex; align-items: center; gap: 8px; font-size: 0.8125rem; color: var(--gray-700);">
                            <span style="width: 6px; height: 6px; background: var(--primary-500); border-radius: 50%;"></span>
                            Top-up game / saldo
                        </div>
                        <div style="display: flex; align-items: center; gap: 8px; font-size: 0.8125rem; color: var(--gray-700);">
                            <span style="width: 6px; height: 6px; background: var(--primary-500); border-radius: 50%;"></span>
                            Donasi / Infaq / Wakaf
                        </div>
                        <div style="display: flex; align-items: center; gap: 8px; font-size: 0.8125rem; color: var(--gray-700);">
                            <span style="width: 6px; height: 6px; background: var(--primary-500); border-radius: 50%;"></span>
                            Pulsa / Voucher
                        </div>
                        <div style="display: flex; align-items: center; gap: 8px; font-size: 0.8125rem; color: var(--gray-700);">
                            <span style="width: 6px; height: 6px; background: var(--primary-500); border-radius: 50%;"></span>
                            Pembayaran sederhana lainnya
                        </div>
                    </div>
                </div>

                <div class="sdk-grid">
                    <!-- Option A: Sudah Punya Form -->
                    <div class="sdk-card" style="background: #fff; border: 2px solid var(--primary-400);">
                        <div style="position: absolute; top: -1px; right: 20px; background: var(--primary-500); color: white; font-size: 0.65rem; font-weight: 700; padding: 4px 10px; border-radius: 0 0 6px 6px;">RECOMMENDED</div>
                        <div class="sdk-header">
                            <span class="sdk-badge" style="background: #dcfce7; color: #166534;">OPSI A</span>
                        </div>
                        <h4 class="sdk-name">Sudah Punya Form/Halaman</h4>
                        <p class="sdk-desc">Website Anda <strong>sudah ada form deposit atau halaman produk</strong>. Download SDK untuk generate QRIS dari sistem Anda.</p>

                        <div class="sdk-use-case">
                            <h5>Isi File Download</h5>
                            <ul>
                                <li>Class NeoPGA (SDK utama)</li>
                                <li>Panduan integrasi singkat</li>
                                <li>Contoh kode callback.php</li>
                            </ul>
                        </div>

                        <div style="background: #f0fdf4; border-radius: 8px; padding: 12px; margin-bottom: 16px; font-size: 0.75rem; color: #166534;">
                            <strong>Anda hanya perlu:</strong> Include SDK, panggil createQRIS($nominal) saat form submit atau saat user pilih produk
                        </div>

                        <a href="download-sdk.php?type=qris-sdk" class="download-btn">
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
                            Download SDK Only
                        </a>
                    </div>

                    <!-- Option B: Belum Punya Form -->
                    <div class="sdk-card" style="background: #fff;">
                        <div class="sdk-header">
                            <span class="sdk-badge" style="background: #fef3c7; color: #92400e;">OPSI B</span>
                        </div>
                        <h4 class="sdk-name">Belum Punya Form/Halaman</h4>
                        <p class="sdk-desc">Website Anda <strong>belum ada form deposit</strong>. Download SDK + template form lengkap dari NEO PGA.</p>

                        <div class="sdk-use-case">
                            <h5>Isi File Download</h5>
                            <ul>
                                <li>Class NeoPGA (SDK utama)</li>
                                <li>Template deposit.php (form)</li>
                                <li>Template callback.php</li>
                                <li>Template sukses.php</li>
                                <li>Struktur database</li>
                            </ul>
                        </div>

                        <div style="background: #fffbeb; border-radius: 8px; padding: 12px; margin-bottom: 16px; font-size: 0.75rem; color: #92400e;">
                            <strong>Anda perlu:</strong> Upload semua file, sesuaikan desain dengan website Anda
                        </div>

                        <a href="download-sdk.php?type=simple" class="download-btn" style="background: linear-gradient(135deg, #f59e0b, #d97706);">
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
                            Download SDK + Template
                        </a>
                    </div>
                </div>
            </div>

            <!-- Full SDK Section -->
            <div style="background: linear-gradient(135deg, #eff6ff, #dbeafe); border: 2px solid #93c5fd; border-radius: 16px; padding: 20px;">
                <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 12px;">
                    <div style="width: 40px; height: 40px; background: #3b82f6; border-radius: 10px; display: flex; align-items: center; justify-content: center;">
                        <svg width="20" height="20" fill="white" viewBox="0 0 24 24"><path d="M20 4H4c-1.11 0-1.99.89-1.99 2L2 18c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V6c0-1.11-.89-2-2-2zm0 14H4v-6h16v6zm0-10H4V6h16v2z"/></svg>
                    </div>
                    <div>
                        <h4 style="font-size: 1.125rem; font-weight: 700; color: var(--gray-900); margin: 0;">QRIS + Bank Transfer</h4>
                        <p style="font-size: 0.75rem; color: var(--gray-500); margin: 0;">Pilihan metode pembayaran lebih lengkap</p>
                    </div>
                </div>

                <!-- Use Cases -->
                <div style="background: rgba(255,255,255,0.7); border-radius: 10px; padding: 14px; margin-bottom: 16px;">
                    <h5 style="font-size: 0.75rem; font-weight: 600; color: var(--gray-500); text-transform: uppercase; letter-spacing: 0.05em; margin: 0 0 10px 0;">Cocok untuk:</h5>
                    <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px;">
                        <div style="display: flex; align-items: center; gap: 8px; font-size: 0.8125rem; color: var(--gray-700);">
                            <span style="width: 6px; height: 6px; background: #3b82f6; border-radius: 50%;"></span>
                            <strong>Toko Online</strong> - E-commerce lengkap
                        </div>
                        <div style="display: flex; align-items: center; gap: 8px; font-size: 0.8125rem; color: var(--gray-700);">
                            <span style="width: 6px; height: 6px; background: #3b82f6; border-radius: 50%;"></span>
                            <strong>Booking</strong> - Hotel, tiket, jadwal
                        </div>
                        <div style="display: flex; align-items: center; gap: 8px; font-size: 0.8125rem; color: var(--gray-700);">
                            <span style="width: 6px; height: 6px; background: #3b82f6; border-radius: 50%;"></span>
                            Invoice / Tagihan
                        </div>
                        <div style="display: flex; align-items: center; gap: 8px; font-size: 0.8125rem; color: var(--gray-700);">
                            <span style="width: 6px; height: 6px; background: #3b82f6; border-radius: 50%;"></span>
                            Pembayaran nominal besar
                        </div>
                    </div>
                </div>

                <div class="sdk-card" style="background: #fff; max-width: 100%;">
                    <div class="sdk-header">
                        <span class="sdk-badge full">FULL SDK</span>
                    </div>
                    <h4 class="sdk-name">SDK untuk Checkout E-commerce</h4>
                    <p class="sdk-desc">Support pembayaran QRIS dan Transfer Bank. User bisa pilih metode pembayaran yang diinginkan.</p>

                    <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; margin-bottom: 16px;">
                        <div class="sdk-use-case" style="margin: 0;">
                            <h5>Isi File Download</h5>
                            <ul>
                                <li>Class NeoPGA (SDK utama)</li>
                                <li>Template checkout.php</li>
                                <li>Template callback.php</li>
                                <li>Cek status order</li>
                            </ul>
                        </div>
                        <div class="sdk-use-case" style="margin: 0;">
                            <h5>Metode Pembayaran</h5>
                            <ul>
                                <li>QRIS (GoPay, OVO, DANA, dll)</li>
                                <li>Transfer Bank (BCA, BNI, Mandiri)</li>
                                <li>Virtual Account</li>
                            </ul>
                        </div>
                    </div>

                    <a href="download-sdk.php?type=full" class="download-btn" style="background: linear-gradient(135deg, #3b82f6, #1d4ed8);">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
                        Download SDK Full
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Kredensial API -->
    <div class="card mb-4">
        <div class="card-header">
            <h3>
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="20" height="20"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z"/></svg>
                Kredensial API Anda
            </h3>
        </div>
        <div class="card-body">
            <div class="credentials-box">
                <h5>Gunakan kredensial ini di SDK</h5>

                <div class="credential-item">
                    <div>
                        <div class="credential-label">API Key</div>
                        <div class="credential-value" id="api-key"><?= htmlspecialchars(substr($apiKey, 0, 20)) ?>...</div>
                    </div>
                    <button class="copy-btn" onclick="copyText('<?= htmlspecialchars($apiKey) ?>')" title="Copy">
                        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"/></svg>
                    </button>
                </div>

                <div class="credential-item">
                    <div>
                        <div class="credential-label">Secret Key</div>
                        <div class="credential-value"><?= htmlspecialchars(substr($secretKey, 0, 20)) ?>...</div>
                    </div>
                    <button class="copy-btn" onclick="copyText('<?= htmlspecialchars($secretKey) ?>')" title="Copy">
                        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"/></svg>
                    </button>
                </div>

                <div class="credential-item">
                    <div>
                        <div class="credential-label">Base URL</div>
                        <div class="credential-value"><?= htmlspecialchars($baseUrl) ?></div>
                    </div>
                    <button class="copy-btn" onclick="copyText('<?= htmlspecialchars($baseUrl) ?>')" title="Copy">
                        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"/></svg>
                    </button>
                </div>
            </div>

            <p style="font-size: 0.75rem; color: var(--gray-500); margin-top: 12px;">
                * Untuk kredensial lengkap, kunjungi menu <a href="api-keys.php" style="color: var(--primary-600); text-decoration: underline;">API Keys</a>
            </p>
        </div>
    </div>

    <!-- Step by Step Guide -->
    <div class="card mb-4">
        <div class="card-header">
            <h3>
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="20" height="20"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01"/></svg>
                Panduan Setup Step-by-Step
            </h3>
        </div>
        <div class="card-body">
            <div class="step-list">
                <div class="step-item">
                    <div class="step-number">1</div>
                    <div class="step-content">
                        <h4>Download SDK & Upload ke Hosting</h4>
                        <p>Download SDK di atas. Rename menjadi <code>neopga.php</code> lalu upload ke folder <code>/includes/</code> di hosting Anda via File Manager cPanel.</p>
                    </div>
                </div>

                <div class="step-item">
                    <div class="step-number">2</div>
                    <div class="step-content">
                        <h4>Edit Form Deposit Anda</h4>
                        <p>Buka file form deposit di website Anda (yang ada input nominal). Tambahkan kode untuk memanggil SDK. <strong>Contoh lengkap sudah ada di dalam file SDK!</strong></p>
                        <div style="background: var(--gray-100); border-radius: 8px; padding: 12px; margin-top: 10px; font-family: 'JetBrains Mono', monospace; font-size: 0.7rem;">
                            <span style="color: #9333ea;">require_once</span> <span style="color: #059669;">'includes/neopga.php'</span>;<br><br>
                            <span style="color: #6b7280;">// Ketika user submit form deposit</span><br>
                            $result = NeoPGA::<span style="color: #2563eb;">createQRIS</span>($nominal, $orderId);<br><br>
                            <span style="color: #9333ea;">if</span> ($result[<span style="color: #059669;">'success'</span>]) {<br>
                            &nbsp;&nbsp;<span style="color: #9333ea;">header</span>(<span style="color: #059669;">'Location: '</span> . $result[<span style="color: #059669;">'payment_url'</span>]);<br>
                            }
                        </div>
                    </div>
                </div>

                <div class="step-item">
                    <div class="step-number">3</div>
                    <div class="step-content">
                        <h4>Buat File callback.php</h4>
                        <p>Buat file baru <code>callback.php</code> untuk menerima notifikasi saat pembayaran sukses. Di file ini, Anda update saldo user di database.</p>
                        <div style="background: var(--gray-100); border-radius: 8px; padding: 12px; margin-top: 10px; font-family: 'JetBrains Mono', monospace; font-size: 0.7rem;">
                            <span style="color: #9333ea;">require_once</span> <span style="color: #059669;">'includes/neopga.php'</span>;<br><br>
                            $payment = NeoPGA::<span style="color: #2563eb;">verifyCallback</span>();<br><br>
                            <span style="color: #9333ea;">if</span> ($payment && $payment[<span style="color: #059669;">'status'</span>] === <span style="color: #059669;">'success'</span>) {<br>
                            &nbsp;&nbsp;<span style="color: #6b7280;">// Update saldo user di database</span><br>
                            &nbsp;&nbsp;<span style="color: #6b7280;">// $pdo->query("UPDATE users SET saldo = saldo + ...");</span><br>
                            }
                        </div>
                    </div>
                </div>

                <div class="step-item">
                    <div class="step-number">4</div>
                    <div class="step-content">
                        <h4>Set URL Callback di Dashboard</h4>
                        <p>Buka menu <a href="settings.php" style="color: var(--primary-600);">Pengaturan</a>, masukkan URL callback Anda. Contoh: <code>https://websiteanda.com/callback.php</code></p>
                    </div>
                </div>

                <div class="step-item">
                    <div class="step-number">5</div>
                    <div class="step-content">
                        <h4>Testing Pembayaran</h4>
                        <p>Test dengan deposit nominal kecil (Rp 10.000). Pastikan QRIS muncul dan setelah bayar, saldo terupdate. Gunakan menu <a href="webhook-test.php" style="color: var(--primary-600);">Test Webhook</a> untuk debug.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- File yang Perlu Diedit -->
    <div class="card">
        <div class="card-header">
            <h3>
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="20" height="20"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z"/></svg>
                File yang Perlu Diedit di Website Anda
            </h3>
        </div>
        <div class="card-body">
            <div class="file-list">
                <div class="file-item">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                    <strong>neopga-sdk.php</strong> — File SDK utama (upload ke hosting)
                </div>
                <div class="file-item">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                    <strong>checkout.php / bayar.php</strong> — Halaman pembayaran Anda (edit untuk include SDK)
                </div>
                <div class="file-item">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                    <strong>callback.php</strong> — Handler webhook (buat baru)
                </div>
                <div class="file-item">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                    <strong>sukses.php</strong> — Halaman sukses pembayaran (opsional)
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Tab Content: Admin Setup -->
<div id="admin-setup" class="tab-content">

    <div class="warning-box">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
        <p><strong>Biaya Setup: Rp 500.000</strong> (sekali bayar). Pembayaran dilakukan setelah setup berhasil dan diuji coba.</p>
    </div>

    <!-- Alur Proses Admin Setup -->
    <div class="card mb-4">
        <div class="card-header">
            <h3>
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="20" height="20"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01"/></svg>
                Alur Proses Setup oleh Admin
            </h3>
        </div>
        <div class="card-body">
            <div style="background: linear-gradient(135deg, #1a2634 0%, #0d1521 100%); border-radius: 12px; padding: 20px; color: #fff; font-family: 'JetBrains Mono', monospace; font-size: 0.7rem; line-height: 1.8; overflow-x: auto; margin-bottom: 20px;">
<pre style="margin: 0; white-space: pre;">
┌─────────────────────────────────────────────────────────────────────────────────┐
│                        ALUR SETUP OLEH ADMIN NEO PGA                            │
└─────────────────────────────────────────────────────────────────────────────────┘

    ┌──────────────┐
    │  1. REQUEST  │  Anda hubungi Admin via WhatsApp
    │    SETUP     │  + Jelaskan kebutuhan (QRIS only / QRIS + Bank)
    └──────┬───────┘  + Kirim URL website Anda
           │
           ▼
    ┌──────────────┐
    │  2. ANALISIS │  Admin cek website Anda
    │    WEBSITE   │  + Cek struktur form deposit/checkout
    └──────┬───────┘  + Tentukan metode integrasi terbaik
           │
           ▼
    ┌──────────────┐
    │  3. KIRIM    │  Anda kirim ke Admin:
    │    AKSES     │  + Akses cPanel/Hosting
    └──────┬───────┘  + Akses Database (jika perlu)
           │
           ▼
    ┌──────────────┐
    │  4. PROSES   │  Admin kerjakan:
    │    INTEGRASI │  + Upload SDK ke hosting
    │              │  + Edit file form/checkout
    └──────┬───────┘  + Buat callback.php
           │
           ▼
    ┌──────────────┐
    │  5. TESTING  │  Admin test pembayaran:
    │              │  + Test QRIS muncul
    └──────┬───────┘  + Test callback (saldo terupdate)
           │
           ▼
    ┌──────────────┐
    │  6. SERAH    │  Anda cek dan test sendiri
    │    TERIMA    │  + Jika OK, lakukan pembayaran Rp 500.000
    └──────┬───────┘  + Ganti password cPanel Anda
           │
           ▼
    ┌──────────────┐
    │  7. SUPPORT  │  Support 7 hari untuk penyesuaian
    │   (7 HARI)   │  jika ada bug atau perubahan kecil
    └──────────────┘
</pre>
            </div>

            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 16px;">
                <div style="background: #f0fdf4; border: 1px solid #86efac; border-radius: 12px; padding: 16px;">
                    <h5 style="font-size: 0.875rem; font-weight: 600; color: #166534; margin-bottom: 8px; display: flex; align-items: center; gap: 8px;">
                        <svg width="18" height="18" fill="currentColor" viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
                        Yang Admin Kerjakan
                    </h5>
                    <ul style="font-size: 0.8125rem; color: #166534; line-height: 1.8; padding-left: 16px; margin: 0;">
                        <li>Upload SDK ke hosting Anda</li>
                        <li>Edit file form deposit/checkout</li>
                        <li>Buat file callback.php</li>
                        <li>Set URL callback di dashboard</li>
                        <li>Test pembayaran sampai berhasil</li>
                    </ul>
                </div>
                <div style="background: #fef3c7; border: 1px solid #fbbf24; border-radius: 12px; padding: 16px;">
                    <h5 style="font-size: 0.875rem; font-weight: 600; color: #92400e; margin-bottom: 8px; display: flex; align-items: center; gap: 8px;">
                        <svg width="18" height="18" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg>
                        Estimasi Waktu
                    </h5>
                    <ul style="font-size: 0.8125rem; color: #92400e; line-height: 1.8; padding-left: 16px; margin: 0;">
                        <li>Website sudah ada form: <strong>1 hari</strong></li>
                        <li>Website belum ada form: <strong>1-2 hari</strong></li>
                        <li>Butuh custom design: <strong>2-3 hari</strong></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <!-- Yang Kami Butuhkan dari Anda -->
    <div class="card mb-4">
        <div class="card-header">
            <h3>
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="20" height="20"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>
                Data yang Perlu Anda Siapkan
            </h3>
        </div>
        <div class="card-body">
            <p style="font-size: 0.875rem; color: var(--gray-600); margin-bottom: 20px;">
                Setelah menghubungi Admin, Anda akan diminta mengirimkan data berikut:
            </p>

            <div style="display: grid; gap: 12px; margin-bottom: 20px;">
                <div style="background: #fff; border: 1px solid var(--gray-200); border-radius: 10px; padding: 16px; display: flex; gap: 12px;">
                    <div style="width: 36px; height: 36px; background: var(--primary-100); border-radius: 8px; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                        <svg width="18" height="18" fill="none" stroke="var(--primary-600)" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 15a4 4 0 004 4h9a5 5 0 10-.1-9.999 5.002 5.002 0 10-9.78 2.096A4.001 4.001 0 003 15z"/></svg>
                    </div>
                    <div>
                        <h5 style="font-size: 0.875rem; font-weight: 600; color: var(--gray-900); margin: 0 0 4px 0;">Akses cPanel / Hosting</h5>
                        <p style="font-size: 0.8125rem; color: var(--gray-500); margin: 0;">URL cPanel, username, dan password. Untuk upload file SDK dan edit kode.</p>
                    </div>
                </div>

                <div style="background: #fff; border: 1px solid var(--gray-200); border-radius: 10px; padding: 16px; display: flex; gap: 12px;">
                    <div style="width: 36px; height: 36px; background: #dbeafe; border-radius: 8px; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                        <svg width="18" height="18" fill="none" stroke="#2563eb" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4"/></svg>
                    </div>
                    <div>
                        <h5 style="font-size: 0.875rem; font-weight: 600; color: var(--gray-900); margin: 0 0 4px 0;">Akses Database (jika perlu)</h5>
                        <p style="font-size: 0.8125rem; color: var(--gray-500); margin: 0;">Nama database, username, password. Untuk callback update saldo user.</p>
                    </div>
                </div>

                <div style="background: #fff; border: 1px solid var(--gray-200); border-radius: 10px; padding: 16px; display: flex; gap: 12px;">
                    <div style="width: 36px; height: 36px; background: #fef3c7; border-radius: 8px; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                        <svg width="18" height="18" fill="none" stroke="#d97706" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"/></svg>
                    </div>
                    <div>
                        <h5 style="font-size: 0.875rem; font-weight: 600; color: var(--gray-900); margin: 0 0 4px 0;">URL Halaman Form</h5>
                        <p style="font-size: 0.8125rem; color: var(--gray-500); margin: 0;">Link halaman deposit/checkout yang akan diintegrasikan dengan QRIS.</p>
                    </div>
                </div>

                <div style="background: #fff; border: 1px solid var(--gray-200); border-radius: 10px; padding: 16px; display: flex; gap: 12px;">
                    <div style="width: 36px; height: 36px; background: #f3e8ff; border-radius: 8px; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                        <svg width="18" height="18" fill="none" stroke="#9333ea" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                    </div>
                    <div>
                        <h5 style="font-size: 0.875rem; font-weight: 600; color: var(--gray-900); margin: 0 0 4px 0;">Nama Tabel & Field Database</h5>
                        <p style="font-size: 0.8125rem; color: var(--gray-500); margin: 0;">Contoh: tabel <code>users</code> field <code>saldo</code> untuk update saldo saat callback.</p>
                    </div>
                </div>
            </div>

            <div style="background: #fef2f2; border: 1px solid #fca5a5; border-radius: 10px; padding: 16px;">
                <h5 style="font-size: 0.875rem; font-weight: 600; color: #991b1b; margin: 0 0 8px 0; display: flex; align-items: center; gap: 8px;">
                    <svg width="18" height="18" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>
                    Keamanan Data Anda
                </h5>
                <ul style="font-size: 0.8125rem; color: #991b1b; line-height: 1.8; padding-left: 16px; margin: 0;">
                    <li>Data akses HANYA digunakan untuk proses setup, tidak disimpan</li>
                    <li><strong>WAJIB</strong> ganti password cPanel setelah setup selesai</li>
                    <li>Backup website Anda sebelum proses dimulai</li>
                </ul>
            </div>
        </div>
    </div>

    <!-- Ketentuan & Pembayaran -->
    <div class="card mb-4">
        <div class="card-header">
            <h3>
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="20" height="20"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                Ketentuan & Pembayaran
            </h3>
        </div>
        <div class="card-body">
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 16px;">
                <div>
                    <h5 style="font-size: 0.875rem; font-weight: 600; color: var(--gray-900); margin: 0 0 12px 0;">Yang Termasuk</h5>
                    <ul style="font-size: 0.8125rem; color: var(--gray-600); line-height: 1.8; padding-left: 16px; margin: 0;">
                        <li>Integrasi pembayaran QRIS (atau QRIS + Bank)</li>
                        <li>Setup callback untuk update saldo/order</li>
                        <li>Testing sampai berfungsi sempurna</li>
                        <li>Support 7 hari untuk penyesuaian</li>
                    </ul>
                </div>
                <div>
                    <h5 style="font-size: 0.875rem; font-weight: 600; color: var(--gray-900); margin: 0 0 12px 0;">Tidak Termasuk</h5>
                    <ul style="font-size: 0.8125rem; color: var(--gray-600); line-height: 1.8; padding-left: 16px; margin: 0;">
                        <li>Desain ulang tampilan website</li>
                        <li>Pembuatan fitur baru (selain integrasi)</li>
                        <li>Perbaikan bug website yang sudah ada</li>
                        <li>Support lebih dari 7 hari</li>
                    </ul>
                </div>
            </div>

            <div style="background: var(--gray-50); border-radius: 12px; padding: 16px; margin-top: 20px; text-align: center;">
                <p style="font-size: 0.875rem; color: var(--gray-600); margin: 0 0 8px 0;">Pembayaran dilakukan setelah:</p>
                <p style="font-size: 1rem; font-weight: 600; color: var(--gray-900); margin: 0;">Setup selesai + Anda sudah test + Semuanya berfungsi</p>
            </div>
        </div>
    </div>

    <!-- Contact -->
    <div class="contact-box">
        <h4>Siap untuk Setup?</h4>
        <p>Hubungi kami via WhatsApp untuk konsultasi dan mulai proses setup.</p>
        <a href="https://wa.me/6281234567890?text=Halo,%20saya%20mau%20request%20setup%20integrasi%20NEO%20PGA.%0A%0AMerchant%20Code:%20<?= urlencode($merchant['merchant_code'] ?? '') ?>%0AURL%20Website:%20%0AKebutuhan:%20QRIS%20Only%20/%20QRIS%20%2B%20Bank" target="_blank" class="contact-btn">
            <svg width="20" height="20" fill="currentColor" viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
            Hubungi Admin via WhatsApp
        </a>
    </div>
</div>

<script>
function showTab(tabId) {
    // Update tab buttons
    document.querySelectorAll('.tab').forEach(tab => tab.classList.remove('active'));
    document.querySelectorAll('.tab').forEach(tab => {
        if (tab.textContent.toLowerCase().includes(tabId.replace('-', ' ').split(' ')[0])) {
            tab.classList.add('active');
        }
    });

    // Show/hide tab content
    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.remove('active');
    });
    document.getElementById(tabId).classList.add('active');
}

function copyText(text) {
    navigator.clipboard.writeText(text).then(() => {
        // Show toast
        const toast = document.createElement('div');
        toast.textContent = 'Copied!';
        toast.style.cssText = `
            position: fixed;
            bottom: 100px;
            left: 50%;
            transform: translateX(-50%);
            background: var(--gray-900);
            color: white;
            padding: 10px 20px;
            border-radius: 8px;
            font-size: 0.875rem;
            z-index: 9999;
        `;
        document.body.appendChild(toast);
        setTimeout(() => toast.remove(), 2000);
    });
}
</script>

<?php require_once 'layout_footer.php'; ?>

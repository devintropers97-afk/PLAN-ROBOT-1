<?php
/**
 * =====================================================================
 * NEO PGA SDK - VERSI SIMPLE (QRIS ONLY)
 * Untuk: Deposit, Top-up, Donasi dengan nominal manual
 * =====================================================================
 *
 * ALUR PENGGUNAAN:
 * ================
 *
 *   [FORM DEPOSIT]          [NEO PGA]              [CALLBACK]
 *        |                      |                      |
 *   User isi nominal            |                      |
 *        |                      |                      |
 *   Klik "Kirim/Bayar"          |                      |
 *        |                      |                      |
 *        +----> Request ------->|                      |
 *        |      (nominal)       |                      |
 *        |                      |                      |
 *        |<---- Redirect -------+                      |
 *        |   (halaman QRIS)     |                      |
 *        |                      |                      |
 *   User scan QRIS              |                      |
 *        |                      |                      |
 *        |                      +----> Webhook ------->|
 *        |                      |   (payment success)  |
 *        |                      |                      |
 *        |                      |               Update saldo user
 *        |                      |                      |
 *   Redirect ke sukses.php <----+                      |
 *
 * =====================================================================
 * LANGKAH INTEGRASI:
 * =====================================================================
 *
 * 1. Upload file ini ke folder website Anda (misal: /includes/neopga.php)
 *
 * 2. Ganti kredensial di bawah ini dengan API Key Anda
 *
 * 3. Di halaman form deposit, tambahkan kode untuk proses pembayaran
 *    (lihat contoh lengkap di bagian bawah file ini)
 *
 * 4. Buat file callback.php untuk menerima notifikasi pembayaran sukses
 *
 * 5. Set URL callback di Dashboard NEO PGA > Pengaturan
 *
 * =====================================================================
 */

class NeoPGA
{
    // =====================================================================
    // GANTI DENGAN KREDENSIAL ANDA
    // Dapatkan di: Dashboard NEO PGA > API Keys
    // =====================================================================
    const API_KEY    = 'GANTI_DENGAN_API_KEY_ANDA';
    const SECRET_KEY = 'GANTI_DENGAN_SECRET_KEY_ANDA';
    const BASE_URL   = 'https://DOMAIN_NEOPGA_ANDA.com';
    // =====================================================================

    /**
     * BUAT PEMBAYARAN QRIS
     *
     * @param int    $amount      Nominal deposit (contoh: 50000)
     * @param string $referenceId ID unik transaksi Anda (contoh: 'DEP-123-1702900000')
     * @param string $description Keterangan (opsional)
     * @param array  $customer    Data customer (opsional)
     * @return array
     *
     * CONTOH PENGGUNAAN:
     *
     *   // Buat pembayaran Rp 50.000
     *   $result = NeoPGA::createQRIS(50000, 'DEP-USER123-' . time());
     *
     *   if ($result['success']) {
     *       // Redirect ke halaman QRIS
     *       header('Location: ' . $result['payment_url']);
     *       exit;
     *   }
     */
    public static function createQRIS($amount, $referenceId, $description = '', $customer = [])
    {
        $data = [
            'reference_id'   => $referenceId,
            'amount'         => (int) $amount,
            'payment_method' => 'qris',
            'description'    => $description ?: 'Deposit',
            'customer_name'  => $customer['name'] ?? '',
            'customer_email' => $customer['email'] ?? '',
            'customer_phone' => $customer['phone'] ?? '',
        ];

        return self::request('POST', '/api/create.php', $data);
    }

    /**
     * CEK STATUS PEMBAYARAN
     */
    public static function checkStatus($invoice)
    {
        return self::request('GET', '/api/status.php?invoice=' . urlencode($invoice));
    }

    /**
     * VERIFIKASI CALLBACK/WEBHOOK
     *
     * Panggil di callback.php untuk memastikan request dari NEO PGA
     *
     * @return array|false Data pembayaran jika valid
     */
    public static function verifyCallback()
    {
        $payload = file_get_contents('php://input');
        $signature = $_SERVER['HTTP_X_SIGNATURE'] ?? '';

        if (empty($payload) || empty($signature)) {
            return false;
        }

        $expectedSignature = hash_hmac('sha256', $payload, self::SECRET_KEY);

        if (!hash_equals($expectedSignature, $signature)) {
            return false;
        }

        $data = json_decode($payload, true);
        return $data['data'] ?? $data;
    }

    /**
     * GET PAYMENT URL
     */
    public static function getPaymentUrl($invoice)
    {
        return self::BASE_URL . '/public/pay.php?invoice=' . urlencode($invoice);
    }

    // =====================================================================
    // INTERNAL - Tidak perlu diubah
    // =====================================================================
    private static function request($method, $endpoint, $data = [])
    {
        $url = self::BASE_URL . $endpoint;

        $headers = [
            'Content-Type: application/json',
            'X-API-Key: ' . self::API_KEY,
        ];

        if ($method === 'POST' && !empty($data)) {
            $jsonData = json_encode($data);
            $signature = hash_hmac('sha256', $jsonData, self::SECRET_KEY);
            $headers[] = 'X-Signature: ' . $signature;
        }

        $ch = curl_init();

        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData ?? '');
        }

        curl_setopt_array($ch, [
            CURLOPT_URL            => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 30,
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);

        $response = curl_exec($ch);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) {
            return ['success' => false, 'error' => 'Connection error: ' . $error];
        }

        $result = json_decode($response, true);

        if (!$result) {
            return ['success' => false, 'error' => 'Invalid response'];
        }

        if (isset($result['data']['invoice_number'])) {
            $result['payment_url'] = self::getPaymentUrl($result['data']['invoice_number']);
        }

        return $result;
    }
}


// =====================================================================
// =====================================================================
//
//   CONTOH LENGKAP INTEGRASI - COPY PASTE KE WEBSITE ANDA
//
// =====================================================================
// =====================================================================

/*
================================================================================
FILE 1: deposit.php (Halaman Form Deposit)
================================================================================

Ini adalah halaman form deposit seperti screenshot Anda.
Copy kode ini dan sesuaikan dengan desain website Anda.

--------------------------------------------------------------------------------
*/

/*
<?php
session_start();
require_once 'includes/neopga.php';  // Sesuaikan path

// Cek login user (sesuaikan dengan sistem login Anda)
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$userId = $_SESSION['user_id'];
$userName = $_SESSION['user_name'] ?? 'User';
$userEmail = $_SESSION['user_email'] ?? '';

// Ambil saldo user dari database (contoh)
// $saldo = getSaldoUser($userId);

$error = '';
$success = '';

// PROSES FORM DEPOSIT
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $nominal = (int) ($_POST['nominal'] ?? 0);
    // Sanitize keterangan untuk keamanan XSS
    $keterangan = htmlspecialchars(strip_tags($_POST['keterangan'] ?? ''), ENT_QUOTES, 'UTF-8');

    // Validasi nominal
    if ($nominal < 10000) {
        $error = 'Minimal deposit Rp 10.000';
    } elseif ($nominal > 10000000) {
        $error = 'Maksimal deposit Rp 10.000.000';
    } else {

        // Generate ID transaksi unik
        // Format: DEP-{user_id}-{timestamp}
        $transactionId = 'DEP-' . $userId . '-' . time();

        // Simpan ke database dulu (status: pending)
        // saveDeposit($transactionId, $userId, $nominal, 'pending');

        // Buat pembayaran QRIS di NEO PGA
        $result = NeoPGA::createQRIS($nominal, $transactionId, $keterangan ?: 'Deposit Saldo', [
            'name'  => $userName,
            'email' => $userEmail,
        ]);

        if ($result['success']) {
            // Simpan invoice number ke database
            // updateDepositInvoice($transactionId, $result['data']['invoice_number']);

            // Redirect ke halaman QRIS
            header('Location: ' . $result['payment_url']);
            exit;

        } else {
            $error = 'Gagal membuat pembayaran: ' . ($result['error'] ?? 'Unknown error');
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Deposit Saldo</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Segoe UI', Tahoma, sans-serif;
            background: #0f1923;
            min-height: 100vh;
            padding: 20px;
        }

        .deposit-container {
            max-width: 450px;
            margin: 0 auto;
            background: linear-gradient(135deg, #1a2634 0%, #0d1521 100%);
            border-radius: 12px;
            border: 1px solid #2a3f55;
            overflow: hidden;
        }

        .deposit-header {
            background: linear-gradient(90deg, #f7b731, #f5a623);
            padding: 15px 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .deposit-header h2 {
            color: #000;
            font-size: 18px;
            font-weight: 600;
        }

        .deposit-body {
            padding: 20px;
        }

        .info-text {
            font-size: 12px;
            color: #8899aa;
            margin-bottom: 20px;
            line-height: 1.5;
        }

        .wallet-info {
            margin-bottom: 20px;
        }

        .wallet-label {
            font-size: 13px;
            color: #8899aa;
            margin-bottom: 5px;
        }

        .wallet-name {
            font-size: 14px;
            color: #fff;
            font-weight: 500;
        }

        .wallet-balance {
            font-size: 20px;
            color: #f7b731;
            font-weight: 700;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-label {
            display: block;
            font-size: 13px;
            color: #8899aa;
            margin-bottom: 8px;
        }

        .form-input, .form-select, .form-textarea {
            width: 100%;
            padding: 12px 15px;
            background: #0d1521;
            border: 1px solid #2a3f55;
            border-radius: 6px;
            color: #fff;
            font-size: 14px;
            transition: border-color 0.2s;
        }

        .form-input:focus, .form-select:focus, .form-textarea:focus {
            outline: none;
            border-color: #f7b731;
        }

        .form-input::placeholder {
            color: #556677;
        }

        .form-select {
            cursor: pointer;
        }

        .form-select option {
            background: #1a2634;
            color: #fff;
        }

        .form-textarea {
            min-height: 60px;
            resize: vertical;
        }

        .form-helper {
            font-size: 11px;
            color: #667788;
            margin-top: 5px;
        }

        .nominal-presets {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 8px;
            margin-bottom: 15px;
        }

        .preset-btn {
            padding: 10px;
            background: #0d1521;
            border: 1px solid #2a3f55;
            border-radius: 6px;
            color: #fff;
            font-size: 12px;
            cursor: pointer;
            transition: all 0.2s;
        }

        .preset-btn:hover {
            border-color: #f7b731;
            background: rgba(247, 183, 49, 0.1);
        }

        .preset-btn.active {
            border-color: #f7b731;
            background: rgba(247, 183, 49, 0.2);
            color: #f7b731;
        }

        .submit-btn {
            width: 100%;
            padding: 14px;
            background: linear-gradient(90deg, #2196f3, #1976d2);
            border: none;
            border-radius: 6px;
            color: #fff;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            margin-top: 10px;
        }

        .submit-btn:hover {
            background: linear-gradient(90deg, #1976d2, #1565c0);
            transform: translateY(-1px);
        }

        .alert {
            padding: 12px 15px;
            border-radius: 6px;
            margin-bottom: 15px;
            font-size: 13px;
        }

        .alert-error {
            background: rgba(244, 67, 54, 0.15);
            border: 1px solid #f44336;
            color: #ff6b6b;
        }

        .alert-success {
            background: rgba(76, 175, 80, 0.15);
            border: 1px solid #4caf50;
            color: #81c784;
        }

        .rekening-info {
            background: #0d1521;
            border: 1px solid #2a3f55;
            border-radius: 6px;
            padding: 12px 15px;
            margin-bottom: 15px;
        }

        .rekening-info p {
            font-size: 13px;
            color: #fff;
        }

        .rekening-info small {
            font-size: 11px;
            color: #667788;
        }
    </style>
</head>
<body>
    <div class="deposit-container">
        <div class="deposit-header">
            <span style="font-size: 20px;">|</span>
            <h2>Formulir Deposit</h2>
        </div>

        <div class="deposit-body">
            <p class="info-text">
                Silakan isi nominal deposit. Setelah klik Kirim, Anda akan diarahkan ke halaman pembayaran QRIS.
            </p>

            <?php if ($error): ?>
            <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <div class="wallet-info">
                <div class="wallet-label">Dompet Utama</div>
                <div class="wallet-balance">IDR <?= number_format($saldo ?? 0) ?></div>
            </div>

            <form method="POST" id="depositForm">
                <div class="form-group">
                    <label class="form-label">Pilih Nominal Cepat</label>
                    <div class="nominal-presets">
                        <button type="button" class="preset-btn" onclick="setNominal(20000)">20rb</button>
                        <button type="button" class="preset-btn" onclick="setNominal(50000)">50rb</button>
                        <button type="button" class="preset-btn" onclick="setNominal(100000)">100rb</button>
                        <button type="button" class="preset-btn" onclick="setNominal(200000)">200rb</button>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Jumlah Deposit</label>
                    <input type="number" name="nominal" id="nominal" class="form-input"
                           placeholder="Masukkan nominal" min="10000" max="10000000" required>
                    <div class="form-helper">Minimal Rp 10.000 - Maksimal Rp 10.000.000</div>
                </div>

                <div class="form-group">
                    <label class="form-label">Keterangan (opsional)</label>
                    <textarea name="keterangan" class="form-textarea"
                              placeholder="Keterangan tambahan..." maxlength="100"></textarea>
                    <div class="form-helper">Maksimal 100 karakter</div>
                </div>

                <button type="submit" class="submit-btn">Kirim</button>
            </form>
        </div>
    </div>

    <script>
    function setNominal(amount) {
        document.getElementById('nominal').value = amount;

        // Update active state
        document.querySelectorAll('.preset-btn').forEach(btn => btn.classList.remove('active'));
        event.target.classList.add('active');
    }

    // Format input nominal
    document.getElementById('nominal').addEventListener('input', function(e) {
        // Remove non-numeric characters
        this.value = this.value.replace(/[^0-9]/g, '');
    });
    </script>
</body>
</html>
*/


/*
================================================================================
FILE 2: callback.php (Webhook Handler - WAJIB!)
================================================================================

File ini menerima notifikasi dari NEO PGA ketika pembayaran berhasil.
Set URL file ini di Dashboard NEO PGA > Pengaturan > Webhook URL

Contoh URL: https://websiteanda.com/callback.php

--------------------------------------------------------------------------------
*/

/*
<?php
// Matikan display error untuk keamanan
error_reporting(0);
ini_set('display_errors', 0);

require_once 'includes/neopga.php';
require_once 'includes/database.php';  // Koneksi database Anda

// Log untuk debugging (hapus di production)
$logFile = __DIR__ . '/logs/callback.log';
file_put_contents($logFile, "\n" . date('Y-m-d H:i:s') . " - Request received\n", FILE_APPEND);

// Verifikasi callback dari NEO PGA
$payment = NeoPGA::verifyCallback();

if ($payment && $payment['status'] === 'success') {

    // ==================================
    // PEMBAYARAN BERHASIL!
    // ==================================

    $referenceId = $payment['reference_id'];      // ID transaksi Anda (DEP-123-xxx)
    $amount      = $payment['amount'];            // Nominal deposit
    $invoice     = $payment['invoice_number'];    // Invoice NEO PGA
    $paidAt      = $payment['paid_at'];           // Waktu bayar

    // Log sukses
    file_put_contents($logFile, date('Y-m-d H:i:s') . " - SUCCESS: $referenceId - Rp $amount\n", FILE_APPEND);

    // Parse user_id dari reference_id
    // Format: DEP-{user_id}-{timestamp}
    $parts = explode('-', $referenceId);
    $userId = $parts[1] ?? null;

    if ($userId) {
        try {
            // Koneksi database
            $pdo = new PDO('mysql:host=localhost;dbname=NAMA_DATABASE', 'USERNAME', 'PASSWORD');
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            // Cek apakah sudah pernah diproses (hindari double credit)
            $check = $pdo->prepare("SELECT status FROM deposits WHERE reference_id = ?");
            $check->execute([$referenceId]);
            $deposit = $check->fetch();

            if (!$deposit || $deposit['status'] !== 'success') {

                // Begin transaction
                $pdo->beginTransaction();

                // 1. Update status deposit
                $pdo->prepare("
                    UPDATE deposits
                    SET status = 'success', paid_at = ?, invoice = ?
                    WHERE reference_id = ?
                ")->execute([$paidAt, $invoice, $referenceId]);

                // 2. Tambah saldo user
                $pdo->prepare("
                    UPDATE users
                    SET saldo = saldo + ?
                    WHERE id = ?
                ")->execute([$amount, $userId]);

                // 3. Catat history saldo
                $pdo->prepare("
                    INSERT INTO saldo_history (user_id, type, amount, description, reference_id, created_at)
                    VALUES (?, 'credit', ?, 'Deposit via QRIS', ?, NOW())
                ")->execute([$userId, $amount, $referenceId]);

                // Commit
                $pdo->commit();

                file_put_contents($logFile, date('Y-m-d H:i:s') . " - Saldo updated for user $userId\n", FILE_APPEND);
            }

        } catch (PDOException $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            file_put_contents($logFile, date('Y-m-d H:i:s') . " - DB ERROR: " . $e->getMessage() . "\n", FILE_APPEND);
        }
    }

    // WAJIB: Response 200 OK
    http_response_code(200);
    echo json_encode(['status' => 'ok']);

} else {
    // Callback tidak valid
    file_put_contents($logFile, date('Y-m-d H:i:s') . " - INVALID callback\n", FILE_APPEND);

    http_response_code(400);
    echo json_encode(['status' => 'error']);
}
*/


/*
================================================================================
FILE 3: sukses.php (Halaman Sukses - Opsional)
================================================================================

Halaman ini ditampilkan setelah user selesai bayar.
User akan di-redirect ke sini dari halaman QRIS NEO PGA.

--------------------------------------------------------------------------------
*/

/*
<?php
session_start();

$invoice = $_GET['invoice'] ?? '';
$status = $_GET['status'] ?? '';

// Cek status pembayaran
if ($invoice) {
    require_once 'includes/neopga.php';
    $result = NeoPGA::checkStatus($invoice);
    $paymentStatus = $result['data']['status'] ?? 'pending';
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Status Pembayaran</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #0f1923;
            color: #fff;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0;
        }
        .status-card {
            background: #1a2634;
            border-radius: 16px;
            padding: 40px;
            text-align: center;
            max-width: 400px;
        }
        .status-icon {
            font-size: 64px;
            margin-bottom: 20px;
        }
        .status-success { color: #4caf50; }
        .status-pending { color: #ff9800; }
        .back-btn {
            display: inline-block;
            margin-top: 20px;
            padding: 12px 30px;
            background: #2196f3;
            color: #fff;
            text-decoration: none;
            border-radius: 8px;
        }
    </style>
</head>
<body>
    <div class="status-card">
        <?php if (isset($paymentStatus) && $paymentStatus === 'success'): ?>
            <div class="status-icon status-success">✓</div>
            <h2>Deposit Berhasil!</h2>
            <p>Saldo Anda telah ditambahkan.</p>
        <?php else: ?>
            <div class="status-icon status-pending">⏳</div>
            <h2>Menunggu Pembayaran</h2>
            <p>Silakan selesaikan pembayaran Anda.</p>
            <script>setTimeout(() => location.reload(), 3000);</script>
        <?php endif; ?>
        <a href="deposit.php" class="back-btn">Kembali</a>
    </div>
</body>
</html>
*/


/*
================================================================================
STRUKTUR DATABASE YANG DIBUTUHKAN
================================================================================

-- Tabel deposits (untuk tracking deposit)
CREATE TABLE deposits (
    id INT AUTO_INCREMENT PRIMARY KEY,
    reference_id VARCHAR(100) UNIQUE NOT NULL,
    user_id INT NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    invoice VARCHAR(100),
    status ENUM('pending', 'success', 'expired', 'failed') DEFAULT 'pending',
    paid_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_reference_id (reference_id),
    INDEX idx_status (status)
);

-- Tabel saldo_history (untuk log mutasi saldo)
CREATE TABLE saldo_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    type ENUM('credit', 'debit') NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    balance_after DECIMAL(15,2),
    description VARCHAR(255),
    reference_id VARCHAR(100),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id)
);

-- Tambah kolom saldo di tabel users (jika belum ada)
ALTER TABLE users ADD COLUMN saldo DECIMAL(15,2) DEFAULT 0;

*/

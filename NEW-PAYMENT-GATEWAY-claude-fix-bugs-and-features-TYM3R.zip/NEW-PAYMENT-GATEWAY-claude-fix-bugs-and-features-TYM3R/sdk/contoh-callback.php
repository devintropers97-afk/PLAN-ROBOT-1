<?php
/**
 * =====================================================================
 * CONTOH FILE CALLBACK.PHP
 * =====================================================================
 *
 * File ini menerima notifikasi (webhook) dari NEO PGA ketika
 * pembayaran berhasil.
 *
 * CARA PAKAI:
 * 1. Upload file ini ke hosting Anda
 * 2. Set URL callback di Dashboard NEO PGA > Pengaturan
 *    Contoh: https://websiteanda.com/callback.php
 * 3. NEO PGA akan otomatis kirim notifikasi ke URL ini
 *
 * =====================================================================
 */

// Include SDK NEO PGA
require_once __DIR__ . '/neopga-sdk.php';  // Sesuaikan path

// Log untuk debugging (hapus di production jika tidak diperlukan)
$logFile = __DIR__ . '/callback.log';
$logData = date('Y-m-d H:i:s') . ' - Request dari: ' . $_SERVER['REMOTE_ADDR'] . "\n";
file_put_contents($logFile, $logData, FILE_APPEND);

// =====================================================================
// VERIFIKASI CALLBACK DARI NEO PGA
// =====================================================================
$payment = NeoPGA::verifyCallback();

if ($payment && $payment['status'] === 'success') {
    // =====================================================================
    // PEMBAYARAN BERHASIL!
    // =====================================================================

    // Data yang tersedia dari NEO PGA:
    $orderId      = $payment['reference_id'];       // ID order dari sistem Anda
    $amount       = $payment['amount'];             // Nominal asli (sebelum kode unik)
    $totalAmount  = $payment['total_amount'];       // Nominal + kode unik
    $uniqueCode   = $payment['unique_code'];        // Kode unik (1-999)
    $invoice      = $payment['invoice_number'];     // Invoice NEO PGA
    $method       = $payment['payment_method'];     // 'qris' atau 'bank_transfer'
    $paidAt       = $payment['paid_at'];            // Waktu pembayaran
    $customerName = $payment['customer_name'] ?? '';
    $customerEmail= $payment['customer_email'] ?? '';

    // Log sukses
    $successLog = date('Y-m-d H:i:s') . " - SUKSES: $orderId - Rp " . number_format($amount) . " ($method)\n";
    file_put_contents($logFile, $successLog, FILE_APPEND);

    // =====================================================================
    // PROSES BISNIS ANDA DI SINI
    // =====================================================================

    // Contoh 1: Koneksi ke database MySQL
    /*
    try {
        $pdo = new PDO(
            'mysql:host=localhost;dbname=nama_database',
            'username_database',
            'password_database',
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );

        // Cek apakah order sudah pernah diproses (hindari double processing)
        $check = $pdo->prepare("SELECT status FROM orders WHERE order_id = ?");
        $check->execute([$orderId]);
        $order = $check->fetch();

        if ($order && $order['status'] !== 'paid') {
            // Update status order
            $update = $pdo->prepare("
                UPDATE orders
                SET status = 'paid',
                    payment_method = ?,
                    paid_amount = ?,
                    paid_at = NOW()
                WHERE order_id = ?
            ");
            $update->execute([$method, $totalAmount, $orderId]);

            // Log ke database
            $pdo->prepare("
                INSERT INTO payment_logs (order_id, invoice, amount, method, created_at)
                VALUES (?, ?, ?, ?, NOW())
            ")->execute([$orderId, $invoice, $amount, $method]);
        }

    } catch (PDOException $e) {
        // Log error database
        file_put_contents($logFile, date('Y-m-d H:i:s') . " - DB ERROR: " . $e->getMessage() . "\n", FILE_APPEND);
    }
    */

    // Contoh 2: Untuk Top Up Game / Saldo
    /*
    // Parse user_id dari order_id (format: TOPUP-{user_id}-{timestamp})
    $parts = explode('-', $orderId);
    if (count($parts) >= 2) {
        $userId = $parts[1];

        // Update saldo user
        $pdo->prepare("
            UPDATE users
            SET saldo = saldo + ?
            WHERE id = ?
        ")->execute([$amount, $userId]);

        // Catat history top up
        $pdo->prepare("
            INSERT INTO topup_history (user_id, amount, invoice, created_at)
            VALUES (?, ?, ?, NOW())
        ")->execute([$userId, $amount, $invoice]);
    }
    */

    // Contoh 3: Kirim email konfirmasi
    /*
    if (!empty($customerEmail)) {
        $subject = "Pembayaran Berhasil - Order #$orderId";
        $message = "
            Halo $customerName,

            Pembayaran Anda telah berhasil diproses!

            Detail Pembayaran:
            - Order ID: $orderId
            - Nominal: Rp " . number_format($amount) . "
            - Metode: " . ($method === 'qris' ? 'QRIS' : 'Transfer Bank') . "
            - Tanggal: $paidAt

            Terima kasih telah berbelanja!
        ";

        $headers = "From: noreply@websiteanda.com\r\n";
        $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

        mail($customerEmail, $subject, $message, $headers);
    }
    */

    // Contoh 4: Kirim notifikasi Telegram ke admin
    /*
    $telegramBotToken = 'YOUR_BOT_TOKEN';
    $telegramChatId = 'YOUR_CHAT_ID';
    $telegramMessage = "💰 Pembayaran Baru!\n\nOrder: $orderId\nNominal: Rp " . number_format($amount) . "\nMetode: $method";

    file_get_contents("https://api.telegram.org/bot$telegramBotToken/sendMessage?chat_id=$telegramChatId&text=" . urlencode($telegramMessage));
    */

    // =====================================================================
    // WAJIB: Response 200 OK
    // =====================================================================
    // Ini memberitahu NEO PGA bahwa callback berhasil diterima
    // Jika tidak response 200, NEO PGA akan retry kirim callback

    http_response_code(200);
    echo json_encode([
        'status' => 'ok',
        'message' => 'Callback processed successfully',
        'order_id' => $orderId
    ]);

} else {
    // =====================================================================
    // CALLBACK TIDAK VALID
    // =====================================================================
    // Bisa karena:
    // - Signature tidak cocok (mungkin fake request)
    // - Status bukan 'success' (bukan pembayaran berhasil)
    // - Payload kosong atau rusak

    $errorLog = date('Y-m-d H:i:s') . " - INVALID: Callback tidak valid\n";
    file_put_contents($logFile, $errorLog, FILE_APPEND);

    http_response_code(400);
    echo json_encode([
        'status' => 'error',
        'message' => 'Invalid callback'
    ]);
}

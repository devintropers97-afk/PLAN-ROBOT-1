<?php
/**
 * NEO PGA Database Update Script
 * Jalankan script ini untuk menambah kolom baru ke tabel yang sudah ada
 *
 * PENTING: Hapus file ini setelah selesai update!
 */

// Security check - hanya admin yang sudah login yang bisa akses
require_once __DIR__ . '/includes/init.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_user']) || empty($_SESSION['admin_user']['id'])) {
    http_response_code(403);
    die('Access denied. Admin login required.');
}

$db = Database::getInstance()->getConnection();

echo "<h2>NEO PGA Database Update</h2>";
echo "<pre>";

$alterations = [
    // Merchant info fields
    "ALTER TABLE merchants ADD COLUMN IF NOT EXISTS business_type VARCHAR(100) NULL AFTER phone",
    "ALTER TABLE merchants ADD COLUMN IF NOT EXISTS business_description TEXT NULL AFTER business_type",
    "ALTER TABLE merchants ADD COLUMN IF NOT EXISTS expected_volume VARCHAR(50) NULL AFTER business_description",
    "ALTER TABLE merchants ADD COLUMN IF NOT EXISTS address TEXT NULL AFTER expected_volume",
    "ALTER TABLE merchants ADD COLUMN IF NOT EXISTS reject_reason TEXT NULL",
    "ALTER TABLE merchants ADD COLUMN IF NOT EXISTS rejected_at DATETIME NULL",
    "ALTER TABLE merchants ADD COLUMN IF NOT EXISTS approved_at DATETIME NULL",
    "ALTER TABLE merchants ADD COLUMN IF NOT EXISTS approved_by INT UNSIGNED NULL",
];

foreach ($alterations as $sql) {
    try {
        $db->exec($sql);
        echo "✅ SUCCESS: " . substr($sql, 0, 80) . "...\n";
    } catch (PDOException $e) {
        // Check if error is "duplicate column"
        if (strpos($e->getMessage(), 'Duplicate column') !== false || strpos($e->getMessage(), 'duplicate column') !== false) {
            echo "⏭️ SKIPPED (already exists): " . substr($sql, 0, 60) . "...\n";
        } else {
            echo "❌ ERROR: " . $e->getMessage() . "\n";
            echo "   SQL: $sql\n";
        }
    }
}

// Bank & Transaction Updates
$bankAlterations = [
    "ALTER TABLE transactions ADD COLUMN IF NOT EXISTS bank_account_id INT UNSIGNED NULL AFTER payment_channel",
    "ALTER TABLE bank_accounts ADD COLUMN IF NOT EXISTS branch VARCHAR(100) NULL AFTER account_name",
    "ALTER TABLE bank_accounts ADD COLUMN IF NOT EXISTS fee_type ENUM('fixed', 'percent') DEFAULT 'fixed' AFTER admin_fee",
    "ALTER TABLE bank_accounts ADD COLUMN IF NOT EXISTS updated_at DATETIME NULL",
];

echo "\n--- Bank & Transaction Updates ---\n";
foreach ($bankAlterations as $sql) {
    try {
        $db->exec($sql);
        echo "✅ SUCCESS: " . substr($sql, 0, 60) . "...\n";
    } catch (PDOException $e) {
        if (strpos($e->getMessage(), 'Duplicate column') !== false || strpos($e->getMessage(), 'duplicate column') !== false) {
            echo "⏭️ SKIPPED (exists): " . substr($sql, 0, 50) . "...\n";
        } else {
            echo "❌ ERROR: " . $e->getMessage() . "\n";
        }
    }
}

echo "\n✅ Database update complete!\n";
echo "</pre>";
echo "<p><a href='admin/'>→ Kembali ke Admin Dashboard</a></p>";
?>

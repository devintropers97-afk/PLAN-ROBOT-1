<?php
/**
 * NEO PGA Admin - Manage Admins
 */
require_once __DIR__ . '/../includes/init.php';

$auth = new Auth('admin');
$auth->requireAuth();

$adminUser = $auth->user();
$db = Database::getInstance();
$message = '';
$messageType = '';

// Handle Create Admin
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_admin'])) {
    verifyCsrf();
    $username = sanitize($_POST['username'] ?? '');
    $fullName = sanitize($_POST['full_name'] ?? '');
    $email = sanitize($_POST['email'] ?? '');
    $phone = sanitize($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';
    $role = sanitize($_POST['role'] ?? 'admin');
    
    if (empty($username) || empty($fullName) || empty($email) || empty($password)) {
        $message = 'Username, nama, email, dan password wajib diisi';
        $messageType = 'danger';
    } else {
        $existsEmail = $db->fetch("SELECT id FROM admins WHERE email = ?", [$email]);
        $existsUsername = $db->fetch("SELECT id FROM admins WHERE username = ?", [$username]);
        
        if ($existsEmail) {
            $message = 'Email sudah terdaftar';
            $messageType = 'danger';
        } elseif ($existsUsername) {
            $message = 'Username sudah terdaftar';
            $messageType = 'danger';
        } else {
            try {
                $hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
                $db->insert('admins', [
                    'username' => $username,
                    'full_name' => $fullName,
                    'email' => $email,
                    'phone' => $phone,
                    'password' => $hash,
                    'role' => $role,
                    'is_active' => 1
                ]);
                $message = 'Admin berhasil ditambahkan';
                $messageType = 'success';
            } catch (Exception $e) {
                $message = 'Gagal menambah admin: ' . $e->getMessage();
                $messageType = 'danger';
            }
        }
    }
}

// Handle Update Status
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle_status'])) {
    verifyCsrf();
    $id = (int)$_POST['admin_id'];
    if ($id != $adminUser['id']) {
        $admin = $db->fetch("SELECT is_active FROM admins WHERE id = ?", [$id]);
        if ($admin) {
            $newStatus = $admin['is_active'] ? 0 : 1;
            $db->update('admins', ['is_active' => $newStatus], 'id = ?', [$id]);
            $message = 'Status admin berhasil diubah';
            $messageType = 'success';
        }
    } else {
        $message = 'Tidak dapat mengubah status sendiri';
        $messageType = 'danger';
    }
}

// Handle Delete
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_admin'])) {
    verifyCsrf();
    $id = (int)$_POST['admin_id'];
    if ($id != $adminUser['id']) {
        $db->delete('admins', 'id = ?', [$id]);
        $message = 'Admin berhasil dihapus';
        $messageType = 'success';
    } else {
        $message = 'Tidak dapat menghapus akun sendiri';
        $messageType = 'danger';
    }
}

// Handle Reset Password
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reset_password'])) {
    verifyCsrf();
    $id = (int)$_POST['admin_id'];
    $newPassword = $_POST['new_password'] ?? '';

    if (strlen($newPassword) < 6) {
        $message = 'Password minimal 6 karakter';
        $messageType = 'danger';
    } else {
        $hash = password_hash($newPassword, PASSWORD_BCRYPT, ['cost' => 12]);
        $db->update('admins', ['password' => $hash, 'password_changed_at' => date('Y-m-d H:i:s')], 'id = ?', [$id]);
        $message = 'Password berhasil direset';
        $messageType = 'success';
    }
}

// Handle Edit Admin
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_admin'])) {
    verifyCsrf();
    $id = (int)$_POST['admin_id'];
    $fullName = sanitize($_POST['full_name'] ?? '');
    $email = sanitize($_POST['email'] ?? '');
    $phone = sanitize($_POST['phone'] ?? '');
    $role = sanitize($_POST['role'] ?? 'admin');

    if (empty($fullName) || empty($email)) {
        $message = 'Nama dan email wajib diisi';
        $messageType = 'danger';
    } else {
        // Check email exists for other user
        $existsEmail = $db->fetch("SELECT id FROM admins WHERE email = ? AND id != ?", [$email, $id]);
        if ($existsEmail) {
            $message = 'Email sudah digunakan oleh admin lain';
            $messageType = 'danger';
        } else {
            // Prevent changing own role to non-super_admin if only super_admin
            if ($id == $adminUser['id'] && $adminUser['role'] === 'super_admin' && $role !== 'super_admin') {
                $superAdminCount = $db->fetch("SELECT COUNT(*) as c FROM admins WHERE role = 'super_admin' AND id != ?", [$id])['c'];
                if ($superAdminCount == 0) {
                    $message = 'Tidak dapat mengubah role super admin terakhir';
                    $messageType = 'danger';
                } else {
                    $db->update('admins', [
                        'full_name' => $fullName,
                        'email' => $email,
                        'phone' => $phone,
                        'role' => $role
                    ], 'id = ?', [$id]);
                    $message = 'Data admin berhasil diperbarui';
                    $messageType = 'success';
                }
            } else {
                $db->update('admins', [
                    'full_name' => $fullName,
                    'email' => $email,
                    'phone' => $phone,
                    'role' => $role
                ], 'id = ?', [$id]);
                $message = 'Data admin berhasil diperbarui';
                $messageType = 'success';
            }
        }
    }
}

// Get admins
$admins = $db->fetchAll("SELECT * FROM admins ORDER BY created_at DESC");

$pageTitle = 'Kelola Admin';
$currentPage = 'admins';

$extraCss = '
.admin-card { background: white; border-radius: 12px; border: 1px solid var(--gray-200); padding: 1.5rem; margin-bottom: 1rem; display: flex; justify-content: space-between; align-items: center; }
.admin-info { display: flex; align-items: center; gap: 1rem; }
.admin-avatar { width: 48px; height: 48px; border-radius: 50%; background: var(--primary); color: white; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 1.25rem; }
.admin-detail h4 { font-weight: 600; margin-bottom: 0.25rem; }
.admin-detail p { font-size: 0.875rem; color: var(--gray-500); margin: 0; }
.admin-meta { display: flex; gap: 1.5rem; align-items: center; }
.admin-actions { display: flex; gap: 0.5rem; }
';

ob_start();
?>

<div class="flex justify-between items-center mb-6">
    <div>
        <h1 class="text-2xl font-bold text-gray-900">Kelola Admin</h1>
        <p class="text-gray-500">Manajemen user administrator sistem</p>
    </div>
    <button onclick="openModal('addAdminModal')" class="btn btn-primary">+ Tambah Admin</button>
</div>

<?php if ($message): ?>
<div class="alert alert-<?= $messageType ?> mb-6"><?= htmlspecialchars($message) ?></div>
<?php endif; ?>

<?php if (empty($admins)): ?>
<div class="card">
    <div class="card-body" style="text-align:center;padding:3rem">
        <p style="color:var(--gray-500);margin-bottom:1rem">Belum ada admin</p>
        <button onclick="openModal('addAdminModal')" class="btn btn-primary">+ Tambah Admin Pertama</button>
    </div>
</div>
<?php else: ?>
<?php foreach ($admins as $admin): ?>
<div class="admin-card">
    <div class="admin-info">
        <div class="admin-avatar"><?= strtoupper(substr($admin['full_name'], 0, 1)) ?></div>
        <div class="admin-detail">
            <h4>
                <?= htmlspecialchars($admin['full_name']) ?>
                <?php if ($admin['id'] == $adminUser['id']): ?>
                <span style="font-size:0.7rem;color:var(--primary);font-weight:normal">(Anda)</span>
                <?php endif; ?>
            </h4>
            <p>@<?= htmlspecialchars($admin['username']) ?> • <?= htmlspecialchars($admin['email']) ?></p>
        </div>
    </div>
    <div class="admin-meta">
        <div>
            <span class="badge badge-<?= $admin['role'] === 'super_admin' ? 'info' : ($admin['role'] === 'admin' ? 'primary' : 'neutral') ?>">
                <?= ucfirst(str_replace('_', ' ', $admin['role'])) ?>
            </span>
        </div>
        <div>
            <span class="badge badge-<?= $admin['is_active'] ? 'success' : 'danger' ?>">
                <?= $admin['is_active'] ? 'Aktif' : 'Nonaktif' ?>
            </span>
        </div>
        <div style="font-size:0.8rem;color:var(--gray-500)">
            <?= $admin['last_login'] ? 'Login: ' . date('d/m H:i', strtotime($admin['last_login'])) : 'Belum pernah login' ?>
        </div>
    </div>
    <div class="admin-actions">
        <button onclick="editAdmin(<?= htmlspecialchars(json_encode($admin)) ?>)" class="btn btn-sm btn-info" title="Edit">✏️</button>
        <?php if ($admin['id'] != $adminUser['id']): ?>
        <form method="POST" style="display:inline">
            <?= csrfField() ?>
            <input type="hidden" name="toggle_status" value="1">
            <input type="hidden" name="admin_id" value="<?= $admin['id'] ?>">
            <button type="submit" class="btn btn-sm btn-secondary" title="Toggle Status">
                <?= $admin['is_active'] ? '⏸' : '▶' ?>
            </button>
        </form>
        <button onclick="resetPassword(<?= $admin['id'] ?>, '<?= htmlspecialchars($admin['full_name']) ?>')" class="btn btn-sm btn-warning" title="Reset Password">🔑</button>
        <form method="POST" style="display:inline" onsubmit="return confirm('Hapus admin <?= htmlspecialchars($admin['full_name']) ?>?')">
            <?= csrfField() ?>
            <input type="hidden" name="delete_admin" value="1">
            <input type="hidden" name="admin_id" value="<?= $admin['id'] ?>">
            <button type="submit" class="btn btn-sm btn-danger" title="Hapus">🗑</button>
        </form>
        <?php else: ?>
        <button onclick="resetPassword(<?= $admin['id'] ?>, '<?= htmlspecialchars($admin['full_name']) ?>')" class="btn btn-sm btn-warning" title="Reset Password">🔑</button>
        <?php endif; ?>
    </div>
</div>
<?php endforeach; ?>
<?php endif; ?>

<!-- Add Admin Modal -->
<div id="addAdminModal" class="modal">
    <div class="modal-content" style="max-width:500px">
        <div class="modal-header">
            <h3 class="modal-title">Tambah Admin Baru</h3>
            <button onclick="closeModal('addAdminModal')" class="modal-close">&times;</button>
        </div>
        <form method="POST">
            <?= csrfField() ?>
            <input type="hidden" name="create_admin" value="1">
            <div class="modal-body">
                <div class="grid grid-cols-2 gap-4">
                    <div class="form-group">
                        <label class="form-label">Username *</label>
                        <input type="text" name="username" class="form-input" required pattern="[a-zA-Z0-9_]+" title="Hanya huruf, angka, underscore">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Nama Lengkap *</label>
                        <input type="text" name="full_name" class="form-input" required>
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">Email *</label>
                    <input type="email" name="email" class="form-input" required>
                </div>
                <div class="grid grid-cols-2 gap-4">
                    <div class="form-group">
                        <label class="form-label">No. Telepon</label>
                        <input type="text" name="phone" class="form-input">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Role</label>
                        <select name="role" class="form-select">
                            <option value="admin">Admin</option>
                            <option value="operator">Operator</option>
                            <option value="super_admin">Super Admin</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">Password *</label>
                    <input type="password" name="password" class="form-input" required minlength="6">
                    <small style="color:var(--gray-500)">Minimal 6 karakter</small>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" onclick="closeModal('addAdminModal')" class="btn btn-secondary">Batal</button>
                <button type="submit" class="btn btn-primary">Tambah Admin</button>
            </div>
        </form>
    </div>
</div>

<!-- Reset Password Modal -->
<div id="resetPasswordModal" class="modal">
    <div class="modal-content" style="max-width:400px">
        <div class="modal-header">
            <h3 class="modal-title">Reset Password</h3>
            <button onclick="closeModal('resetPasswordModal')" class="modal-close">&times;</button>
        </div>
        <form method="POST">
            <?= csrfField() ?>
            <input type="hidden" name="reset_password" value="1">
            <input type="hidden" name="admin_id" id="resetAdminId">
            <div class="modal-body">
                <p style="margin-bottom:1rem">Reset password untuk: <strong id="resetAdminName"></strong></p>
                <div class="form-group">
                    <label class="form-label">Password Baru *</label>
                    <input type="password" name="new_password" class="form-input" required minlength="6">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" onclick="closeModal('resetPasswordModal')" class="btn btn-secondary">Batal</button>
                <button type="submit" class="btn btn-primary">Reset Password</button>
            </div>
        </form>
    </div>
</div>

<!-- Edit Admin Modal -->
<div id="editAdminModal" class="modal">
    <div class="modal-content" style="max-width:500px">
        <div class="modal-header">
            <h3 class="modal-title">Edit Data Admin</h3>
            <button onclick="closeModal('editAdminModal')" class="modal-close">&times;</button>
        </div>
        <form method="POST">
            <?= csrfField() ?>
            <input type="hidden" name="edit_admin" value="1">
            <input type="hidden" name="admin_id" id="editAdminId">
            <div class="modal-body">
                <div class="form-group">
                    <label class="form-label">Username</label>
                    <input type="text" id="editAdminUsername" class="form-input" disabled style="background:var(--gray-100)">
                    <small style="color:var(--gray-500)">Username tidak dapat diubah</small>
                </div>
                <div class="form-group">
                    <label class="form-label">Nama Lengkap *</label>
                    <input type="text" name="full_name" id="editAdminFullName" class="form-input" required>
                </div>
                <div class="grid grid-cols-2 gap-4">
                    <div class="form-group">
                        <label class="form-label">Email *</label>
                        <input type="email" name="email" id="editAdminEmail" class="form-input" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">No. Telepon</label>
                        <input type="text" name="phone" id="editAdminPhone" class="form-input">
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">Role</label>
                    <select name="role" id="editAdminRole" class="form-select">
                        <option value="admin">Admin</option>
                        <option value="operator">Operator</option>
                        <option value="super_admin">Super Admin</option>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" onclick="closeModal('editAdminModal')" class="btn btn-secondary">Batal</button>
                <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
            </div>
        </form>
    </div>
</div>

<script>
function resetPassword(id, name) {
    document.getElementById('resetAdminId').value = id;
    document.getElementById('resetAdminName').textContent = name;
    openModal('resetPasswordModal');
}

function editAdmin(admin) {
    document.getElementById('editAdminId').value = admin.id;
    document.getElementById('editAdminUsername').value = admin.username;
    document.getElementById('editAdminFullName').value = admin.full_name || '';
    document.getElementById('editAdminEmail').value = admin.email || '';
    document.getElementById('editAdminPhone').value = admin.phone || '';
    document.getElementById('editAdminRole').value = admin.role || 'admin';
    openModal('editAdminModal');
}
</script>

<?php
$content = ob_get_clean();
include __DIR__ . '/layout.php';
?>

<?php
/**
 * NEO PGA Merchant Dashboard - Layout Footer
 */
if (ob_get_level() > 0) {
    ob_end_flush();
}
?>
        </div><!-- /.page-body -->
    </main><!-- /.main-content -->

    <script>
        // Toggle mobile menu
        function toggleMenu() {
            const toggle = document.querySelector('.menu-toggle');
            const menu = document.getElementById('mobileMenu');
            const overlay = document.getElementById('menuOverlay');

            if (toggle && menu && overlay) {
                toggle.classList.toggle('active');
                menu.classList.toggle('active');
                overlay.classList.toggle('active');
                document.body.style.overflow = menu.classList.contains('active') ? 'hidden' : '';
            }
        }

        // Close menu on nav item click (mobile)
        document.querySelectorAll('.mobile-menu .nav-item').forEach(item => {
            item.addEventListener('click', () => {
                if (window.innerWidth < 1024) {
                    toggleMenu();
                }
            });
        });

        // Close menu on escape key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                const menu = document.getElementById('mobileMenu');
                if (menu && menu.classList.contains('active')) {
                    toggleMenu();
                }
            }
        });

        // Format currency helper
        function formatRupiah(num) {
            return 'Rp ' + new Intl.NumberFormat('id-ID').format(num);
        }

        // Format number helper
        function formatNumber(num) {
            return new Intl.NumberFormat('id-ID').format(num);
        }

        // ============================================
        // AUTO-REFRESH SYSTEM (Every 2 seconds)
        // Untuk update real-time transaksi & dashboard
        // ============================================
        const MerchantAutoRefresh = {
            interval: 2000, // 2 detik
            timer: null,
            lastActivity: Date.now(),
            paused: false,

            init() {
                this.start();

                // Track user activity
                document.addEventListener('keydown', () => this.onUserActivity());
                document.addEventListener('mousedown', () => this.onUserActivity());
                document.addEventListener('focus', (e) => {
                    if (e.target.matches('input, textarea, select')) {
                        this.pause();
                    }
                }, true);
                document.addEventListener('blur', (e) => {
                    if (e.target.matches('input, textarea, select')) {
                        setTimeout(() => {
                            if (!document.activeElement.matches('input, textarea, select')) {
                                this.resume();
                            }
                        }, 1000);
                    }
                }, true);

                this.createIndicator();
            },

            createIndicator() {
                const indicator = document.createElement('div');
                indicator.id = 'autoRefreshIndicator';
                indicator.innerHTML = `
                    <div style="display:flex;align-items:center;gap:6px">
                        <span class="pulse-dot"></span>
                        <span>Live: <strong>ON</strong></span>
                    </div>
                `;
                indicator.style.cssText = `
                    position: fixed;
                    bottom: 80px;
                    right: 16px;
                    background: linear-gradient(135deg, #10b981, #059669);
                    color: white;
                    padding: 6px 12px;
                    border-radius: 50px;
                    font-size: 11px;
                    font-weight: 500;
                    z-index: 9999;
                    box-shadow: 0 4px 15px rgba(16, 185, 129, 0.4);
                `;
                document.body.appendChild(indicator);

                // Add styles
                const style = document.createElement('style');
                style.textContent = `
                    .pulse-dot {
                        width: 6px;
                        height: 6px;
                        background: white;
                        border-radius: 50%;
                        animation: pulse 1s infinite;
                    }
                    @keyframes pulse {
                        0%, 100% { opacity: 1; transform: scale(1); }
                        50% { opacity: 0.5; transform: scale(1.3); }
                    }
                    #autoRefreshIndicator.paused {
                        background: linear-gradient(135deg, #f59e0b, #d97706) !important;
                    }
                    #autoRefreshIndicator.paused .pulse-dot {
                        animation: none;
                    }
                    @media (min-width: 1024px) {
                        #autoRefreshIndicator { bottom: 20px; right: 20px; }
                    }
                `;
                document.head.appendChild(style);
            },

            start() {
                this.timer = setInterval(() => this.refresh(), this.interval);
            },

            pause() {
                this.paused = true;
                const indicator = document.getElementById('autoRefreshIndicator');
                if (indicator) {
                    indicator.classList.add('paused');
                    indicator.querySelector('strong').textContent = 'PAUSED';
                }
            },

            resume() {
                this.paused = false;
                const indicator = document.getElementById('autoRefreshIndicator');
                if (indicator) {
                    indicator.classList.remove('paused');
                    indicator.querySelector('strong').textContent = 'ON';
                }
            },

            onUserActivity() {
                this.lastActivity = Date.now();
            },

            shouldRefresh() {
                if (this.paused) return false;
                if (document.activeElement.matches('input, textarea, select')) return false;
                if (Date.now() - this.lastActivity < 500) return false;
                return true;
            },

            refresh() {
                if (!this.shouldRefresh()) return;

                const scrollPos = window.scrollY;

                fetch(window.location.href, {
                    headers: { 'X-Requested-With': 'XMLHttpRequest' }
                })
                .then(response => response.text())
                .then(html => {
                    const parser = new DOMParser();
                    const newDoc = parser.parseFromString(html, 'text/html');

                    // Update tables
                    document.querySelectorAll('.table tbody').forEach((table, i) => {
                        const newTable = newDoc.querySelectorAll('.table tbody')[i];
                        if (newTable) table.innerHTML = newTable.innerHTML;
                    });

                    // Update stat values
                    document.querySelectorAll('.stat-value').forEach((stat, i) => {
                        const newStat = newDoc.querySelectorAll('.stat-value')[i];
                        if (newStat && stat.textContent !== newStat.textContent) {
                            stat.textContent = newStat.textContent;
                            stat.style.transition = 'background 0.3s';
                            stat.style.background = 'rgba(16, 185, 129, 0.2)';
                            stat.style.borderRadius = '8px';
                            setTimeout(() => stat.style.background = '', 500);
                        }
                    });

                    // Update badges
                    document.querySelectorAll('.badge').forEach((badge, i) => {
                        const newBadge = newDoc.querySelectorAll('.badge')[i];
                        if (newBadge) badge.outerHTML = newBadge.outerHTML;
                    });

                    window.scrollTo(0, scrollPos);

                    // Flash indicator
                    const indicator = document.getElementById('autoRefreshIndicator');
                    if (indicator) {
                        indicator.style.transform = 'scale(1.1)';
                        setTimeout(() => indicator.style.transform = 'scale(1)', 200);
                    }
                })
                .catch(err => console.log('Auto-refresh error:', err));
            }
        };

        // ============================================
        // PUSH NOTIFICATION SYSTEM (Browser)
        // Untuk notifikasi transaksi real-time ke HP
        // ============================================
        const PushNotification = {
            permission: 'default',
            enabled: false,

            init() {
                // Check if browser supports notifications
                if (!('Notification' in window)) {
                    console.log('Browser tidak support notifikasi');
                    return;
                }

                this.permission = Notification.permission;

                // Create enable button if not granted
                if (Notification.permission === 'default') {
                    this.createEnableButton();
                } else if (Notification.permission === 'granted') {
                    this.enabled = true;
                    this.startPolling();
                }
            },

            createEnableButton() {
                const btn = document.createElement('div');
                btn.id = 'pushNotifBtn';
                btn.innerHTML = `
                    <button id="enableNotifBtn" style="
                        display: flex;
                        align-items: center;
                        gap: 8px;
                        padding: 10px 16px;
                        background: linear-gradient(135deg, #3b82f6, #2563eb);
                        color: white;
                        border: none;
                        border-radius: 10px;
                        font-size: 12px;
                        font-weight: 600;
                        cursor: pointer;
                        box-shadow: 0 4px 15px rgba(59, 130, 246, 0.4);
                        transition: transform 0.2s, box-shadow 0.2s;
                    ">
                        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/>
                        </svg>
                        Aktifkan Notifikasi HP
                    </button>
                `;
                btn.style.cssText = `
                    position: fixed;
                    bottom: 140px;
                    right: 16px;
                    z-index: 9998;
                `;
                document.body.appendChild(btn);

                // Desktop position
                if (window.innerWidth >= 1024) {
                    btn.style.bottom = '80px';
                    btn.style.right = '20px';
                }

                // Add click event listener properly
                const enableBtn = document.getElementById('enableNotifBtn');
                if (enableBtn) {
                    enableBtn.addEventListener('click', () => {
                        this.requestPermission();
                    });

                    // Hover effect
                    enableBtn.addEventListener('mouseenter', () => {
                        enableBtn.style.transform = 'scale(1.05)';
                        enableBtn.style.boxShadow = '0 6px 20px rgba(59, 130, 246, 0.5)';
                    });
                    enableBtn.addEventListener('mouseleave', () => {
                        enableBtn.style.transform = 'scale(1)';
                        enableBtn.style.boxShadow = '0 4px 15px rgba(59, 130, 246, 0.4)';
                    });
                }
            },

            requestPermission() {
                console.log('Requesting notification permission...');

                Notification.requestPermission().then(permission => {
                    console.log('Permission result:', permission);

                    if (permission === 'granted') {
                        this.enabled = true;
                        this.permission = 'granted';

                        // Remove the button
                        const btnContainer = document.getElementById('pushNotifBtn');
                        if (btnContainer) btnContainer.remove();

                        // Show success notification
                        this.showNotification('Notifikasi Aktif!', 'Anda akan menerima notifikasi setiap ada pembayaran sukses.');

                        // Start polling for new transactions
                        this.startPolling();

                        // Show success indicator
                        this.showSuccessIndicator();
                    } else if (permission === 'denied') {
                        alert('Notifikasi diblokir oleh browser. Silakan aktifkan di pengaturan browser Anda.');
                    }
                }).catch(err => {
                    console.error('Error requesting permission:', err);
                    alert('Gagal mengaktifkan notifikasi. Pastikan Anda menggunakan HTTPS.');
                });
            },

            showSuccessIndicator() {
                const indicator = document.createElement('div');
                indicator.innerHTML = `
                    <div style="display:flex;align-items:center;gap:8px">
                        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                        </svg>
                        <span>Notifikasi Aktif!</span>
                    </div>
                `;
                indicator.style.cssText = `
                    position: fixed;
                    bottom: 140px;
                    right: 16px;
                    background: linear-gradient(135deg, #10b981, #059669);
                    color: white;
                    padding: 10px 16px;
                    border-radius: 10px;
                    font-size: 12px;
                    font-weight: 600;
                    z-index: 9998;
                    box-shadow: 0 4px 15px rgba(16, 185, 129, 0.4);
                `;
                if (window.innerWidth >= 1024) {
                    indicator.style.bottom = '80px';
                    indicator.style.right = '20px';
                }
                document.body.appendChild(indicator);

                // Remove after 3 seconds
                setTimeout(() => indicator.remove(), 3000);
            },

            showNotification(title, body, icon = null) {
                if (!this.enabled) return;

                try {
                    const options = {
                        body: body,
                        icon: icon || '/assets/images/logo-icon.svg',
                        badge: '/assets/images/logo-icon.svg',
                        vibrate: [200, 100, 200],
                        tag: 'neo-pga-' + Date.now(),
                        requireInteraction: true
                    };

                    const notif = new Notification(title, options);
                    notif.onclick = () => {
                        window.focus();
                        notif.close();
                    };
                } catch (err) {
                    console.error('Error showing notification:', err);
                }
            },

            lastCheckTime: Date.now(),

            startPolling() {
                console.log('Starting notification polling...');
                // Check for new transactions every 5 seconds
                setInterval(() => this.checkNewTransactions(), 5000);
            },

            checkNewTransactions() {
                if (!this.enabled) return;

                fetch('api/dashboard-stats.php?check_new=1&since=' + this.lastCheckTime)
                    .then(res => res.json())
                    .then(data => {
                        if (data.new_transactions && data.new_transactions.length > 0) {
                            data.new_transactions.forEach(trx => {
                                this.showNotification(
                                    '✅ Pembayaran Berhasil!',
                                    `${trx.customer_name || 'Customer'}\nRp ${formatNumber(trx.amount)}\nInvoice: ${trx.invoice_number}`
                                );
                            });
                        }
                        this.lastCheckTime = Date.now();
                    })
                    .catch(err => console.log('Check notifications error:', err));
            }
        };

        // Initialize on page load
        document.addEventListener('DOMContentLoaded', () => {
            MerchantAutoRefresh.init();
            PushNotification.init();
        });
    </script>

    <!-- Security Protection -->
    <script src="<?= ASSETS_URL ?>/js/security.js"></script>
</body>
</html>

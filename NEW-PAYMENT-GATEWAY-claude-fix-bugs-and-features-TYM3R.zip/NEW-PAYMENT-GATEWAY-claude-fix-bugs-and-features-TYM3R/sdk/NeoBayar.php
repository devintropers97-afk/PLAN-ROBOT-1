<?php
/**
 * ==========================================
 * NEO PGA SDK - SUPER SIMPLE INTEGRATION
 * ==========================================
 *
 * CARA PAKAI (3 LANGKAH SAJA!):
 *
 * 1. Copy file ini ke project kamu
 * 2. Ganti API_KEY dan SECRET_KEY di bawah
 * 3. Panggil function yang kamu butuhkan
 *
 * CONTOH:
 *
 *   // Buat pembayaran
 *   $result = NeoPGA::createPayment(100000, 'ORDER-123', 'Beli Produk');
 *
 *   // Redirect ke halaman bayar
 *   header('Location: ' . $result['payment_url']);
 *
 * ==========================================
 */

class NeoPGA
{
    // ========================================
    // GANTI INI DENGAN KREDENSIAL KAMU!
    // ========================================
    const API_KEY    = 'YOUR_API_KEY_HERE';      // Dari menu API Keys
    const SECRET_KEY = 'YOUR_SECRET_KEY_HERE';   // Dari menu API Keys
    const BASE_URL   = 'https://your-neopga-domain.com'; // GANTI dengan domain NEO PGA kamu!
    // ========================================

    /**
     * BUAT PEMBAYARAN BARU
     *
     * @param int    $amount      Nominal pembayaran (contoh: 100000)
     * @param string $referenceId ID unik dari sistem kamu (contoh: 'ORDER-123')
     * @param string $description Deskripsi pembayaran
     * @param array  $customer    Data customer (opsional)
     * @return array
     *
     * CONTOH PENGGUNAAN:
     *
     *   // Simple
     *   $result = NeoPGA::createPayment(100000, 'ORDER-123', 'Pembayaran Produk');
     *
     *   // Dengan data customer
     *   $result = NeoPGA::createPayment(100000, 'ORDER-123', 'Pembayaran', [
     *       'name'  => 'John Doe',
     *       'email' => 'john@email.com',
     *       'phone' => '081234567890'
     *   ]);
     *
     *   // Cek hasil
     *   if ($result['success']) {
     *       // Redirect ke halaman bayar
     *       header('Location: ' . $result['payment_url']);
     *       exit;
     *   } else {
     *       echo 'Error: ' . $result['error'];
     *   }
     */
    public static function createPayment($amount, $referenceId, $description = '', $customer = [])
    {
        $data = [
            'reference_id'   => $referenceId,
            'amount'         => (int) $amount,
            'payment_method' => 'qris',
            'description'    => $description ?: 'Pembayaran',
            'customer_name'  => $customer['name'] ?? '',
            'customer_email' => $customer['email'] ?? '',
            'customer_phone' => $customer['phone'] ?? '',
        ];

        return self::request('POST', '/api/create.php', $data);
    }

    /**
     * CEK STATUS PEMBAYARAN
     *
     * @param string $invoice Invoice number dari NEO PGA
     * @return array
     *
     * CONTOH:
     *   $status = NeoPGA::checkStatus('INV20231209ABCD1234');
     *
     *   if ($status['success']) {
     *       echo 'Status: ' . $status['data']['status'];
     *       // pending, success, expired, failed
     *   }
     */
    public static function checkStatus($invoice)
    {
        return self::request('GET', '/api/status.php?invoice=' . urlencode($invoice));
    }

    /**
     * CEK STATUS BY REFERENCE ID
     *
     * @param string $referenceId Reference ID dari sistem kamu
     * @return array
     *
     * CONTOH:
     *   $status = NeoPGA::checkStatusByRef('ORDER-123');
     */
    public static function checkStatusByRef($referenceId)
    {
        return self::request('GET', '/api/status.php?reference_id=' . urlencode($referenceId));
    }

    /**
     * VERIFIKASI CALLBACK/WEBHOOK
     *
     * Panggil ini di file callback.php kamu untuk memastikan
     * request benar-benar dari NEO PGA (bukan fake)
     *
     * @return array|false Returns data jika valid, false jika tidak
     *
     * CONTOH (di callback.php):
     *
     *   $payment = NeoPGA::verifyCallback();
     *
     *   if ($payment && $payment['status'] === 'success') {
     *       // Update database kamu
     *       $orderId = $payment['reference_id'];
     *       updateOrderStatus($orderId, 'paid');
     *
     *       // WAJIB response 200 OK
     *       http_response_code(200);
     *       echo json_encode(['status' => 'ok']);
     *   }
     */
    public static function verifyCallback()
    {
        // Get raw payload
        $payload = file_get_contents('php://input');

        // Get signature from header
        $signature = $_SERVER['HTTP_X_SIGNATURE'] ?? '';

        if (empty($payload) || empty($signature)) {
            return false;
        }

        // Verify signature
        $expectedSignature = hash_hmac('sha256', $payload, self::SECRET_KEY);

        if (!hash_equals($expectedSignature, $signature)) {
            return false;
        }

        // Parse and return data
        $data = json_decode($payload, true);

        return $data['data'] ?? $data;
    }

    /**
     * GENERATE PAYMENT URL
     *
     * Jika kamu sudah punya invoice number, gunakan ini
     * untuk mendapatkan URL pembayaran
     *
     * @param string $invoice
     * @return string
     */
    public static function getPaymentUrl($invoice)
    {
        return self::BASE_URL . '/public/pay.php?invoice=' . urlencode($invoice);
    }

    // ========================================
    // INTERNAL - Tidak perlu diubah
    // ========================================

    private static function request($method, $endpoint, $data = [])
    {
        $url = self::BASE_URL . $endpoint;

        $headers = [
            'Content-Type: application/json',
            'X-API-Key: ' . self::API_KEY,
        ];

        // Add signature for POST requests
        if ($method === 'POST' && !empty($data)) {
            $jsonData = json_encode($data);
            $signature = hash_hmac('sha256', $jsonData, self::SECRET_KEY);
            $headers[] = 'X-Signature: ' . $signature;
        }

        $ch = curl_init();

        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData ?? '');
        }

        curl_setopt_array($ch, [
            CURLOPT_URL            => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 30,
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);

        $response = curl_exec($ch);
        $error = curl_error($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($error) {
            return [
                'success' => false,
                'error'   => 'Connection error: ' . $error
            ];
        }

        $result = json_decode($response, true);

        if (!$result) {
            return [
                'success' => false,
                'error'   => 'Invalid response from server'
            ];
        }

        // Add payment_url for convenience
        if (isset($result['data']['invoice_number'])) {
            $result['payment_url'] = self::getPaymentUrl($result['data']['invoice_number']);
        }

        return $result;
    }
}

// ==========================================
// BACKWARD COMPATIBILITY ALIAS
// ==========================================
// Keep old class name for existing integrations
class_alias('NeoPGA', 'NeoBayar');

// ==========================================
// QUICK FUNCTIONS (Lebih Singkat Lagi!)
// ==========================================

/**
 * Shortcut untuk buat pembayaran
 *
 * CONTOH:
 *   $result = neopga_create(100000, 'ORDER-123');
 *   redirect($result['payment_url']);
 */
function neopga_create($amount, $referenceId, $description = '', $customer = [])
{
    return NeoPGA::createPayment($amount, $referenceId, $description, $customer);
}

/**
 * Shortcut untuk cek status
 */
function neopga_status($invoice)
{
    return NeoPGA::checkStatus($invoice);
}

/**
 * Shortcut untuk verifikasi callback
 */
function neopga_verify()
{
    return NeoPGA::verifyCallback();
}

// Backward compatibility function aliases (old NeoBayar function names)
function neobayar_create($amount, $referenceId, $description = '', $customer = []) {
    return neopga_create($amount, $referenceId, $description, $customer);
}
function neobayar_status($invoice) {
    return neopga_status($invoice);
}
function neobayar_verify() {
    return neopga_verify();
}

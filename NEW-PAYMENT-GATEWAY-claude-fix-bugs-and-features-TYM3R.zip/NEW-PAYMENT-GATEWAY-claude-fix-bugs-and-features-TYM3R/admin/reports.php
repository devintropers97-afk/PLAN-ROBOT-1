<?php
/**
 * NEO PGA Admin - Reports
 */
require_once __DIR__ . '/../includes/init.php';

$auth = new Auth('admin');
$auth->requireAuth();

$adminUser = $auth->user();
$db = Database::getInstance();

// Date range
$startDate = $_GET['start_date'] ?? date('Y-m-01');
$endDate = $_GET['end_date'] ?? date('Y-m-d');

// Get stats
$stats = $db->fetch(
    "SELECT 
        COUNT(*) as total_trx,
        SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) as success_trx,
        COALESCE(SUM(CASE WHEN status = 'success' THEN total_amount ELSE 0 END), 0) as total_amount,
        COALESCE(SUM(CASE WHEN status = 'success' THEN commission_amount ELSE 0 END), 0) as total_commission
     FROM transactions 
     WHERE DATE(created_at) BETWEEN ? AND ?",
    [$startDate, $endDate]
);

// Daily breakdown
$dailyData = $db->fetchAll(
    "SELECT 
        DATE(created_at) as date,
        COUNT(*) as total,
        SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) as success,
        COALESCE(SUM(CASE WHEN status = 'success' THEN total_amount ELSE 0 END), 0) as amount
     FROM transactions 
     WHERE DATE(created_at) BETWEEN ? AND ?
     GROUP BY DATE(created_at)
     ORDER BY date DESC",
    [$startDate, $endDate]
);

// Top merchants
$topMerchants = $db->fetchAll(
    "SELECT m.business_name, COUNT(t.id) as trx_count, 
            COALESCE(SUM(CASE WHEN t.status = 'success' THEN t.total_amount ELSE 0 END), 0) as total_amount
     FROM merchants m
     LEFT JOIN transactions t ON m.id = t.merchant_id AND DATE(t.created_at) BETWEEN ? AND ?
     GROUP BY m.id
     ORDER BY total_amount DESC
     LIMIT 10",
    [$startDate, $endDate]
);

$pageTitle = 'Laporan';
$currentPage = 'reports';

$extraCss = '
.report-filters { background: white; border-radius: 12px; border: 1px solid var(--gray-200); padding: 1.5rem; margin-bottom: 1.5rem; }
.report-filters form { display: flex; gap: 1rem; align-items: flex-end; flex-wrap: wrap; }
.stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 1rem; margin-bottom: 1.5rem; }
.stat-box { background: white; border-radius: 12px; border: 1px solid var(--gray-200); padding: 1.5rem; }
.stat-box .label { font-size: 0.875rem; color: var(--gray-500); margin-bottom: 0.5rem; }
.stat-box .value { font-size: 1.5rem; font-weight: 700; color: var(--gray-900); }
.stat-box .value.primary { color: var(--primary); }
.stat-box .value.success { color: var(--success); }
.report-grid { display: grid; grid-template-columns: 2fr 1fr; gap: 1.5rem; }
@media (max-width: 1024px) { .stats-grid { grid-template-columns: repeat(2, 1fr); } .report-grid { grid-template-columns: 1fr; } }
@media (max-width: 768px) { .stats-grid { grid-template-columns: 1fr; } }
';

ob_start();
?>

<div class="flex justify-between items-center mb-6">
    <div>
        <h1 class="text-2xl font-bold text-gray-900">Laporan Transaksi</h1>
        <p class="text-gray-500">Periode: <?= date('d M Y', strtotime($startDate)) ?> - <?= date('d M Y', strtotime($endDate)) ?></p>
    </div>
    <a href="reports-export.php?start_date=<?= $startDate ?>&end_date=<?= $endDate ?>" class="btn btn-primary">
        📊 Export Excel
    </a>
</div>

<!-- Filters -->
<div class="report-filters">
    <form method="GET">
        <div class="form-group" style="margin-bottom:0">
            <label class="form-label">Tanggal Mulai</label>
            <input type="date" name="start_date" class="form-input" value="<?= $startDate ?>">
        </div>
        <div class="form-group" style="margin-bottom:0">
            <label class="form-label">Tanggal Akhir</label>
            <input type="date" name="end_date" class="form-input" value="<?= $endDate ?>">
        </div>
        <button type="submit" class="btn btn-primary">Tampilkan</button>
    </form>
</div>

<!-- Stats -->
<div class="stats-grid">
    <div class="stat-box">
        <div class="label">Total Transaksi</div>
        <div class="value"><?= number_format($stats['total_trx'] ?? 0) ?></div>
    </div>
    <div class="stat-box">
        <div class="label">Transaksi Sukses</div>
        <div class="value success"><?= number_format($stats['success_trx'] ?? 0) ?></div>
    </div>
    <div class="stat-box">
        <div class="label">Total Nilai Transaksi</div>
        <div class="value primary"><?= formatRupiah($stats['total_amount'] ?? 0) ?></div>
    </div>
    <div class="stat-box">
        <div class="label">Total Komisi</div>
        <div class="value"><?= formatRupiah($stats['total_commission'] ?? 0) ?></div>
    </div>
</div>

<div class="report-grid">
    <!-- Daily Breakdown -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Breakdown Harian</h3>
        </div>
        <div class="table-wrapper">
            <table class="table">
                <thead>
                    <tr>
                        <th>Tanggal</th>
                        <th>Total Trx</th>
                        <th>Sukses</th>
                        <th>Nilai Sukses</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($dailyData)): ?>
                    <tr><td colspan="4" style="text-align:center;padding:2rem;color:var(--gray-500)">Tidak ada data</td></tr>
                    <?php else: ?>
                    <?php foreach ($dailyData as $day): ?>
                    <tr>
                        <td><?= date('d M Y', strtotime($day['date'])) ?></td>
                        <td><?= number_format($day['total']) ?></td>
                        <td><span class="badge badge-success"><?= number_format($day['success']) ?></span></td>
                        <td style="font-weight:600"><?= formatRupiah($day['amount']) ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- Top Merchants -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Top Merchants</h3>
        </div>
        <div class="card-body">
            <?php if (empty($topMerchants)): ?>
            <p style="text-align:center;color:var(--gray-500);padding:2rem">Tidak ada data</p>
            <?php else: ?>
            <?php foreach ($topMerchants as $i => $merchant): ?>
            <div style="display:flex;justify-content:space-between;align-items:center;padding:0.75rem 0;border-bottom:1px solid var(--gray-100)">
                <div style="display:flex;align-items:center;gap:0.75rem">
                    <span style="width:24px;height:24px;background:var(--gray-100);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:0.75rem;font-weight:600"><?= $i + 1 ?></span>
                    <div>
                        <div style="font-weight:600;font-size:0.875rem"><?= htmlspecialchars($merchant['business_name']) ?></div>
                        <div style="font-size:0.75rem;color:var(--gray-500)"><?= number_format($merchant['trx_count']) ?> transaksi</div>
                    </div>
                </div>
                <div style="font-weight:600;color:var(--primary)"><?= formatRupiah($merchant['total_amount']) ?></div>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php
$content = ob_get_clean();
include __DIR__ . '/layout.php';
?>

<?php
/**
 * NEO PGA Database Class
 * PDO Database wrapper with prepared statements
 */

class Database
{
    private static $instance = null;
    private $pdo;
    private $statement;
    private $queryCount = 0;

    /**
     * Private constructor for singleton pattern
     */
    private function __construct()
    {
        $dsn = sprintf(
            "mysql:host=%s;port=%s;dbname=%s;charset=%s",
            DB_HOST,
            DB_PORT,
            DB_NAME,
            DB_CHARSET
        );

        $options = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES " . DB_CHARSET
        ];

        try {
            $this->pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            if (APP_DEBUG) {
                die("Database connection failed: " . $e->getMessage());
            } else {
                die("Database connection failed. Please try again later.");
            }
        }
    }

    /**
     * Get database instance (singleton)
     */
    public static function getInstance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Get PDO instance
     */
    public function getPdo(): PDO
    {
        return $this->pdo;
    }

    /**
     * Execute a query with parameters
     */
    public function query(string $sql, array $params = []): self
    {
        $this->queryCount++;
        $this->statement = $this->pdo->prepare($sql);
        $this->statement->execute($params);
        return $this;
    }

    /**
     * Fetch single row
     * Can be called with SQL and params for convenience
     */
    public function fetch(?string $sql = null, array $params = []): ?array
    {
        if ($sql !== null) {
            $this->query($sql, $params);
        }
        $result = $this->statement->fetch();
        return $result ?: null;
    }

    /**
     * Fetch all rows
     * Can be called with SQL and params for convenience
     */
    public function fetchAll(?string $sql = null, array $params = []): array
    {
        if ($sql !== null) {
            $this->query($sql, $params);
        }
        return $this->statement->fetchAll();
    }

    /**
     * Fetch single column value
     * @return mixed
     */
    public function fetchColumn()
    {
        return $this->statement->fetchColumn();
    }

    /**
     * Get row count
     */
    public function rowCount(): int
    {
        return $this->statement->rowCount();
    }

    /**
     * Get last insert ID
     */
    public function lastInsertId(): string
    {
        return $this->pdo->lastInsertId();
    }

    /**
     * Begin transaction
     */
    public function beginTransaction(): bool
    {
        return $this->pdo->beginTransaction();
    }

    /**
     * Commit transaction
     */
    public function commit(): bool
    {
        return $this->pdo->commit();
    }

    /**
     * Rollback transaction
     */
    public function rollback(): bool
    {
        return $this->pdo->rollBack();
    }

    /**
     * Check if currently in a transaction
     */
    public function inTransaction(): bool
    {
        return $this->pdo->inTransaction();
    }

    /**
     * Insert record
     */
    public function insert(string $table, array $data): int
    {
        $columns = implode(', ', array_keys($data));
        $placeholders = implode(', ', array_fill(0, count($data), '?'));
        
        $sql = "INSERT INTO {$table} ({$columns}) VALUES ({$placeholders})";
        $this->query($sql, array_values($data));
        
        return (int) $this->lastInsertId();
    }

    /**
     * Update record
     */
    public function update(string $table, array $data, string $where, array $whereParams = []): int
    {
        $set = implode(' = ?, ', array_keys($data)) . ' = ?';
        $sql = "UPDATE {$table} SET {$set} WHERE {$where}";
        
        $params = array_merge(array_values($data), $whereParams);
        $this->query($sql, $params);
        
        return $this->rowCount();
    }

    /**
     * Delete record
     */
    public function delete(string $table, string $where, array $params = []): int
    {
        $sql = "DELETE FROM {$table} WHERE {$where}";
        $this->query($sql, $params);
        return $this->rowCount();
    }

    /**
     * Find single record by ID
     */
    public function find(string $table, int $id, string $column = 'id'): ?array
    {
        $sql = "SELECT * FROM {$table} WHERE {$column} = ? LIMIT 1";
        $result = $this->query($sql, [$id])->fetch();
        return $result ?: null; // PDO::fetch() returns false on no results
    }

    /**
     * Find single record by conditions
     */
    public function findBy(string $table, array $conditions): ?array
    {
        $where = implode(' = ? AND ', array_keys($conditions)) . ' = ?';
        $sql = "SELECT * FROM {$table} WHERE {$where} LIMIT 1";
        $result = $this->query($sql, array_values($conditions))->fetch();
        return $result ?: null; // PDO::fetch() returns false on no results
    }

    /**
     * Find all records
     */
    public function findAll(string $table, string $orderBy = 'id DESC', int $limit = 0): array
    {
        $sql = "SELECT * FROM {$table} ORDER BY {$orderBy}";
        if ($limit > 0) {
            $sql .= " LIMIT {$limit}";
        }
        return $this->query($sql)->fetchAll();
    }

    /**
     * Count records
     */
    public function count(string $table, string $where = '1=1', array $params = []): int
    {
        $sql = "SELECT COUNT(*) FROM {$table} WHERE {$where}";
        $result = $this->query($sql, $params)->fetchColumn();
        return (int) ($result ?: 0);
    }

    /**
     * Check if record exists
     */
    public function exists(string $table, string $where, array $params = []): bool
    {
        return $this->count($table, $where, $params) > 0;
    }

    /**
     * Get query count
     */
    public function getQueryCount(): int
    {
        return $this->queryCount;
    }

    /**
     * Prevent cloning
     */
    private function __clone() {}

    /**
     * Prevent unserialization
     */
    public function __wakeup()
    {
        throw new Exception("Cannot unserialize singleton");
    }
}

// Note: db() helper function is defined in init.php to avoid duplicate declaration

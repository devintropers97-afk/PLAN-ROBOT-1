<?php
/**
 * NEO PGA Admin - Payment Verification
 * VERSI KETAT: Kode unik WAJIB, transfer tanpa kode unik = TOLAK
 */
require_once __DIR__ . '/../includes/init.php';

$auth = new Auth('admin');
$auth->requireAuth();

$adminUser = $auth->user();
$db = Database::getInstance();
$transaction = new Transaction();

$message = '';
$messageType = '';
$foundTransaction = null;
$showManualConfirm = false;
$manualConfirmData = null;

// =============================================
// AUTO-RESET KODE UNIK YANG HAMPIR HABIS
// Threshold: 5 atau kurang kode tersedia
// =============================================
$autoResetCount = 0;
$merchantsNeedingReset = $db->fetchAll(
    "SELECT m.id, m.business_name,
            COUNT(CASE WHEN pc.status = 'available' THEN 1 END) as available,
            COUNT(CASE WHEN pc.status = 'used' THEN 1 END) as used
     FROM merchants m
     LEFT JOIN payment_codes pc ON m.id = pc.merchant_id
     GROUP BY m.id
     HAVING available <= 5 AND used > 0"
);

foreach ($merchantsNeedingReset as $m) {
    $db->query(
        "UPDATE payment_codes
         SET status = 'available',
             transaction_id = NULL,
             reserved_at = NULL,
             expires_at = NULL,
             used_at = NULL
         WHERE merchant_id = ? AND status = 'used'",
        [$m['id']]
    );
    $resetCount = $db->rowCount();
    $autoResetCount += $resetCount;
    if ($resetCount > 0) {
        logActivity('system', null, 'payment_code_auto_reset_verify', 'payment_codes',
            "Auto-reset {$resetCount} codes for merchant #{$m['id']} - triggered by verify page");
    }
}

// Handle verification by amount (STRICT MODE)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['verify_amount'])) {
    verifyCsrf();
    $amount = (int) preg_replace('/[^0-9]/', '', $_POST['amount'] ?? '');
    
    if ($amount > 0) {
        // Cari transaksi dengan nominal PERSIS (termasuk kode unik)
        $result = $transaction->autoVerify($amount);
        
        if ($result['success']) {
            $message = '✅ Transaksi ' . ($result['data']['invoice_number'] ?? '') . ' berhasil diverifikasi!';
            $messageType = 'success';
        } else {
            // Cek apakah ada transaksi dengan nominal dasar (tanpa kode unik)
            $baseAmountTrx = $db->fetch(
                "SELECT t.*, m.business_name as merchant_name 
                 FROM transactions t 
                 LEFT JOIN merchants m ON t.merchant_id = m.id
                 WHERE t.amount = ? AND t.status IN ('pending', 'waiting') 
                 ORDER BY t.created_at DESC LIMIT 1",
                [$amount]
            );
            
            if ($baseAmountTrx) {
                // Ada transaksi tapi customer transfer TANPA kode unik
                $message = '⚠️ PERINGATAN: Ditemukan transaksi dengan nominal dasar Rp ' . number_format($amount, 0, ',', '.') . 
                           ' tapi customer seharusnya transfer Rp ' . number_format($baseAmountTrx['total_amount'], 0, ',', '.') . 
                           ' (termasuk kode unik +' . $baseAmountTrx['unique_code'] . '). ' .
                           'Customer mungkin transfer TANPA kode unik. Silakan konfirmasi manual atau minta customer transfer ulang dengan nominal yang benar.';
                $messageType = 'warning';
                $showManualConfirm = true;
                $manualConfirmData = $baseAmountTrx;
            } else {
                $message = $result['message'];
                $messageType = 'danger';
            }
        }
    } else {
        $message = 'Masukkan nominal yang valid';
        $messageType = 'danger';
    }
}

// Handle MANUAL verification (admin override - dengan konfirmasi)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['verify_invoice'])) {
    verifyCsrf();
    $invoice = sanitize($_POST['invoice'] ?? '');
    $forceVerify = isset($_POST['force_verify']) && $_POST['force_verify'] === '1';
    $adminNotes = sanitize($_POST['admin_notes'] ?? '');
    
    $trx = $transaction->getByInvoice($invoice);
    
    if ($trx) {
        if ($forceVerify) {
            // Admin memaksa verifikasi (dengan catatan)
            $notes = "MANUAL OVERRIDE oleh Admin: " . ($adminNotes ?: 'Tanpa catatan');
            $result = $transaction->verify($trx['id'], $auth->id(), $notes);
            
            if ($result['success']) {
                $message = '✅ Transaksi berhasil diverifikasi secara MANUAL oleh Admin!';
                $messageType = 'success';
                
                // Log aktivitas khusus
                logActivity('admin', $auth->id(), 'manual_verify_override', 'transactions', 
                    "Manual override verification for {$trx['invoice_number']} - Notes: {$adminNotes}");
            } else {
                $message = $result['message'];
                $messageType = 'danger';
            }
        } else {
            // Verifikasi normal
            $result = $transaction->verify($trx['id'], $auth->id(), '');
            if ($result['success']) {
                $message = '✅ Transaksi berhasil diverifikasi!';
                $messageType = 'success';
            } else {
                $message = $result['message'];
                $messageType = 'danger';
            }
        }
    } else {
        $message = 'Transaksi tidak ditemukan';
        $messageType = 'danger';
    }
}

// Search by amount
if (isset($_GET['search_amount'])) {
    $searchAmount = (int) preg_replace('/[^0-9]/', '', $_GET['search_amount']);
    if ($searchAmount > 0) {
        // Cari dengan nominal persis
        $foundTransaction = $transaction->findByUniqueAmount($searchAmount);
        
        // Jika tidak ketemu, cari dengan nominal dasar
        if (!$foundTransaction) {
            $baseMatch = $db->fetch(
                "SELECT t.*, m.business_name as merchant_name 
                 FROM transactions t 
                 LEFT JOIN merchants m ON t.merchant_id = m.id
                 WHERE t.amount = ? AND t.status IN ('pending', 'waiting') 
                 ORDER BY t.created_at DESC LIMIT 1",
                [$searchAmount]
            );
            
            if ($baseMatch) {
                $foundTransaction = $baseMatch;
                $foundTransaction['_warning'] = 'Nominal cocok dengan AMOUNT DASAR, bukan total. Customer mungkin tidak menyertakan kode unik!';
            }
        }
    }
}

// Get pending transactions
$pendingTransactions = $db->fetchAll(
    "SELECT t.*, m.business_name as merchant_name 
     FROM transactions t 
     LEFT JOIN merchants m ON t.merchant_id = m.id 
     WHERE t.status IN ('pending', 'waiting') 
     ORDER BY t.created_at DESC LIMIT 20"
);
$pendingCount = $db->fetch("SELECT COUNT(*) as c FROM transactions WHERE status IN ('pending', 'waiting')")['c'] ?? 0;

// Get payment code stats
$codeStats = $db->fetch(
    "SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status = 'available' THEN 1 ELSE 0 END) as available,
        SUM(CASE WHEN status = 'reserved' THEN 1 ELSE 0 END) as reserved,
        SUM(CASE WHEN status = 'used' THEN 1 ELSE 0 END) as used
     FROM payment_codes"
);

$pageTitle = 'Verifikasi Pembayaran';
$currentPage = 'verify';

$extraCss = '
.verify-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; margin-bottom: 1.5rem; }
.verify-card { background: white; border-radius: 12px; border: 1px solid var(--gray-200); }
.verify-card.highlight { border-color: var(--primary); box-shadow: 0 0 0 3px rgba(13, 148, 136, 0.1); }
.verify-card-header { padding: 1rem 1.5rem; border-bottom: 1px solid var(--gray-100); font-weight: 600; }
.verify-card-body { padding: 1.5rem; }
.amount-input { font-size: 1.25rem !important; font-weight: 600 !important; }
.found-box { background: var(--gray-50); border-radius: 8px; padding: 1rem; margin-top: 1rem; }
.found-row { display: flex; justify-content: space-between; padding: 0.5rem 0; }
.warning-box { background: #fef3c7; border: 2px solid #f59e0b; border-radius: 12px; padding: 1rem; margin: 1rem 0; }
.danger-box { background: #fee2e2; border: 2px solid #ef4444; border-radius: 12px; padding: 1rem; margin: 1rem 0; }
.code-stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 1rem; margin-bottom: 1.5rem; }
.code-stat { background: white; border-radius: 10px; padding: 1rem; text-align: center; border: 1px solid var(--gray-200); }
.code-stat-value { font-size: 1.5rem; font-weight: 700; }
.code-stat-label { font-size: 0.75rem; color: var(--gray-500); text-transform: uppercase; }
.manual-confirm-box { background: linear-gradient(135deg, #fef3c7, #fef9c3); border: 2px solid #f59e0b; border-radius: 16px; padding: 1.5rem; margin: 1.5rem 0; }
@media (max-width: 768px) { .verify-grid { grid-template-columns: 1fr; } .code-stats { grid-template-columns: repeat(2, 1fr); } }
';

ob_start();
?>

<!-- Payment Code Stats -->
<div class="code-stats">
    <div class="code-stat">
        <div class="code-stat-value" style="color: var(--gray-700)"><?= number_format($codeStats['total'] ?? 0) ?></div>
        <div class="code-stat-label">Total Kode</div>
    </div>
    <div class="code-stat" style="<?= ($codeStats['available'] ?? 0) <= 5 ? 'background: #fef3c7; border: 2px solid #f59e0b;' : '' ?>">
        <div class="code-stat-value" style="color: #10b981"><?= number_format($codeStats['available'] ?? 0) ?></div>
        <div class="code-stat-label">Tersedia <?= ($codeStats['available'] ?? 0) <= 5 ? '⚠️' : '' ?></div>
    </div>
    <div class="code-stat">
        <div class="code-stat-value" style="color: #f59e0b"><?= number_format($codeStats['reserved'] ?? 0) ?></div>
        <div class="code-stat-label">Dipakai</div>
    </div>
    <div class="code-stat">
        <div class="code-stat-value" style="color: #6b7280"><?= number_format($codeStats['used'] ?? 0) ?></div>
        <div class="code-stat-label">Selesai</div>
    </div>
</div>

<?php if ($autoResetCount > 0): ?>
<div style="background: linear-gradient(135deg, rgba(16, 185, 129, 0.1), rgba(5, 150, 105, 0.1)); border: 2px solid #10b981; border-radius: 10px; padding: 0.75rem 1rem; margin-bottom: 1rem; display: flex; align-items: center; gap: 8px;">
    <span style="font-size: 1.2rem;">🔄</span>
    <span style="color: #059669; font-size: 0.85rem;">
        <strong>AUTO-RESET:</strong> <?= $autoResetCount ?> kode unik telah direset otomatis karena hampir habis!
    </span>
</div>
<?php endif; ?>

<?php if ($message): ?>
<div class="alert alert-<?= $messageType ?> mb-6">
    <?= $message ?>
</div>
<?php endif; ?>

<?php if ($showManualConfirm && $manualConfirmData): ?>
<!-- Manual Confirm Box -->
<div class="manual-confirm-box">
    <h3 style="margin:0 0 1rem;color:#92400e;display:flex;align-items:center;gap:8px">
        <span style="font-size:1.5rem">⚠️</span> Konfirmasi Manual Diperlukan
    </h3>
    <div class="danger-box">
        <strong style="color:#dc2626">Customer transfer TANPA kode unik!</strong>
        <p style="margin:8px 0 0;color:#7f1d1d;font-size:0.9rem">
            Seharusnya: <strong>Rp <?= number_format($manualConfirmData['total_amount'], 0, ',', '.') ?></strong> 
            (Amount: Rp <?= number_format($manualConfirmData['amount'], 0, ',', '.') ?> + Kode Unik: +<?= $manualConfirmData['unique_code'] ?>)
        </p>
    </div>
    
    <div class="found-box" style="background:white">
        <div class="found-row"><span>Invoice:</span><code><?= $manualConfirmData['invoice_number'] ?></code></div>
        <div class="found-row"><span>Merchant:</span><strong><?= htmlspecialchars($manualConfirmData['merchant_name'] ?? '-') ?></strong></div>
        <div class="found-row"><span>Customer:</span><strong><?= htmlspecialchars($manualConfirmData['customer_name'] ?? '-') ?></strong></div>
        <div class="found-row"><span>Amount Dasar:</span><span>Rp <?= number_format($manualConfirmData['amount'], 0, ',', '.') ?></span></div>
        <div class="found-row"><span>Kode Unik:</span><span style="color:#dc2626;font-weight:700">+<?= $manualConfirmData['unique_code'] ?></span></div>
        <div class="found-row"><span>Total Seharusnya:</span><strong style="color:#dc2626">Rp <?= number_format($manualConfirmData['total_amount'], 0, ',', '.') ?></strong></div>
    </div>
    
    <form method="POST" style="margin-top:1.5rem">
        <?= csrfField() ?>
        <input type="hidden" name="verify_invoice" value="1">
        <input type="hidden" name="force_verify" value="1">
        <input type="hidden" name="invoice" value="<?= $manualConfirmData['invoice_number'] ?>">
        
        <div class="form-group">
            <label class="form-label">Catatan Admin (Wajib untuk override):</label>
            <textarea name="admin_notes" class="form-input" rows="2" required placeholder="Contoh: Customer sudah konfirmasi via WA, selisih Rp <?= $manualConfirmData['unique_code'] ?> diabaikan"></textarea>
        </div>
        
        <div style="display:flex;gap:1rem">
            <button type="submit" class="btn btn-warning" onclick="return confirm('YAKIN verifikasi manual? Pastikan sudah konfirmasi dengan customer!')">
                ⚠️ Verifikasi Manual (Override)
            </button>
            <a href="verify.php" class="btn btn-secondary">Batal</a>
        </div>
    </form>
</div>
<?php endif; ?>

<div class="verify-grid">
    <!-- Quick Verify -->
    <div class="verify-card highlight">
        <div class="verify-card-header">⚡ Verifikasi Cepat (Nominal PERSIS)</div>
        <div class="verify-card-body">
            <div class="warning-box" style="margin-top:0">
                <strong style="color:#92400e">⚠️ PENTING:</strong>
                <p style="margin:4px 0 0;color:#a16207;font-size:0.85rem">
                    Masukkan nominal PERSIS yang diterima (termasuk kode unik). 
                    Jika customer transfer tanpa kode unik, sistem akan MENOLAK dan meminta konfirmasi admin.
                </p>
            </div>
            
            <form method="POST" id="quickVerifyForm">
                <?= csrfField() ?>
                <input type="hidden" name="verify_amount" value="1">
                <div class="form-group">
                    <label class="form-label">Nominal Transfer Diterima</label>
                    <input type="text" name="amount" id="verifyAmount" class="form-input amount-input" placeholder="100.500" autocomplete="off" autofocus>
                </div>
                <button type="submit" class="btn btn-primary" style="width:100%">Verifikasi Sekarang</button>
            </form>
        </div>
    </div>
    
    <!-- Search -->
    <div class="verify-card">
        <div class="verify-card-header">🔍 Cari Transaksi</div>
        <div class="verify-card-body">
            <p class="text-gray-500 text-sm mb-4">Cari transaksi berdasarkan nominal</p>
            <form method="GET" class="mb-4">
                <div class="flex gap-2">
                    <input type="text" name="search_amount" class="form-input" style="flex:1" placeholder="Masukkan nominal..." value="<?= htmlspecialchars($_GET['search_amount'] ?? '') ?>">
                    <button type="submit" class="btn btn-secondary">Cari</button>
                </div>
            </form>
            
            <?php if ($foundTransaction): ?>
                <?php if (isset($foundTransaction['_warning'])): ?>
                <div class="alert alert-warning" style="margin-bottom:1rem">
                    ⚠️ <?= $foundTransaction['_warning'] ?>
                </div>
                <?php else: ?>
                <div class="alert alert-success">✅ Transaksi Ditemukan!</div>
                <?php endif; ?>
                
                <div class="found-box">
                    <div class="found-row"><span>Invoice:</span><code><?= $foundTransaction['invoice_number'] ?></code></div>
                    <div class="found-row"><span>Amount:</span><span>Rp <?= number_format($foundTransaction['amount'], 0, ',', '.') ?></span></div>
                    <div class="found-row"><span>Kode Unik:</span><span style="color:#0d9488;font-weight:600">+<?= $foundTransaction['unique_code'] ?></span></div>
                    <div class="found-row"><span>Total Bayar:</span><strong style="color:var(--primary)">Rp <?= number_format($foundTransaction['total_amount'], 0, ',', '.') ?></strong></div>
                    <div class="found-row"><span>Status:</span><span class="badge badge-<?= $foundTransaction['status'] === 'success' ? 'success' : 'warning' ?>"><?= ucfirst($foundTransaction['status']) ?></span></div>
                    
                    <?php if (in_array($foundTransaction['status'], ['pending', 'waiting'])): ?>
                    <form method="POST" class="mt-4">
                        <?= csrfField() ?>
                        <input type="hidden" name="verify_invoice" value="1">
                        <input type="hidden" name="invoice" value="<?= $foundTransaction['invoice_number'] ?>">
                        <button type="submit" class="btn btn-success" style="width:100%">✓ Verifikasi Transaksi Ini</button>
                    </form>
                    <?php endif; ?>
                </div>
            <?php elseif (isset($_GET['search_amount'])): ?>
            <div class="alert alert-warning">Tidak ditemukan transaksi pending dengan nominal tersebut.</div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Pending List -->
<div class="card">
    <div class="card-header" style="display:flex;justify-content:space-between;align-items:center">
        <h3 class="card-title">Transaksi Menunggu Verifikasi <span class="badge badge-warning"><?= $pendingCount ?></span></h3>
    </div>
    <div class="table-wrapper">
        <table class="table">
            <thead>
                <tr>
                    <th>Invoice</th>
                    <th>Merchant</th>
                    <th>Customer</th>
                    <th>Amount</th>
                    <th>Kode Unik</th>
                    <th>Total Bayar</th>
                    <th>Expired</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($pendingTransactions)): ?>
                <tr><td colspan="8" style="text-align:center;padding:2rem;color:var(--gray-500)">✅ Tidak ada transaksi pending</td></tr>
                <?php else: ?>
                <?php foreach ($pendingTransactions as $trx): ?>
                <tr>
                    <td><code style="font-size:0.75rem"><?= $trx['invoice_number'] ?></code></td>
                    <td><?= htmlspecialchars($trx['merchant_name'] ?? '-') ?></td>
                    <td><?= htmlspecialchars($trx['customer_name'] ?? '-') ?></td>
                    <td style="font-size:0.85rem">Rp <?= number_format($trx['amount'], 0, ',', '.') ?></td>
                    <td><span style="color:#0d9488;font-weight:600">+<?= $trx['unique_code'] ?></span></td>
                    <td style="font-weight:700;color:var(--primary)">Rp <?= number_format($trx['total_amount'], 0, ',', '.') ?></td>
                    <td style="font-size:0.8rem"><?= date('d/m H:i', strtotime($trx['expired_at'])) ?></td>
                    <td>
                        <form method="POST" style="display:inline">
                            <?= csrfField() ?>
                            <input type="hidden" name="verify_invoice" value="1">
                            <input type="hidden" name="invoice" value="<?= $trx['invoice_number'] ?>">
                            <button type="submit" class="btn btn-sm btn-success" onclick="return confirm('Verifikasi transaksi ini?\n\nPastikan customer sudah transfer PERSIS Rp <?= number_format($trx['total_amount'], 0, ',', '.') ?>')">✓</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
document.getElementById('verifyAmount')?.addEventListener('input', function(e) {
    let v = this.value.replace(/[^0-9]/g, '');
    if (v) this.value = new Intl.NumberFormat('id-ID').format(v);
});
document.getElementById('quickVerifyForm')?.addEventListener('submit', function(e) {
    document.getElementById('verifyAmount').value = document.getElementById('verifyAmount').value.replace(/[^0-9]/g, '');
});
</script>

<?php
$content = ob_get_clean();
include __DIR__ . '/layout.php';
?>

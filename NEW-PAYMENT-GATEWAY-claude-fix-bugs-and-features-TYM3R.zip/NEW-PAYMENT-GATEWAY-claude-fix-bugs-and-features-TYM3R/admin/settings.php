<?php
/**
 * NEO PGA Admin - Settings
 */
require_once __DIR__ . '/../includes/init.php';

$auth = new Auth('admin');
$auth->requireAuth();

$adminUser = $auth->user();
$db = Database::getInstance();
$message = '';
$messageType = '';

// Nama tabel settings
$tableName = 'system_settings';

// Get current settings
$settings = [];
try {
    $rows = $db->fetchAll("SELECT setting_key, setting_value FROM $tableName");
    foreach ($rows as $row) {
        $settings[$row['setting_key']] = $row['setting_value'];
    }
} catch (Exception $e) {
    // Table mungkin belum ada
}

// Handle Save
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    
    $updates = [
        'app_name' => sanitize($_POST['app_name'] ?? 'NEO PGA'),
        'company_name' => sanitize($_POST['company_name'] ?? ''),
        'company_email' => sanitize($_POST['company_email'] ?? ''),
        'company_phone' => sanitize($_POST['company_phone'] ?? ''),
        'company_address' => sanitize($_POST['company_address'] ?? ''),
        'default_commission' => (float)($_POST['default_commission'] ?? 2.5),
        'unique_code_min' => (int)($_POST['unique_code_min'] ?? 1),
        'unique_code_max' => (int)($_POST['unique_code_max'] ?? 999),
        'payment_expiry_minutes' => (int)($_POST['payment_expiry_minutes'] ?? 60),
        'min_settlement' => (int)($_POST['min_settlement'] ?? 50000),
    ];
    
    try {
        foreach ($updates as $key => $value) {
            $exists = $db->fetch("SELECT id FROM $tableName WHERE setting_key = ?", [$key]);
            if ($exists) {
                $db->query("UPDATE $tableName SET setting_value = ? WHERE setting_key = ?", [$value, $key]);
            } else {
                $db->query("INSERT INTO $tableName (setting_key, setting_value) VALUES (?, ?)", [$key, $value]);
            }
            $settings[$key] = $value;
        }
        $message = 'Pengaturan berhasil disimpan';
        $messageType = 'success';
    } catch (Exception $e) {
        $message = 'Gagal menyimpan: ' . $e->getMessage();
        $messageType = 'danger';
    }
}

$pageTitle = 'Pengaturan';
$currentPage = 'settings';

$extraCss = '
.settings-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 1.5rem; }
.settings-section { background: white; border-radius: 12px; border: 1px solid var(--gray-200); }
.settings-section-header { padding: 1rem 1.5rem; border-bottom: 1px solid var(--gray-100); font-weight: 600; }
.settings-section-body { padding: 1.5rem; }
@media (max-width: 768px) { .settings-grid { grid-template-columns: 1fr; } }
';

ob_start();
?>

<div class="flex justify-between items-center mb-6">
    <div>
        <h1 class="text-2xl font-bold text-gray-900">Pengaturan Sistem</h1>
        <p class="text-gray-500">Konfigurasi aplikasi payment gateway</p>
    </div>
</div>

<?php if ($message): ?>
<div class="alert alert-<?= $messageType ?> mb-6"><?= htmlspecialchars($message) ?></div>
<?php endif; ?>

<form method="POST">
    <?= csrfField() ?>
    <div class="settings-grid">
        <!-- Company Info -->
        <div class="settings-section">
            <div class="settings-section-header">🏢 Informasi Perusahaan</div>
            <div class="settings-section-body">
                <div class="form-group">
                    <label class="form-label">Nama Aplikasi</label>
                    <input type="text" name="app_name" class="form-input" value="<?= htmlspecialchars($settings['app_name'] ?? 'NEO PGA') ?>">
                </div>
                <div class="form-group">
                    <label class="form-label">Nama Perusahaan</label>
                    <input type="text" name="company_name" class="form-input" value="<?= htmlspecialchars($settings['company_name'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label class="form-label">Email</label>
                    <input type="email" name="company_email" class="form-input" value="<?= htmlspecialchars($settings['company_email'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label class="form-label">Telepon</label>
                    <input type="text" name="company_phone" class="form-input" value="<?= htmlspecialchars($settings['company_phone'] ?? '') ?>">
                </div>
                <div class="form-group mb-0">
                    <label class="form-label">Alamat</label>
                    <textarea name="company_address" class="form-input" rows="2"><?= htmlspecialchars($settings['company_address'] ?? '') ?></textarea>
                </div>
            </div>
        </div>
        
        <!-- Payment Settings -->
        <div class="settings-section">
            <div class="settings-section-header">💳 Pengaturan Pembayaran</div>
            <div class="settings-section-body">
                <div class="form-group">
                    <label class="form-label">Komisi Default (%)</label>
                    <input type="number" name="default_commission" class="form-input" step="0.1" min="0" max="100" value="<?= $settings['default_commission'] ?? 2.5 ?>">
                    <small style="color:var(--gray-500)">Persentase komisi dari setiap transaksi</small>
                </div>
                <div class="grid grid-cols-2 gap-4">
                    <div class="form-group">
                        <label class="form-label">Kode Unik Min</label>
                        <input type="number" name="unique_code_min" class="form-input" min="1" value="<?= $settings['unique_code_min'] ?? 1 ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Kode Unik Max</label>
                        <input type="number" name="unique_code_max" class="form-input" min="1" value="<?= $settings['unique_code_max'] ?? 999 ?>">
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">Expiry Pembayaran (menit)</label>
                    <input type="number" name="payment_expiry_minutes" class="form-input" min="5" value="<?= $settings['payment_expiry_minutes'] ?? 60 ?>">
                    <small style="color:var(--gray-500)">Waktu kadaluarsa link pembayaran</small>
                </div>
                <div class="form-group mb-0">
                    <label class="form-label">Min Settlement (Rp)</label>
                    <input type="number" name="min_settlement" class="form-input" min="0" value="<?= $settings['min_settlement'] ?? 50000 ?>">
                    <small style="color:var(--gray-500)">Minimal saldo untuk pencairan</small>
                </div>
            </div>
        </div>
    </div>
    
    <div style="margin-top:1.5rem;text-align:right">
        <button type="submit" class="btn btn-primary" style="min-width:150px">💾 Simpan Pengaturan</button>
    </div>
</form>

<?php
$content = ob_get_clean();
include __DIR__ . '/layout.php';
?>

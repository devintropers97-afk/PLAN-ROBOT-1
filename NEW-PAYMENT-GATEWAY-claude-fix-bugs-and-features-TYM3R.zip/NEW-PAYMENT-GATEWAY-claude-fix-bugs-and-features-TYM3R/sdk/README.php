<?php
/**
 * NEO PGA SDK - README
 * Dokumentasi penggunaan SDK untuk integrasi
 */
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NEO PGA SDK - Dokumentasi</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #f3f4f6; padding: 40px 20px; line-height: 1.6; }
        .container { max-width: 900px; margin: 0 auto; }
        h1 { color: #1f2937; text-align: center; margin-bottom: 10px; }
        .subtitle { color: #6b7280; text-align: center; margin-bottom: 40px; }
        .card { background: #fff; border-radius: 16px; padding: 28px; margin-bottom: 24px; box-shadow: 0 4px 15px rgba(0,0,0,.05); }
        h2 { color: #1f2937; font-size: 1.2rem; margin-bottom: 16px; display: flex; align-items: center; gap: 10px; }
        h2 span { font-size: 1.4rem; }
        .badge { display: inline-block; padding: 4px 12px; border-radius: 50px; font-size: .8rem; font-weight: 600; }
        .badge-green { background: #dcfce7; color: #16a34a; }
        .badge-yellow { background: #fef3c7; color: #b45309; }
        .badge-blue { background: #dbeafe; color: #1e40af; }
        table { width: 100%; border-collapse: collapse; margin: 16px 0; }
        th { background: #f9fafb; padding: 12px 16px; text-align: left; font-size: .85rem; color: #6b7280; border-bottom: 2px solid #e5e7eb; }
        td { padding: 12px 16px; border-bottom: 1px solid #f3f4f6; vertical-align: top; }
        code { background: #f3f4f6; padding: 2px 8px; border-radius: 4px; font-size: .9rem; }
        .tip { background: linear-gradient(135deg, #dbeafe, #eff6ff); border: 1px solid #93c5fd; border-radius: 12px; padding: 16px 20px; margin: 16px 0; }
        .tip-title { font-weight: 700; color: #1e40af; margin-bottom: 6px; }
        .tip-text { color: #1e40af; font-size: .95rem; }
        .btn { display: inline-flex; align-items: center; gap: 8px; padding: 12px 24px; background: #0d9488; color: #fff; text-decoration: none; border-radius: 10px; font-weight: 600; margin-top: 16px; transition: all 0.2s; }
        .btn:hover { background: #0f766e; transform: translateY(-2px); }
        pre { background: #1e293b; color: #e2e8f0; padding: 20px; border-radius: 12px; overflow-x: auto; font-size: 13px; line-height: 1.6; margin: 16px 0; }
        .step { display: flex; gap: 16px; padding: 16px 0; border-bottom: 1px solid #f3f4f6; }
        .step:last-child { border-bottom: none; }
        .step-num { width: 32px; height: 32px; background: #0d9488; color: #fff; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 700; flex-shrink: 0; }
        .step-content { flex: 1; }
        .step-content h4 { font-size: .95rem; color: #1f2937; margin-bottom: 4px; }
        .step-content p { font-size: .85rem; color: #6b7280; }
        .sdk-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 16px; }
        .sdk-item { background: #f9fafb; border: 2px solid #e5e7eb; border-radius: 14px; padding: 20px; transition: all 0.2s; }
        .sdk-item:hover { border-color: #0d9488; }
        .sdk-item h4 { font-size: 1rem; color: #1f2937; margin-bottom: 8px; }
        .sdk-item p { font-size: .85rem; color: #6b7280; margin-bottom: 12px; }
        .warning { background: linear-gradient(135deg, #fef3c7, #fffbeb); border: 2px solid #f59e0b; border-radius: 14px; padding: 20px; margin-bottom: 24px; }
        .warning-title { font-weight: 700; color: #92400e; margin-bottom: 8px; display: flex; align-items: center; gap: 8px; }
        .warning-text { color: #a16207; font-size: .9rem; line-height: 1.6; }
    </style>
</head>
<body>
    <div class="container">
        <h1>NEO PGA SDK</h1>
        <p class="subtitle">Integrasi Payment Gateway dalam Hitungan Menit</p>

        <!-- Warning: Download dari Dashboard -->
        <div class="warning">
            <div class="warning-title">
                <span style="font-size: 24px;">💡</span>
                Download SDK dari Dashboard Merchant!
            </div>
            <div class="warning-text">
                <strong>Cara terbaik:</strong> Login ke Dashboard Merchant &rarr; Integration Center &rarr; Download SDK.
                File SDK akan otomatis terisi API Key & Secret Key Anda. Tidak perlu edit manual!
            </div>
        </div>

        <!-- Pilihan SDK -->
        <div class="card">
            <h2><span>📦</span> Pilihan SDK</h2>
            <p style="color: #6b7280; margin-bottom: 20px;">NEO PGA menyediakan 3 jenis SDK untuk berbagai kebutuhan:</p>

            <div class="sdk-grid">
                <div class="sdk-item" style="border-color: #86efac;">
                    <span class="badge badge-green">QRIS Only</span>
                    <h4 style="margin-top: 12px;">neopga-qris-sdk.php</h4>
                    <p>SDK saja untuk merchant yang <strong>sudah punya form deposit</strong>. Tinggal include dan panggil function.</p>
                    <ul style="font-size: .85rem; color: #6b7280; padding-left: 16px;">
                        <li>Deposit saldo manual</li>
                        <li>Top-up game</li>
                        <li>Donasi / infaq</li>
                    </ul>
                </div>

                <div class="sdk-item" style="border-color: #fbbf24;">
                    <span class="badge badge-yellow">QRIS + Template</span>
                    <h4 style="margin-top: 12px;">neopga-simple.php</h4>
                    <p>SDK + template form lengkap untuk merchant yang <strong>belum punya form deposit</strong>.</p>
                    <ul style="font-size: .85rem; color: #6b7280; padding-left: 16px;">
                        <li>Form deposit siap pakai</li>
                        <li>Halaman sukses</li>
                        <li>Callback handler</li>
                    </ul>
                </div>

                <div class="sdk-item" style="border-color: #93c5fd;">
                    <span class="badge badge-blue">Full SDK</span>
                    <h4 style="margin-top: 12px;">neopga-full.php</h4>
                    <p>SDK lengkap untuk <strong>QRIS + Bank Transfer</strong>. Cocok untuk e-commerce.</p>
                    <ul style="font-size: .85rem; color: #6b7280; padding-left: 16px;">
                        <li>Multi metode pembayaran</li>
                        <li>Virtual Account</li>
                        <li>Invoice / tagihan</li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Kode Unik -->
        <div class="card" style="background: linear-gradient(135deg, #fef3c7, #fde68a); border: none;">
            <h2 style="color: #92400e;"><span>🔢</span> Tentang Kode Unik</h2>
            <p style="color: #92400e; margin-bottom: 16px;">
                Semua pembayaran NEO PGA menggunakan <strong>kode unik (1-999)</strong> untuk identifikasi otomatis.
            </p>
            <div style="background: #fff; border-radius: 10px; padding: 16px; margin-bottom: 16px;">
                <strong style="color: #1f2937;">Contoh:</strong>
                <ul style="font-size: .9rem; color: #4b5563; padding-left: 20px; margin-top: 8px;">
                    <li>User deposit Rp 50.000</li>
                    <li>Sistem generate kode unik: 123</li>
                    <li>User bayar: Rp 50.123 (tepat!)</li>
                    <li>Sistem otomatis cocokkan &rarr; Saldo terupdate Rp 50.000</li>
                </ul>
            </div>
            <p style="color: #92400e; font-size: .9rem;">
                <strong>Penting:</strong> User harus bayar dengan nominal TEPAT termasuk kode unik, baru pembayaran terverifikasi.
            </p>
        </div>

        <!-- Quick Start -->
        <div class="card">
            <h2><span>🚀</span> Quick Start (5 Langkah)</h2>

            <div class="step">
                <div class="step-num">1</div>
                <div class="step-content">
                    <h4>Download SDK</h4>
                    <p>Login Dashboard Merchant &rarr; Integration Center &rarr; Pilih SDK &rarr; Download</p>
                </div>
            </div>

            <div class="step">
                <div class="step-num">2</div>
                <div class="step-content">
                    <h4>Upload ke Hosting</h4>
                    <p>Upload file SDK ke folder <code>/includes/</code> via cPanel File Manager</p>
                </div>
            </div>

            <div class="step">
                <div class="step-num">3</div>
                <div class="step-content">
                    <h4>Edit Form Deposit</h4>
                    <p>Include SDK dan panggil <code>NeoPGA::createQRIS()</code> saat form disubmit</p>
                </div>
            </div>

            <div class="step">
                <div class="step-num">4</div>
                <div class="step-content">
                    <h4>Buat callback.php</h4>
                    <p>File untuk menerima notifikasi pembayaran sukses dan update database</p>
                </div>
            </div>

            <div class="step">
                <div class="step-num">5</div>
                <div class="step-content">
                    <h4>Set URL Callback</h4>
                    <p>Dashboard &rarr; Pengaturan &rarr; Masukkan URL callback Anda</p>
                </div>
            </div>
        </div>

        <!-- Contoh Kode -->
        <div class="card">
            <h2><span>💻</span> Contoh Kode</h2>

            <h4 style="font-size: .9rem; color: #6b7280; margin-bottom: 12px;">Buat Pembayaran QRIS:</h4>
            <pre>&lt;?php
require_once 'includes/neopga.php';

// Buat pembayaran
$result = NeoPGA::createQRIS(50000, 'DEP-USER123-' . time());

if ($result['success']) {
    // Redirect ke halaman bayar
    header('Location: ' . $result['payment_url']);
    exit;
} else {
    echo 'Error: ' . $result['message'];
}
?&gt;</pre>

            <h4 style="font-size: .9rem; color: #6b7280; margin-bottom: 12px; margin-top: 24px;">Terima Callback:</h4>
            <pre>&lt;?php
require_once 'includes/neopga.php';

$payment = NeoPGA::verifyCallback();

if ($payment && $payment['status'] === 'success') {
    $orderId = $payment['reference_id'];
    $amount  = $payment['amount'];

    // Update saldo user di database Anda
    // $pdo->query("UPDATE users SET saldo = saldo + $amount WHERE ...");

    http_response_code(200);
    echo json_encode(['status' => 'ok']);
}
?&gt;</pre>
        </div>

        <!-- Isi Folder SDK -->
        <div class="card">
            <h2><span>📁</span> Isi Folder SDK</h2>
            <table>
                <tr>
                    <th>File</th>
                    <th>Keterangan</th>
                </tr>
                <tr>
                    <td><code>neopga-qris-sdk.php</code></td>
                    <td>SDK QRIS saja (untuk yang sudah punya form)</td>
                </tr>
                <tr>
                    <td><code>neopga-simple.php</code></td>
                    <td>SDK QRIS + template form lengkap</td>
                </tr>
                <tr>
                    <td><code>neopga-full.php</code></td>
                    <td>SDK Full (QRIS + Bank Transfer)</td>
                </tr>
                <tr>
                    <td><code>NeoBayar.php</code></td>
                    <td>SDK Class alternatif (backward compatible)</td>
                </tr>
                <tr>
                    <td><code>contoh-callback.php</code></td>
                    <td>Contoh implementasi callback</td>
                </tr>
                <tr>
                    <td><code>README.php</code></td>
                    <td>File dokumentasi ini</td>
                </tr>
            </table>
        </div>

        <!-- Link -->
        <div class="card" style="text-align: center; background: linear-gradient(135deg, #0d9488, #0f766e); color: #fff;">
            <h2 style="color: #fff; justify-content: center;"><span>📖</span> Dokumentasi Lengkap</h2>
            <p style="opacity: .9; margin-bottom: 20px;">Panduan step-by-step lengkap tersedia di Dashboard Merchant</p>
            <a href="../merchant/dokumentasi.php" class="btn" style="background: #fff; color: #0d9488;">Buka Dokumentasi &rarr;</a>
            <a href="../merchant/integration-center.php" class="btn" style="background: rgba(255,255,255,0.2); color: #fff; margin-left: 10px;">Integration Center &rarr;</a>
        </div>

        <!-- Help -->
        <div class="tip" style="margin-top: 24px;">
            <div class="tip-title">Butuh Bantuan?</div>
            <div class="tip-text">
                <strong>Admin Setup (Rp 500.000):</strong> Tim kami yang setup integrasi ke website Anda.<br>
                Hubungi via WhatsApp: <a href="https://wa.me/6289534340757" style="color: #1e40af;">0895-3434-07575</a>
            </div>
        </div>
    </div>
</body>
</html>

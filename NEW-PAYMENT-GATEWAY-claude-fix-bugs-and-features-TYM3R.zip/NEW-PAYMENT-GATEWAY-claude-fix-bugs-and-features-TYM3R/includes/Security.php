<?php
/**
 * NEO PGA Security Class
 * Comprehensive security measures for the application
 *
 * PENTING: File PHP TIDAK BISA dilihat oleh user karena diproses di server.
 * Yang terlihat hanya OUTPUT HTML-nya.
 */

class Security
{
    // ============================================
    // SECURITY HEADERS
    // ============================================

    /**
     * Set all security headers
     */
    public static function setHeaders(): void
    {
        // Prevent clickjacking
        header('X-Frame-Options: SAMEORIGIN');

        // XSS Protection
        header('X-XSS-Protection: 1; mode=block');

        // Prevent MIME sniffing
        header('X-Content-Type-Options: nosniff');

        // Referrer policy
        header('Referrer-Policy: strict-origin-when-cross-origin');

        // Permissions Policy
        header('Permissions-Policy: geolocation=(), microphone=(), camera=(), payment=()');

        // Remove PHP version header
        header_remove('X-Powered-By');

        // Cache control for sensitive pages
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
        header('Expires: 0');
    }

    /**
     * Set Content Security Policy
     */
    public static function setCSP(): void
    {
        $csp = [
            "default-src 'self'",
            "script-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
            "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
            "font-src 'self' https://fonts.gstatic.com",
            "img-src 'self' data: https:",
            "connect-src 'self'",
            "frame-ancestors 'self'",
            "form-action 'self'",
            "base-uri 'self'"
        ];

        header('Content-Security-Policy: ' . implode('; ', $csp));
    }

    // ============================================
    // INPUT VALIDATION & SANITIZATION
    // ============================================

    /**
     * Sanitize string input
     */
    public static function sanitizeString($input): string
    {
        if ($input === null) return '';
        return htmlspecialchars(strip_tags(trim((string)$input)), ENT_QUOTES, 'UTF-8');
    }

    /**
     * Sanitize email
     */
    public static function sanitizeEmail($email): string
    {
        return filter_var(trim((string)$email), FILTER_SANITIZE_EMAIL);
    }

    /**
     * Sanitize integer
     */
    public static function sanitizeInt($input): int
    {
        return (int) filter_var($input, FILTER_SANITIZE_NUMBER_INT);
    }

    /**
     * Sanitize float/decimal
     */
    public static function sanitizeFloat($input): float
    {
        return (float) filter_var($input, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
    }

    /**
     * Sanitize URL
     */
    public static function sanitizeUrl($url): string
    {
        return filter_var(trim((string)$url), FILTER_SANITIZE_URL);
    }

    /**
     * Validate and sanitize all POST data
     */
    public static function sanitizePost(): array
    {
        $sanitized = [];
        foreach ($_POST as $key => $value) {
            if (is_array($value)) {
                $sanitized[$key] = array_map([self::class, 'sanitizeString'], $value);
            } else {
                $sanitized[$key] = self::sanitizeString($value);
            }
        }
        return $sanitized;
    }

    // ============================================
    // SQL INJECTION PREVENTION
    // ============================================

    /**
     * Check for SQL injection patterns
     */
    public static function detectSQLInjection(string $input): bool
    {
        $patterns = [
            '/(\%27)|(\')|(\-\-)|(\%23)|(#)/i',
            '/((\%3D)|(=))[^\n]*((\%27)|(\')|(\-\-)|(\%3B)|(;))/i',
            '/\w*((\%27)|(\'))((\%6F)|o|(\%4F))((\%72)|r|(\%52))/i',
            '/((\%27)|(\'))union/i',
            '/exec(\s|\+)+(s|x)p\w+/i',
            '/UNION(\s+)SELECT/i',
            '/INSERT(\s+)INTO/i',
            '/DELETE(\s+)FROM/i',
            '/DROP(\s+)TABLE/i',
            '/UPDATE(\s+)\w+(\s+)SET/i'
        ];

        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $input)) {
                self::logSecurityEvent('sql_injection_attempt', $input);
                return true;
            }
        }

        return false;
    }

    // ============================================
    // XSS PREVENTION
    // ============================================

    /**
     * Check for XSS patterns
     */
    public static function detectXSS(string $input): bool
    {
        $patterns = [
            '/<script\b[^>]*>(.*?)<\/script>/is',
            '/javascript:/i',
            '/on\w+\s*=/i',
            '/<iframe/i',
            '/<object/i',
            '/<embed/i',
            '/<link/i',
            '/<meta/i',
            '/expression\s*\(/i',
            '/url\s*\(/i'
        ];

        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $input)) {
                self::logSecurityEvent('xss_attempt', $input);
                return true;
            }
        }

        return false;
    }

    /**
     * Clean potential XSS
     */
    public static function cleanXSS(string $input): string
    {
        // Remove null bytes
        $input = str_replace(chr(0), '', $input);

        // Remove javascript: protocol
        $input = preg_replace('/javascript:/i', '', $input);

        // Remove event handlers
        $input = preg_replace('/on\w+\s*=/i', '', $input);

        // Encode special characters
        return htmlspecialchars($input, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }

    // ============================================
    // BRUTE FORCE PROTECTION
    // ============================================

    private static $maxLoginAttempts = 5;
    private static $lockoutTime = 900; // 15 minutes

    /**
     * Check if IP is locked out
     */
    public static function isLockedOut(string $ip): bool
    {
        $key = 'login_attempts_' . md5($ip);
        $attempts = $_SESSION[$key] ?? ['count' => 0, 'time' => 0];

        if ($attempts['count'] >= self::$maxLoginAttempts) {
            if (time() - $attempts['time'] < self::$lockoutTime) {
                return true;
            }
            // Reset after lockout period
            unset($_SESSION[$key]);
        }

        return false;
    }

    /**
     * Record failed login attempt
     */
    public static function recordFailedLogin(string $ip): void
    {
        $key = 'login_attempts_' . md5($ip);
        $attempts = $_SESSION[$key] ?? ['count' => 0, 'time' => time()];
        $attempts['count']++;
        $attempts['time'] = time();
        $_SESSION[$key] = $attempts;

        self::logSecurityEvent('failed_login', "IP: $ip, Attempts: {$attempts['count']}");
    }

    /**
     * Clear login attempts after successful login
     */
    public static function clearLoginAttempts(string $ip): void
    {
        $key = 'login_attempts_' . md5($ip);
        unset($_SESSION[$key]);
    }

    /**
     * Get remaining lockout time
     */
    public static function getLockoutRemaining(string $ip): int
    {
        $key = 'login_attempts_' . md5($ip);
        $attempts = $_SESSION[$key] ?? ['count' => 0, 'time' => 0];

        if ($attempts['count'] >= self::$maxLoginAttempts) {
            $remaining = self::$lockoutTime - (time() - $attempts['time']);
            return max(0, $remaining);
        }

        return 0;
    }

    // ============================================
    // PASSWORD SECURITY
    // ============================================

    /**
     * Check password strength
     */
    public static function isStrongPassword(string $password): array
    {
        $errors = [];

        if (strlen($password) < 8) {
            $errors[] = 'Password minimal 8 karakter';
        }
        if (!preg_match('/[A-Z]/', $password)) {
            $errors[] = 'Password harus mengandung huruf besar';
        }
        if (!preg_match('/[a-z]/', $password)) {
            $errors[] = 'Password harus mengandung huruf kecil';
        }
        if (!preg_match('/[0-9]/', $password)) {
            $errors[] = 'Password harus mengandung angka';
        }

        return [
            'valid' => empty($errors),
            'errors' => $errors
        ];
    }

    /**
     * Hash password securely
     */
    public static function hashPassword(string $password): string
    {
        return password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
    }

    /**
     * Verify password
     */
    public static function verifyPassword(string $password, string $hash): bool
    {
        return password_verify($password, $hash);
    }

    // ============================================
    // TOKEN GENERATION
    // ============================================

    /**
     * Generate secure random token
     */
    public static function generateToken(int $length = 32): string
    {
        return bin2hex(random_bytes($length));
    }

    /**
     * Generate API key
     */
    public static function generateApiKey(): string
    {
        return 'npga_' . self::generateToken(24);
    }

    /**
     * Generate secret key
     */
    public static function generateSecretKey(): string
    {
        return self::generateToken(32);
    }

    // ============================================
    // FILE UPLOAD SECURITY
    // ============================================

    private static $allowedMimeTypes = [
        'image/jpeg',
        'image/png',
        'image/gif',
        'image/webp',
        'application/pdf'
    ];

    private static $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'pdf'];

    /**
     * Validate uploaded file
     */
    public static function validateUpload(array $file, int $maxSize = 5242880): array
    {
        $errors = [];

        // Check for upload errors
        if ($file['error'] !== UPLOAD_ERR_OK) {
            $errors[] = 'Upload gagal';
            return ['valid' => false, 'errors' => $errors];
        }

        // Check file size
        if ($file['size'] > $maxSize) {
            $errors[] = 'File terlalu besar (max ' . ($maxSize / 1024 / 1024) . 'MB)';
        }

        // Check extension
        $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($extension, self::$allowedExtensions)) {
            $errors[] = 'Tipe file tidak diizinkan';
        }

        // Check MIME type
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mimeType = $finfo->file($file['tmp_name']);
        if (!in_array($mimeType, self::$allowedMimeTypes)) {
            $errors[] = 'Tipe file tidak valid';
        }

        // Check for PHP code in file
        $content = file_get_contents($file['tmp_name']);
        if (preg_match('/<\?php|<\?=|<%/i', $content)) {
            $errors[] = 'File mengandung kode berbahaya';
            self::logSecurityEvent('malicious_upload', $file['name']);
        }

        return [
            'valid' => empty($errors),
            'errors' => $errors
        ];
    }

    /**
     * Sanitize filename
     */
    public static function sanitizeFilename(string $filename): string
    {
        // Remove path info
        $filename = basename($filename);

        // Remove special characters
        $filename = preg_replace('/[^a-zA-Z0-9_\-\.]/', '', $filename);

        // Prevent directory traversal
        $filename = str_replace(['..', '/', '\\'], '', $filename);

        return $filename;
    }

    // ============================================
    // SECURITY LOGGING
    // ============================================

    /**
     * Log security event
     */
    public static function logSecurityEvent(string $event, string $details = ''): void
    {
        $logFile = ROOT_PATH . '/logs/security.log';
        $logDir = dirname($logFile);

        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }

        $timestamp = date('Y-m-d H:i:s');
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';
        $uri = $_SERVER['REQUEST_URI'] ?? 'unknown';

        $logEntry = sprintf(
            "[%s] %s | IP: %s | URI: %s | UA: %s | Details: %s\n",
            $timestamp,
            strtoupper($event),
            $ip,
            $uri,
            substr($userAgent, 0, 100),
            substr($details, 0, 500)
        );

        file_put_contents($logFile, $logEntry, FILE_APPEND | LOCK_EX);
    }

    // ============================================
    // REQUEST VALIDATION
    // ============================================

    /**
     * Validate request method
     */
    public static function requireMethod(string $method): void
    {
        if ($_SERVER['REQUEST_METHOD'] !== strtoupper($method)) {
            http_response_code(405);
            die('Method Not Allowed');
        }
    }

    /**
     * Require HTTPS
     */
    public static function requireHTTPS(): void
    {
        if (!isset($_SERVER['HTTPS']) || $_SERVER['HTTPS'] !== 'on') {
            $redirectUrl = 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
            header('Location: ' . $redirectUrl, true, 301);
            exit;
        }
    }

    /**
     * Check if request is from allowed origin
     */
    public static function checkOrigin(array $allowedOrigins): bool
    {
        $origin = $_SERVER['HTTP_ORIGIN'] ?? $_SERVER['HTTP_REFERER'] ?? '';

        foreach ($allowedOrigins as $allowed) {
            if (strpos($origin, $allowed) !== false) {
                return true;
            }
        }

        return false;
    }

    // ============================================
    // BOT/CRAWLER DETECTION
    // ============================================

    /**
     * Detect if request is from a bot
     */
    public static function isBot(): bool
    {
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';

        $botPatterns = [
            '/bot/i', '/crawl/i', '/spider/i', '/slurp/i',
            '/mediapartners/i', '/wget/i', '/curl/i'
        ];

        foreach ($botPatterns as $pattern) {
            if (preg_match($pattern, $userAgent)) {
                return true;
            }
        }

        return false;
    }

    // ============================================
    // ENCRYPTION
    // ============================================

    private static $encryptionKey = null;

    /**
     * Get encryption key
     */
    private static function getEncryptionKey(): string
    {
        if (self::$encryptionKey === null) {
            // Use ENCRYPTION_KEY from config or generate one
            self::$encryptionKey = defined('ENCRYPTION_KEY') ? ENCRYPTION_KEY : hash('sha256', 'neopga_default_key');
        }
        return self::$encryptionKey;
    }

    /**
     * Encrypt data
     */
    public static function encrypt(string $data): string
    {
        $key = self::getEncryptionKey();
        $iv = random_bytes(16);
        $encrypted = openssl_encrypt($data, 'AES-256-CBC', $key, 0, $iv);
        return base64_encode($iv . $encrypted);
    }

    /**
     * Decrypt data
     */
    public static function decrypt(string $data): ?string
    {
        $key = self::getEncryptionKey();
        $data = base64_decode($data);
        $iv = substr($data, 0, 16);
        $encrypted = substr($data, 16);
        $decrypted = openssl_decrypt($encrypted, 'AES-256-CBC', $key, 0, $iv);
        return $decrypted !== false ? $decrypted : null;
    }

    // ============================================
    // HONEYPOT
    // ============================================

    /**
     * Generate honeypot field
     */
    public static function honeypotField(): string
    {
        return '<div style="position:absolute;left:-9999px;top:-9999px;">
            <input type="text" name="website_url" value="" tabindex="-1" autocomplete="off">
        </div>';
    }

    /**
     * Check honeypot (returns true if bot detected)
     */
    public static function checkHoneypot(): bool
    {
        if (!empty($_POST['website_url'])) {
            self::logSecurityEvent('honeypot_triggered', 'Bot detected via honeypot');
            return true;
        }
        return false;
    }
}

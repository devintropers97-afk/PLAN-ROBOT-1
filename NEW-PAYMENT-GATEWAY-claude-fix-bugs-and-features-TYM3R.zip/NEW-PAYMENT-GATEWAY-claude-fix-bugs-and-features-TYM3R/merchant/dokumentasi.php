<?php
/**
 * NEO PGA - Dokumentasi API v3.0 (SUPER USER-FRIENDLY)
 * DIBUAT UNTUK ORANG AWAM SEKALIPUN!
 * Version: 3.0 - Human-Friendly Edition
 */
require_once __DIR__ . '/../includes/init.php';

if (!isset($_SESSION['merchant_user']) || empty($_SESSION['merchant_user']['id'])) {
    header('Location: login.php');
    exit;
}

$merchant = $_SESSION['merchant_user'];
$db = Database::getInstance();
$fullMerchant = $db->fetch("SELECT * FROM merchants WHERE id = ?", [$merchant['id']]);
if ($fullMerchant) $merchant = $fullMerchant;

$baseUrl = rtrim(APP_URL, '/');
$apiKey = htmlspecialchars($merchant['api_key'] ?? 'BELUM_ADA_API_KEY');
$secretKey = htmlspecialchars($merchant['secret_key'] ?? 'BELUM_ADA_SECRET_KEY');
$pageTitle = 'Panduan Integrasi';
$currentPage = 'api-docs';

include __DIR__ . '/layout_header.php';
?>

<style>
:root { --neo:#0d9488; --neo-dark:#0f766e; --success:#10b981; --warn:#f59e0b; --danger:#ef4444; }
.dw { max-width:1100px; margin:0 auto; }
.hero { background:linear-gradient(135deg,var(--neo),var(--neo-dark),#064e3b); color:#fff; padding:50px 40px; border-radius:24px; margin-bottom:30px; text-align:center; }
.hero h1 { font-size:2rem; font-weight:800; margin:0 0 12px; }
.hero p { font-size:1.1rem; opacity:.9; margin:0; }
.hero-badge { display:inline-block; background:rgba(255,255,255,.2); padding:6px 16px; border-radius:50px; font-size:.85rem; font-weight:600; margin-top:15px; }
.tabs { background:#fff; border-radius:16px; padding:8px; margin-bottom:25px; display:flex; gap:8px; flex-wrap:wrap; box-shadow:0 2px 8px rgba(0,0,0,.06); border:1px solid #e5e7eb; position:sticky; top:70px; z-index:100; }
.tab { padding:12px 20px; border-radius:10px; border:none; background:transparent; color:#4b5563; font-size:14px; font-weight:600; cursor:pointer; }
.tab:hover { background:#f3f4f6; }
.tab.active { background:var(--neo); color:#fff; }
.tc { display:none; }
.tc.active { display:block; animation:fadeIn .3s ease; }
@keyframes fadeIn { from{opacity:0;transform:translateY(10px)} to{opacity:1;transform:translateY(0)} }
.card { background:#fff; border-radius:16px; padding:28px; margin-bottom:20px; border:1px solid #e5e7eb; }
.card-h { display:flex; align-items:center; gap:12px; margin-bottom:20px; padding-bottom:16px; border-bottom:2px solid #f3f4f6; }
.card-icon { width:48px; height:48px; border-radius:12px; display:flex; align-items:center; justify-content:center; font-size:24px; background:linear-gradient(135deg,#ccfbf1,#99f6e4); }
.card-icon.orange { background:linear-gradient(135deg,#ffedd5,#fed7aa); }
.card-icon.blue { background:linear-gradient(135deg,#dbeafe,#bfdbfe); }
.card-icon.purple { background:linear-gradient(135deg,#ede9fe,#ddd6fe); }
.card-icon.green { background:linear-gradient(135deg,#dcfce7,#bbf7d0); }
.card-icon.red { background:linear-gradient(135deg,#fee2e2,#fecaca); }
.card-t { font-size:1.3rem; font-weight:700; color:#1f2937; margin:0; }
.card-st { font-size:.9rem; color:#6b7280; margin:4px 0 0; }
.cred { background:linear-gradient(135deg,#1f2937,#374151); border-radius:20px; padding:30px; color:#fff; }
.cred-warn { background:rgba(239,68,68,.15); border:1px solid rgba(239,68,68,.3); border-radius:12px; padding:14px 18px; margin-bottom:20px; display:flex; gap:12px; }
.cred-item { background:rgba(255,255,255,.08); border-radius:12px; padding:16px 20px; margin-bottom:12px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; }
.cred-label { font-size:.75rem; color:rgba(255,255,255,.5); text-transform:uppercase; margin-bottom:6px; }
.cred-val { font-family:monospace; font-size:.95rem; word-break:break-all; }
.cbtn { background:rgba(255,255,255,.1); border:none; color:rgba(255,255,255,.8); padding:10px 16px; border-radius:8px; cursor:pointer; font-size:.85rem; }
.cbtn:hover { background:rgba(255,255,255,.2); }
.cbtn.copied { background:var(--success); color:#fff; }
.code { background:#0f172a; border-radius:16px; overflow:hidden; margin:16px 0; }
.code-h { background:#1e293b; padding:12px 18px; display:flex; justify-content:space-between; align-items:center; }
.code-fn { color:#94a3b8; font-size:.85rem; font-weight:500; }
.code-cp { background:#334155; border:none; color:#94a3b8; padding:6px 14px; border-radius:6px; cursor:pointer; font-size:.8rem; }
.code-cp:hover { background:#475569; color:#fff; }
.code-cp.copied { background:#10b981; color:#fff; }
.code-b { padding:20px; overflow-x:auto; }
.code-b pre { margin:0; color:#e2e8f0; font-family:Consolas,monospace; font-size:13px; line-height:1.7; white-space:pre; }
.cm { color:#64748b; }
.str { color:#86efac; }
.kw { color:#c084fc; }
.var { color:#7dd3fc; }
.num { color:#fda4af; }
.alert { padding:18px 22px; border-radius:14px; margin:16px 0; display:flex; gap:14px; }
.alert-i { background:linear-gradient(135deg,#dbeafe,#eff6ff); border:1px solid #93c5fd; }
.alert-w { background:linear-gradient(135deg,#fef3c7,#fffbeb); border:1px solid #fcd34d; }
.alert-s { background:linear-gradient(135deg,#dcfce7,#f0fdf4); border:1px solid #86efac; }
.alert-d { background:linear-gradient(135deg,#fee2e2,#fef2f2); border:1px solid #fca5a5; }
.alert-icon { font-size:22px; }
.alert-t { font-weight:700; margin-bottom:4px; }
.alert-txt { font-size:.95rem; line-height:1.5; }
.flow { display:flex; align-items:center; justify-content:space-between; gap:8px; padding:24px; background:#f9fafb; border-radius:16px; margin:20px 0; overflow-x:auto; flex-wrap:wrap; }
.flow-item { text-align:center; padding:16px; background:#fff; border-radius:14px; border:2px solid #e5e7eb; min-width:90px; }
.flow-icon { font-size:1.8rem; margin-bottom:8px; }
.flow-lbl { font-size:.8rem; font-weight:600; color:#374151; }
.flow-arr { font-size:1.2rem; color:#9ca3af; }
.chk { background:#f9fafb; border-radius:16px; padding:24px; border:1px solid #e5e7eb; margin-top:20px; }
.chk-t { font-size:1.1rem; font-weight:700; color:#1f2937; margin:0 0 16px; }
.chk-item { display:flex; align-items:flex-start; gap:12px; padding:12px 0; border-bottom:1px dashed #e5e7eb; }
.chk-item:last-child { border-bottom:none; }
.chk-box { width:24px; height:24px; min-width:24px; border:2px solid #d1d5db; border-radius:6px; cursor:pointer; display:flex; align-items:center; justify-content:center; }
.chk-box:hover { border-color:var(--neo); }
.chk-box.checked { background:var(--success); border-color:var(--success); color:#fff; }
.chk-txt { flex:1; font-size:.95rem; color:#374151; }
.chk-item.checked .chk-txt { text-decoration:line-through; color:#9ca3af; }
.vstep { display:flex; gap:20px; padding:20px; background:#f9fafb; border-radius:16px; border:2px solid #f3f4f6; margin-bottom:16px; }
.vstep:hover { border-color:var(--neo); transform:translateX(4px); }
.vstep-n { width:44px; height:44px; min-width:44px; background:linear-gradient(135deg,var(--neo),var(--neo-dark)); color:#fff; border-radius:12px; display:flex; align-items:center; justify-content:center; font-size:1.2rem; font-weight:700; }
.vstep-t { font-size:1.1rem; font-weight:700; color:#1f2937; margin:0 0 6px; }
.vstep-d { font-size:.95rem; color:#4b5563; margin:0; line-height:1.5; }
.vstep-a { display:inline-flex; align-items:center; gap:6px; margin-top:10px; padding:8px 16px; background:var(--neo); color:#fff; border-radius:8px; font-size:.85rem; font-weight:600; text-decoration:none; }
.vstep-a:hover { background:var(--neo-dark); }
.tbl { width:100%; border-collapse:collapse; margin:16px 0; }
.tbl th { background:#f9fafb; padding:14px 16px; text-align:left; font-weight:700; font-size:.85rem; color:#4b5563; border-bottom:2px solid #e5e7eb; }
.tbl td { padding:14px 16px; border-bottom:1px solid #f3f4f6; font-size:.95rem; color:#374151; vertical-align:top; }
.tbl code { background:#f3f4f6; padding:3px 8px; border-radius:5px; font-size:.85rem; }
.badge { display:inline-block; padding:4px 10px; border-radius:6px; font-size:.75rem; font-weight:700; }
.badge-r { background:#fee2e2; color:#dc2626; }
.badge-o { background:#dbeafe; color:#2563eb; }
.case-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(280px,1fr)); gap:20px; }
.case-card { background:#fff; border-radius:16px; padding:24px; border:2px solid #f3f4f6; cursor:pointer; transition:all .3s; }
.case-card:hover { border-color:var(--neo); transform:translateY(-4px); }
.case-card.active { border-color:var(--neo); background:linear-gradient(135deg,#f0fdfa,#fff); }
.case-emoji { font-size:2.5rem; margin-bottom:12px; }
.case-t { font-size:1.15rem; font-weight:700; color:#1f2937; margin:0 0 8px; }
.case-d { font-size:.9rem; color:#6b7280; margin:0; }
.case-c { display:none; }
.case-c.active { display:block; }
.faq-item { background:#fff; border:1px solid #e5e7eb; border-radius:14px; margin-bottom:12px; overflow:hidden; }
.faq-q { padding:18px 22px; display:flex; justify-content:space-between; align-items:center; cursor:pointer; }
.faq-q:hover { background:#f9fafb; }
.faq-qt { font-size:1rem; font-weight:600; color:#1f2937; }
.faq-tog { font-size:1.2rem; color:#9ca3af; transition:transform .3s; }
.faq-item.open .faq-tog { transform:rotate(180deg); }
.faq-a { padding:0 22px 18px; color:#4b5563; font-size:.95rem; line-height:1.6; display:none; border-top:1px solid #f3f4f6; }
.faq-item.open .faq-a { display:block; }
.support { background:linear-gradient(135deg,#1f2937,#374151); border-radius:20px; padding:50px 40px; text-align:center; color:#fff; margin-top:30px; }
.support-icon { font-size:3.5rem; margin-bottom:16px; }
.support-t { font-size:1.6rem; font-weight:700; margin:0 0 10px; }
.support-txt { font-size:1rem; opacity:.8; margin:0 0 28px; }
.support-btns { display:flex; gap:16px; justify-content:center; flex-wrap:wrap; }
.support-btn { display:inline-flex; align-items:center; gap:10px; padding:14px 28px; border-radius:12px; text-decoration:none; font-weight:600; }
.support-btn.wa { background:#25d366; color:#fff; }
.support-btn.em { background:#fff; color:#1f2937; }
@media(max-width:768px) {
    .hero { padding:30px 24px; }
    .hero h1 { font-size:1.6rem; }
    .flow { flex-wrap:wrap; justify-content:center; }
    .vstep { flex-direction:column; text-align:center; }
    .vstep-n { margin:0 auto 12px; }
    .cred-item { flex-direction:column; }
}
</style>

<div class="dw">
    <!-- Hero -->
    <div class="hero">
        <h1>🚀 Panduan Integrasi NEO PGA</h1>
        <p>Dibuat super simpel, bahkan untuk pemula!</p>
        <div class="hero-badge">✨ Copy-Paste Langsung Jalan!</div>
    </div>
    
    <!-- Banner Integration Center - SDK Download -->
    <div style="background:linear-gradient(135deg,#10b981,#059669);border-radius:16px;padding:20px 28px;margin-bottom:16px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:16px;">
        <div style="color:#fff;">
            <div style="font-size:1.1rem;font-weight:700;">📦 Baru? Download SDK Siap Pakai!</div>
            <div style="font-size:.9rem;opacity:.9;">SDK sudah terisi API Key Anda. Tinggal upload dan integrasi!</div>
        </div>
        <a href="integration-center.php" style="background:#fff;color:#059669;padding:12px 24px;border-radius:10px;text-decoration:none;font-weight:700;font-size:.9rem;">Download SDK →</a>
    </div>

    <!-- Banner Panduan Simpel -->
    <div style="background:linear-gradient(135deg,#f59e0b,#d97706);border-radius:16px;padding:20px 28px;margin-bottom:16px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:16px;">
        <div style="color:#fff;">
            <div style="font-size:1.1rem;font-weight:700;">⚡ Cuma punya 1 file index.php?</div>
            <div style="font-size:.9rem;opacity:.9;">Pakai Panduan Super Simpel — Copy-paste langsung jalan!</div>
        </div>
        <a href="dokumentasi-simpel.php" style="background:#fff;color:#d97706;padding:12px 24px;border-radius:10px;text-decoration:none;font-weight:700;font-size:.9rem;">Buka Panduan Simpel →</a>
    </div>

    <!-- Info Kode Unik -->
    <div style="background:linear-gradient(135deg,#fef3c7,#fde68a);border:2px solid #f59e0b;border-radius:16px;padding:18px 24px;margin-bottom:24px;display:flex;align-items:flex-start;gap:14px;">
        <span style="font-size:28px;">💡</span>
        <div>
            <div style="font-size:1rem;font-weight:700;color:#92400e;margin-bottom:4px;">Semua Pembayaran NEO PGA Menggunakan Kode Unik</div>
            <div style="font-size:.9rem;color:#a16207;line-height:1.5;">Setiap transaksi ditambahkan <strong>kode unik (1-999)</strong> untuk identifikasi otomatis. Contoh: Deposit Rp 50.000 → User bayar Rp 50.123 (123 = kode unik). Sistem otomatis cocokkan saat pembayaran masuk.</div>
        </div>
    </div>
    
    <!-- Tabs -->
    <div class="tabs">
        <button class="tab active" onclick="showTab('mulai')">🏁 Mulai dari Sini</button>
        <button class="tab" onclick="showTab('sdk')">📦 Pakai SDK (Recommended)</button>
        <button class="tab" onclick="showTab('kasus')">📚 Studi Kasus</button>
        <button class="tab" onclick="showTab('api')">📖 API Reference</button>
        <button class="tab" onclick="showTab('faq')">❓ FAQ</button>
    </div>
    
    <!-- TAB 1: MULAI -->
    <div id="tab-mulai" class="tc active">
        
        <!-- Flow Diagram -->
        <div class="card">
            <div class="card-h">
                <div class="card-icon">🔄</div>
                <div><h3 class="card-t">Bagaimana NEO PGA Bekerja?</h3><p class="card-st">Pahami flow ini dulu, integrasi jadi mudah!</p></div>
            </div>
            <div class="flow">
                <div class="flow-item"><div class="flow-icon">🛒</div><div class="flow-lbl">Customer<br>Checkout</div></div>
                <div class="flow-arr">→</div>
                <div class="flow-item"><div class="flow-icon">📤</div><div class="flow-lbl">Website<br>Request API</div></div>
                <div class="flow-arr">→</div>
                <div class="flow-item"><div class="flow-icon">🔗</div><div class="flow-lbl">NEO PGA<br>Buat Invoice</div></div>
                <div class="flow-arr">→</div>
                <div class="flow-item"><div class="flow-icon">💳</div><div class="flow-lbl">Customer<br>Bayar</div></div>
                <div class="flow-arr">→</div>
                <div class="flow-item"><div class="flow-icon">📡</div><div class="flow-lbl">NEO PGA<br>Callback</div></div>
                <div class="flow-arr">→</div>
                <div class="flow-item"><div class="flow-icon">✅</div><div class="flow-lbl">Update<br>Database</div></div>
            </div>
            <div class="alert alert-i">
                <div class="alert-icon">💡</div>
                <div><div class="alert-t">Simpelnya:</div><div class="alert-txt">Customer checkout → Website kamu kirim data ke NEO PGA → Dapat link bayar → Customer bayar → NEO PGA kasih tau kamu (callback) → Kamu update database → Selesai!</div></div>
            </div>
        </div>
        
        <!-- Step 1: Credentials -->
        <div class="card">
            <div class="card-h">
                <div class="card-icon orange">🔑</div>
                <div><h3 class="card-t">Step 1: Simpan Credentials Kamu</h3><p class="card-st">Ini "kunci" untuk akses API NEO PGA</p></div>
            </div>
            <div class="cred">
                <div class="cred-warn">
                    <span style="font-size:20px">🔒</span>
                    <div style="color:#fca5a5"><strong>RAHASIA!</strong> Secret Key jangan pernah di-share atau ditaruh di JavaScript/HTML!</div>
                </div>
                <div class="cred-item">
                    <div><div class="cred-label">API URL</div><div class="cred-val" id="c-url"><?= $baseUrl ?>/api/</div></div>
                    <button class="cbtn" onclick="copyC('c-url',this)">📋 Copy</button>
                </div>
                <div class="cred-item">
                    <div><div class="cred-label">API KEY (untuk header request)</div><div class="cred-val" id="c-key"><?= $apiKey ?></div></div>
                    <button class="cbtn" onclick="copyC('c-key',this)">📋 Copy</button>
                </div>
                <div class="cred-item">
                    <div><div class="cred-label">SECRET KEY (untuk verifikasi callback)</div><div class="cred-val" id="c-sec"><?= $secretKey ?></div></div>
                    <button class="cbtn" onclick="copyC('c-sec',this)">📋 Copy</button>
                </div>
            </div>
            <div class="chk">
                <div class="chk-t">✅ Checklist Step 1</div>
                <div class="chk-item"><div class="chk-box" onclick="toggleChk(this)"></div><div class="chk-txt">Sudah copy API URL</div></div>
                <div class="chk-item"><div class="chk-box" onclick="toggleChk(this)"></div><div class="chk-txt">Sudah copy API Key dan simpan aman</div></div>
                <div class="chk-item"><div class="chk-box" onclick="toggleChk(this)"></div><div class="chk-txt">Sudah copy Secret Key dan simpan aman</div></div>
            </div>
        </div>
        
        <!-- Step 2: Checkout File -->
        <div class="card">
            <div class="card-h">
                <div class="card-icon blue">📦</div>
                <div><h3 class="card-t">Step 2: Buat File checkout.php</h3><p class="card-st">File ini untuk membuat pembayaran baru</p></div>
            </div>
            <div class="alert alert-w">
                <div class="alert-icon">⚠️</div>
                <div><div class="alert-t">Dimana taruh file ini?</div><div class="alert-txt">Upload ke hosting website kamu. Contoh: <code>https://websitekamu.com/checkout.php</code></div></div>
            </div>
            <div class="code">
                <div class="code-h">
                    <span class="code-fn">checkout.php — Copy & Upload ke server</span>
                    <button class="code-cp" onclick="copyCode('code1',this)">📋 Copy</button>
                </div>
                <div class="code-b"><pre id="code1"><span class="kw">&lt;?php</span>
<span class="cm">// =============================================</span>
<span class="cm">// CHECKOUT.PHP - BUAT PEMBAYARAN BARU</span>
<span class="cm">// =============================================</span>

<span class="cm">// Konfigurasi - GANTI DENGAN MILIK KAMU!</span>
<span class="var">$API_KEY</span> = <span class="str">"<?= $apiKey ?>"</span>;
<span class="var">$API_URL</span> = <span class="str">"<?= $baseUrl ?>/api/create.php"</span>;

<span class="cm">// Data pembayaran (ambil dari form/cart)</span>
<span class="var">$data</span> = [
    <span class="str">"amount"</span>         => <span class="num">150000</span>,                     <span class="cm">// Rp 150.000</span>
    <span class="str">"customer_name"</span>  => <span class="str">"Budi Santoso"</span>,
    <span class="str">"customer_email"</span> => <span class="str">"budi@email.com"</span>,
    <span class="str">"customer_phone"</span> => <span class="str">"081234567890"</span>,
    <span class="str">"description"</span>    => <span class="str">"Pembelian Produk ABC"</span>,
    <span class="str">"reference_id"</span>   => <span class="str">"ORDER-"</span> . <span class="kw">time</span>(),
    <span class="str">"callback_url"</span>   => <span class="str">"https://websitekamu.com/callback.php"</span>,
    <span class="str">"redirect_url"</span>   => <span class="str">"https://websitekamu.com/sukses.php"</span>
];

<span class="cm">// Kirim ke NEO PGA</span>
<span class="var">$ch</span> = <span class="kw">curl_init</span>();
<span class="kw">curl_setopt_array</span>(<span class="var">$ch</span>, [
    CURLOPT_URL            => <span class="var">$API_URL</span>,
    CURLOPT_RETURNTRANSFER => <span class="kw">true</span>,
    CURLOPT_POST           => <span class="kw">true</span>,
    CURLOPT_TIMEOUT        => <span class="num">30</span>,
    CURLOPT_HTTPHEADER     => [
        <span class="str">"X-API-Key: "</span> . <span class="var">$API_KEY</span>,
        <span class="str">"Content-Type: application/json"</span>
    ],
    CURLOPT_POSTFIELDS     => <span class="kw">json_encode</span>(<span class="var">$data</span>)
]);

<span class="var">$response</span> = <span class="kw">curl_exec</span>(<span class="var">$ch</span>);
<span class="kw">curl_close</span>(<span class="var">$ch</span>);
<span class="var">$result</span> = <span class="kw">json_decode</span>(<span class="var">$response</span>, <span class="kw">true</span>);

<span class="kw">if</span> (<span class="var">$result</span> && <span class="var">$result</span>[<span class="str">'success'</span>]) {
    <span class="cm">// BERHASIL! Redirect ke halaman bayar</span>
    <span class="kw">header</span>(<span class="str">"Location: "</span> . <span class="var">$result</span>[<span class="str">'data'</span>][<span class="str">'payment_url'</span>]);
    <span class="kw">exit</span>;
} <span class="kw">else</span> {
    <span class="cm">// GAGAL</span>
    <span class="kw">echo</span> <span class="str">"Error: "</span> . (<span class="var">$result</span>[<span class="str">'message'</span>] ?? <span class="str">'Unknown error'</span>);
}
<span class="kw">?&gt;</span></pre></div>
            </div>
            <div class="chk">
                <div class="chk-t">✅ Checklist Step 2</div>
                <div class="chk-item"><div class="chk-box" onclick="toggleChk(this)"></div><div class="chk-txt">Sudah copy kode checkout</div></div>
                <div class="chk-item"><div class="chk-box" onclick="toggleChk(this)"></div><div class="chk-txt">Sudah ganti API_KEY dengan milik sendiri</div></div>
                <div class="chk-item"><div class="chk-box" onclick="toggleChk(this)"></div><div class="chk-txt">Sudah ganti callback_url dengan URL website kamu</div></div>
                <div class="chk-item"><div class="chk-box" onclick="toggleChk(this)"></div><div class="chk-txt">Sudah upload ke hosting</div></div>
            </div>
        </div>
        
        <!-- Step 3: Callback File -->
        <div class="card">
            <div class="card-h">
                <div class="card-icon purple">📡</div>
                <div><h3 class="card-t">Step 3: Buat File callback.php</h3><p class="card-st">File ini menerima notifikasi saat pembayaran berhasil</p></div>
            </div>
            <div class="alert alert-d">
                <div class="alert-icon">🚨</div>
                <div><div class="alert-t">INI PALING PENTING!</div><div class="alert-txt">Tanpa callback, kamu tidak akan tau kalau customer sudah bayar! File ini HARUS bisa diakses publik (tanpa login).</div></div>
            </div>
            <div class="code">
                <div class="code-h">
                    <span class="code-fn">callback.php — WAJIB dibuat!</span>
                    <button class="code-cp" onclick="copyCode('code2',this)">📋 Copy</button>
                </div>
                <div class="code-b"><pre id="code2"><span class="kw">&lt;?php</span>
<span class="cm">// =============================================</span>
<span class="cm">// CALLBACK.PHP - TERIMA NOTIFIKASI PEMBAYARAN</span>
<span class="cm">// File ini dipanggil otomatis oleh NEO PGA!</span>
<span class="cm">// =============================================</span>

<span class="var">$SECRET_KEY</span> = <span class="str">"<?= $secretKey ?>"</span>;

<span class="cm">// Terima data dari NEO PGA</span>
<span class="var">$rawPayload</span> = <span class="kw">file_get_contents</span>(<span class="str">'php://input'</span>);
<span class="var">$data</span> = <span class="kw">json_decode</span>(<span class="var">$rawPayload</span>, <span class="kw">true</span>);

<span class="cm">// Log untuk debugging (hapus di production)</span>
<span class="kw">file_put_contents</span>(<span class="str">'callback_log.txt'</span>, <span class="kw">date</span>(<span class="str">'Y-m-d H:i:s'</span>).<span class="str">" | "</span>.<span class="var">$rawPayload</span>.<span class="str">"\n"</span>, FILE_APPEND);

<span class="cm">// VERIFIKASI SIGNATURE (PENTING!)</span>
<span class="var">$expectedSig</span> = <span class="kw">hash_hmac</span>(<span class="str">'sha256'</span>, <span class="kw">json_encode</span>(<span class="var">$data</span>[<span class="str">'data'</span>]), <span class="var">$SECRET_KEY</span>);

<span class="kw">if</span> (!<span class="kw">isset</span>(<span class="var">$data</span>[<span class="str">'signature'</span>]) || <span class="var">$data</span>[<span class="str">'signature'</span>] !== <span class="var">$expectedSig</span>) {
    <span class="kw">http_response_code</span>(<span class="num">401</span>);
    <span class="kw">echo</span> <span class="kw">json_encode</span>([<span class="str">'status'</span>=><span class="str">'error'</span>, <span class="str">'message'</span>=><span class="str">'Invalid signature'</span>]);
    <span class="kw">exit</span>;
}

<span class="cm">// Proses pembayaran sukses</span>
<span class="kw">if</span> (<span class="var">$data</span>[<span class="str">'event'</span>] === <span class="str">'payment.success'</span>) {
    <span class="var">$invoiceNumber</span> = <span class="var">$data</span>[<span class="str">'data'</span>][<span class="str">'invoice_number'</span>];
    <span class="var">$referenceId</span>   = <span class="var">$data</span>[<span class="str">'data'</span>][<span class="str">'reference_id'</span>];
    <span class="var">$amount</span>        = <span class="var">$data</span>[<span class="str">'data'</span>][<span class="str">'amount'</span>];
    
    <span class="cm">// =============================================</span>
    <span class="cm">// UPDATE DATABASE KAMU DI SINI!</span>
    <span class="cm">// =============================================</span>
    <span class="cm">// Contoh:</span>
    <span class="cm">// $db = new PDO("mysql:host=localhost;dbname=toko", "user", "pass");</span>
    <span class="cm">// $db->query("UPDATE orders SET status='paid' WHERE reference_id='$referenceId'");</span>
    
    <span class="cm">// Kirim email ke customer (opsional)</span>
    <span class="cm">// mail($data['data']['customer']['email'], "Pembayaran Berhasil", "...");</span>
}

<span class="cm">// WAJIB return 200 OK</span>
<span class="kw">http_response_code</span>(<span class="num">200</span>);
<span class="kw">echo</span> <span class="kw">json_encode</span>([<span class="str">'status'</span>=><span class="str">'ok'</span>]);
<span class="kw">?&gt;</span></pre></div>
            </div>
            <div class="alert alert-s">
                <div class="alert-icon">✅</div>
                <div><div class="alert-t">Checklist Callback:</div><div class="alert-txt">☑️ File bisa diakses publik<br>☑️ Tidak butuh login<br>☑️ Return HTTP 200<br>☑️ Verifikasi signature<br>☑️ Update database</div></div>
            </div>
            <div class="chk">
                <div class="chk-t">✅ Checklist Step 3</div>
                <div class="chk-item"><div class="chk-box" onclick="toggleChk(this)"></div><div class="chk-txt">Sudah copy kode callback</div></div>
                <div class="chk-item"><div class="chk-box" onclick="toggleChk(this)"></div><div class="chk-txt">Sudah ganti SECRET_KEY dengan milik sendiri</div></div>
                <div class="chk-item"><div class="chk-box" onclick="toggleChk(this)"></div><div class="chk-txt">Sudah tambahkan logic update database</div></div>
                <div class="chk-item"><div class="chk-box" onclick="toggleChk(this)"></div><div class="chk-txt">Sudah upload dan bisa diakses publik</div></div>
            </div>
        </div>
        
        <!-- Step 4: Testing -->
        <div class="card">
            <div class="card-h">
                <div class="card-icon green">🧪</div>
                <div><h3 class="card-t">Step 4: Testing</h3><p class="card-st">Pastikan semua berjalan dengan baik</p></div>
            </div>
            <div class="vstep">
                <div class="vstep-n">1</div>
                <div><h4 class="vstep-t">Test via Dashboard</h4><p class="vstep-d">Buat transaksi test dari menu "Buat Pembayaran". Gunakan nominal kecil (Rp 10rb-50rb).</p><a href="<?= $baseUrl ?>/merchant/create-payment.php" class="vstep-a" target="_blank">🔗 Buka Buat Pembayaran</a></div>
            </div>
            <div class="vstep">
                <div class="vstep-n">2</div>
                <div><h4 class="vstep-t">Test via Demo Page</h4><p class="vstep-d">Gunakan halaman demo untuk simulasi pembayaran.</p><a href="<?= $baseUrl ?>/demo/" class="vstep-a" target="_blank">🔗 Buka Demo</a></div>
            </div>
            <div class="vstep">
                <div class="vstep-n">3</div>
                <div><h4 class="vstep-t">Cek Callback Log</h4><p class="vstep-d">Setelah transaksi sukses, cek file <code>callback_log.txt</code> di server.</p></div>
            </div>
            <div class="chk">
                <div class="chk-t">✅ Checklist Step 4</div>
                <div class="chk-item"><div class="chk-box" onclick="toggleChk(this)"></div><div class="chk-txt">Test transaksi berhasil dibuat</div></div>
                <div class="chk-item"><div class="chk-box" onclick="toggleChk(this)"></div><div class="chk-txt">Halaman pembayaran muncul</div></div>
                <div class="chk-item"><div class="chk-box" onclick="toggleChk(this)"></div><div class="chk-txt">Callback diterima (cek log)</div></div>
                <div class="chk-item"><div class="chk-box" onclick="toggleChk(this)"></div><div class="chk-txt">Database terupdate</div></div>
            </div>
        </div>
        
        <!-- SELESAI -->
        <div class="card" style="background:linear-gradient(135deg,#10b981,#059669);color:#fff;border:none;text-align:center;padding:40px;">
            <div style="font-size:4rem;margin-bottom:16px;">🎉</div>
            <h2 style="font-size:1.8rem;font-weight:800;margin:0 0 10px;">Selamat! Integrasi Selesai!</h2>
            <p style="font-size:1.1rem;opacity:.9;margin:0;">Website kamu sudah siap menerima pembayaran via NEO PGA</p>
        </div>
        
    </div>

    <!-- TAB SDK: PENDEKATAN SDK (RECOMMENDED) -->
    <div id="tab-sdk" class="tc">

        <!-- Pilih Metode SDK -->
        <div class="card">
            <div class="card-h">
                <div class="card-icon">📦</div>
                <div><h3 class="card-t">Pilih SDK Sesuai Kebutuhan</h3><p class="card-st">SDK sudah terisi API Key Anda, tinggal upload!</p></div>
            </div>

            <!-- QRIS Only -->
            <div style="background:linear-gradient(135deg,#f0fdf4,#ecfdf5);border:2px solid #86efac;border-radius:16px;padding:20px;margin-bottom:16px;">
                <h4 style="font-size:1.1rem;font-weight:700;color:#166534;margin:0 0 12px;">QRIS Only</h4>
                <p style="font-size:.9rem;color:#15803d;margin:0 0 16px;">Untuk: Deposit saldo, top-up game, donasi, toko online sederhana</p>
                <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;">
                    <a href="download-sdk.php?type=qris-sdk" style="display:flex;align-items:center;gap:10px;background:#fff;border:1px solid #86efac;border-radius:10px;padding:14px 18px;text-decoration:none;">
                        <span style="font-size:1.5rem;">📄</span>
                        <div>
                            <div style="font-weight:600;color:#166534;">SDK Only</div>
                            <div style="font-size:.8rem;color:#15803d;">Sudah punya form deposit</div>
                        </div>
                    </a>
                    <a href="download-sdk.php?type=simple" style="display:flex;align-items:center;gap:10px;background:#fff;border:1px solid #86efac;border-radius:10px;padding:14px 18px;text-decoration:none;">
                        <span style="font-size:1.5rem;">📁</span>
                        <div>
                            <div style="font-weight:600;color:#166534;">SDK + Template</div>
                            <div style="font-size:.8rem;color:#15803d;">Belum punya form deposit</div>
                        </div>
                    </a>
                </div>
            </div>

            <!-- Full SDK -->
            <div style="background:linear-gradient(135deg,#eff6ff,#dbeafe);border:2px solid #93c5fd;border-radius:16px;padding:20px;">
                <h4 style="font-size:1.1rem;font-weight:700;color:#1e40af;margin:0 0 12px;">QRIS + Bank Transfer</h4>
                <p style="font-size:.9rem;color:#2563eb;margin:0 0 16px;">Untuk: E-commerce, booking, invoice, pembayaran nominal besar</p>
                <a href="download-sdk.php?type=full" style="display:inline-flex;align-items:center;gap:10px;background:#fff;border:1px solid #93c5fd;border-radius:10px;padding:14px 18px;text-decoration:none;">
                    <span style="font-size:1.5rem;">💳</span>
                    <div>
                        <div style="font-weight:600;color:#1e40af;">Full SDK</div>
                        <div style="font-size:.8rem;color:#2563eb;">Multi metode pembayaran</div>
                    </div>
                </a>
            </div>
        </div>

        <!-- Step 1: Download & Upload -->
        <div class="card">
            <div class="card-h">
                <div class="card-icon orange">1️⃣</div>
                <div><h3 class="card-t">Step 1: Download SDK & Upload</h3><p class="card-st">File SDK sudah terisi API Key Anda!</p></div>
            </div>
            <div class="vstep">
                <div class="vstep-n">a</div>
                <div><h4 class="vstep-t">Download SDK</h4><p class="vstep-d">Klik tombol download di atas. File akan otomatis terisi API Key & Secret Key Anda.</p></div>
            </div>
            <div class="vstep">
                <div class="vstep-n">b</div>
                <div><h4 class="vstep-t">Rename File</h4><p class="vstep-d">Rename file jadi <code>neopga.php</code> (lebih mudah diingat)</p></div>
            </div>
            <div class="vstep">
                <div class="vstep-n">c</div>
                <div><h4 class="vstep-t">Upload ke Hosting</h4><p class="vstep-d">Upload via cPanel File Manager ke folder <code>/includes/</code> atau folder sejenis di hosting Anda.</p></div>
            </div>
        </div>

        <!-- Step 2: Edit Form -->
        <div class="card">
            <div class="card-h">
                <div class="card-icon blue">2️⃣</div>
                <div><h3 class="card-t">Step 2: Edit Form Deposit/Checkout</h3><p class="card-st">Tambahkan 5 baris kode ini saat form disubmit</p></div>
            </div>
            <div class="code">
                <div class="code-h">
                    <span class="code-fn">deposit.php atau checkout.php</span>
                    <button class="code-cp" onclick="copyCode('code-sdk-form',this)">📋 Copy</button>
                </div>
                <div class="code-b"><pre id="code-sdk-form"><span class="kw">&lt;?php</span>
<span class="cm">// 1. Include SDK (sesuaikan path)</span>
<span class="kw">require_once</span> <span class="str">'includes/neopga.php'</span>;

<span class="cm">// 2. Ketika user submit form deposit</span>
<span class="kw">if</span> (<span class="var">$_SERVER</span>[<span class="str">'REQUEST_METHOD'</span>] === <span class="str">'POST'</span>) {
    <span class="var">$nominal</span> = (<span class="kw">int</span>) <span class="var">$_POST</span>[<span class="str">'nominal'</span>];
    <span class="var">$orderId</span> = <span class="str">'DEP-'</span> . <span class="var">$userId</span> . <span class="str">'-'</span> . <span class="kw">time</span>();

    <span class="cm">// 3. Buat pembayaran QRIS</span>
    <span class="var">$result</span> = NeoPGA::<span class="kw">createQRIS</span>(<span class="var">$nominal</span>, <span class="var">$orderId</span>);

    <span class="kw">if</span> (<span class="var">$result</span>[<span class="str">'success'</span>]) {
        <span class="cm">// 4. Redirect ke halaman bayar</span>
        <span class="kw">header</span>(<span class="str">'Location: '</span> . <span class="var">$result</span>[<span class="str">'payment_url'</span>]);
        <span class="kw">exit</span>;
    } <span class="kw">else</span> {
        <span class="kw">echo</span> <span class="str">'Error: '</span> . <span class="var">$result</span>[<span class="str">'message'</span>];
    }
}
<span class="kw">?&gt;</span></pre></div>
            </div>
            <div class="alert alert-i">
                <div class="alert-icon">💡</div>
                <div><div class="alert-t">Catatan:</div><div class="alert-txt"><code>$userId</code> adalah ID user yang sedang login di sistem Anda. Ini dipakai di callback untuk update saldo user yang benar.</div></div>
            </div>
        </div>

        <!-- Step 3: Callback -->
        <div class="card">
            <div class="card-h">
                <div class="card-icon purple">3️⃣</div>
                <div><h3 class="card-t">Step 3: Buat File callback.php</h3><p class="card-st">File ini dipanggil NEO PGA saat pembayaran sukses</p></div>
            </div>
            <div class="alert alert-d">
                <div class="alert-icon">🚨</div>
                <div><div class="alert-t">PALING PENTING!</div><div class="alert-txt">Tanpa callback, saldo user tidak akan terupdate. File ini HARUS bisa diakses publik (tanpa login).</div></div>
            </div>
            <div class="code">
                <div class="code-h">
                    <span class="code-fn">callback.php — Buat di root folder website</span>
                    <button class="code-cp" onclick="copyCode('code-sdk-cb',this)">📋 Copy</button>
                </div>
                <div class="code-b"><pre id="code-sdk-cb"><span class="kw">&lt;?php</span>
<span class="cm">// callback.php - Terima notifikasi dari NEO PGA</span>

<span class="kw">require_once</span> <span class="str">'includes/neopga.php'</span>;

<span class="cm">// Verifikasi dan ambil data pembayaran</span>
<span class="var">$payment</span> = NeoPGA::<span class="kw">verifyCallback</span>();

<span class="kw">if</span> (<span class="var">$payment</span> && <span class="var">$payment</span>[<span class="str">'status'</span>] === <span class="str">'success'</span>) {
    <span class="cm">// Data yang tersedia:</span>
    <span class="var">$orderId</span>    = <span class="var">$payment</span>[<span class="str">'reference_id'</span>];    <span class="cm">// ID order dari Anda</span>
    <span class="var">$amount</span>     = <span class="var">$payment</span>[<span class="str">'amount'</span>];          <span class="cm">// Nominal asli</span>
    <span class="var">$totalPaid</span>  = <span class="var">$payment</span>[<span class="str">'total_amount'</span>];    <span class="cm">// Nominal + kode unik</span>
    <span class="var">$uniqueCode</span> = <span class="var">$payment</span>[<span class="str">'unique_code'</span>];     <span class="cm">// Kode unik (1-999)</span>
    <span class="var">$invoice</span>    = <span class="var">$payment</span>[<span class="str">'invoice_number'</span>];  <span class="cm">// Invoice NEO PGA</span>

    <span class="cm">// Parse user_id dari order_id (format: DEP-{user_id}-{timestamp})</span>
    <span class="var">$parts</span> = <span class="kw">explode</span>(<span class="str">'-'</span>, <span class="var">$orderId</span>);
    <span class="var">$userId</span> = <span class="var">$parts</span>[<span class="num">1</span>] ?? <span class="kw">null</span>;

    <span class="kw">if</span> (<span class="var">$userId</span>) {
        <span class="cm">// ========================================</span>
        <span class="cm">// UPDATE SALDO USER DI DATABASE ANDA</span>
        <span class="cm">// ========================================</span>
        <span class="var">$pdo</span> = <span class="kw">new</span> PDO(<span class="str">'mysql:host=localhost;dbname=NAMA_DB'</span>, <span class="str">'USERNAME'</span>, <span class="str">'PASSWORD'</span>);

        <span class="cm">// Update saldo (gunakan $amount, bukan $totalPaid)</span>
        <span class="var">$stmt</span> = <span class="var">$pdo</span>-><span class="kw">prepare</span>(<span class="str">'UPDATE users SET saldo = saldo + ? WHERE id = ?'</span>);
        <span class="var">$stmt</span>-><span class="kw">execute</span>([<span class="var">$amount</span>, <span class="var">$userId</span>]);

        <span class="cm">// (Opsional) Log transaksi</span>
        <span class="var">$stmt</span> = <span class="var">$pdo</span>-><span class="kw">prepare</span>(<span class="str">'INSERT INTO deposits (user_id, amount, invoice, created_at) VALUES (?, ?, ?, NOW())'</span>);
        <span class="var">$stmt</span>-><span class="kw">execute</span>([<span class="var">$userId</span>, <span class="var">$amount</span>, <span class="var">$invoice</span>]);
    }

    <span class="cm">// WAJIB return 200 OK</span>
    <span class="kw">http_response_code</span>(<span class="num">200</span>);
    <span class="kw">echo</span> <span class="kw">json_encode</span>([<span class="str">'status'</span> => <span class="str">'ok'</span>]);
} <span class="kw">else</span> {
    <span class="kw">http_response_code</span>(<span class="num">400</span>);
    <span class="kw">echo</span> <span class="kw">json_encode</span>([<span class="str">'status'</span> => <span class="str">'invalid'</span>]);
}
<span class="kw">?&gt;</span></pre></div>
            </div>
        </div>

        <!-- Step 4: Set Callback URL -->
        <div class="card">
            <div class="card-h">
                <div class="card-icon green">4️⃣</div>
                <div><h3 class="card-t">Step 4: Set URL Callback di Dashboard</h3><p class="card-st">Agar NEO PGA tahu kemana mengirim notifikasi</p></div>
            </div>
            <div class="vstep">
                <div class="vstep-n">a</div>
                <div><h4 class="vstep-t">Buka Menu Pengaturan</h4><p class="vstep-d">Dashboard NEO PGA → <a href="settings.php" style="color:var(--neo);">Pengaturan</a></p></div>
            </div>
            <div class="vstep">
                <div class="vstep-n">b</div>
                <div><h4 class="vstep-t">Masukkan URL Callback</h4><p class="vstep-d">Isi dengan URL callback Anda, contoh: <code>https://websiteanda.com/callback.php</code></p></div>
            </div>
            <div class="vstep">
                <div class="vstep-n">c</div>
                <div><h4 class="vstep-t">Simpan</h4><p class="vstep-d">Klik tombol Simpan. URL ini akan digunakan untuk semua transaksi.</p></div>
            </div>
        </div>

        <!-- Step 5: Testing -->
        <div class="card">
            <div class="card-h">
                <div class="card-icon">5️⃣</div>
                <div><h3 class="card-t">Step 5: Testing</h3><p class="card-st">Coba dengan nominal kecil dulu!</p></div>
            </div>
            <div class="vstep">
                <div class="vstep-n">1</div>
                <div><h4 class="vstep-t">Test Deposit</h4><p class="vstep-d">Buka halaman deposit website Anda, isi nominal Rp 10.000, submit form.</p></div>
            </div>
            <div class="vstep">
                <div class="vstep-n">2</div>
                <div><h4 class="vstep-t">Cek QRIS Muncul</h4><p class="vstep-d">Pastikan halaman QRIS NEO PGA muncul dengan nominal + kode unik.</p></div>
            </div>
            <div class="vstep">
                <div class="vstep-n">3</div>
                <div><h4 class="vstep-t">Bayar QRIS</h4><p class="vstep-d">Scan QRIS dengan GoPay/OVO/DANA. Bayar dengan nominal TEPAT termasuk kode unik!</p></div>
            </div>
            <div class="vstep">
                <div class="vstep-n">4</div>
                <div><h4 class="vstep-t">Cek Saldo Terupdate</h4><p class="vstep-d">Cek saldo user di website Anda. Jika bertambah Rp 10.000, berarti SUKSES!</p></div>
            </div>
            <div class="alert alert-s">
                <div class="alert-icon">✅</div>
                <div><div class="alert-t">Selamat!</div><div class="alert-txt">Jika saldo terupdate, integrasi Anda sudah berjalan dengan benar. Website Anda siap menerima pembayaran!</div></div>
            </div>
        </div>

    </div>

    <!-- TAB 2: STUDI KASUS -->
    <div id="tab-kasus" class="tc">
        <div class="card">
            <div class="card-h">
                <div class="card-icon blue">📚</div>
                <div><h3 class="card-t">Pilih Studi Kasus Bisnismu</h3><p class="card-st">Klik untuk melihat contoh kode lengkap</p></div>
            </div>
            <div class="case-grid">
                <div class="case-card active" onclick="showCase('game')">
                    <div class="case-emoji">🎮</div>
                    <h4 class="case-t">Game Top Up</h4>
                    <p class="case-d">Top up diamond, voucher game, in-game currency</p>
                </div>
                <div class="case-card" onclick="showCase('digital')">
                    <div class="case-emoji">💻</div>
                    <h4 class="case-t">Jasa Digital</h4>
                    <p class="case-d">Hosting, domain, VPN, software license</p>
                </div>
                <div class="case-card" onclick="showCase('toko')">
                    <div class="case-emoji">👕</div>
                    <h4 class="case-t">Toko Online</h4>
                    <p class="case-d">Jual baju, sepatu, produk fisik</p>
                </div>
            </div>
        </div>
        
        <!-- Case: Game -->
        <div id="case-game" class="case-c active">
            <div class="card">
                <div class="card-h">
                    <div class="card-icon orange">🎮</div>
                    <div><h3 class="card-t">Studi Kasus: Website Top Up Game</h3><p class="card-st">Contoh untuk Mobile Legends, Free Fire, dll</p></div>
                </div>
                <div class="alert alert-i">
                    <div class="alert-icon">💡</div>
                    <div><div class="alert-t">Skenario:</div><div class="alert-txt">Customer beli 100 Diamond ML seharga Rp 15.000. Setelah bayar, sistem otomatis proses top up ke akun game.</div></div>
                </div>
                <div class="code">
                    <div class="code-h"><span class="code-fn">checkout-game.php</span><button class="code-cp" onclick="copyCode('code-game',this)">📋 Copy</button></div>
                    <div class="code-b"><pre id="code-game"><span class="kw">&lt;?php</span>
<span class="cm">// checkout-game.php - Top Up Game</span>

<span class="var">$API_KEY</span> = <span class="str">"<?= $apiKey ?>"</span>;
<span class="var">$API_URL</span> = <span class="str">"<?= $baseUrl ?>/api/create.php"</span>;

<span class="cm">// Data dari form</span>
<span class="var">$gameUserId</span> = <span class="var">$_POST</span>[<span class="str">'user_id'</span>];     <span class="cm">// ID akun ML</span>
<span class="var">$gameZoneId</span> = <span class="var">$_POST</span>[<span class="str">'zone_id'</span>];     <span class="cm">// Zone ID</span>
<span class="var">$productId</span>  = <span class="var">$_POST</span>[<span class="str">'product'</span>];      <span class="cm">// 86dm, 172dm, dll</span>
<span class="var">$custPhone</span>  = <span class="var">$_POST</span>[<span class="str">'phone'</span>];

<span class="cm">// Daftar produk</span>
<span class="var">$products</span> = [
    <span class="str">'86dm'</span>  => [<span class="str">'name'</span>=><span class="str">'86 Diamond'</span>,  <span class="str">'price'</span>=><span class="num">15000</span>],
    <span class="str">'172dm'</span> => [<span class="str">'name'</span>=><span class="str">'172 Diamond'</span>, <span class="str">'price'</span>=><span class="num">29000</span>],
    <span class="str">'344dm'</span> => [<span class="str">'name'</span>=><span class="str">'344 Diamond'</span>, <span class="str">'price'</span>=><span class="num">55000</span>],
];

<span class="var">$product</span> = <span class="var">$products</span>[<span class="var">$productId</span>];
<span class="var">$orderId</span> = <span class="str">'TOPUP-'</span>.<span class="kw">time</span>().<span class="kw">rand</span>(<span class="num">100</span>,<span class="num">999</span>);

<span class="cm">// Simpan ke database dulu</span>
<span class="var">$db</span> = <span class="kw">new</span> PDO(<span class="str">"mysql:host=localhost;dbname=topup"</span>, <span class="str">"user"</span>, <span class="str">"pass"</span>);
<span class="var">$db</span>->query(<span class="str">"INSERT INTO orders (order_id, product, amount, game_user_id, game_zone_id, phone, status) 
            VALUES ('$orderId', '{$product['name']}', {$product['price']}, '$gameUserId', '$gameZoneId', '$custPhone', 'pending')"</span>);

<span class="cm">// Buat pembayaran</span>
<span class="var">$data</span> = [
    <span class="str">'amount'</span>         => <span class="var">$product</span>[<span class="str">'price'</span>],
    <span class="str">'customer_name'</span>  => <span class="str">'Player '</span>.<span class="var">$gameUserId</span>,
    <span class="str">'customer_email'</span> => <span class="str">'player@topup.com'</span>,
    <span class="str">'customer_phone'</span> => <span class="var">$custPhone</span>,
    <span class="str">'description'</span>    => <span class="var">$product</span>[<span class="str">'name'</span>].<span class="str">' - ID: '</span>.<span class="var">$gameUserId</span>,
    <span class="str">'reference_id'</span>   => <span class="var">$orderId</span>,
    <span class="str">'callback_url'</span>   => <span class="str">'https://topup-kamu.com/callback.php'</span>,
    <span class="str">'expiry_minutes'</span> => <span class="num">30</span>
];

<span class="cm">// Kirim request (sama seperti sebelumnya)</span>
<span class="var">$ch</span> = <span class="kw">curl_init</span>();
<span class="kw">curl_setopt_array</span>(<span class="var">$ch</span>, [
    CURLOPT_URL => <span class="var">$API_URL</span>,
    CURLOPT_RETURNTRANSFER => <span class="kw">true</span>,
    CURLOPT_POST => <span class="kw">true</span>,
    CURLOPT_HTTPHEADER => [<span class="str">'X-API-Key: '</span>.<span class="var">$API_KEY</span>, <span class="str">'Content-Type: application/json'</span>],
    CURLOPT_POSTFIELDS => <span class="kw">json_encode</span>(<span class="var">$data</span>)
]);
<span class="var">$result</span> = <span class="kw">json_decode</span>(<span class="kw">curl_exec</span>(<span class="var">$ch</span>), <span class="kw">true</span>);
<span class="kw">curl_close</span>(<span class="var">$ch</span>);

<span class="kw">if</span> (<span class="var">$result</span>[<span class="str">'success'</span>]) {
    <span class="kw">header</span>(<span class="str">'Location: '</span>.<span class="var">$result</span>[<span class="str">'data'</span>][<span class="str">'payment_url'</span>]);
}
<span class="kw">?&gt;</span></pre></div>
                </div>
                <div class="code">
                    <div class="code-h"><span class="code-fn">callback-game.php — Proses Top Up Otomatis</span><button class="code-cp" onclick="copyCode('code-game-cb',this)">📋 Copy</button></div>
                    <div class="code-b"><pre id="code-game-cb"><span class="kw">&lt;?php</span>
<span class="cm">// callback-game.php</span>
<span class="var">$SECRET_KEY</span> = <span class="str">"<?= $secretKey ?>"</span>;
<span class="var">$data</span> = <span class="kw">json_decode</span>(<span class="kw">file_get_contents</span>(<span class="str">'php://input'</span>), <span class="kw">true</span>);

<span class="cm">// Verifikasi signature</span>
<span class="var">$sig</span> = <span class="kw">hash_hmac</span>(<span class="str">'sha256'</span>, <span class="kw">json_encode</span>(<span class="var">$data</span>[<span class="str">'data'</span>]), <span class="var">$SECRET_KEY</span>);
<span class="kw">if</span> (<span class="var">$data</span>[<span class="str">'signature'</span>] !== <span class="var">$sig</span>) { <span class="kw">http_response_code</span>(<span class="num">401</span>); <span class="kw">exit</span>; }

<span class="kw">if</span> (<span class="var">$data</span>[<span class="str">'event'</span>] === <span class="str">'payment.success'</span>) {
    <span class="var">$orderId</span> = <span class="var">$data</span>[<span class="str">'data'</span>][<span class="str">'reference_id'</span>];
    
    <span class="var">$db</span> = <span class="kw">new</span> PDO(<span class="str">"mysql:host=localhost;dbname=topup"</span>, <span class="str">"user"</span>, <span class="str">"pass"</span>);
    <span class="var">$order</span> = <span class="var">$db</span>->query(<span class="str">"SELECT * FROM orders WHERE order_id='$orderId'"</span>)->fetch();
    
    <span class="kw">if</span> (<span class="var">$order</span> && <span class="var">$order</span>[<span class="str">'status'</span>] === <span class="str">'pending'</span>) {
        <span class="cm">// =============================================</span>
        <span class="cm">// PROSES TOP UP DI SINI!</span>
        <span class="cm">// Integrasi dengan API provider game</span>
        <span class="cm">// processTopUp($order['game_user_id'], $order['game_zone_id'], $order['product']);</span>
        <span class="cm">// =============================================</span>
        
        <span class="var">$db</span>->query(<span class="str">"UPDATE orders SET status='success' WHERE order_id='$orderId'"</span>);
        
        <span class="cm">// Kirim notif WA ke customer (opsional)</span>
        <span class="cm">// sendWhatsApp($order['phone'], "Top up berhasil!");</span>
    }
}

<span class="kw">http_response_code</span>(<span class="num">200</span>);
<span class="kw">echo</span> <span class="str">'OK'</span>;
<span class="kw">?&gt;</span></pre></div>
                </div>
            </div>
        </div>
        
        <!-- Case: Digital -->
        <div id="case-digital" class="case-c">
            <div class="card">
                <div class="card-h">
                    <div class="card-icon purple">💻</div>
                    <div><h3 class="card-t">Studi Kasus: Jasa Digital</h3><p class="card-st">Hosting, domain, VPN, software license</p></div>
                </div>
                <div class="alert alert-i">
                    <div class="alert-icon">💡</div>
                    <div><div class="alert-t">Skenario:</div><div class="alert-txt">Customer beli hosting 1 tahun Rp 250.000. Setelah bayar, sistem buat akun hosting dan kirim detail login via email.</div></div>
                </div>
                <p style="color:#6b7280;margin-top:20px;">Kode sama seperti contoh checkout.php di atas. Yang berbeda adalah logic di callback:</p>
                <div class="code">
                    <div class="code-h"><span class="code-fn">callback-hosting.php — Aktivasi Otomatis</span><button class="code-cp" onclick="copyCode('code-host',this)">📋 Copy</button></div>
                    <div class="code-b"><pre id="code-host"><span class="kw">&lt;?php</span>
<span class="cm">// Di bagian callback, setelah verifikasi signature:</span>

<span class="kw">if</span> (<span class="var">$data</span>[<span class="str">'event'</span>] === <span class="str">'payment.success'</span>) {
    <span class="var">$orderId</span> = <span class="var">$data</span>[<span class="str">'data'</span>][<span class="str">'reference_id'</span>];
    <span class="var">$custEmail</span> = <span class="var">$data</span>[<span class="str">'data'</span>][<span class="str">'customer'</span>][<span class="str">'email'</span>];
    
    <span class="cm">// Buat akun hosting (integrasi cPanel/Plesk API)</span>
    <span class="var">$username</span> = <span class="str">'user'</span>.<span class="kw">time</span>();
    <span class="var">$password</span> = <span class="kw">bin2hex</span>(<span class="kw">random_bytes</span>(<span class="num">8</span>));
    <span class="cm">// createHostingAccount($domain, $username, $password);</span>
    
    <span class="cm">// Update database</span>
    <span class="var">$db</span>->query(<span class="str">"UPDATE orders SET status='active' WHERE order_id='$orderId'"</span>);
    
    <span class="cm">// Kirim email login</span>
    <span class="var">$emailBody</span> = <span class="str">"
        Hosting Anda sudah aktif!
        
        Login cPanel:
        - URL: https://cpanel.domain.com
        - Username: $username
        - Password: $password
    "</span>;
    <span class="kw">mail</span>(<span class="var">$custEmail</span>, <span class="str">'Hosting Aktif!'</span>, <span class="var">$emailBody</span>);
}
<span class="kw">?&gt;</span></pre></div>
                </div>
            </div>
        </div>
        
        <!-- Case: Toko -->
        <div id="case-toko" class="case-c">
            <div class="card">
                <div class="card-h">
                    <div class="card-icon green">👕</div>
                    <div><h3 class="card-t">Studi Kasus: Toko Online Baju</h3><p class="card-st">E-commerce, dropship</p></div>
                </div>
                <div class="alert alert-i">
                    <div class="alert-icon">💡</div>
                    <div><div class="alert-t">Skenario:</div><div class="alert-txt">Customer beli Kaos + Celana total Rp 285.000. Setelah bayar, admin dapat notifikasi untuk proses pengiriman.</div></div>
                </div>
                <div class="code">
                    <div class="code-h"><span class="code-fn">callback-toko.php — Notifikasi Admin</span><button class="code-cp" onclick="copyCode('code-toko',this)">📋 Copy</button></div>
                    <div class="code-b"><pre id="code-toko"><span class="kw">&lt;?php</span>
<span class="cm">// Di bagian callback, setelah verifikasi signature:</span>

<span class="kw">if</span> (<span class="var">$data</span>[<span class="str">'event'</span>] === <span class="str">'payment.success'</span>) {
    <span class="var">$orderId</span> = <span class="var">$data</span>[<span class="str">'data'</span>][<span class="str">'reference_id'</span>];
    <span class="var">$amount</span> = <span class="var">$data</span>[<span class="str">'data'</span>][<span class="str">'amount'</span>];
    <span class="var">$custName</span> = <span class="var">$data</span>[<span class="str">'data'</span>][<span class="str">'customer'</span>][<span class="str">'name'</span>];
    
    <span class="cm">// Update status order</span>
    <span class="var">$db</span>->query(<span class="str">"UPDATE orders SET status='paid', paid_at=NOW() WHERE order_id='$orderId'"</span>);
    
    <span class="cm">// Kirim email konfirmasi ke customer</span>
    <span class="kw">mail</span>(<span class="var">$data</span>[<span class="str">'data'</span>][<span class="str">'customer'</span>][<span class="str">'email'</span>], <span class="str">'Pembayaran Berhasil'</span>, <span class="str">"
        Halo $custName,
        Pembayaran order #$orderId berhasil!
        Pesanan akan segera diproses.
    "</span>);
    
    <span class="cm">// Kirim notifikasi ke admin (Telegram/WA)</span>
    <span class="var">$adminMsg</span> = <span class="str">"🛒 ORDER BARU!\nOrder: #$orderId\nCustomer: $custName\nTotal: Rp "</span>.<span class="kw">number_format</span>(<span class="var">$amount</span>);
    <span class="cm">// sendTelegram($adminMsg);</span>
    <span class="cm">// sendWhatsApp('08123456789', $adminMsg);</span>
    
    <span class="cm">// Kurangi stok (opsional)</span>
    <span class="cm">// updateStock($orderId);</span>
}
<span class="kw">?&gt;</span></pre></div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- TAB 3: API REFERENCE -->
    <div id="tab-api" class="tc">
        <div class="card">
            <div class="card-h">
                <div class="card-icon blue">📤</div>
                <div><h3 class="card-t">POST /api/create.php</h3><p class="card-st">Buat transaksi pembayaran baru</p></div>
            </div>
            <h4 style="margin:20px 0 12px;font-size:1rem;">📋 Header Request:</h4>
            <table class="tbl">
                <tr><th>Header</th><th>Value</th><th>Wajib</th></tr>
                <tr><td><code>X-API-Key</code></td><td>API Key Anda</td><td><span class="badge badge-r">YA</span></td></tr>
                <tr><td><code>Content-Type</code></td><td>application/json</td><td><span class="badge badge-r">YA</span></td></tr>
            </table>
            <h4 style="margin:20px 0 12px;font-size:1rem;">📋 Body Parameters:</h4>
            <table class="tbl">
                <tr><th>Parameter</th><th>Tipe</th><th>Wajib</th><th>Keterangan</th></tr>
                <tr><td><code>amount</code></td><td>integer</td><td><span class="badge badge-r">YA</span></td><td>Nominal Rupiah (min:10.000, max:100.000.000)</td></tr>
                <tr><td><code>customer_name</code></td><td>string</td><td><span class="badge badge-r">YA</span></td><td>Nama customer</td></tr>
                <tr><td><code>customer_email</code></td><td>string</td><td><span class="badge badge-r">YA</span></td><td>Email customer</td></tr>
                <tr><td><code>customer_phone</code></td><td>string</td><td><span class="badge badge-o">TIDAK</span></td><td>No HP</td></tr>
                <tr><td><code>description</code></td><td>string</td><td><span class="badge badge-o">TIDAK</span></td><td>Deskripsi (max 255)</td></tr>
                <tr><td><code>reference_id</code></td><td>string</td><td><span class="badge badge-o">TIDAK</span></td><td>ID unik dari sistem kamu</td></tr>
                <tr><td><code>callback_url</code></td><td>string</td><td><span class="badge badge-o">TIDAK</span></td><td>URL untuk callback</td></tr>
                <tr><td><code>redirect_url</code></td><td>string</td><td><span class="badge badge-o">TIDAK</span></td><td>URL redirect setelah bayar</td></tr>
                <tr><td><code>expiry_minutes</code></td><td>integer</td><td><span class="badge badge-o">TIDAK</span></td><td>Waktu kadaluarsa (default:60, min:5, max:1440)</td></tr>
            </table>
        </div>
        
        <div class="card">
            <div class="card-h">
                <div class="card-icon purple">🔍</div>
                <div><h3 class="card-t">GET /api/status.php</h3><p class="card-st">Cek status transaksi</p></div>
            </div>
            <p style="color:#6b7280;margin-bottom:16px;">URL: <code><?= $baseUrl ?>/api/status.php?invoice=INVOICE_NUMBER</code></p>
            <h4 style="margin:20px 0 12px;font-size:1rem;">📊 Status yang Mungkin:</h4>
            <table class="tbl">
                <tr><th>Status</th><th>Artinya</th><th>Action</th></tr>
                <tr><td><span style="background:#fef3c7;color:#b45309;padding:4px 12px;border-radius:50px;font-weight:600;">pending</span></td><td>Menunggu pembayaran</td><td>Tampilkan halaman bayar</td></tr>
                <tr><td><span style="background:#dcfce7;color:#16a34a;padding:4px 12px;border-radius:50px;font-weight:600;">success</span></td><td>Pembayaran berhasil</td><td>Proses pesanan</td></tr>
                <tr><td><span style="background:#fee2e2;color:#dc2626;padding:4px 12px;border-radius:50px;font-weight:600;">expired</span></td><td>Kadaluarsa</td><td>Minta order ulang</td></tr>
                <tr><td><span style="background:#fee2e2;color:#dc2626;padding:4px 12px;border-radius:50px;font-weight:600;">failed</span></td><td>Gagal</td><td>Coba lagi</td></tr>
            </table>
        </div>
        
        <div class="card">
            <div class="card-h">
                <div class="card-icon orange">📡</div>
                <div><h3 class="card-t">Callback (Webhook)</h3><p class="card-st">Format data yang dikirim ke callback_url</p></div>
            </div>
            <h4 style="margin:20px 0 12px;font-size:1rem;">📥 Format Data:</h4>
            <div class="code">
                <div class="code-b"><pre>{
    <span class="str">"event"</span>: <span class="str">"payment.success"</span>,
    <span class="str">"timestamp"</span>: <span class="str">"2024-12-10T15:30:00+07:00"</span>,
    <span class="str">"data"</span>: {
        <span class="str">"invoice_number"</span>: <span class="str">"INV20241210XXXXX"</span>,
        <span class="str">"reference_id"</span>: <span class="str">"ORDER-123456"</span>,
        <span class="str">"amount"</span>: <span class="num">150000</span>,
        <span class="str">"total_amount"</span>: <span class="num">150234</span>,
        <span class="str">"status"</span>: <span class="str">"success"</span>,
        <span class="str">"customer"</span>: {
            <span class="str">"name"</span>: <span class="str">"Budi Santoso"</span>,
            <span class="str">"email"</span>: <span class="str">"budi@email.com"</span>
        }
    },
    <span class="str">"signature"</span>: <span class="str">"abc123..."</span>
}</pre></div>
            </div>
            <h4 style="margin:20px 0 12px;font-size:1rem;">🔐 Verifikasi Signature:</h4>
            <div class="code">
                <div class="code-b"><pre><span class="var">$expectedSig</span> = <span class="kw">hash_hmac</span>(<span class="str">'sha256'</span>, <span class="kw">json_encode</span>(<span class="var">$data</span>[<span class="str">'data'</span>]), <span class="var">$SECRET_KEY</span>);
<span class="kw">if</span> (<span class="var">$data</span>[<span class="str">'signature'</span>] === <span class="var">$expectedSig</span>) {
    <span class="cm">// Valid!</span>
}</pre></div>
            </div>
        </div>
    </div>
    
    <!-- TAB 4: FAQ -->
    <div id="tab-faq" class="tc">
        <div class="card">
            <div class="card-h">
                <div class="card-icon purple">❓</div>
                <div><h3 class="card-t">Pertanyaan yang Sering Ditanyakan</h3><p class="card-st">Klik untuk melihat jawaban</p></div>
            </div>
            
            <div class="faq-item open">
                <div class="faq-q" onclick="toggleFaq(this)"><span class="faq-qt">🤔 Apakah saya harus punya server sendiri?</span><span class="faq-tog">▼</span></div>
                <div class="faq-a"><strong>Ya, minimal hosting PHP biasa sudah cukup.</strong> Kode integrasi dijalankan di server (backend). Hosting shared murah (Rp 50rb/tahun) sudah bisa.</div>
            </div>
            
            <div class="faq-item">
                <div class="faq-q" onclick="toggleFaq(this)"><span class="faq-qt">⏰ Berapa lama waktu kadaluarsa?</span><span class="faq-tog">▼</span></div>
                <div class="faq-a">Default <strong>60 menit</strong>. Bisa diubah via <code>expiry_minutes</code> (min:5, max:1440/24jam).</div>
            </div>
            
            <div class="faq-item">
                <div class="faq-q" onclick="toggleFaq(this)"><span class="faq-qt">💰 Apa itu kode unik?</span><span class="faq-tog">▼</span></div>
                <div class="faq-a"><strong>3 digit tambahan</strong> untuk membedakan pembayaran. Contoh: Rp 150.000 jadi Rp 150.234. Customer HARUS bayar dengan nominal tepat termasuk kode unik!</div>
            </div>
            
            <div class="faq-item">
                <div class="faq-q" onclick="toggleFaq(this)"><span class="faq-qt">🔒 Aman taruh API Key di PHP?</span><span class="faq-tog">▼</span></div>
                <div class="faq-a"><strong>Aman</strong>, karena kode PHP diproses di server. Yang TIDAK boleh: taruh di JavaScript/HTML yang bisa dilihat user!</div>
            </div>
            
            <div class="faq-item">
                <div class="faq-q" onclick="toggleFaq(this)"><span class="faq-qt">📡 Callback tidak masuk?</span><span class="faq-tog">▼</span></div>
                <div class="faq-a">Checklist:<br>1. URL bisa diakses publik?<br>2. Server online?<br>3. Ada firewall block?<br>4. Return HTTP 200?<br>5. callback_url benar?</div>
            </div>
            
            <div class="faq-item">
                <div class="faq-q" onclick="toggleFaq(this)"><span class="faq-qt">🔄 Signature invalid?</span><span class="faq-tog">▼</span></div>
                <div class="faq-a">1. SECRET_KEY sudah benar?<br>2. Gunakan <code>json_encode($data['data'])</code> — hanya bagian data!<br>3. Algoritma <code>sha256</code></div>
            </div>
        </div>
    </div>
    
    <!-- Support -->
    <div class="support">
        <div class="support-icon">💬</div>
        <h2 class="support-t">Butuh Bantuan?</h2>
        <p class="support-txt">Tim kami siap membantu integrasi</p>
        <div class="support-btns">
            <a href="https://wa.me/6281234567890" target="_blank" class="support-btn wa">📱 WhatsApp</a>
            <a href="mailto:support@neopga.com" class="support-btn em">✉️ Email</a>
        </div>
    </div>
</div>

<script>
function showTab(id) {
    document.querySelectorAll('.tc').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.getElementById('tab-'+id).classList.add('active');
    event.target.classList.add('active');
}

function showCase(id) {
    document.querySelectorAll('.case-c').forEach(c => c.classList.remove('active'));
    document.querySelectorAll('.case-card').forEach(c => c.classList.remove('active'));
    document.getElementById('case-'+id).classList.add('active');
    event.target.closest('.case-card').classList.add('active');
}

function copyC(id, btn) {
    navigator.clipboard.writeText(document.getElementById(id).innerText).then(() => {
        btn.innerText = '✓ Copied!';
        btn.classList.add('copied');
        setTimeout(() => { btn.innerText = '📋 Copy'; btn.classList.remove('copied'); }, 2000);
    });
}

function copyCode(id, btn) {
    navigator.clipboard.writeText(document.getElementById(id).innerText).then(() => {
        btn.innerText = '✓ Copied!';
        btn.classList.add('copied');
        setTimeout(() => { btn.innerText = '📋 Copy'; btn.classList.remove('copied'); }, 2000);
    });
}

function toggleChk(el) {
    el.classList.toggle('checked');
    el.closest('.chk-item').classList.toggle('checked');
    el.innerHTML = el.classList.contains('checked') ? '✓' : '';
}

function toggleFaq(el) {
    el.closest('.faq-item').classList.toggle('open');
}
</script>

<?php include __DIR__ . '/layout_footer.php'; ?>

<?php
/**
 * NEO PGA - Payment Link Generator
 * Generate shareable payment links
 */
require_once __DIR__ . '/../includes/init.php';

$pageTitle = 'Payment Link Generator';
$currentPage = 'payment-link';

// Include layout header (handles auth)
include __DIR__ . '/layout_header.php';

$db = Database::getInstance();
$message = '';
$messageType = '';
$generatedLink = null;

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();

    $amount = (int) preg_replace('/[^0-9]/', '', $_POST['amount'] ?? '');
    $description = sanitize($_POST['description'] ?? '');
    $customerName = sanitize($_POST['customer_name'] ?? '');
    $customerEmail = sanitize($_POST['customer_email'] ?? '');
    $customerPhone = sanitize($_POST['customer_phone'] ?? '');
    $expiryHours = (int) ($_POST['expiry_hours'] ?? 24);
    $referenceId = sanitize($_POST['reference_id'] ?? '') ?: 'LINK-' . strtoupper(bin2hex(random_bytes(4)));

    if ($amount < MIN_AMOUNT) {
        $message = 'Minimal nominal adalah ' . formatRupiah(MIN_AMOUNT);
        $messageType = 'danger';
    } elseif ($amount > MAX_AMOUNT) {
        $message = 'Maksimal nominal adalah ' . formatRupiah(MAX_AMOUNT);
        $messageType = 'danger';
    } else {
        try {
            // Create transaction via Transaction class
            $transaction = new Transaction();
            $result = $transaction->create([
                'merchant_id' => $merchantId,
                'reference_id' => $referenceId,
                'amount' => $amount,
                'description' => $description ?: 'Payment Link',
                'customer_name' => $customerName,
                'customer_email' => $customerEmail,
                'customer_phone' => $customerPhone,
                'payment_method' => 'qris',
                'expiry_minutes' => $expiryHours * 60
            ]);

            if ($result['success']) {
                $invoiceNumber = $result['data']['invoice_number'];
                $generatedLink = PUBLIC_URL . '/pay.php?invoice=' . $invoiceNumber;
                $message = 'Payment link berhasil dibuat!';
                $messageType = 'success';
            } else {
                $message = $result['message'] ?? 'Gagal membuat payment link';
                $messageType = 'danger';
            }
        } catch (Exception $e) {
            $message = 'Error: ' . $e->getMessage();
            $messageType = 'danger';
        }
    }
}

// Get recent payment links
$recentLinks = $db->fetchAll(
    "SELECT * FROM transactions
     WHERE merchant_id = ? AND reference_id LIKE 'LINK-%'
     ORDER BY created_at DESC LIMIT 10",
    [$merchantId]
) ?: [];
?>

<style>
.link-generator {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 1.5rem;
}

.generator-card {
    background: white;
    border-radius: 16px;
    border: 1px solid var(--gray-200);
    overflow: hidden;
}

.generator-header {
    padding: 1.25rem 1.5rem;
    border-bottom: 1px solid var(--gray-100);
    background: linear-gradient(135deg, var(--primary-50), white);
}

.generator-header h3 {
    margin: 0;
    font-size: 1.1rem;
    font-weight: 600;
    color: var(--gray-800);
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.generator-body {
    padding: 1.5rem;
}

.form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 1rem;
}

.form-group {
    margin-bottom: 1.25rem;
}

.form-label {
    display: block;
    font-size: 0.8rem;
    font-weight: 600;
    color: var(--gray-600);
    margin-bottom: 0.5rem;
    text-transform: uppercase;
    letter-spacing: 0.03em;
}

.form-input {
    width: 100%;
    padding: 0.75rem 1rem;
    border: 1px solid var(--gray-300);
    border-radius: 10px;
    font-size: 0.95rem;
    transition: all 0.2s;
}

.form-input:focus {
    outline: none;
    border-color: var(--primary);
    box-shadow: 0 0 0 3px rgba(13, 148, 136, 0.1);
}

.form-input.amount-input {
    font-size: 1.5rem;
    font-weight: 700;
    text-align: center;
    padding: 1rem;
}

.amount-preview {
    text-align: center;
    padding: 1rem;
    background: var(--gray-50);
    border-radius: 10px;
    margin-bottom: 1rem;
}

.amount-preview-label {
    font-size: 0.8rem;
    color: var(--gray-500);
    margin-bottom: 0.25rem;
}

.amount-preview-value {
    font-size: 1.75rem;
    font-weight: 800;
    color: var(--primary);
}

/* Generated Link Box */
.link-result {
    background: linear-gradient(135deg, #ecfdf5, #d1fae5);
    border: 2px solid #10b981;
    border-radius: 16px;
    padding: 1.5rem;
    margin-bottom: 1.5rem;
}

.link-result-header {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    margin-bottom: 1rem;
}

.link-result-icon {
    width: 48px;
    height: 48px;
    background: #10b981;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
}

.link-result-title {
    font-size: 1.1rem;
    font-weight: 700;
    color: #065f46;
}

.link-result-subtitle {
    font-size: 0.85rem;
    color: #047857;
}

.link-url-box {
    background: white;
    border-radius: 10px;
    padding: 1rem;
    display: flex;
    align-items: center;
    gap: 1rem;
    margin-bottom: 1rem;
}

.link-url {
    flex: 1;
    font-family: var(--font-mono);
    font-size: 0.85rem;
    color: var(--gray-700);
    word-break: break-all;
}

.share-buttons {
    display: flex;
    gap: 0.75rem;
    flex-wrap: wrap;
}

.share-btn {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.625rem 1rem;
    border-radius: 8px;
    font-size: 0.85rem;
    font-weight: 500;
    text-decoration: none;
    transition: all 0.2s;
    border: none;
    cursor: pointer;
}

.share-btn-copy {
    background: var(--primary);
    color: white;
}

.share-btn-copy:hover {
    background: var(--primary-dark);
}

.share-btn-wa {
    background: #25d366;
    color: white;
}

.share-btn-wa:hover {
    background: #1da851;
}

.share-btn-email {
    background: #6b7280;
    color: white;
}

.share-btn-email:hover {
    background: #4b5563;
}

.share-btn-qr {
    background: white;
    color: var(--gray-700);
    border: 1px solid var(--gray-300);
}

.share-btn-qr:hover {
    background: var(--gray-50);
}

/* Recent Links Table */
.recent-links {
    margin-top: 1.5rem;
}

.link-table {
    width: 100%;
    border-collapse: collapse;
}

.link-table th {
    text-align: left;
    padding: 0.75rem 1rem;
    font-size: 0.75rem;
    font-weight: 600;
    text-transform: uppercase;
    color: var(--gray-500);
    border-bottom: 1px solid var(--gray-200);
}

.link-table td {
    padding: 0.875rem 1rem;
    font-size: 0.875rem;
    border-bottom: 1px solid var(--gray-100);
}

.link-table tbody tr:hover {
    background: var(--gray-50);
}

/* QR Modal */
.qr-modal {
    display: none;
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,0.5);
    z-index: 1000;
    align-items: center;
    justify-content: center;
}

.qr-modal.active {
    display: flex;
}

.qr-modal-content {
    background: white;
    border-radius: 16px;
    padding: 2rem;
    text-align: center;
    max-width: 320px;
}

.qr-code-img {
    width: 200px;
    height: 200px;
    margin: 1rem auto;
}

@media (max-width: 768px) {
    .link-generator {
        grid-template-columns: 1fr;
    }
    .form-row {
        grid-template-columns: 1fr;
    }
}
</style>

<?php if ($message): ?>
<div class="alert alert-<?= $messageType ?> mb-6"><?= htmlspecialchars($message) ?></div>
<?php endif; ?>

<?php if ($generatedLink): ?>
<div class="link-result">
    <div class="link-result-header">
        <div class="link-result-icon">✓</div>
        <div>
            <div class="link-result-title">Payment Link Berhasil Dibuat!</div>
            <div class="link-result-subtitle">Bagikan link ini ke customer Anda</div>
        </div>
    </div>

    <div class="link-url-box">
        <div class="link-url" id="generated-link"><?= htmlspecialchars($generatedLink) ?></div>
    </div>

    <div class="share-buttons">
        <button class="share-btn share-btn-copy" onclick="copyLink()">
            <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"/></svg>
            Copy Link
        </button>
        <a href="https://wa.me/?text=<?= urlencode("Silakan lakukan pembayaran melalui link berikut:\n" . $generatedLink) ?>" target="_blank" class="share-btn share-btn-wa">
            <svg width="16" height="16" fill="currentColor" viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
            WhatsApp
        </a>
        <a href="mailto:?subject=Payment%20Link&body=<?= urlencode("Silakan lakukan pembayaran melalui link berikut:\n" . $generatedLink) ?>" class="share-btn share-btn-email">
            <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
            Email
        </a>
        <button class="share-btn share-btn-qr" onclick="showQR()">
            <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v1m6 11h2m-6 0h-2v4m0-11v3m0 0h.01M12 12h4.01M16 20h2M4 12h4m12 0h.01M5 8h2a1 1 0 001-1V5a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1zm12 0h2a1 1 0 001-1V5a1 1 0 00-1-1h-2a1 1 0 00-1 1v2a1 1 0 001 1zM5 20h2a1 1 0 001-1v-2a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1z"/></svg>
            QR Code
        </button>
    </div>
</div>
<?php endif; ?>

<div class="link-generator">
    <!-- Generator Form -->
    <div class="generator-card">
        <div class="generator-header">
            <h3>🔗 Buat Payment Link Baru</h3>
        </div>
        <div class="generator-body">
            <form method="POST">
                <?= csrfField() ?>

                <div class="amount-preview">
                    <div class="amount-preview-label">Total Pembayaran</div>
                    <div class="amount-preview-value" id="amount-display">Rp 0</div>
                </div>

                <div class="form-group">
                    <label class="form-label">Nominal *</label>
                    <input type="text" name="amount" id="amount-input" class="form-input amount-input" placeholder="100.000" required>
                </div>

                <div class="form-group">
                    <label class="form-label">Deskripsi</label>
                    <input type="text" name="description" class="form-input" placeholder="Pembayaran untuk...">
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Nama Customer</label>
                        <input type="text" name="customer_name" class="form-input" placeholder="John Doe">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Email Customer</label>
                        <input type="email" name="customer_email" class="form-input" placeholder="john@example.com">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">No. HP Customer</label>
                        <input type="text" name="customer_phone" class="form-input" placeholder="08123456789">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Masa Berlaku</label>
                        <select name="expiry_hours" class="form-input">
                            <option value="1">1 Jam</option>
                            <option value="6">6 Jam</option>
                            <option value="12">12 Jam</option>
                            <option value="24" selected>24 Jam</option>
                            <option value="48">48 Jam</option>
                            <option value="72">72 Jam</option>
                            <option value="168">7 Hari</option>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Reference ID (Opsional)</label>
                    <input type="text" name="reference_id" class="form-input" placeholder="ORDER-123">
                    <small style="color: var(--gray-500); font-size: 0.75rem;">Kosongkan untuk auto-generate</small>
                </div>

                <button type="submit" class="btn btn-primary" style="width: 100%; padding: 1rem; font-size: 1rem;">
                    🔗 Generate Payment Link
                </button>
            </form>
        </div>
    </div>

    <!-- Recent Links -->
    <div class="generator-card">
        <div class="generator-header">
            <h3>📋 Payment Link Terbaru</h3>
        </div>
        <div class="generator-body" style="padding: 0;">
            <?php if (empty($recentLinks)): ?>
            <div style="padding: 3rem; text-align: center; color: var(--gray-400);">
                <div style="font-size: 2.5rem; margin-bottom: 1rem;">🔗</div>
                <p>Belum ada payment link</p>
            </div>
            <?php else: ?>
            <div style="overflow-x: auto;">
                <table class="link-table">
                    <thead>
                        <tr>
                            <th>Invoice</th>
                            <th>Nominal</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recentLinks as $link): ?>
                        <tr>
                            <td>
                                <code style="font-size: 0.75rem;"><?= htmlspecialchars($link['invoice_number']) ?></code>
                                <div style="font-size: 0.75rem; color: var(--gray-500); margin-top: 2px;">
                                    <?= date('d/m H:i', strtotime($link['created_at'])) ?>
                                </div>
                            </td>
                            <td style="font-weight: 600;"><?= formatRupiah($link['total_amount']) ?></td>
                            <td>
                                <?php
                                $statusClass = [
                                    'success' => 'success',
                                    'pending' => 'warning',
                                    'expired' => 'neutral',
                                    'failed' => 'danger'
                                ][$link['status']] ?? 'neutral';
                                ?>
                                <span class="badge badge-<?= $statusClass ?>"><?= ucfirst($link['status']) ?></span>
                            </td>
                            <td>
                                <?php if ($link['status'] === 'pending'): ?>
                                <button class="btn btn-sm btn-secondary" onclick="copyToClipboard('<?= PUBLIC_URL ?>/pay.php?invoice=<?= $link['invoice_number'] ?>')">
                                    Copy
                                </button>
                                <?php else: ?>
                                <span style="color: var(--gray-400);">-</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- QR Modal -->
<div class="qr-modal" id="qr-modal" onclick="if(event.target === this) this.classList.remove('active')">
    <div class="qr-modal-content">
        <h3 style="margin: 0 0 0.5rem 0;">QR Code Payment</h3>
        <p style="color: var(--gray-500); font-size: 0.9rem; margin-bottom: 1rem;">Scan untuk membayar</p>
        <div id="qr-code-container" class="qr-code-img"></div>
        <button class="btn btn-secondary" style="margin-top: 1rem;" onclick="document.getElementById('qr-modal').classList.remove('active')">Tutup</button>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/qrcode@1.5.3/build/qrcode.min.js"></script>
<script>
// Amount formatting
const amountInput = document.getElementById('amount-input');
const amountDisplay = document.getElementById('amount-display');

amountInput?.addEventListener('input', function() {
    let value = this.value.replace(/[^0-9]/g, '');
    if (value) {
        this.value = new Intl.NumberFormat('id-ID').format(value);
        amountDisplay.textContent = 'Rp ' + new Intl.NumberFormat('id-ID').format(value);
    } else {
        amountDisplay.textContent = 'Rp 0';
    }
});

// Copy link function
function copyLink() {
    const link = document.getElementById('generated-link')?.textContent;
    if (link) {
        copyToClipboard(link);
    }
}

function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        alert('Link berhasil disalin!');
    }).catch(() => {
        // Fallback
        const textarea = document.createElement('textarea');
        textarea.value = text;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        alert('Link berhasil disalin!');
    });
}

// Show QR Code
function showQR() {
    const link = document.getElementById('generated-link')?.textContent;
    if (!link) return;

    const container = document.getElementById('qr-code-container');
    container.innerHTML = '';

    QRCode.toCanvas(link, { width: 200, margin: 2 }, function(error, canvas) {
        if (!error) {
            container.appendChild(canvas);
            document.getElementById('qr-modal').classList.add('active');
        }
    });
}
</script>

<?php include __DIR__ . '/layout_footer.php'; ?>

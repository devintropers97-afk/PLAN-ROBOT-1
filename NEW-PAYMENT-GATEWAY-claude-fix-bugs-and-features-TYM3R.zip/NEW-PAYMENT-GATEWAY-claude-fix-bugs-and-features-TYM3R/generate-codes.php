<?php
/**
 * NEO PGA - Generate Payment Codes
 * 
 * Script untuk generate payment codes untuk semua merchant
 * Jalankan sekali setelah setup database
 * 
 * Usage:
 * - Via browser: https://domain.com/generate-codes.php?key=YOUR_SECRET_KEY
 * - Via CLI: php generate-codes.php
 */

// Security key untuk akses via browser
// PENTING: Ganti key ini dengan string random yang unik!
$securityKey = defined('CRON_SECRET_KEY') ? CRON_SECRET_KEY : 'GANTI_DENGAN_KEY_RAHASIA_ANDA';

// Check access
if (php_sapi_name() !== 'cli') {
    if (!isset($_GET['key']) || $_GET['key'] !== $securityKey) {
        http_response_code(403);
        die('Access denied. Use ?key=YOUR_SECRET_KEY');
    }
    header('Content-Type: text/plain; charset=utf-8');
}

require_once __DIR__ . '/includes/init.php';

$db = Database::getInstance();

echo "===========================================\n";
echo "  NEO PGA - Payment Codes Generator\n";
echo "===========================================\n\n";

// Get all merchants
$merchants = $db->fetchAll("SELECT id, business_name, merchant_code FROM merchants");

if (empty($merchants)) {
    echo "❌ Tidak ada merchant ditemukan!\n";
    exit;
}

echo "Ditemukan " . count($merchants) . " merchant\n\n";

$codeMin = defined('UNIQUE_CODE_MIN') ? UNIQUE_CODE_MIN : 1;
$codeMax = defined('UNIQUE_CODE_MAX') ? UNIQUE_CODE_MAX : 999;
$totalCodes = $codeMax - $codeMin + 1;

foreach ($merchants as $merchant) {
    echo "-------------------------------------------\n";
    echo "Merchant: {$merchant['business_name']} (#{$merchant['id']})\n";
    
    // Check existing codes
    $existingCount = $db->fetch(
        "SELECT COUNT(*) as c FROM payment_codes WHERE merchant_id = ?",
        [$merchant['id']]
    )['c'] ?? 0;
    
    if ($existingCount >= $totalCodes) {
        echo "  ✅ Sudah ada {$existingCount} kode (lengkap)\n";
        continue;
    }
    
    echo "  Existing: {$existingCount} kode\n";
    echo "  Generating codes {$codeMin} - {$codeMax}...\n";
    
    $generated = 0;
    $skipped = 0;
    
    for ($code = $codeMin; $code <= $codeMax; $code++) {
        // Check if exists
        $exists = $db->fetch(
            "SELECT id FROM payment_codes WHERE merchant_id = ? AND code = ?",
            [$merchant['id'], $code]
        );
        
        if ($exists) {
            $skipped++;
            continue;
        }
        
        // Insert new code
        $db->query(
            "INSERT INTO payment_codes (merchant_id, code, status, created_at) VALUES (?, ?, 'available', NOW())",
            [$merchant['id'], $code]
        );
        $generated++;
    }
    
    echo "  ✅ Generated: {$generated} | Skipped: {$skipped}\n";
}

echo "\n===========================================\n";
echo "  SELESAI!\n";
echo "===========================================\n\n";

// Show summary
echo "SUMMARY:\n";
foreach ($merchants as $merchant) {
    $stats = $db->fetch(
        "SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN status = 'available' THEN 1 ELSE 0 END) as available,
            SUM(CASE WHEN status = 'reserved' THEN 1 ELSE 0 END) as reserved,
            SUM(CASE WHEN status = 'used' THEN 1 ELSE 0 END) as used
         FROM payment_codes WHERE merchant_id = ?",
        [$merchant['id']]
    );
    
    echo "  - {$merchant['business_name']}: {$stats['total']} total ({$stats['available']} available, {$stats['reserved']} reserved, {$stats['used']} used)\n";
}

echo "\n✅ Payment codes siap digunakan!\n";

<?php
/**
 * NEO PGA Rate Limiter
 *
 * Simple file-based rate limiter for API endpoints
 * Can be upgraded to Redis/Memcached for production at scale
 */
class RateLimiter
{
    private $storageDir;
    private $limit;
    private $window;

    /**
     * @param int $limit Max requests per window
     * @param int $window Time window in seconds
     */
    public function __construct(int $limit = 100, int $window = 60)
    {
        $this->limit = $limit;
        $this->window = $window;
        $this->storageDir = ROOT_PATH . '/logs/rate_limit';

        if (!is_dir($this->storageDir)) {
            @mkdir($this->storageDir, 0755, true);
        }
    }

    /**
     * Check if request is allowed
     *
     * @param string $identifier API key, IP, or user ID
     * @return array ['allowed' => bool, 'remaining' => int, 'reset' => int]
     */
    public function check(string $identifier): array
    {
        $key = $this->getKey($identifier);
        $file = $this->storageDir . '/' . $key . '.json';
        $now = time();

        // Get current data
        $data = $this->getData($file);

        // Check if window has expired
        if ($data['window_start'] + $this->window < $now) {
            // New window
            $data = [
                'count' => 0,
                'window_start' => $now
            ];
        }

        // Calculate remaining
        $remaining = max(0, $this->limit - $data['count']);
        $reset = $data['window_start'] + $this->window;

        // Check if allowed
        $allowed = $data['count'] < $this->limit;

        if ($allowed) {
            // Increment counter
            $data['count']++;
            $this->saveData($file, $data);
        }

        return [
            'allowed' => $allowed,
            'remaining' => $remaining - ($allowed ? 1 : 0),
            'reset' => $reset,
            'limit' => $this->limit
        ];
    }

    /**
     * Set rate limit response headers
     */
    public function setHeaders(array $result): void
    {
        header('X-RateLimit-Limit: ' . $result['limit']);
        header('X-RateLimit-Remaining: ' . $result['remaining']);
        header('X-RateLimit-Reset: ' . $result['reset']);
    }

    /**
     * Handle rate limit exceeded
     */
    public function exceeded(array $result): void
    {
        $this->setHeaders($result);
        http_response_code(429);
        header('Retry-After: ' . ($result['reset'] - time()));
        echo json_encode([
            'success' => false,
            'error' => 'Rate limit exceeded',
            'message' => 'Too many requests. Please try again later.',
            'retry_after' => $result['reset'] - time()
        ]);
        exit;
    }

    private function getKey(string $identifier): string
    {
        return md5($identifier);
    }

    private function getData(string $file): array
    {
        if (!file_exists($file)) {
            return [
                'count' => 0,
                'window_start' => time()
            ];
        }

        $content = @file_get_contents($file);
        $data = json_decode($content, true);

        if (!$data || !isset($data['count'])) {
            return [
                'count' => 0,
                'window_start' => time()
            ];
        }

        return $data;
    }

    private function saveData(string $file, array $data): void
    {
        @file_put_contents($file, json_encode($data), LOCK_EX);
    }

    /**
     * Cleanup old rate limit files
     */
    public static function cleanup(): void
    {
        $dir = ROOT_PATH . '/logs/rate_limit';
        if (!is_dir($dir)) return;

        $files = glob($dir . '/*.json');
        $expiry = time() - 3600; // 1 hour

        foreach ($files as $file) {
            if (filemtime($file) < $expiry) {
                @unlink($file);
            }
        }
    }
}

/**
 * Quick rate limit check function
 *
 * @param string $identifier
 * @param int $limit
 * @param int $window
 * @return bool Returns false if rate limited
 */
function checkRateLimit(string $identifier, int $limit = 100, int $window = 60): bool
{
    $limiter = new RateLimiter($limit, $window);
    $result = $limiter->check($identifier);

    $limiter->setHeaders($result);

    if (!$result['allowed']) {
        $limiter->exceeded($result);
        return false; // Never reached, but for clarity
    }

    return true;
}

/**
 * IP-based rate limiting for public endpoints
 */
function checkIpRateLimit(int $limit = 60, int $window = 60): bool
{
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['HTTP_X_REAL_IP'] ?? $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    // Get first IP if multiple
    $ip = explode(',', $ip)[0];
    $ip = trim($ip);

    return checkRateLimit('ip:' . $ip, $limit, $window);
}

/**
 * API key based rate limiting
 */
function checkApiKeyRateLimit(string $apiKey, int $limit = 100, int $window = 60): bool
{
    return checkRateLimit('api:' . $apiKey, $limit, $window);
}

<?php
/**
 * NEO PGA - Landing Page
 * Payment Gateway Termudah di Indonesia
 * by SITUNEO
 */

// Load SEO helper
require_once __DIR__ . '/includes/seo.php';

// FAQ data untuk Schema
$faqs = [
    ['question' => 'Apa itu NEO PGA?', 'answer' => 'NEO PGA adalah payment gateway Indonesia yang memungkinkan UMKM menerima pembayaran online via QRIS dan Bank Transfer dengan fee terendah 15% dan verifikasi otomatis.'],
    ['question' => 'Berapa fee transaksi NEO PGA?', 'answer' => 'Fee transaksi NEO PGA hanya 15% all-in, sudah termasuk semua biaya tanpa biaya tersembunyi.'],
    ['question' => 'Apakah perlu verifikasi dokumen untuk daftar?', 'answer' => 'Tidak perlu! Daftar di NEO PGA langsung aktif tanpa verifikasi dokumen yang ribet.'],
    ['question' => 'Metode pembayaran apa saja yang didukung?', 'answer' => 'NEO PGA mendukung pembayaran via QRIS (semua e-wallet dan mobile banking) serta Bank Transfer dengan kode unik otomatis.'],
    ['question' => 'Apakah ada biaya bulanan atau setup?', 'answer' => 'Tidak ada biaya bulanan atau setup. Anda hanya membayar fee per transaksi yang berhasil.'],
    ['question' => 'Bagaimana proses pencairan dana?', 'answer' => 'Dana bisa dicairkan kapan saja ke rekening bank Anda dengan proses yang cepat dan mudah.']
];
?>
<!DOCTYPE html>
<html lang="id" prefix="og: https://ogp.me/ns#">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">

    <!-- Primary Meta Tags -->
    <title>NEO PGA - Payment Gateway Termudah untuk UMKM Indonesia | Fee 15%</title>
    <meta name="title" content="NEO PGA - Payment Gateway Termudah untuk UMKM Indonesia | Fee 15%">
    <meta name="description" content="Payment Gateway Indonesia #1 untuk UMKM. Fee hanya 15%, daftar langsung aktif, terima pembayaran via QRIS & Bank Transfer. Verifikasi otomatis, tanpa coding, gratis setup!">
    <meta name="keywords" content="payment gateway indonesia, payment gateway umkm, payment gateway murah, qris payment gateway, terima pembayaran online, gateway pembayaran indonesia, integrasi payment gateway, payment gateway terbaik, payment gateway gratis, fee payment gateway rendah, payment gateway tanpa ribet, verifikasi pembayaran otomatis, payment gateway untuk toko online, payment gateway ecommerce indonesia">
    <meta name="author" content="NEO PGA Team">
    <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1">
    <meta name="googlebot" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1">
    <meta name="bingbot" content="index, follow">
    <link rel="canonical" href="https://neopga.com/">

    <!-- Favicon & Icons -->
    <link rel="icon" type="image/svg+xml" href="assets/images/favicon.svg">
    <link rel="apple-touch-icon" href="assets/images/logo-icon.svg">
    <link rel="manifest" href="manifest.json">
    <meta name="theme-color" content="#0D9488">
    <meta name="msapplication-TileColor" content="#0D9488">

    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://neopga.com/">
    <meta property="og:title" content="NEO PGA - Payment Gateway Termudah untuk UMKM Indonesia">
    <meta property="og:description" content="Payment Gateway Indonesia #1 untuk UMKM. Fee hanya 15%, daftar langsung aktif, terima pembayaran via QRIS & Bank Transfer. Verifikasi otomatis!">
    <meta property="og:image" content="https://neopga.com/assets/images/og-image.png">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="630">
    <meta property="og:image:alt" content="NEO PGA Payment Gateway Indonesia">
    <meta property="og:site_name" content="NEO PGA">
    <meta property="og:locale" content="id_ID">

    <!-- Twitter -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:url" content="https://neopga.com/">
    <meta name="twitter:title" content="NEO PGA - Payment Gateway Termudah untuk UMKM Indonesia">
    <meta name="twitter:description" content="Payment Gateway Indonesia #1 untuk UMKM. Fee hanya 15%, daftar langsung aktif, terima pembayaran via QRIS & Bank Transfer.">
    <meta name="twitter:image" content="https://neopga.com/assets/images/og-image.png">
    <meta name="twitter:site" content="@neopga">
    <meta name="twitter:creator" content="@neopga">

    <!-- Additional SEO Meta -->
    <meta name="geo.region" content="ID">
    <meta name="geo.country" content="Indonesia">
    <meta name="language" content="Indonesian">
    <meta name="distribution" content="global">
    <meta name="rating" content="general">
    <meta name="revisit-after" content="3 days">
    <meta name="coverage" content="Indonesia">
    <meta name="target" content="UMKM, Bisnis Online, Toko Online, E-commerce">

    <!-- Mobile Web App -->
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">
    <meta name="apple-mobile-web-app-title" content="NEO PGA">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="application-name" content="NEO PGA">
    <meta name="format-detection" content="telephone=no">

    <!-- Structured Data / JSON-LD -->
    <?= generateOrganizationSchema() ?>
    <?= generateWebsiteSchema() ?>
    <?= generateSoftwareSchema() ?>
    <?= generateLocalBusinessSchema() ?>
    <?= generateHowToSchema() ?>
    <?= generateFAQSchema($faqs) ?>

    <!-- Preconnect for Performance -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="dns-prefetch" href="https://fonts.googleapis.com">
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">

    <style>
        :root {
            --primary-50: #ecfdf5;
            --primary-100: #d1fae5;
            --primary-200: #a7f3d0;
            --primary-300: #6ee7b7;
            --primary-400: #34d399;
            --primary-500: #10b981;
            --primary-600: #059669;
            --primary-700: #047857;
            --primary-800: #065f46;
            --primary-900: #064e3b;

            --gray-50: #f9fafb;
            --gray-100: #f3f4f6;
            --gray-200: #e5e7eb;
            --gray-300: #d1d5db;
            --gray-400: #9ca3af;
            --gray-500: #6b7280;
            --gray-600: #4b5563;
            --gray-700: #374151;
            --gray-800: #1f2937;
            --gray-900: #111827;
            --gray-950: #030712;

            --accent-blue: #3b82f6;
            --accent-purple: #8b5cf6;
            --accent-pink: #ec4899;
            --accent-orange: #f97316;

            --success: #22c55e;
            --warning: #eab308;
            --danger: #ef4444;

            --radius-sm: 8px;
            --radius-md: 12px;
            --radius-lg: 16px;
            --radius-xl: 24px;
            --radius-2xl: 32px;
            --radius-full: 9999px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html {
            scroll-behavior: smooth;
            scroll-padding-top: 80px;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            color: var(--gray-900);
            line-height: 1.6;
            background: #fff;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            overflow-x: hidden;
        }

        .container {
            width: 100%;
            max-width: 1280px;
            margin: 0 auto;
            padding: 0 24px;
        }

        img { max-width: 100%; height: auto; }
        a { text-decoration: none; color: inherit; transition: color 0.2s; }

        /* Typography */
        h1, h2, h3, h4, h5, h6 {
            font-weight: 700;
            line-height: 1.2;
            color: var(--gray-900);
            letter-spacing: -0.02em;
        }

        h1 { font-size: clamp(2.25rem, 5vw, 4rem); font-weight: 800; }
        h2 { font-size: clamp(1.75rem, 4vw, 3rem); }
        h3 { font-size: clamp(1.25rem, 2vw, 1.5rem); }

        p { color: var(--gray-600); }

        /* Buttons */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            padding: 16px 32px;
            font-size: 0.9375rem;
            font-weight: 600;
            border-radius: var(--radius-full);
            border: none;
            cursor: pointer;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            font-family: inherit;
            white-space: nowrap;
            position: relative;
            overflow: hidden;
        }

        .btn::before {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(180deg, rgba(255,255,255,0.2) 0%, transparent 50%);
            opacity: 0;
            transition: opacity 0.3s;
        }

        .btn:hover::before { opacity: 1; }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary-500) 0%, var(--primary-600) 100%);
            color: #fff;
            box-shadow:
                0 1px 2px rgba(0,0,0,0.05),
                0 4px 12px rgba(16, 185, 129, 0.25),
                inset 0 1px 0 rgba(255,255,255,0.2);
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow:
                0 4px 8px rgba(0,0,0,0.1),
                0 8px 24px rgba(16, 185, 129, 0.35),
                inset 0 1px 0 rgba(255,255,255,0.2);
        }

        .btn-primary:active {
            transform: translateY(0);
        }

        .btn-secondary {
            background: rgba(255,255,255,0.08);
            color: #fff;
            border: 1px solid rgba(255,255,255,0.15);
            backdrop-filter: blur(12px);
        }

        .btn-secondary:hover {
            background: rgba(255,255,255,0.15);
            border-color: rgba(255,255,255,0.25);
        }

        .btn-outline {
            background: transparent;
            color: var(--primary-600);
            border: 2px solid var(--primary-200);
        }

        .btn-outline:hover {
            background: var(--primary-50);
            border-color: var(--primary-300);
        }

        .btn-ghost {
            background: transparent;
            color: var(--gray-700);
        }

        .btn-ghost:hover {
            background: var(--gray-100);
        }

        .btn-lg { padding: 18px 40px; font-size: 1rem; }
        .btn-sm { padding: 12px 24px; font-size: 0.875rem; }
        .btn-icon { padding: 12px; }

        /* Header */
        .header {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            padding: 16px 0;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .header.scrolled {
            padding: 12px 0;
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(20px) saturate(180%);
            border-bottom: 1px solid rgba(0,0,0,0.05);
        }

        .header-inner {
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
            z-index: 10;
        }

        .logo-mark {
            width: 44px;
            height: 44px;
            background: linear-gradient(135deg, var(--primary-500) 0%, var(--primary-600) 100%);
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
            position: relative;
        }

        .logo-mark::after {
            content: '';
            position: absolute;
            inset: 0;
            border-radius: inherit;
            background: linear-gradient(180deg, rgba(255,255,255,0.3) 0%, transparent 50%);
        }

        .logo-mark svg {
            width: 24px;
            height: 24px;
            fill: #fff;
            position: relative;
            z-index: 1;
        }

        .logo-text {
            font-size: 1.375rem;
            font-weight: 800;
            color: #fff;
            letter-spacing: -0.02em;
        }

        .header.scrolled .logo-text { color: var(--gray-900); }

        .logo-text span {
            background: linear-gradient(135deg, var(--primary-400) 0%, var(--primary-500) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .nav-desktop {
            display: none;
            align-items: center;
            gap: 8px;
        }

        .nav-link {
            padding: 10px 18px;
            color: rgba(255,255,255,0.75);
            font-size: 0.9375rem;
            font-weight: 500;
            border-radius: var(--radius-full);
            transition: all 0.2s;
        }

        .header.scrolled .nav-link { color: var(--gray-600); }

        .nav-link:hover {
            color: #fff;
            background: rgba(255,255,255,0.1);
        }

        .header.scrolled .nav-link:hover {
            color: var(--gray-900);
            background: var(--gray-100);
        }

        .nav-cta {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-left: 32px;
        }

        .nav-cta .btn-ghost {
            color: rgba(255,255,255,0.9);
        }

        .header.scrolled .nav-cta .btn-ghost {
            color: var(--gray-700);
        }

        /* DEMO Badge in Navbar */
        .nav-demo {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: linear-gradient(135deg, #f59e0b 0%, #ef4444 100%);
            color: #fff !important;
            font-weight: 700;
            padding: 8px 16px !important;
            border-radius: var(--radius-full);
            font-size: 0.8rem;
            letter-spacing: 0.05em;
            text-transform: uppercase;
            box-shadow: 0 4px 15px rgba(239, 68, 68, 0.4);
            animation: demoGlow 2s ease-in-out infinite;
        }

        .nav-demo:hover {
            background: linear-gradient(135deg, #fbbf24 0%, #f87171 100%);
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(239, 68, 68, 0.5);
        }

        .header.scrolled .nav-demo {
            color: #fff !important;
        }

        .demo-pulse {
            width: 8px;
            height: 8px;
            background: #fff;
            border-radius: 50%;
            animation: pulse 1.5s ease-in-out infinite;
        }

        @keyframes demoGlow {
            0%, 100% { box-shadow: 0 4px 15px rgba(239, 68, 68, 0.4); }
            50% { box-shadow: 0 4px 25px rgba(239, 68, 68, 0.6); }
        }

        @keyframes pulse {
            0%, 100% { opacity: 1; transform: scale(1); }
            50% { opacity: 0.5; transform: scale(0.8); }
        }

        .mobile-menu-btn {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 44px;
            height: 44px;
            background: rgba(255,255,255,0.1);
            border: 1px solid rgba(255,255,255,0.15);
            border-radius: var(--radius-md);
            cursor: pointer;
            z-index: 10;
            transition: all 0.2s;
        }

        .header.scrolled .mobile-menu-btn {
            background: var(--gray-100);
            border-color: var(--gray-200);
        }

        .mobile-menu-btn svg {
            width: 22px;
            height: 22px;
            stroke: #fff;
            transition: stroke 0.2s;
        }

        .header.scrolled .mobile-menu-btn svg { stroke: var(--gray-700); }

        /* Mobile Menu */
        .mobile-menu {
            position: fixed;
            inset: 0;
            background: var(--gray-950);
            z-index: 999;
            padding: 100px 24px 40px;
            display: flex;
            flex-direction: column;
            opacity: 0;
            visibility: hidden;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .mobile-menu.active {
            opacity: 1;
            visibility: visible;
        }

        .mobile-menu-close {
            position: absolute;
            top: 16px;
            right: 24px;
            width: 44px;
            height: 44px;
            background: rgba(255,255,255,0.1);
            border: none;
            border-radius: var(--radius-md);
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .mobile-menu-close svg {
            width: 22px;
            height: 22px;
            stroke: #fff;
        }

        .mobile-menu-links {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .mobile-menu-links a {
            padding: 16px 0;
            color: rgba(255,255,255,0.9);
            font-size: 1.25rem;
            font-weight: 600;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            transition: color 0.2s;
        }

        .mobile-menu-links a:hover {
            color: var(--primary-400);
        }

        .mobile-menu-cta {
            margin-top: auto;
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        @media (min-width: 1024px) {
            .nav-desktop { display: flex; }
            .mobile-menu-btn { display: none; }
        }

        /* Hero */
        .hero {
            position: relative;
            min-height: 100vh;
            display: flex;
            align-items: center;
            background: linear-gradient(135deg, var(--gray-950) 0%, var(--gray-900) 50%, #0c1a1a 100%);
            overflow: hidden;
            padding: 120px 0 80px;
        }

        .hero-bg {
            position: absolute;
            inset: 0;
            overflow: hidden;
        }

        .hero-glow {
            position: absolute;
            width: 800px;
            height: 800px;
            border-radius: 50%;
            filter: blur(120px);
            opacity: 0.4;
        }

        .hero-glow-1 {
            top: -20%;
            right: -10%;
            background: var(--primary-600);
        }

        .hero-glow-2 {
            bottom: -30%;
            left: -10%;
            background: var(--accent-blue);
            opacity: 0.2;
        }

        .hero-grid {
            position: absolute;
            inset: 0;
            background-image:
                linear-gradient(rgba(255,255,255,0.03) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255,255,255,0.03) 1px, transparent 1px);
            background-size: 64px 64px;
            mask-image: radial-gradient(ellipse at 50% 50%, black 20%, transparent 70%);
        }

        .hero-content {
            position: relative;
            z-index: 2;
            max-width: 900px;
            margin: 0 auto;
            text-align: center;
        }

        .hero-eyebrow {
            display: inline-flex;
            align-items: center;
            gap: 12px;
            padding: 10px 20px 10px 14px;
            background: rgba(255,255,255,0.06);
            border: 1px solid rgba(255,255,255,0.1);
            border-radius: var(--radius-full);
            margin-bottom: 32px;
            backdrop-filter: blur(12px);
        }

        .hero-eyebrow-badge {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 28px;
            height: 28px;
            background: linear-gradient(135deg, var(--primary-500), var(--primary-600));
            border-radius: 50%;
        }

        .hero-eyebrow-badge svg {
            width: 14px;
            height: 14px;
            fill: #fff;
        }

        .hero-eyebrow-text {
            font-size: 0.875rem;
            font-weight: 600;
            color: rgba(255,255,255,0.9);
        }

        .hero-title {
            font-size: clamp(2.5rem, 6vw, 4.5rem);
            font-weight: 800;
            line-height: 1.05;
            color: #fff;
            margin-bottom: 24px;
            letter-spacing: -0.03em;
        }

        .hero-title-gradient {
            background: linear-gradient(135deg, var(--primary-300) 0%, var(--primary-400) 50%, var(--accent-blue) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .hero-desc {
            font-size: clamp(1rem, 2vw, 1.25rem);
            color: rgba(255,255,255,0.6);
            max-width: 640px;
            margin: 0 auto 40px;
            line-height: 1.7;
        }

        .hero-cta {
            display: flex;
            flex-direction: column;
            gap: 16px;
            margin-bottom: 64px;
        }

        .hero-stats {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 16px;
        }

        .hero-stat {
            display: flex;
            align-items: center;
            gap: 16px;
            padding: 20px 28px;
            background: rgba(255,255,255,0.04);
            border: 1px solid rgba(255,255,255,0.08);
            border-radius: var(--radius-xl);
            backdrop-filter: blur(12px);
            transition: all 0.3s;
        }

        .hero-stat:hover {
            background: rgba(255,255,255,0.08);
            border-color: rgba(255,255,255,0.15);
            transform: translateY(-4px);
        }

        .hero-stat-icon {
            width: 52px;
            height: 52px;
            background: linear-gradient(135deg, var(--primary-500) 0%, var(--primary-600) 100%);
            border-radius: var(--radius-lg);
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 16px rgba(16, 185, 129, 0.3);
        }

        .hero-stat-icon svg {
            width: 26px;
            height: 26px;
            stroke: #fff;
            fill: none;
        }

        .hero-stat-content { text-align: left; }

        .hero-stat-value {
            font-size: 1.75rem;
            font-weight: 800;
            color: #fff;
            line-height: 1;
            letter-spacing: -0.02em;
        }

        .hero-stat-label {
            font-size: 0.875rem;
            color: rgba(255,255,255,0.5);
            margin-top: 4px;
            font-weight: 500;
        }

        @media (min-width: 768px) {
            .hero { padding: 0; }
            .hero-cta { flex-direction: row; justify-content: center; }
        }

        /* Trust Bar */
        .trust-bar {
            padding: 32px 0;
            background: #fff;
            border-bottom: 1px solid var(--gray-100);
        }

        .trust-bar-inner {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 24px;
        }

        .trust-bar-label {
            font-size: 0.75rem;
            font-weight: 600;
            color: var(--gray-400);
            text-transform: uppercase;
            letter-spacing: 0.1em;
        }

        .trust-bar-items {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 40px;
            align-items: center;
        }

        .trust-bar-item {
            display: flex;
            align-items: center;
            gap: 12px;
            color: var(--gray-500);
            font-weight: 600;
            font-size: 0.9375rem;
        }

        .trust-bar-item svg {
            width: 28px;
            height: 28px;
            stroke: var(--primary-500);
        }

        /* Section */
        .section {
            padding: 80px 0;
        }

        @media (min-width: 768px) {
            .section { padding: 120px 0; }
        }

        .section-header {
            text-align: center;
            max-width: 700px;
            margin: 0 auto 64px;
        }

        .section-eyebrow {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 16px;
            background: var(--primary-50);
            color: var(--primary-600);
            font-size: 0.8125rem;
            font-weight: 700;
            border-radius: var(--radius-full);
            margin-bottom: 20px;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        .section-title {
            margin-bottom: 16px;
        }

        .section-desc {
            font-size: 1.125rem;
            color: var(--gray-500);
            line-height: 1.7;
        }

        /* Features */
        .features {
            background: var(--gray-50);
        }

        .features-grid {
            display: grid;
            gap: 24px;
        }

        .feature-card {
            background: #fff;
            border-radius: var(--radius-2xl);
            padding: 36px;
            border: 1px solid var(--gray-200);
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
        }

        .feature-card::before {
            content: '';
            position: absolute;
            inset: -1px;
            border-radius: inherit;
            background: linear-gradient(135deg, var(--primary-300), var(--accent-blue));
            opacity: 0;
            transition: opacity 0.4s;
            z-index: -1;
        }

        .feature-card:hover {
            transform: translateY(-8px);
            border-color: transparent;
            box-shadow:
                0 4px 6px rgba(0,0,0,0.02),
                0 12px 24px rgba(0,0,0,0.04),
                0 24px 48px rgba(0,0,0,0.06);
        }

        .feature-card:hover::before {
            opacity: 1;
        }

        .feature-icon {
            width: 64px;
            height: 64px;
            border-radius: var(--radius-lg);
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 24px;
            font-size: 1.75rem;
            position: relative;
        }

        .feature-icon::after {
            content: '';
            position: absolute;
            inset: 0;
            border-radius: inherit;
            background: linear-gradient(180deg, rgba(255,255,255,0.8) 0%, rgba(255,255,255,0) 100%);
        }

        .feature-icon.green { background: linear-gradient(135deg, var(--primary-100), var(--primary-200)); }
        .feature-icon.blue { background: linear-gradient(135deg, #dbeafe, #bfdbfe); }
        .feature-icon.amber { background: linear-gradient(135deg, #fef3c7, #fde68a); }
        .feature-icon.purple { background: linear-gradient(135deg, #f3e8ff, #e9d5ff); }
        .feature-icon.pink { background: linear-gradient(135deg, #fce7f3, #fbcfe8); }
        .feature-icon.orange { background: linear-gradient(135deg, #ffedd5, #fed7aa); }

        .feature-title {
            font-size: 1.25rem;
            font-weight: 700;
            margin-bottom: 12px;
            color: var(--gray-900);
        }

        .feature-desc {
            color: var(--gray-500);
            font-size: 0.9375rem;
            line-height: 1.7;
        }

        @media (min-width: 768px) {
            .features-grid { grid-template-columns: repeat(2, 1fr); gap: 32px; }
        }

        @media (min-width: 1024px) {
            .features-grid { grid-template-columns: repeat(3, 1fr); }
        }

        /* How It Works */
        .how-it-works {
            background: #fff;
        }

        .steps-wrapper {
            max-width: 800px;
            margin: 0 auto;
        }

        .step {
            display: flex;
            gap: 32px;
            padding: 32px 0;
            position: relative;
        }

        .step:not(:last-child)::after {
            content: '';
            position: absolute;
            left: 31px;
            top: 96px;
            bottom: 0;
            width: 2px;
            background: linear-gradient(180deg, var(--primary-300), var(--primary-100));
        }

        .step-number {
            width: 64px;
            height: 64px;
            min-width: 64px;
            background: linear-gradient(135deg, var(--primary-500), var(--primary-600));
            color: #fff;
            border-radius: var(--radius-xl);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            font-weight: 800;
            box-shadow: 0 8px 24px rgba(16, 185, 129, 0.3);
            position: relative;
            z-index: 1;
        }

        .step-content {
            flex: 1;
            padding-top: 8px;
        }

        .step-title {
            font-size: 1.25rem;
            font-weight: 700;
            margin-bottom: 8px;
            color: var(--gray-900);
        }

        .step-desc {
            color: var(--gray-500);
            font-size: 1rem;
            line-height: 1.7;
        }

        /* Pricing */
        .pricing {
            background: linear-gradient(180deg, var(--gray-50) 0%, #fff 100%);
        }

        .pricing-grid {
            display: grid;
            gap: 24px;
            max-width: 1200px;
            margin: 0 auto;
        }

        .pricing-card {
            background: #fff;
            border-radius: var(--radius-2xl);
            padding: 40px;
            border: 2px solid var(--gray-200);
            position: relative;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .pricing-card:hover {
            border-color: var(--gray-300);
        }

        .pricing-card.featured {
            border-color: var(--primary-400);
            box-shadow:
                0 0 0 4px var(--primary-100),
                0 25px 50px -12px rgba(16, 185, 129, 0.25);
        }

        .pricing-badge {
            position: absolute;
            top: -16px;
            left: 50%;
            transform: translateX(-50%);
            background: linear-gradient(135deg, var(--primary-500), var(--primary-600));
            color: #fff;
            padding: 10px 28px;
            border-radius: var(--radius-full);
            font-size: 0.8125rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            box-shadow: 0 4px 16px rgba(16, 185, 129, 0.4);
        }

        .pricing-header {
            text-align: center;
            margin-bottom: 32px;
            padding-bottom: 32px;
            border-bottom: 1px solid var(--gray-200);
        }

        .pricing-icon {
            font-size: 3.5rem;
            margin-bottom: 16px;
            display: block;
        }

        .pricing-name {
            font-size: 0.9375rem;
            font-weight: 700;
            color: var(--gray-500);
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-bottom: 12px;
        }

        .pricing-price {
            font-size: 3rem;
            font-weight: 800;
            color: var(--gray-900);
            line-height: 1;
            letter-spacing: -0.03em;
        }

        .pricing-period {
            font-size: 0.9375rem;
            color: var(--gray-500);
            margin-top: 8px;
        }

        .pricing-desc {
            background: var(--gray-50);
            border-radius: var(--radius-xl);
            padding: 20px;
            margin-bottom: 32px;
            font-size: 0.9375rem;
            color: var(--gray-600);
            line-height: 1.7;
        }

        .pricing-desc strong {
            color: var(--gray-900);
            font-weight: 600;
        }

        .pricing-features {
            list-style: none;
            margin-bottom: 32px;
        }

        .pricing-features li {
            display: flex;
            align-items: flex-start;
            gap: 14px;
            padding: 12px 0;
            font-size: 0.9375rem;
            color: var(--gray-700);
        }

        .pricing-features li svg {
            width: 22px;
            height: 22px;
            stroke: var(--primary-500);
            flex-shrink: 0;
            margin-top: 1px;
        }

        @media (min-width: 768px) {
            .pricing-grid { grid-template-columns: repeat(3, 1fr); gap: 32px; }
            .pricing-card.featured { transform: scale(1.03); }
        }

        /* Demo */
        .demo {
            background: var(--gray-950);
            position: relative;
            overflow: hidden;
        }

        .demo::before {
            content: '';
            position: absolute;
            top: 0;
            right: 0;
            width: 600px;
            height: 600px;
            background: radial-gradient(circle, rgba(16, 185, 129, 0.15), transparent 70%);
        }

        .demo-content {
            position: relative;
            z-index: 1;
            text-align: center;
            max-width: 600px;
            margin: 0 auto;
        }

        .demo h2 {
            color: #fff;
            margin-bottom: 16px;
        }

        .demo p {
            color: rgba(255,255,255,0.6);
            font-size: 1.125rem;
            margin-bottom: 36px;
        }

        .demo-card {
            background: rgba(255,255,255,0.04);
            border: 1px solid rgba(255,255,255,0.08);
            border-radius: var(--radius-2xl);
            padding: 32px;
            margin-top: 48px;
            backdrop-filter: blur(12px);
        }

        .demo-card h3 {
            color: #fff;
            font-size: 1.25rem;
            margin-bottom: 12px;
        }

        .demo-card p {
            color: rgba(255,255,255,0.5);
            font-size: 0.9375rem;
            margin-bottom: 0;
        }

        /* FAQ */
        .faq {
            background: #fff;
        }

        .faq-grid {
            max-width: 800px;
            margin: 0 auto;
        }

        .faq-item {
            border-bottom: 1px solid var(--gray-200);
        }

        .faq-question {
            display: flex;
            align-items: center;
            gap: 20px;
            padding: 28px 0;
            cursor: pointer;
            transition: color 0.2s;
        }

        .faq-question:hover { color: var(--primary-600); }

        .faq-icon {
            width: 52px;
            height: 52px;
            background: var(--primary-50);
            border-radius: var(--radius-lg);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            flex-shrink: 0;
        }

        .faq-question h3 {
            flex: 1;
            font-size: 1.0625rem;
            font-weight: 600;
            color: inherit;
        }

        .faq-toggle {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            background: var(--gray-100);
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s;
            flex-shrink: 0;
        }

        .faq-item.active .faq-toggle {
            background: var(--primary-500);
            transform: rotate(45deg);
        }

        .faq-toggle svg {
            width: 18px;
            height: 18px;
            stroke: var(--gray-600);
            stroke-width: 2;
        }

        .faq-item.active .faq-toggle svg { stroke: #fff; }

        .faq-answer {
            display: none;
            padding: 0 0 28px 72px;
            color: var(--gray-600);
            font-size: 0.9375rem;
            line-height: 1.8;
        }

        .faq-item.active .faq-answer { display: block; }

        /* Policy */
        .policy {
            padding: 32px 0;
            background: linear-gradient(135deg, #fef9c3, #fef3c7);
            border-top: 3px solid var(--warning);
        }

        .policy-inner {
            display: flex;
            gap: 24px;
            align-items: flex-start;
            max-width: 900px;
            margin: 0 auto;
        }

        .policy-icon {
            width: 56px;
            height: 56px;
            min-width: 56px;
            background: #fff;
            border-radius: var(--radius-lg);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.75rem;
            box-shadow: 0 2px 8px rgba(0,0,0,0.06);
        }

        .policy-content h4 {
            font-size: 1.0625rem;
            color: #92400e;
            margin-bottom: 8px;
        }

        .policy-content p {
            color: #78350f;
            font-size: 0.9375rem;
            line-height: 1.7;
        }

        /* CTA */
        .cta {
            background: var(--gray-50);
            text-align: center;
        }

        .cta-inner {
            max-width: 640px;
            margin: 0 auto;
        }

        .cta h2 { margin-bottom: 16px; }

        .cta p {
            font-size: 1.125rem;
            margin-bottom: 36px;
        }

        .cta-buttons {
            display: flex;
            flex-direction: column;
            gap: 16px;
            justify-content: center;
        }

        @media (min-width: 640px) {
            .cta-buttons { flex-direction: row; }
        }

        /* Footer */
        .footer {
            background: var(--gray-950);
            color: #fff;
            padding: 80px 0 40px;
        }

        .footer-grid {
            display: grid;
            gap: 48px;
            margin-bottom: 48px;
        }

        .footer-brand .logo-text {
            color: #fff;
            margin-bottom: 16px;
        }

        .footer-brand p {
            color: var(--gray-400);
            font-size: 0.9375rem;
            line-height: 1.7;
            max-width: 280px;
        }

        .footer-title {
            font-size: 0.875rem;
            font-weight: 700;
            margin-bottom: 20px;
            color: #fff;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        .footer-links {
            list-style: none;
        }

        .footer-links li { margin-bottom: 12px; }

        .footer-links a {
            color: var(--gray-400);
            font-size: 0.9375rem;
            transition: color 0.2s;
        }

        .footer-links a:hover { color: var(--primary-400); }

        .footer-bottom {
            padding-top: 32px;
            border-top: 1px solid rgba(255,255,255,0.1);
            text-align: center;
            color: var(--gray-500);
            font-size: 0.875rem;
        }

        @media (min-width: 768px) {
            .footer-grid { grid-template-columns: 2fr 1fr 1fr 1fr; }
        }

        /* Anti-select */
        body {
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }

        input, textarea {
            -webkit-user-select: text;
            -moz-user-select: text;
            user-select: text;
        }

        /* Utility */
        .btn-block { width: 100%; }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="header" id="header">
        <div class="container">
            <div class="header-inner">
                <a href="/" class="logo">
                    <div class="logo-mark">
                        <svg viewBox="0 0 24 24" fill="none">
                            <path d="M4 20 C4 20, 7 15, 10 10 C11 8, 11.5 6, 12 4" stroke="#14B8A6" stroke-width="2.5" stroke-linecap="round"/>
                            <path d="M20 20 C20 20, 17 15, 14 10 C13 8, 12.5 6, 12 4" stroke="#0D9488" stroke-width="2.5" stroke-linecap="round"/>
                            <circle cx="12" cy="4" r="2.5" fill="#F59E0B"/>
                            <line x1="12" y1="7" x2="12" y2="18" stroke="#0D9488" stroke-width="2" stroke-linecap="round"/>
                        </svg>
                    </div>
                    <span class="logo-text">NEO <span>PGA</span></span>
                </a>

                <nav class="nav-desktop">
                    <a href="#fitur" class="nav-link">Fitur</a>
                    <a href="#cara-kerja" class="nav-link">Cara Kerja</a>
                    <a href="#harga" class="nav-link">Harga</a>
                    <a href="#faq" class="nav-link">FAQ</a>
                    <a href="demo/" class="nav-link nav-demo">
                        <span class="demo-pulse"></span>
                        DEMO
                    </a>
                    <div class="nav-cta">
                        <a href="merchant/login.php" class="btn btn-sm btn-ghost">Masuk</a>
                        <a href="merchant/register.php" class="btn btn-sm btn-primary">Daftar Gratis</a>
                    </div>
                </nav>

                <button class="mobile-menu-btn" onclick="openMobileMenu()">
                    <svg fill="none" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/>
                    </svg>
                </button>
            </div>
        </div>
    </header>

    <!-- Mobile Menu -->
    <div class="mobile-menu" id="mobileMenu">
        <button class="mobile-menu-close" onclick="closeMobileMenu()">
            <svg fill="none" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
            </svg>
        </button>
        <div class="mobile-menu-links">
            <a href="#fitur" onclick="closeMobileMenu()">Fitur</a>
            <a href="#cara-kerja" onclick="closeMobileMenu()">Cara Kerja</a>
            <a href="#harga" onclick="closeMobileMenu()">Harga</a>
            <a href="#faq" onclick="closeMobileMenu()">FAQ</a>
            <a href="demo/" style="color: #f59e0b; display: flex; align-items: center; gap: 10px;">
                <span style="width:10px;height:10px;background:#f59e0b;border-radius:50%;animation:pulse 1.5s infinite;"></span>
                LIHAT DEMO
            </a>
        </div>
        <div class="mobile-menu-cta">
            <a href="merchant/login.php" class="btn btn-secondary btn-block">Masuk</a>
            <a href="merchant/register.php" class="btn btn-primary btn-block">Daftar Gratis</a>
        </div>
    </div>

    <!-- Hero -->
    <section class="hero">
        <div class="hero-bg">
            <div class="hero-glow hero-glow-1"></div>
            <div class="hero-glow hero-glow-2"></div>
            <div class="hero-grid"></div>
        </div>

        <div class="container">
            <div class="hero-content">
                <div class="hero-eyebrow">
                    <span class="hero-eyebrow-badge">
                        <svg viewBox="0 0 24 24"><path d="M5 13l4 4L19 7"/></svg>
                    </span>
                    <span class="hero-eyebrow-text">Payment Gateway Terpercaya</span>
                </div>

                <h1 class="hero-title">
                    Terima Pembayaran<br>
                    <span class="hero-title-gradient">Langsung Aktif</span>
                </h1>

                <p class="hero-desc">
                    Daftar sekarang, langsung bisa terima pembayaran via QRIS dan Bank Transfer. Tanpa ribet verifikasi dokumen berminggu-minggu. Cocok untuk UMKM dan bisnis online.
                </p>

                <div class="hero-cta">
                    <a href="merchant/register.php" class="btn btn-primary btn-lg">
                        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
                        Mulai Gratis Sekarang
                    </a>
                    <a href="#demo" class="btn btn-secondary btn-lg">
                        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
                        Lihat Demo
                    </a>
                </div>

                <div class="hero-stats">
                    <div class="hero-stat">
                        <div class="hero-stat-icon">
                            <svg viewBox="0 0 24 24" stroke-width="2"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75"/></svg>
                        </div>
                        <div class="hero-stat-content">
                            <div class="hero-stat-value">500+</div>
                            <div class="hero-stat-label">Merchant Aktif</div>
                        </div>
                    </div>
                    <div class="hero-stat">
                        <div class="hero-stat-icon">
                            <svg viewBox="0 0 24 24" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
                        </div>
                        <div class="hero-stat-content">
                            <div class="hero-stat-value">5 Menit</div>
                            <div class="hero-stat-label">Setup Cepat</div>
                        </div>
                    </div>
                    <div class="hero-stat">
                        <div class="hero-stat-icon">
                            <svg viewBox="0 0 24 24" stroke-width="2"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><path d="M22 4L12 14.01l-3-3"/></svg>
                        </div>
                        <div class="hero-stat-content">
                            <div class="hero-stat-value">24/7</div>
                            <div class="hero-stat-label">Auto Verifikasi</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Trust Bar -->
    <section class="trust-bar">
        <div class="container">
            <div class="trust-bar-inner">
                <div class="trust-bar-label">Metode Pembayaran</div>
                <div class="trust-bar-items">
                    <div class="trust-bar-item">
                        <svg viewBox="0 0 24 24" fill="none" stroke-width="1.5"><rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20"/></svg>
                        QRIS
                    </div>
                    <div class="trust-bar-item">
                        <svg viewBox="0 0 24 24" fill="none" stroke-width="1.5"><rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20M6 15h4M14 15h4"/></svg>
                        Bank Transfer
                    </div>
                    <div class="trust-bar-item">
                        <svg viewBox="0 0 24 24" fill="none" stroke-width="1.5"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                        SSL Encrypted
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Features -->
    <section class="section features" id="fitur">
        <div class="container">
            <div class="section-header">
                <span class="section-eyebrow">Keunggulan</span>
                <h2 class="section-title">Kenapa Pilih NEO PGA?</h2>
                <p class="section-desc">Solusi payment gateway yang dirancang khusus untuk kemudahan UMKM dan bisnis online Indonesia</p>
            </div>

            <div class="features-grid">
                <div class="feature-card">
                    <div class="feature-icon green">&#9889;</div>
                    <h3 class="feature-title">Langsung Aktif</h3>
                    <p class="feature-desc">Daftar sekarang, langsung bisa terima pembayaran. Tidak perlu verifikasi dokumen berhari-hari seperti payment gateway lain.</p>
                </div>

                <div class="feature-card">
                    <div class="feature-icon blue">&#10004;</div>
                    <h3 class="feature-title">Verifikasi Otomatis</h3>
                    <p class="feature-desc">Pembayaran dari customer terverifikasi otomatis. Tidak perlu cek manual satu per satu, bisnis bisa jalan sendiri 24/7.</p>
                </div>

                <div class="feature-card">
                    <div class="feature-icon amber">&#128337;</div>
                    <h3 class="feature-title">Setup 5 Menit</h3>
                    <p class="feature-desc">Tutorial lengkap step-by-step disediakan. Atau pilih paket jasa setup, kami yang kerjakan semua sampai jalan.</p>
                </div>

                <div class="feature-card">
                    <div class="feature-icon orange">&#128176;</div>
                    <h3 class="feature-title">Fee Transparan 15%</h3>
                    <p class="feature-desc">Hanya 15% per transaksi sukses. Tidak ada biaya bulanan, tidak ada biaya setup, tidak ada biaya tersembunyi.</p>
                </div>

                <div class="feature-card">
                    <div class="feature-icon purple">&#128274;</div>
                    <h3 class="feature-title">Aman &amp; Terpercaya</h3>
                    <p class="feature-desc">Data terenkripsi standar industri. Signature verification untuk setiap transaksi. API key dapat diregenerasi kapan saja.</p>
                </div>

                <div class="feature-card">
                    <div class="feature-icon pink">&#128172;</div>
                    <h3 class="feature-title">Support WhatsApp</h3>
                    <p class="feature-desc">Ada kendala? Langsung chat WhatsApp, tidak perlu buka tiket atau tunggu email berhari-hari. Respon cepat dan ramah.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- How It Works -->
    <section class="section how-it-works" id="cara-kerja">
        <div class="container">
            <div class="section-header">
                <span class="section-eyebrow">Cara Kerja</span>
                <h2 class="section-title">Mulai dalam 4 Langkah</h2>
                <p class="section-desc">Terima pembayaran online dalam hitungan menit, bukan minggu</p>
            </div>

            <div class="steps-wrapper">
                <div class="step">
                    <div class="step-number">1</div>
                    <div class="step-content">
                        <h3 class="step-title">Daftar Akun Gratis</h3>
                        <p class="step-desc">Isi form pendaftaran dengan data bisnis Anda. Akun langsung aktif tanpa perlu verifikasi dokumen yang memakan waktu lama.</p>
                    </div>
                </div>

                <div class="step">
                    <div class="step-number">2</div>
                    <div class="step-content">
                        <h3 class="step-title">Setup Integrasi</h3>
                        <p class="step-desc">Copy API key dari dashboard, ikuti tutorial lengkap yang disediakan. Atau gunakan jasa setup dari kami, terima beres.</p>
                    </div>
                </div>

                <div class="step">
                    <div class="step-number">3</div>
                    <div class="step-content">
                        <h3 class="step-title">Customer Bayar</h3>
                        <p class="step-desc">Customer scan QRIS atau transfer bank. Pembayaran langsung terverifikasi otomatis oleh sistem, Anda tidak perlu cek manual.</p>
                    </div>
                </div>

                <div class="step">
                    <div class="step-number">4</div>
                    <div class="step-content">
                        <h3 class="step-title">Cairkan Dana</h3>
                        <p class="step-desc">Request pencairan kapan saja melalui dashboard. Dana langsung ditransfer ke rekening bank Anda dengan cepat.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Pricing -->
    <section class="section pricing" id="harga">
        <div class="container">
            <div class="section-header">
                <span class="section-eyebrow">Harga</span>
                <h2 class="section-title">Pilih Paket Anda</h2>
                <p class="section-desc">Mulai gratis, bayar hanya ketika ada transaksi sukses</p>
            </div>

            <div class="pricing-grid">
                <div class="pricing-card">
                    <div class="pricing-header">
                        <span class="pricing-icon">&#128230;</span>
                        <div class="pricing-name">Gratis</div>
                        <div class="pricing-price">Rp 0</div>
                        <div class="pricing-period">Setup Mandiri</div>
                    </div>

                    <div class="pricing-desc">
                        Cocok untuk yang sudah familiar dengan teknis website dan mau setup sendiri mengikuti tutorial.
                    </div>

                    <ul class="pricing-features">
                        <li>
                            <svg viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M5 13l4 4L19 7"/></svg>
                            Akses dashboard lengkap
                        </li>
                        <li>
                            <svg viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M5 13l4 4L19 7"/></svg>
                            QRIS + Bank Transfer
                        </li>
                        <li>
                            <svg viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M5 13l4 4L19 7"/></svg>
                            Verifikasi otomatis 24/7
                        </li>
                        <li>
                            <svg viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M5 13l4 4L19 7"/></svg>
                            Tutorial lengkap
                        </li>
                        <li>
                            <svg viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M5 13l4 4L19 7"/></svg>
                            <strong>Fee 15% per transaksi</strong>
                        </li>
                    </ul>

                    <a href="merchant/register.php" class="btn btn-outline btn-block">Daftar Gratis</a>
                </div>

                <div class="pricing-card featured">
                    <span class="pricing-badge">Rekomendasi</span>
                    <div class="pricing-header">
                        <span class="pricing-icon">&#128736;</span>
                        <div class="pricing-name">Setup Terima Beres</div>
                        <div class="pricing-price">Rp 500rb</div>
                        <div class="pricing-period">Sekali Bayar</div>
                    </div>

                    <div class="pricing-desc">
                        <strong>Apa yang Anda dapat:</strong> Kami setup lengkap payment gateway di hosting/domain Anda. Install, konfigurasi, test sampai jalan 100%.
                    </div>

                    <ul class="pricing-features">
                        <li>
                            <svg viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M5 13l4 4L19 7"/></svg>
                            <strong>Semua fitur GRATIS</strong>
                        </li>
                        <li>
                            <svg viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M5 13l4 4L19 7"/></svg>
                            Install di hosting Anda
                        </li>
                        <li>
                            <svg viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M5 13l4 4L19 7"/></svg>
                            Konfigurasi database
                        </li>
                        <li>
                            <svg viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M5 13l4 4L19 7"/></svg>
                            Setup domain &amp; SSL
                        </li>
                        <li>
                            <svg viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M5 13l4 4L19 7"/></svg>
                            Test sampai jalan 100%
                        </li>
                        <li>
                            <svg viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M5 13l4 4L19 7"/></svg>
                            Support 7 hari
                        </li>
                    </ul>

                    <a href="https://wa.me/6289534340757?text=Halo,%20saya%20mau%20paket%20Setup%20Terima%20Beres%20NEO%20PGA" target="_blank" class="btn btn-primary btn-block">Chat WhatsApp</a>
                </div>

                <div class="pricing-card">
                    <div class="pricing-header">
                        <span class="pricing-icon">&#127912;</span>
                        <div class="pricing-name">Full Custom</div>
                        <div class="pricing-price">Rp 1jt</div>
                        <div class="pricing-period">Sekali Bayar</div>
                    </div>

                    <div class="pricing-desc">
                        <strong>Apa yang Anda dapat:</strong> Semua dari paket Setup + custom design sesuai brand Anda. Landing page, halaman pembayaran, semua disesuaikan.
                    </div>

                    <ul class="pricing-features">
                        <li>
                            <svg viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M5 13l4 4L19 7"/></svg>
                            <strong>Semua dari Setup</strong>
                        </li>
                        <li>
                            <svg viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M5 13l4 4L19 7"/></svg>
                            Custom design brand
                        </li>
                        <li>
                            <svg viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M5 13l4 4L19 7"/></svg>
                            Landing page profesional
                        </li>
                        <li>
                            <svg viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M5 13l4 4L19 7"/></svg>
                            Responsive mobile/desktop
                        </li>
                        <li>
                            <svg viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M5 13l4 4L19 7"/></svg>
                            3x revisi design
                        </li>
                        <li>
                            <svg viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M5 13l4 4L19 7"/></svg>
                            Support 14 hari
                        </li>
                    </ul>

                    <a href="https://wa.me/6289534340757?text=Halo,%20saya%20mau%20paket%20Full%20Custom%20NEO%20PGA" target="_blank" class="btn btn-outline btn-block">Chat WhatsApp</a>
                </div>
            </div>
        </div>
    </section>

    <!-- Demo -->
    <section class="section demo" id="demo">
        <div class="container">
            <div class="demo-content">
                <h2>Lihat Langsung Cara Kerjanya</h2>
                <p>Coba DigiStore - contoh toko online yang sudah terintegrasi NEO PGA. Anda bisa coba proses pembayaran dari awal sampai selesai.</p>
                <a href="demo/" class="btn btn-primary btn-lg">
                    <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
                    Buka Demo Store
                </a>

                <div class="demo-card">
                    <h3>Apa yang bisa dicoba?</h3>
                    <p>Pilih produk, checkout, pilih metode pembayaran (QRIS/Bank Transfer), dan lihat bagaimana sistem verifikasi otomatis bekerja secara real-time.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- FAQ -->
    <section class="section faq" id="faq">
        <div class="container">
            <div class="section-header">
                <span class="section-eyebrow">FAQ</span>
                <h2 class="section-title">Pertanyaan Umum</h2>
                <p class="section-desc">Jawaban untuk pertanyaan yang sering ditanyakan</p>
            </div>

            <div class="faq-grid">
                <div class="faq-item active">
                    <div class="faq-question" onclick="toggleFaq(this)">
                        <div class="faq-icon">&#10067;</div>
                        <h3>Kenapa verifikasinya bisa langsung aktif?</h3>
                        <div class="faq-toggle">
                            <svg viewBox="0 0 24 24" fill="none"><path d="M12 5v14M5 12h14"/></svg>
                        </div>
                    </div>
                    <div class="faq-answer">
                        NEO PGA menggunakan sistem verifikasi otomatis berbasis teknologi. Berbeda dengan payment gateway konvensional yang membutuhkan review manual dokumen berminggu-minggu, sistem kami langsung aktif setelah pendaftaran sehingga Anda bisa langsung terima pembayaran.
                    </div>
                </div>

                <div class="faq-item">
                    <div class="faq-question" onclick="toggleFaq(this)">
                        <div class="faq-icon">&#128179;</div>
                        <h3>Metode pembayaran apa saja yang didukung?</h3>
                        <div class="faq-toggle">
                            <svg viewBox="0 0 24 24" fill="none"><path d="M12 5v14M5 12h14"/></svg>
                        </div>
                    </div>
                    <div class="faq-answer">
                        NEO PGA mendukung QRIS (bisa dibayar via GoPay, OVO, DANA, ShopeePay, LinkAja, dan semua e-wallet) serta Bank Transfer (BCA, BNI, Mandiri, BRI). Semua pembayaran terverifikasi otomatis.
                    </div>
                </div>

                <div class="faq-item">
                    <div class="faq-question" onclick="toggleFaq(this)">
                        <div class="faq-icon">&#128176;</div>
                        <h3>Fee 15% itu mahal tidak?</h3>
                        <div class="faq-toggle">
                            <svg viewBox="0 0 24 24" fill="none"><path d="M12 5v14M5 12h14"/></svg>
                        </div>
                    </div>
                    <div class="faq-answer">
                        Tergantung kebutuhan Anda. Fee 15% sudah termasuk semua biaya (tidak ada biaya setup, bulanan, atau tersembunyi). Untuk UMKM dengan omzet di bawah Rp 10 juta/bulan, ini lebih hemat dibanding payment gateway lain yang punya minimum fee. Plus, Anda dapat kemudahan verifikasi otomatis dan setup instan.
                    </div>
                </div>

                <div class="faq-item">
                    <div class="faq-question" onclick="toggleFaq(this)">
                        <div class="faq-icon">&#128104;&#8205;&#128187;</div>
                        <h3>Saya tidak paham teknis, bisa pakai NEO PGA?</h3>
                        <div class="faq-toggle">
                            <svg viewBox="0 0 24 24" fill="none"><path d="M12 5v14M5 12h14"/></svg>
                        </div>
                    </div>
                    <div class="faq-answer">
                        Tentu bisa! Pilih paket Setup Terima Beres (Rp 500rb) - kami yang install dan konfigurasi semuanya di hosting Anda. Anda tinggal terima jadi dan langsung pakai. Support via WhatsApp juga selalu siap membantu.
                    </div>
                </div>

                <div class="faq-item">
                    <div class="faq-question" onclick="toggleFaq(this)">
                        <div class="faq-icon">&#128274;</div>
                        <h3>Apakah aman untuk bisnis saya?</h3>
                        <div class="faq-toggle">
                            <svg viewBox="0 0 24 24" fill="none"><path d="M12 5v14M5 12h14"/></svg>
                        </div>
                    </div>
                    <div class="faq-answer">
                        Ya, keamanan adalah prioritas kami. Data terenkripsi dengan standar industri, setiap transaksi menggunakan signature verification, dan API key bisa diregenerasi kapan saja. Dashboard dilengkapi log aktivitas lengkap untuk memantau semua transaksi.
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Policy -->
    <section class="policy">
        <div class="container">
            <div class="policy-inner">
                <div class="policy-icon">&#9888;&#65039;</div>
                <div class="policy-content">
                    <h4>Kebijakan Penting</h4>
                    <p>NEO PGA adalah penyedia layanan payment gateway. Jika terjadi laporan penipuan atau scam dari transaksi yang dilakukan merchant dengan bukti yang valid, akun merchant akan kami blokir permanen tanpa pemberitahuan. Kami tidak bertanggung jawab atas kerugian yang timbul dari transaksi antara merchant dan pembeli. Dengan mendaftar, Anda menyetujui untuk menggunakan layanan ini secara bertanggung jawab dan sesuai hukum yang berlaku.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA -->
    <section class="section cta">
        <div class="container">
            <div class="cta-inner">
                <h2>Siap Terima Pembayaran Online?</h2>
                <p>Daftar sekarang dan mulai terima pembayaran dalam hitungan menit. Gratis, tanpa kartu kredit.</p>
                <div class="cta-buttons">
                    <a href="merchant/register.php" class="btn btn-primary btn-lg">
                        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
                        Daftar Gratis Sekarang
                    </a>
                    <a href="https://wa.me/6289534340757?text=Halo,%20saya%20mau%20tanya%20tentang%20NEO%20PGA" target="_blank" class="btn btn-outline btn-lg">
                        <svg width="20" height="20" fill="currentColor" viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                        Tanya via WhatsApp
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-grid">
                <div class="footer-brand">
                    <div class="logo-text">NEO <span>PGA</span></div>
                    <p>Payment Gateway termudah untuk UMKM Indonesia. Daftar langsung aktif, verifikasi otomatis, tanpa ribet.</p>
                </div>

                <div>
                    <h4 class="footer-title">Produk</h4>
                    <ul class="footer-links">
                        <li><a href="#fitur">Fitur</a></li>
                        <li><a href="#harga">Harga</a></li>
                        <li><a href="#demo">Demo</a></li>
                        <li><a href="merchant/dokumentasi.php">Dokumentasi API</a></li>
                    </ul>
                </div>

                <div>
                    <h4 class="footer-title">Akun</h4>
                    <ul class="footer-links">
                        <li><a href="merchant/login.php">Login Merchant</a></li>
                        <li><a href="merchant/register.php">Daftar Merchant</a></li>
                        <li><a href="admin/login.php">Admin Panel</a></li>
                    </ul>
                </div>

                <div>
                    <h4 class="footer-title">Kontak</h4>
                    <ul class="footer-links">
                        <li><a href="https://wa.me/6289534340757" target="_blank">WA: 0895-3434-0757</a></li>
                        <li><a href="mailto:support@neopga.com">support@neopga.com</a></li>
                    </ul>
                </div>
            </div>

            <div class="footer-bottom">
                &copy; <?= date('Y') ?> NEO PGA by SITUNEO. All rights reserved.
            </div>
        </div>
    </footer>

    <script>
        // Header scroll
        const header = document.getElementById('header');
        window.addEventListener('scroll', () => {
            header.classList.toggle('scrolled', window.scrollY > 50);
        });

        // Mobile menu
        function openMobileMenu() {
            document.getElementById('mobileMenu').classList.add('active');
            document.body.style.overflow = 'hidden';
        }

        function closeMobileMenu() {
            document.getElementById('mobileMenu').classList.remove('active');
            document.body.style.overflow = '';
        }

        // FAQ
        function toggleFaq(el) {
            const item = el.parentElement;
            const wasActive = item.classList.contains('active');
            document.querySelectorAll('.faq-item').forEach(i => i.classList.remove('active'));
            if (!wasActive) item.classList.add('active');
        }

        // Smooth scroll
        document.querySelectorAll('a[href^="#"]').forEach(a => {
            a.addEventListener('click', e => {
                e.preventDefault();
                const target = document.querySelector(a.getAttribute('href'));
                if (target) target.scrollIntoView({ behavior: 'smooth' });
                closeMobileMenu();
            });
        });

    </script>

    <!-- Security Protection -->
    <script src="assets/js/security.js"></script>
</body>
</html>

<?php
/**
 * NEO PGA API - Health Check
 *
 * GET /api/health.php
 *
 * Endpoint untuk mengecek kesehatan sistem:
 * - Database connection
 * - File permissions
 * - Queue status
 * - System load
 *
 * Tidak memerlukan authentication.
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Cache-Control: no-cache, no-store, must-revalidate');

$startTime = microtime(true);
$health = [
    'status' => 'healthy',
    'timestamp' => date('c'),
    'version' => '2.0.0',
    'checks' => []
];

// 1. Database Check
try {
    require_once __DIR__ . '/../includes/init.php';
    $db = Database::getInstance();

    // Test query
    $result = $db->fetch("SELECT 1 as test");

    if ($result && $result['test'] == 1) {
        $health['checks']['database'] = [
            'status' => 'healthy',
            'message' => 'Database connection OK'
        ];
    } else {
        throw new Exception('Database query failed');
    }

    // Check tables exist
    $tables = ['merchants', 'transactions', 'bank_accounts', 'payment_codes'];
    $missingTables = [];

    foreach ($tables as $table) {
        $check = $db->fetch("SHOW TABLES LIKE ?", [$table]);
        if (!$check) {
            $missingTables[] = $table;
        }
    }

    if (!empty($missingTables)) {
        $health['checks']['database']['warning'] = 'Missing tables: ' . implode(', ', $missingTables);
        $health['status'] = 'degraded';
    }

} catch (Exception $e) {
    $health['checks']['database'] = [
        'status' => 'unhealthy',
        'message' => 'Database connection failed'
    ];
    $health['status'] = 'unhealthy';
}

// 2. File System Check
$writableDirs = [
    'logs' => __DIR__ . '/../logs',
    'cache' => __DIR__ . '/../cache',
    'uploads' => __DIR__ . '/../uploads'
];

$fileSystemHealthy = true;
$health['checks']['filesystem'] = ['directories' => []];

foreach ($writableDirs as $name => $path) {
    if (!file_exists($path)) {
        // Try to create directory
        @mkdir($path, 0755, true);
    }

    $writable = is_writable($path);
    $health['checks']['filesystem']['directories'][$name] = [
        'path' => $name,
        'writable' => $writable
    ];

    if (!$writable) {
        $fileSystemHealthy = false;
    }
}

$health['checks']['filesystem']['status'] = $fileSystemHealthy ? 'healthy' : 'unhealthy';
if (!$fileSystemHealthy) {
    $health['status'] = 'degraded';
}

// 3. Queue/Pending Transactions Check
try {
    if (isset($db)) {
        // Count pending transactions
        $pending = $db->fetch("SELECT COUNT(*) as count FROM transactions WHERE status = 'pending'");
        $expired = $db->fetch("SELECT COUNT(*) as count FROM transactions WHERE status = 'pending' AND expired_at < NOW()");

        $health['checks']['queue'] = [
            'status' => 'healthy',
            'pending_transactions' => (int)($pending['count'] ?? 0),
            'expired_pending' => (int)($expired['count'] ?? 0)
        ];

        // Warning if too many expired pending
        if ($expired['count'] > 100) {
            $health['checks']['queue']['warning'] = 'High number of expired pending transactions';
        }
    }
} catch (Exception $e) {
    $health['checks']['queue'] = [
        'status' => 'unknown',
        'message' => 'Could not check queue status'
    ];
}

// 4. PHP Configuration Check
$health['checks']['php'] = [
    'status' => 'healthy',
    'version' => PHP_VERSION,
    'memory_limit' => ini_get('memory_limit'),
    'max_execution_time' => ini_get('max_execution_time'),
    'extensions' => [
        'pdo_mysql' => extension_loaded('pdo_mysql'),
        'curl' => extension_loaded('curl'),
        'json' => extension_loaded('json'),
        'openssl' => extension_loaded('openssl'),
        'mbstring' => extension_loaded('mbstring')
    ]
];

// Check required extensions
$requiredExtensions = ['pdo_mysql', 'curl', 'json'];
foreach ($requiredExtensions as $ext) {
    if (!extension_loaded($ext)) {
        $health['checks']['php']['status'] = 'unhealthy';
        $health['status'] = 'unhealthy';
    }
}

// 5. Disk Space Check
$diskPath = __DIR__;
$freeSpace = @disk_free_space($diskPath);
$totalSpace = @disk_total_space($diskPath);

if ($freeSpace !== false && $totalSpace !== false) {
    $usedPercent = round((1 - ($freeSpace / $totalSpace)) * 100, 2);
    $health['checks']['disk'] = [
        'status' => $usedPercent < 90 ? 'healthy' : 'warning',
        'free_space_mb' => round($freeSpace / 1024 / 1024, 2),
        'total_space_mb' => round($totalSpace / 1024 / 1024, 2),
        'used_percent' => $usedPercent
    ];

    if ($usedPercent >= 90) {
        $health['status'] = 'degraded';
    }
}

// 6. Response Time
$responseTime = round((microtime(true) - $startTime) * 1000, 2);
$health['response_time_ms'] = $responseTime;

// Set HTTP status code based on health
if ($health['status'] === 'unhealthy') {
    http_response_code(503);
} elseif ($health['status'] === 'degraded') {
    http_response_code(200); // Still return 200 for degraded but functional
}

// Simple format for monitoring tools
if (isset($_GET['simple'])) {
    echo json_encode([
        'status' => $health['status'],
        'timestamp' => $health['timestamp']
    ]);
    exit;
}

echo json_encode($health, JSON_PRETTY_PRINT);

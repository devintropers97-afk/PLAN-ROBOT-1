<?php
/**
 * =========================================================
 * PANDUAN INTEGRASI LANDING PAGE KE NEOBAYAR
 * Untuk Pemula yang Tidak Paham Coding
 * =========================================================
 */
require_once __DIR__ . '/../../config/config.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panduan Integrasi Landing Page | NEO PGA</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root{--neo:#0d9488;--neo-dark:#0f766e;--bg:#0f172a;--card:#1e293b;--text:#e2e8f0;--muted:#94a3b8}
        *{margin:0;padding:0;box-sizing:border-box}
        body{font-family:'Plus Jakarta Sans',sans-serif;background:var(--bg);color:var(--text);line-height:1.7;padding:40px 20px}
        .container{max-width:900px;margin:0 auto}
        h1{font-size:2rem;font-weight:800;margin-bottom:10px;background:linear-gradient(135deg,#fff,var(--neo));-webkit-background-clip:text;-webkit-text-fill-color:transparent}
        .subtitle{color:var(--muted);font-size:1.1rem;margin-bottom:40px}
        .card{background:var(--card);border-radius:16px;padding:30px;margin-bottom:30px;border:1px solid rgba(255,255,255,.1)}
        .card h2{font-size:1.3rem;font-weight:700;margin-bottom:20px;display:flex;align-items:center;gap:12px}
        .card h2 .num{background:var(--neo);color:#fff;width:36px;height:36px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:1rem}
        .highlight{background:linear-gradient(135deg,rgba(13,148,136,.2),rgba(13,148,136,.05));border:1px solid rgba(13,148,136,.3);border-radius:12px;padding:20px;margin:20px 0}
        .highlight-title{font-weight:700;color:var(--neo);margin-bottom:10px;font-size:1rem}
        pre{background:#0a0f1a;border-radius:12px;padding:20px;overflow-x:auto;font-size:.85rem;line-height:1.6;border:1px solid rgba(255,255,255,.05)}
        code{font-family:'JetBrains Mono',monospace;color:#e2e8f0}
        .added{background:rgba(16,185,129,.2);border-left:3px solid #10b981;padding:2px 8px;display:block;margin:2px 0}
        .comment{color:#6b7280;font-style:italic}
        .btn-wa{display:inline-flex;align-items:center;gap:10px;background:#25D366;color:#fff;padding:16px 32px;border-radius:14px;text-decoration:none;font-weight:600;font-size:1rem;transition:all .3s;margin-top:20px}
        .btn-wa:hover{transform:scale(1.05);box-shadow:0 10px 30px rgba(37,211,102,.3)}
        .flow{display:flex;gap:10px;flex-wrap:wrap;margin:20px 0}
        .flow-item{background:rgba(255,255,255,.05);padding:12px 20px;border-radius:10px;font-size:.9rem;display:flex;align-items:center;gap:8px}
        .flow-item .arrow{color:var(--neo)}
        ul{margin:15px 0 15px 25px}
        li{margin-bottom:8px}
        .important{background:linear-gradient(135deg,rgba(245,158,11,.2),rgba(245,158,11,.05));border:1px solid rgba(245,158,11,.3);border-radius:12px;padding:20px;margin:20px 0}
        .important-title{font-weight:700;color:#f59e0b;margin-bottom:10px}
        @media(max-width:640px){h1{font-size:1.6rem}.card{padding:20px}}
    </style>
</head>
<body>
<div class="container">
    <h1>🎯 Panduan Integrasi Landing Page</h1>
    <p class="subtitle">Untuk pemula yang tidak paham coding. Ikuti step by step!</p>

    <!-- SDK Banner -->
    <div style="background:linear-gradient(135deg,#0d9488,#059669);border-radius:16px;padding:24px;margin-bottom:24px;border:2px solid rgba(255,255,255,.2)">
        <div style="font-weight:700;color:#fff;margin-bottom:8px;font-size:1.1rem">Cara Termudah: Download SDK Siap Pakai!</div>
        <p style="color:rgba(255,255,255,.9);margin-bottom:16px;font-size:.95rem">SDK sudah terisi API Key Anda. Tinggal upload dan integrasi. Tidak perlu copy-paste kode manual!</p>
        <a href="../../merchant/integration-center.php" style="display:inline-flex;align-items:center;gap:8px;background:#fff;color:#0d9488;padding:12px 24px;border-radius:10px;text-decoration:none;font-weight:600;font-size:.95rem">📦 Download SDK di Integration Center</a>
    </div>

    <!-- Kode Unik Info -->
    <div style="background:linear-gradient(135deg,rgba(245,158,11,.2),rgba(245,158,11,.1));border:2px solid rgba(245,158,11,.4);border-radius:14px;padding:20px;margin-bottom:24px">
        <div style="font-weight:700;color:#f59e0b;margin-bottom:8px;display:flex;align-items:center;gap:8px">
            <span style="font-size:1.3rem">💡</span> Tentang Kode Unik NEO PGA
        </div>
        <p style="color:#fcd34d;font-size:.9rem;line-height:1.6">Semua pembayaran NEO PGA menggunakan <strong>kode unik (1-999)</strong> untuk identifikasi otomatis. User bayar Rp 50.123 (123 = kode unik) → Sistem otomatis cocokkan → Saldo terupdate Rp 50.000.</p>
    </div>

    <!-- Help Banner -->
    <div class="important">
        <div class="important-title">😵 Masih Bingung?</div>
        <p>Jangan khawatir! Kirim saja file HTML landing page kamu dan akses cPanel, kami bantu integrasikan sampai jalan 100%!</p>
        <a href="https://wa.me/6289534340757?text=Halo,%20saya%20butuh%20bantuan%20integrasi%20payment%20gateway.%0A%0AWebsite:%20[URL%20website%20kamu]%0AcPanel:%20[username%20dan%20password]" 
           class="btn-wa" target="_blank">
            📱 WhatsApp: 0895-3434-07575
        </a>
    </div>

    <!-- Step 1 -->
    <div class="card">
        <h2><span class="num">1</span> Apa yang Perlu Disiapkan?</h2>
        <ul>
            <li><strong>Landing page HTML</strong> — File website kamu (seperti DigiStore yang sudah kamu buat)</li>
            <li><strong>Akun NEO PGA</strong> — Daftar di merchant panel untuk dapat API Key</li>
            <li><strong>Hosting PHP</strong> — cPanel biasa sudah cukup</li>
        </ul>
        
        <div class="highlight">
            <div class="highlight-title">📋 Yang Kamu Dapat dari NEO PGA:</div>
            <ul>
                <li><code>API_KEY</code> — untuk autentikasi</li>
                <li><code>SECRET_KEY</code> — untuk verifikasi signature</li>
                <li><code>URL NEO PGA</code> — endpoint API</li>
            </ul>
        </div>
    </div>

    <!-- Step 2 -->
    <div class="card">
        <h2><span class="num">2</span> Alur Pembayaran</h2>
        <div class="flow">
            <div class="flow-item">Customer klik "Beli"</div>
            <div class="flow-item"><span class="arrow">→</span></div>
            <div class="flow-item">Isi form checkout</div>
            <div class="flow-item"><span class="arrow">→</span></div>
            <div class="flow-item">Kirim data ke NEO PGA API</div>
            <div class="flow-item"><span class="arrow">→</span></div>
            <div class="flow-item">Redirect ke halaman bayar</div>
            <div class="flow-item"><span class="arrow">→</span></div>
            <div class="flow-item">Customer bayar</div>
            <div class="flow-item"><span class="arrow">→</span></div>
            <div class="flow-item">Callback ke website kamu</div>
        </div>
    </div>

    <!-- Step 3 -->
    <div class="card">
        <h2><span class="num">3</span> Bagian yang Ditambahkan ke Landing Page</h2>
        
        <p style="margin-bottom:20px">Berikut adalah kode yang <strong>perlu ditambahkan</strong> ke landing page DigiStore kamu:</p>
        
        <div class="highlight">
            <div class="highlight-title">🔧 BAGIAN 1: Tambahkan di PALING ATAS file (sebelum &lt;!DOCTYPE html&gt;)</div>
        </div>
        
        <pre><code><span class="added">&lt;?php</span>
<span class="added">// ============================================</span>
<span class="added">// KONFIGURASI - GANTI DENGAN DATA KAMU!</span>
<span class="added">// ============================================</span>
<span class="added">define('NEOPGA_URL', 'https://neopga.com');  // URL NEO PGA kamu</span>
<span class="added">define('API_KEY', 'nb_live_xxxxx');               // API Key dari dashboard</span>
<span class="added">define('SECRET_KEY', 'nb_secret_xxxxx');          // Secret Key dari dashboard</span>
<span class="added"></span>
<span class="added">// ============================================</span>
<span class="added">// PROSES PEMBAYARAN (jangan diubah)</span>
<span class="added">// ============================================</span>
<span class="added">$paymentResult = null;</span>
<span class="added">$paymentError = null;</span>
<span class="added"></span>
<span class="added">if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'create_payment') {</span>
<span class="added">    // Ambil data dari form</span>
<span class="added">    $orderId = 'ORD-' . time() . '-' . strtoupper(substr(md5(rand()), 0, 6));</span>
<span class="added">    $amount = intval($_POST['amount']);</span>
<span class="added">    $productName = htmlspecialchars($_POST['product_name']);</span>
<span class="added">    $customerName = htmlspecialchars($_POST['customer_name']);</span>
<span class="added">    $customerEmail = filter_var($_POST['customer_email'], FILTER_SANITIZE_EMAIL);</span>
<span class="added">    $customerPhone = preg_replace('/[^0-9]/', '', $_POST['customer_phone']);</span>
<span class="added">    $paymentMethod = $_POST['payment_method'];</span>
<span class="added">    </span>
<span class="added">    // Kirim ke NEO PGA API</span>
<span class="added">    $data = [</span>
<span class="added">        'order_id' => $orderId,</span>
<span class="added">        'amount' => $amount,</span>
<span class="added">        'customer_name' => $customerName,</span>
<span class="added">        'customer_email' => $customerEmail,</span>
<span class="added">        'customer_phone' => $customerPhone,</span>
<span class="added">        'payment_method' => $paymentMethod,</span>
<span class="added">        'description' => 'Pembelian: ' . $productName</span>
<span class="added">    ];</span>
<span class="added">    </span>
<span class="added">    // Generate signature</span>
<span class="added">    $data['signature'] = hash('sha256', $orderId . $amount . SECRET_KEY);</span>
<span class="added">    </span>
<span class="added">    // Kirim request</span>
<span class="added">    $ch = curl_init(NEOPGA_URL . '/api/create-payment.php');</span>
<span class="added">    curl_setopt_array($ch, [</span>
<span class="added">        CURLOPT_RETURNTRANSFER => true,</span>
<span class="added">        CURLOPT_POST => true,</span>
<span class="added">        CURLOPT_POSTFIELDS => json_encode($data),</span>
<span class="added">        CURLOPT_HTTPHEADER => [</span>
<span class="added">            'Content-Type: application/json',</span>
<span class="added">            'X-API-Key: ' . API_KEY</span>
<span class="added">        ]</span>
<span class="added">    ]);</span>
<span class="added">    </span>
<span class="added">    $response = curl_exec($ch);</span>
<span class="added">    curl_close($ch);</span>
<span class="added">    </span>
<span class="added">    if ($response) {</span>
<span class="added">        $result = json_decode($response, true);</span>
<span class="added">        if (isset($result['success']) && $result['success']) {</span>
<span class="added">            header('Location: ' . $result['data']['payment_url']);</span>
<span class="added">            exit;</span>
<span class="added">        } else {</span>
<span class="added">            $paymentError = $result['message'] ?? 'Gagal membuat pembayaran';</span>
<span class="added">        }</span>
<span class="added">    }</span>
<span class="added">}</span>
<span class="added">?&gt;</span>
<span class="comment">&lt;!-- Setelah ini baru kode HTML biasa --&gt;</span>
&lt;!DOCTYPE html&gt;
...</code></pre>

        <div class="highlight" style="margin-top:30px">
            <div class="highlight-title">🔧 BAGIAN 2: Ubah form checkout dari JavaScript ke PHP</div>
        </div>
        
        <pre><code><span class="comment">&lt;!-- SEBELUM (JavaScript only - tidak kirim ke server) --&gt;</span>
&lt;form id="checkoutForm" onsubmit="processPayment(event)"&gt;
    ...
&lt;/form&gt;

<span class="comment">&lt;!-- SESUDAH (PHP form - kirim ke server) --&gt;</span>
<span class="added">&lt;form method="POST" action="" id="checkoutForm"&gt;</span>
<span class="added">    &lt;input type="hidden" name="action" value="create_payment"&gt;</span>
<span class="added">    &lt;input type="hidden" name="product_name" id="inputProductName" value=""&gt;</span>
<span class="added">    &lt;input type="hidden" name="amount" id="inputAmount" value=""&gt;</span>
    
    <span class="comment">&lt;!-- Field lainnya sama, tapi tambahkan name="" --&gt;</span>
<span class="added">    &lt;input type="text" name="customer_name" ...&gt;</span>
<span class="added">    &lt;input type="email" name="customer_email" ...&gt;</span>
<span class="added">    &lt;input type="tel" name="customer_phone" ...&gt;</span>
<span class="added">    &lt;input type="hidden" name="payment_method" id="selectedPayment" value="qris"&gt;</span>
    
    &lt;button type="submit"&gt;Bayar Sekarang&lt;/button&gt;
&lt;/form&gt;</code></pre>

        <div class="highlight" style="margin-top:30px">
            <div class="highlight-title">🔧 BAGIAN 3: Update function openCheckout()</div>
        </div>
        
        <pre><code>function openCheckout(productName, amount) {
    document.getElementById('orderProduct').textContent = productName;
    document.getElementById('orderTotal').textContent = 'Rp ' + amount.toLocaleString('id-ID');
    
    <span class="added">// TAMBAHAN: Set hidden input untuk form PHP</span>
    <span class="added">document.getElementById('inputProductName').value = productName;</span>
    <span class="added">document.getElementById('inputAmount').value = amount;</span>
    
    document.getElementById('checkoutModal').classList.add('active');
}</code></pre>
    </div>

    <!-- Step 4 -->
    <div class="card">
        <h2><span class="num">4</span> Rename File</h2>
        <p>Setelah menambahkan kode PHP, rename file kamu:</p>
        
        <div class="flow">
            <div class="flow-item"><code>index.html</code></div>
            <div class="flow-item"><span class="arrow">→</span></div>
            <div class="flow-item"><code>index.php</code></div>
        </div>
        
        <p style="margin-top:15px;color:var(--muted)">File .html tidak bisa menjalankan kode PHP. Jadi harus diubah ke .php</p>
    </div>

    <!-- Step 5 -->
    <div class="card">
        <h2><span class="num">5</span> Upload ke Hosting</h2>
        <ul>
            <li>Login ke cPanel</li>
            <li>Buka <strong>File Manager</strong></li>
            <li>Masuk ke folder <code>public_html</code></li>
            <li>Upload file <code>index.php</code></li>
            <li>Selesai! Coba akses website kamu</li>
        </ul>
    </div>

    <!-- Download -->
    <div class="card">
        <h2><span class="num">📥</span> Download Contoh Lengkap</h2>
        <p>Kami sudah siapkan file DigiStore yang sudah terintegrasi dengan NEO PGA. Tinggal ganti API Key saja!</p>
        
        <div class="highlight">
            <div class="highlight-title">File tersedia:</div>
            <ul>
                <li><a href="digistore-terintegrasi.php" style="color:var(--neo)" download>digistore-terintegrasi.php</a> — Landing page siap pakai</li>
            </ul>
        </div>
    </div>

    <!-- Final CTA -->
    <div class="important">
        <div class="important-title">🤝 Butuh Bantuan Profesional? (Admin Setup)</div>
        <p>Tim kami bisa bantu setup lengkap dari A-Z dengan biaya <strong>Rp 500.000</strong> (sekali setup). Cukup kirim:</p>
        <ul>
            <li>URL website kamu</li>
            <li>Akses cPanel (username + password)</li>
            <li>File landing page (jika ada)</li>
        </ul>
        <p style="margin-top:15px;color:var(--muted);font-size:.9rem">Pembayaran setelah setup berhasil dan diuji coba. Support 7 hari pasca setup.</p>
        <a href="https://wa.me/6289534340757?text=Halo,%20saya%20butuh%20bantuan%20Admin%20Setup%20integrasi%20NEO%20PGA.%0A%0AWebsite:%20%0AcPanel:%20"
           class="btn-wa" target="_blank">
            📱 WhatsApp: 0895-3434-07575
        </a>
    </div>

    <p style="text-align:center;color:var(--muted);margin-top:40px">
        © <?= date('Y') ?> NEO PGA - Payment Gateway untuk Indonesia
    </p>
</div>
</body>
</html>

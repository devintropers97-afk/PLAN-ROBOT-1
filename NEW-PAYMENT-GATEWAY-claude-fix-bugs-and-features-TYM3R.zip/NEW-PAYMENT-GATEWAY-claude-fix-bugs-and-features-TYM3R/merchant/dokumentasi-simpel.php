<?php
/**
 * NEO PGA - Panduan Integrasi SUPER SIMPEL
 * Untuk yang cuma punya 1 file index.php
 * Versi: Copy-Paste & Go!
 */
require_once __DIR__ . '/../includes/init.php';

if (!isset($_SESSION['merchant_user']) || empty($_SESSION['merchant_user']['id'])) {
    header('Location: login.php');
    exit;
}

$merchant = $_SESSION['merchant_user'];
$db = Database::getInstance();
$fullMerchant = $db->fetch("SELECT * FROM merchants WHERE id = ?", [$merchant['id']]);
if ($fullMerchant) $merchant = $fullMerchant;

$baseUrl = rtrim(APP_URL, '/');
$apiKey = htmlspecialchars($merchant['api_key'] ?? 'BELUM_ADA_API_KEY');
$secretKey = htmlspecialchars($merchant['secret_key'] ?? 'BELUM_ADA_SECRET_KEY');
$pageTitle = 'Panduan Simpel (1 File)';
$currentPage = 'api-docs';

include __DIR__ . '/layout_header.php';
?>

<style>
:root{--neo:#0d9488;--neo-dark:#0f766e;--success:#10b981;--warn:#f59e0b;--danger:#ef4444}
.sw{max-width:900px;margin:0 auto}
.hero{background:linear-gradient(135deg,#f59e0b,#d97706,#b45309);color:#fff;padding:40px;border-radius:24px;margin-bottom:30px;text-align:center}
.hero h1{font-size:1.8rem;font-weight:800;margin:0 0 10px}
.hero p{font-size:1rem;opacity:.9;margin:0}
.hero-badge{display:inline-block;background:rgba(255,255,255,.25);padding:8px 20px;border-radius:50px;font-size:.9rem;font-weight:700;margin-top:16px}
.card{background:#fff;border-radius:20px;padding:28px;margin-bottom:24px;border:1px solid #e5e7eb;box-shadow:0 4px 15px rgba(0,0,0,.04)}
.card-h{display:flex;align-items:center;gap:14px;margin-bottom:20px;padding-bottom:16px;border-bottom:2px solid #f3f4f6}
.card-icon{width:50px;height:50px;border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:26px}
.card-icon.yellow{background:linear-gradient(135deg,#fef3c7,#fde68a)}
.card-icon.blue{background:linear-gradient(135deg,#dbeafe,#bfdbfe)}
.card-icon.green{background:linear-gradient(135deg,#dcfce7,#bbf7d0)}
.card-icon.purple{background:linear-gradient(135deg,#ede9fe,#ddd6fe)}
.card-icon.orange{background:linear-gradient(135deg,#ffedd5,#fed7aa)}
.card-icon.red{background:linear-gradient(135deg,#fee2e2,#fecaca)}
.card-t{font-size:1.25rem;font-weight:700;color:#1f2937;margin:0}
.card-st{font-size:.9rem;color:#6b7280;margin:4px 0 0}
.alert{padding:18px 22px;border-radius:14px;margin:16px 0;display:flex;gap:14px;align-items:flex-start}
.alert-i{background:linear-gradient(135deg,#dbeafe,#eff6ff);border:1px solid #93c5fd}
.alert-w{background:linear-gradient(135deg,#fef3c7,#fffbeb);border:1px solid #fcd34d}
.alert-s{background:linear-gradient(135deg,#dcfce7,#f0fdf4);border:1px solid #86efac}
.alert-d{background:linear-gradient(135deg,#fee2e2,#fef2f2);border:1px solid #fca5a5}
.alert-icon{font-size:24px;line-height:1}
.alert-t{font-weight:700;margin-bottom:4px;color:#1f2937}
.alert-txt{font-size:.95rem;line-height:1.6;color:#374151}
.cred{background:linear-gradient(135deg,#1f2937,#374151);border-radius:20px;padding:28px;color:#fff}
.cred-item{background:rgba(255,255,255,.08);border-radius:12px;padding:14px 18px;margin-bottom:10px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px}
.cred-label{font-size:.7rem;color:rgba(255,255,255,.5);text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px}
.cred-val{font-family:'Courier New',monospace;font-size:.9rem;word-break:break-all}
.cbtn{background:rgba(255,255,255,.12);border:none;color:rgba(255,255,255,.9);padding:10px 16px;border-radius:8px;cursor:pointer;font-size:.85rem;font-weight:600;transition:all .2s}
.cbtn:hover{background:rgba(255,255,255,.2)}
.cbtn.copied{background:#10b981;color:#fff}
.code{background:#0f172a;border-radius:16px;overflow:hidden;margin:20px 0}
.code-h{background:#1e293b;padding:14px 20px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px}
.code-fn{color:#94a3b8;font-size:.85rem;font-weight:600}
.code-cp{background:#334155;border:none;color:#e2e8f0;padding:8px 16px;border-radius:8px;cursor:pointer;font-size:.8rem;font-weight:600;transition:all .2s}
.code-cp:hover{background:#475569}
.code-cp.copied{background:#10b981}
.code-b{padding:24px;overflow-x:auto}
.code-b pre{margin:0;color:#e2e8f0;font-family:'Courier New',Consolas,monospace;font-size:13px;line-height:1.8;white-space:pre}
.cm{color:#64748b;font-style:italic}
.str{color:#86efac}
.kw{color:#c084fc}
.var{color:#7dd3fc}
.num{color:#fda4af}
.vstep{display:flex;gap:20px;padding:20px;background:#f9fafb;border-radius:16px;border:2px solid #f3f4f6;margin-bottom:14px;transition:all .2s}
.vstep:hover{border-color:var(--neo);transform:translateX(4px)}
.vstep-n{width:46px;height:46px;min-width:46px;background:linear-gradient(135deg,var(--neo),var(--neo-dark));color:#fff;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.2rem;font-weight:800}
.vstep-c{flex:1}
.vstep-t{font-size:1.05rem;font-weight:700;color:#1f2937;margin:0 0 6px}
.vstep-d{font-size:.9rem;color:#4b5563;margin:0;line-height:1.5}
.flow{display:flex;align-items:center;justify-content:center;gap:6px;padding:24px 16px;background:linear-gradient(135deg,#f0fdfa,#ecfdf5);border-radius:16px;margin:20px 0;overflow-x:auto;flex-wrap:wrap}
.flow-item{text-align:center;padding:14px 12px;background:#fff;border-radius:12px;border:2px solid #d1fae5;min-width:80px}
.flow-icon{font-size:1.6rem;margin-bottom:6px}
.flow-lbl{font-size:.7rem;font-weight:600;color:#374151;line-height:1.3}
.flow-arr{font-size:1.1rem;color:#10b981;font-weight:bold}
.method-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px;margin:20px 0}
.method-card{background:#fff;border-radius:14px;padding:20px;border:2px solid #e5e7eb;text-align:center;transition:all .2s;cursor:default}
.method-card:hover{border-color:var(--neo)}
.method-card.rec{border-color:#10b981;background:linear-gradient(135deg,#f0fdf4,#fff)}
.method-icon{font-size:2rem;margin-bottom:8px}
.method-name{font-weight:700;color:#1f2937;margin-bottom:4px;font-size:.95rem}
.method-desc{font-size:.8rem;color:#6b7280;line-height:1.4}
.method-badge{display:inline-block;background:#10b981;color:#fff;font-size:.65rem;padding:3px 10px;border-radius:50px;margin-top:10px;font-weight:700}
.chk{background:#f9fafb;border-radius:16px;padding:24px;border:1px solid #e5e7eb;margin-top:20px}
.chk-t{font-size:1.05rem;font-weight:700;color:#1f2937;margin:0 0 16px}
.chk-item{display:flex;align-items:flex-start;gap:12px;padding:10px 0;border-bottom:1px dashed #e5e7eb}
.chk-item:last-child{border-bottom:none}
.chk-box{width:24px;height:24px;min-width:24px;border:2px solid #d1d5db;border-radius:6px;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:all .2s}
.chk-box:hover{border-color:var(--neo)}
.chk-box.checked{background:#10b981;border-color:#10b981;color:#fff}
.chk-txt{flex:1;font-size:.9rem;color:#374151}
.chk-item.done .chk-txt{text-decoration:line-through;color:#9ca3af}
.tabs{display:flex;gap:8px;margin-bottom:24px;flex-wrap:wrap}
.tab{padding:12px 24px;border-radius:12px;border:2px solid #e5e7eb;background:#fff;color:#4b5563;font-size:.9rem;font-weight:600;cursor:pointer;transition:all .2s}
.tab:hover{border-color:var(--neo)}
.tab.active{background:var(--neo);border-color:var(--neo);color:#fff}
.tc{display:none}
.tc.active{display:block;animation:fadeIn .3s ease}
@keyframes fadeIn{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
.compare-tbl{width:100%;border-collapse:collapse;margin:20px 0;font-size:.9rem}
.compare-tbl th{background:var(--neo);color:#fff;padding:14px;text-align:center}
.compare-tbl td{padding:12px 14px;border:1px solid #e5e7eb;text-align:center}
.compare-tbl tr:nth-child(even){background:#f9fafb}
.compare-tbl .yes{color:#10b981;font-weight:700}
.compare-tbl .no{color:#9ca3af}
.back-link{display:inline-flex;align-items:center;gap:8px;color:var(--neo);text-decoration:none;font-weight:600;margin-bottom:20px}
.back-link:hover{text-decoration:underline}
@media(max-width:640px){
.hero{padding:30px 20px}
.hero h1{font-size:1.5rem}
.vstep{flex-direction:column;text-align:center}
.vstep-n{margin:0 auto 10px}
.flow{padding:16px 10px}
.flow-item{min-width:65px;padding:10px 8px}
.cred-item{flex-direction:column;align-items:stretch}
.method-grid{grid-template-columns:1fr 1fr}
}
</style>

<div class="sw">
    <a href="dokumentasi.php" class="back-link">← Kembali ke Dokumentasi Lengkap</a>
    
    <!-- Banner SDK Download -->
    <div style="background:linear-gradient(135deg,#10b981,#059669);border-radius:16px;padding:20px 24px;margin-bottom:16px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:16px;">
        <div style="color:#fff;">
            <div style="font-size:1.1rem;font-weight:700;">📦 Prefer Download SDK Siap Pakai?</div>
            <div style="font-size:.9rem;opacity:.9;">SDK sudah terisi API Key Anda. Tinggal upload dan integrasi!</div>
        </div>
        <a href="integration-center.php" style="background:#fff;color:#059669;padding:12px 24px;border-radius:10px;text-decoration:none;font-weight:700;font-size:.9rem;">Download SDK →</a>
    </div>

    <!-- Info Kode Unik -->
    <div style="background:linear-gradient(135deg,#fef3c7,#fde68a);border:2px solid #f59e0b;border-radius:14px;padding:16px 20px;margin-bottom:16px;display:flex;align-items:flex-start;gap:12px;">
        <span style="font-size:24px;">💡</span>
        <div>
            <div style="font-size:.95rem;font-weight:700;color:#92400e;margin-bottom:4px;">Semua Pembayaran NEO PGA Menggunakan Kode Unik</div>
            <div style="font-size:.85rem;color:#a16207;line-height:1.5;">Setiap transaksi ditambahkan <strong>kode unik (1-999)</strong> untuk identifikasi otomatis. Contoh: Rp 50.000 → User bayar Rp 50.123</div>
        </div>
    </div>

    <!-- Help Banner -->
    <div class="alert alert-w" style="margin-bottom:20px;padding:24px;border-radius:16px;background:linear-gradient(135deg,#fef3c7,#fffbeb);border:2px solid #f59e0b">
        <div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap">
            <span style="font-size:2.5rem">😵</span>
            <div style="flex:1;min-width:200px">
                <strong style="font-size:1.1rem;color:#92400e;display:block;margin-bottom:4px">Masih Bingung?</strong>
                <span style="color:#a16207">Kirim URL website + akses cPanel, kami bantu setup sampai jalan!</span>
            </div>
            <a href="https://wa.me/6289534340757?text=Halo,%20saya%20butuh%20bantuan%20setup%20payment%20gateway%20NEO PGA.%0A%0AWebsite:%20%0AcPanel:%20"
               target="_blank"
               style="background:#25D366;color:#fff;padding:12px 24px;border-radius:12px;text-decoration:none;font-weight:600;display:inline-flex;align-items:center;gap:8px;white-space:nowrap">
                📱 WA: 0895-3434-07575
            </a>
        </div>
    </div>
    
    <!-- Hero -->
    <div class="hero">
        <h1>⚡ Panduan Super Simpel</h1>
        <p>Untuk yang cuma punya 1 file index.php</p>
        <div class="hero-badge">🎯 Copy-Paste Langsung Jalan!</div>
    </div>
    
    <!-- Tabs -->
    <div class="tabs">
        <button class="tab active" onclick="showTab('tanpa-db')">📄 Tanpa Database</button>
        <button class="tab" onclick="showTab('dengan-db')">💾 Dengan Database</button>
        <button class="tab" onclick="showTab('notif')">📱 Metode Notifikasi</button>
    </div>
    
    <!-- ============================================== -->
    <!-- TAB: TANPA DATABASE -->
    <!-- ============================================== -->
    <div id="tab-tanpa-db" class="tc active">
        
        <!-- Situasi -->
        <div class="card">
            <div class="card-h">
                <div class="card-icon yellow">🤔</div>
                <div><h3 class="card-t">Situasi Kamu</h3><p class="card-st">Familiar dengan kondisi ini?</p></div>
            </div>
            <div class="alert alert-i">
                <div class="alert-icon">📁</div>
                <div><div class="alert-t">Di cPanel kamu cuma ada:</div><div class="alert-txt"><code>public_html/index.php</code> — Landing page 1 halaman</div></div>
            </div>
            <div class="alert alert-w">
                <div class="alert-icon">❓</div>
                <div><div class="alert-t">Pertanyaan:</div><div class="alert-txt">"Gimana manggil checkout.php & callback.php kalau yang kepake cuma index.php?"</div></div>
            </div>
            <div class="alert alert-s">
                <div class="alert-icon">✅</div>
                <div><div class="alert-t">Solusi:</div><div class="alert-txt"><strong>GABUNG SEMUA dalam 1 file!</strong> Copy kode di bawah, ganti beberapa bagian, upload. Selesai!</div></div>
            </div>
        </div>
        
        <!-- Flow -->
        <div class="card">
            <div class="card-h">
                <div class="card-icon blue">🔄</div>
                <div><h3 class="card-t">Alur Kerja</h3><p class="card-st">Semua pakai index.php dengan ?action=xxx</p></div>
            </div>
            <div class="flow">
                <div class="flow-item"><div class="flow-icon">🏠</div><div class="flow-lbl">index.php</div></div>
                <div class="flow-arr">→</div>
                <div class="flow-item"><div class="flow-icon">📤</div><div class="flow-lbl">?action=<br>checkout</div></div>
                <div class="flow-arr">→</div>
                <div class="flow-item"><div class="flow-icon">💳</div><div class="flow-lbl">NEO PGA<br>Bayar</div></div>
                <div class="flow-arr">→</div>
                <div class="flow-item"><div class="flow-icon">📡</div><div class="flow-lbl">?action=<br>callback</div></div>
                <div class="flow-arr">→</div>
                <div class="flow-item"><div class="flow-icon">✅</div><div class="flow-lbl">?action=<br>sukses</div></div>
            </div>
        </div>
        
        <!-- Credentials -->
        <div class="card">
            <div class="card-h">
                <div class="card-icon orange">🔑</div>
                <div><h3 class="card-t">Credentials Kamu</h3><p class="card-st">Copy dulu, nanti paste di kode</p></div>
            </div>
            <div class="cred">
                <div class="cred-item">
                    <div><div class="cred-label">API KEY</div><div class="cred-val" id="c-key"><?= $apiKey ?></div></div>
                    <button class="cbtn" onclick="copyC('c-key',this)">📋 Copy</button>
                </div>
                <div class="cred-item">
                    <div><div class="cred-label">SECRET KEY</div><div class="cred-val" id="c-sec"><?= $secretKey ?></div></div>
                    <button class="cbtn" onclick="copyC('c-sec',this)">📋 Copy</button>
                </div>
                <div class="cred-item">
                    <div><div class="cred-label">API URL</div><div class="cred-val" id="c-url"><?= $baseUrl ?>/api/create.php</div></div>
                    <button class="cbtn" onclick="copyC('c-url',this)">📋 Copy</button>
                </div>
            </div>
        </div>
        
        <!-- Yang Harus Diganti -->
        <div class="card">
            <div class="card-h">
                <div class="card-icon red">✏️</div>
                <div><h3 class="card-t">Yang HARUS Diganti</h3><p class="card-st">Sebelum upload, ganti 4 hal ini!</p></div>
            </div>
            <table class="compare-tbl">
                <tr><th style="background:#dc2626">Cari Ini</th><th style="background:#16a34a">Ganti Dengan</th></tr>
                <tr><td><code>$API_KEY = "..."</code></td><td>API Key kamu (dari atas)</td></tr>
                <tr><td><code>$SECRET_KEY = "..."</code></td><td>Secret Key kamu (dari atas)</td></tr>
                <tr><td><code>DOMAINKAMU.com</code></td><td>Domain website kamu</td></tr>
                <tr><td><code>150000</code></td><td>Harga produk kamu (Rupiah)</td></tr>
            </table>
        </div>
        
        <!-- KODE LENGKAP -->
        <div class="card">
            <div class="card-h">
                <div class="card-icon green">📄</div>
                <div><h3 class="card-t">Kode Lengkap — TANPA Database</h3><p class="card-st">Copy semua, paste ke index.php</p></div>
            </div>
            
            <div class="code">
                <div class="code-h">
                    <span class="code-fn">index.php — All-in-One (Tanpa Database)</span>
                    <button class="code-cp" onclick="copyCode('code-no-db',this)">📋 Copy Semua</button>
                </div>
                <div class="code-b"><pre id="code-no-db">&lt;?php
// ============================================================
//  NEO PGA - ALL IN ONE (Landing + Checkout + Callback)
//  Versi: TANPA DATABASE - Data disimpan ke file TXT
// ============================================================

// =====================
// KONFIGURASI - GANTI!
// =====================
$API_KEY    = "<?= $apiKey ?>";      // API Key kamu
$SECRET_KEY = "<?= $secretKey ?>";   // Secret Key kamu
$API_URL    = "<?= $baseUrl ?>/api/create.php";
$MY_DOMAIN  = "https://DOMAINKAMU.com";  // GANTI dengan domain kamu!

// =====================
// ROUTER SEDERHANA
// =====================
$action = $_GET['action'] ?? 'home';

// =====================
// 1. CALLBACK (dipanggil NEO PGA saat pembayaran sukses)
// =====================
if ($action === 'callback') {
    $rawPayload = file_get_contents('php://input');
    $data = json_decode($rawPayload, true);
    
    // Verifikasi signature - WAJIB!
    $expectedSig = hash_hmac('sha256', json_encode($data['data']), $SECRET_KEY);
    if (!isset($data['signature']) || $data['signature'] !== $expectedSig) {
        http_response_code(401);
        exit('Invalid signature');
    }
    
    // Proses pembayaran sukses
    if ($data['event'] === 'payment.success') {
        $orderId   = $data['data']['reference_id'];
        $amount    = $data['data']['amount'];
        $custName  = $data['data']['customer']['name'];
        $custEmail = $data['data']['customer']['email'];
        $custPhone = $data['data']['customer']['phone'] ?? '-';
        
        // =====================
        // SIMPAN KE FILE TXT (tanpa database)
        // =====================
        $logLine = date('Y-m-d H:i:s') . " | $orderId | $custName | $custPhone | $custEmail | Rp " . number_format($amount) . "\n";
        file_put_contents('orders.txt', $logLine, FILE_APPEND);
        
        // =====================
        // NOTIFIKASI (pilih salah satu atau semua)
        // =====================
        
        // Opsi 1: Email ke kamu (uncomment untuk aktifkan)
        // mail('emailkamu@gmail.com', '💰 Order Baru!', "Order: $orderId\nCustomer: $custName\nHP: $custPhone\nTotal: Rp " . number_format($amount));
        
        // Opsi 2: Telegram (uncomment & isi token)
        // $telegramToken = 'BOT_TOKEN_KAMU';
        // $telegramChatId = 'CHAT_ID_KAMU';
        // $msg = "💰 ORDER BARU!\nID: $orderId\nCustomer: $custName\nHP: $custPhone\nTotal: Rp " . number_format($amount);
        // file_get_contents("https://api.telegram.org/bot{$telegramToken}/sendMessage?chat_id={$telegramChatId}&text=" . urlencode($msg));
        
        // Opsi 3: Email ke customer
        // mail($custEmail, 'Pembayaran Berhasil!', "Halo $custName,\n\nPembayaran Rp " . number_format($amount) . " sudah kami terima.\nOrder ID: $orderId\n\nTerima kasih!");
    }
    
    // WAJIB return 200 OK
    http_response_code(200);
    exit('OK');
}

// =====================
// 2. CHECKOUT (proses form pembayaran)
// =====================
if ($action === 'checkout' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'amount'         => (int) $_POST['amount'],
        'customer_name'  => $_POST['name'],
        'customer_email' => $_POST['email'],
        'customer_phone' => $_POST['phone'],
        'description'    => $_POST['product'] ?? 'Pembelian Produk',
        'reference_id'   => 'ORD-' . time() . rand(100, 999),
        'callback_url'   => $MY_DOMAIN . '/index.php?action=callback',
        'redirect_url'   => $MY_DOMAIN . '/index.php?action=sukses',
        'expiry_minutes' => 60
    ];
    
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL            => $API_URL,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_HTTPHEADER     => [
            'X-API-Key: ' . $API_KEY,
            'Content-Type: application/json'
        ],
        CURLOPT_POSTFIELDS     => json_encode($data)
    ]);
    $response = curl_exec($ch);
    curl_close($ch);
    $result = json_decode($response, true);
    
    if ($result && $result['success']) {
        // Redirect ke halaman pembayaran NEO PGA
        header('Location: ' . $result['data']['payment_url']);
        exit;
    } else {
        $error = $result['message'] ?? 'Gagal membuat pembayaran';
    }
}

// =====================
// 3. HALAMAN SUKSES
// =====================
if ($action === 'sukses') {
?>
&lt;!DOCTYPE html>
&lt;html>
&lt;head>
    &lt;title>Pembayaran Berhasil&lt;/title>
    &lt;meta name="viewport" content="width=device-width,initial-scale=1">
&lt;/head>
&lt;body style="font-family:Arial,sans-serif;text-align:center;padding:60px 20px;background:linear-gradient(135deg,#f0fdf4,#ecfdf5);min-height:100vh;">
    &lt;div style="max-width:400px;margin:0 auto;background:#fff;padding:50px 30px;border-radius:24px;box-shadow:0 10px 40px rgba(0,0,0,.1);">
        &lt;div style="font-size:80px;margin-bottom:20px;">✅&lt;/div>
        &lt;h1 style="color:#16a34a;margin:0 0 16px;font-size:1.8rem;">Pembayaran Berhasil!&lt;/h1>
        &lt;p style="color:#4b5563;font-size:1.1rem;margin:0 0 30px;">Terima kasih sudah berbelanja.&lt;/p>
        &lt;a href="index.php" style="display:inline-block;padding:16px 36px;background:linear-gradient(135deg,#10b981,#059669);color:#fff;text-decoration:none;border-radius:12px;font-weight:bold;font-size:1rem;">← Kembali ke Home&lt;/a>
    &lt;/div>
&lt;/body>
&lt;/html>
&lt;?php
    exit;
}

// =====================
// 4. LANDING PAGE (HOME)
// =====================
?>
&lt;!DOCTYPE html>
&lt;html>
&lt;head>
    &lt;title>Produk Saya - Beli Sekarang&lt;/title>
    &lt;meta name="viewport" content="width=device-width,initial-scale=1">
    &lt;style>
        * { box-sizing:border-box; margin:0; padding:0; }
        body { font-family:Arial,sans-serif; background:linear-gradient(135deg,#f0fdfa,#ecfdf5); min-height:100vh; padding:40px 20px; }
        .container { max-width:480px; margin:0 auto; }
        .card { background:#fff; border-radius:24px; padding:40px 32px; box-shadow:0 10px 40px rgba(0,0,0,.1); }
        h1 { color:#1f2937; font-size:1.8rem; margin-bottom:8px; }
        .desc { color:#6b7280; margin-bottom:24px; line-height:1.5; }
        .price { font-size:2.5rem; font-weight:800; color:#10b981; margin-bottom:32px; }
        .price small { font-size:1rem; color:#9ca3af; font-weight:normal; }
        input { width:100%; padding:16px; border:2px solid #e5e7eb; border-radius:12px; font-size:16px; margin-bottom:14px; }
        input:focus { border-color:#10b981; outline:none; }
        button { width:100%; padding:18px; background:linear-gradient(135deg,#10b981,#059669); color:#fff; border:none; border-radius:12px; font-size:18px; font-weight:700; cursor:pointer; transition:all .2s; }
        button:hover { transform:translateY(-2px); box-shadow:0 8px 25px rgba(16,185,129,.4); }
        .secure { text-align:center; margin-top:20px; color:#9ca3af; font-size:14px; }
        .error { background:#fee2e2; color:#dc2626; padding:14px; border-radius:10px; margin-bottom:20px; font-size:14px; }
    &lt;/style>
&lt;/head>
&lt;body>
    &lt;div class="container">
        &lt;div class="card">
            &lt;h1>🛒 Nama Produk Kamu&lt;/h1>
            &lt;p class="desc">Deskripsi singkat produk kamu di sini. Jelaskan manfaat dan keunggulan produk.&lt;/p>
            &lt;div class="price">Rp 150.000 &lt;small>/item&lt;/small>&lt;/div>
            
            &lt;?php if (!empty($error)): ?>
                &lt;div class="error">&lt;?= htmlspecialchars($error) ?>&lt;/div>
            &lt;?php endif; ?>
            
            &lt;form method="POST" action="index.php?action=checkout">
                &lt;input type="hidden" name="amount" value="150000">
                &lt;input type="hidden" name="product" value="Nama Produk Kamu">
                
                &lt;input type="text" name="name" placeholder="Nama Lengkap" required>
                &lt;input type="email" name="email" placeholder="Email" required>
                &lt;input type="tel" name="phone" placeholder="No. WhatsApp" required>
                
                &lt;button type="submit">🔒 Bayar Sekarang&lt;/button>
            &lt;/form>
            
            &lt;div class="secure">🔐 Pembayaran aman via NEO PGA&lt;/div>
        &lt;/div>
    &lt;/div>
&lt;/body>
&lt;/html></pre></div>
            </div>
            
            <div class="chk">
                <div class="chk-t">✅ Checklist Sebelum Upload</div>
                <div class="chk-item"><div class="chk-box" onclick="toggleChk(this)"></div><div class="chk-txt">Sudah ganti <code>$API_KEY</code></div></div>
                <div class="chk-item"><div class="chk-box" onclick="toggleChk(this)"></div><div class="chk-txt">Sudah ganti <code>$SECRET_KEY</code></div></div>
                <div class="chk-item"><div class="chk-box" onclick="toggleChk(this)"></div><div class="chk-txt">Sudah ganti <code>DOMAINKAMU.com</code></div></div>
                <div class="chk-item"><div class="chk-box" onclick="toggleChk(this)"></div><div class="chk-txt">Sudah ganti harga <code>150000</code></div></div>
                <div class="chk-item"><div class="chk-box" onclick="toggleChk(this)"></div><div class="chk-txt">Sudah ganti nama & deskripsi produk</div></div>
            </div>
        </div>
        
        <!-- Cara Upload -->
        <div class="card">
            <div class="card-h">
                <div class="card-icon purple">📤</div>
                <div><h3 class="card-t">Cara Upload ke cPanel</h3></div>
            </div>
            <div class="vstep"><div class="vstep-n">1</div><div class="vstep-c"><h4 class="vstep-t">Login cPanel</h4><p class="vstep-d">Buka <code>namadomainkamu.com/cpanel</code> atau dari provider hosting</p></div></div>
            <div class="vstep"><div class="vstep-n">2</div><div class="vstep-c"><h4 class="vstep-t">Buka File Manager</h4><p class="vstep-d">Masuk ke folder <code>public_html</code></p></div></div>
            <div class="vstep"><div class="vstep-n">3</div><div class="vstep-c"><h4 class="vstep-t">Backup file lama</h4><p class="vstep-d">Rename <code>index.php</code> jadi <code>index-backup.php</code></p></div></div>
            <div class="vstep"><div class="vstep-n">4</div><div class="vstep-c"><h4 class="vstep-t">Buat file baru</h4><p class="vstep-d">Klik <strong>+ File</strong> → nama: <code>index.php</code></p></div></div>
            <div class="vstep"><div class="vstep-n">5</div><div class="vstep-c"><h4 class="vstep-t">Edit & paste</h4><p class="vstep-d">Klik kanan → <strong>Edit</strong> → Paste kode → <strong>Save</strong></p></div></div>
            <div class="vstep"><div class="vstep-n">6</div><div class="vstep-c"><h4 class="vstep-t">Test!</h4><p class="vstep-d">Buka website, isi form, coba bayar! 🎉</p></div></div>
        </div>
        
        <!-- Dimana Data Order? -->
        <div class="card">
            <div class="card-h">
                <div class="card-icon blue">📋</div>
                <div><h3 class="card-t">Dimana Data Order?</h3><p class="card-st">File orders.txt</p></div>
            </div>
            <div class="alert alert-i">
                <div class="alert-icon">📄</div>
                <div><div class="alert-t">Lokasi: public_html/orders.txt</div><div class="alert-txt">Setiap pembayaran sukses, otomatis tersimpan di file ini.<br><br><strong>Format isi:</strong><br><code>2024-12-10 15:30:00 | ORD-123456 | Budi | 081234567890 | budi@email.com | Rp 150,000</code></div></div>
            </div>
            <p style="color:#6b7280;margin-top:16px;font-size:.9rem;">Download file ini dari cPanel kapan saja untuk lihat semua order.</p>
        </div>
        
    </div>
    
    <!-- ============================================== -->
    <!-- TAB: DENGAN DATABASE -->
    <!-- ============================================== -->
    <div id="tab-dengan-db" class="tc">
        
        <div class="card">
            <div class="card-h">
                <div class="card-icon green">💾</div>
                <div><h3 class="card-t">Kapan Butuh Database?</h3></div>
            </div>
            <table class="compare-tbl">
                <tr><th style="background:#6b7280;">Fitur</th><th>Tanpa DB</th><th>Dengan DB</th></tr>
                <tr><td style="text-align:left;">Simpan order</td><td>File TXT</td><td class="yes">✅ MySQL</td></tr>
                <tr><td style="text-align:left;">Cari order lama</td><td class="no">❌ Manual</td><td class="yes">✅ Search</td></tr>
                <tr><td style="text-align:left;">Dashboard admin</td><td class="no">❌</td><td class="yes">✅</td></tr>
                <tr><td style="text-align:left;">Laporan penjualan</td><td class="no">❌ Manual</td><td class="yes">✅ Otomatis</td></tr>
                <tr><td style="text-align:left;">Tracking status</td><td class="no">❌</td><td class="yes">✅</td></tr>
                <tr><td style="text-align:left;">Kompleksitas</td><td class="yes">✅ Simpel</td><td>Perlu setup</td></tr>
                <tr><td style="text-align:left;">Cocok untuk</td><td>1-10 order/hari</td><td>&gt;10 order/hari</td></tr>
            </table>
            <div class="alert alert-s">
                <div class="alert-icon">💡</div>
                <div><div class="alert-t">Rekomendasi:</div><div class="alert-txt">Baru mulai? Pakai <strong>tanpa database</strong> dulu. Kalau sudah ramai, upgrade ke database.</div></div>
            </div>
        </div>
        
        <!-- Setup Database -->
        <div class="card">
            <div class="card-h">
                <div class="card-icon purple">🔧</div>
                <div><h3 class="card-t">Step 1: Buat Database di cPanel</h3></div>
            </div>
            <div class="vstep"><div class="vstep-n">1</div><div class="vstep-c"><h4 class="vstep-t">Buka MySQL Databases</h4><p class="vstep-d">Di cPanel, cari menu <strong>MySQL® Databases</strong></p></div></div>
            <div class="vstep"><div class="vstep-n">2</div><div class="vstep-c"><h4 class="vstep-t">Buat Database</h4><p class="vstep-d">Isi nama (contoh: <code>toko</code>) → klik <strong>Create Database</strong></p></div></div>
            <div class="vstep"><div class="vstep-n">3</div><div class="vstep-c"><h4 class="vstep-t">Buat User</h4><p class="vstep-d">Scroll ke bawah → buat user + password → <strong>Create User</strong></p></div></div>
            <div class="vstep"><div class="vstep-n">4</div><div class="vstep-c"><h4 class="vstep-t">Assign User</h4><p class="vstep-d">Pilih user & database → <strong>Add</strong> → centang <strong>ALL PRIVILEGES</strong></p></div></div>
        </div>
        
        <!-- SQL -->
        <div class="card">
            <div class="card-h">
                <div class="card-icon orange">📊</div>
                <div><h3 class="card-t">Step 2: Buat Tabel</h3><p class="card-st">Buka phpMyAdmin → tab SQL → paste & jalankan</p></div>
            </div>
            <div class="code">
                <div class="code-h"><span class="code-fn">SQL - Buat Tabel Orders</span><button class="code-cp" onclick="copyCode('code-sql',this)">📋 Copy</button></div>
                <div class="code-b"><pre id="code-sql">CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id VARCHAR(50) UNIQUE,
    customer_name VARCHAR(100),
    customer_email VARCHAR(100),
    customer_phone VARCHAR(20),
    product VARCHAR(255),
    amount INT,
    status ENUM('pending', 'paid', 'shipped', 'completed') DEFAULT 'pending',
    invoice_number VARCHAR(50),
    paid_at DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);</pre></div>
            </div>
        </div>
        
        <!-- Kode Database -->
        <div class="card">
            <div class="card-h">
                <div class="card-icon green">📄</div>
                <div><h3 class="card-t">Step 3: Kode dengan Database</h3></div>
            </div>
            
            <div class="alert alert-d">
                <div class="alert-icon">🚨</div>
                <div><div class="alert-t">Ganti juga:</div><div class="alert-txt"><code>$DB_NAME</code>, <code>$DB_USER</code>, <code>$DB_PASS</code> dengan kredensial database kamu!</div></div>
            </div>
            
            <div class="code">
                <div class="code-h"><span class="code-fn">index.php — Versi Database</span><button class="code-cp" onclick="copyCode('code-db',this)">📋 Copy</button></div>
                <div class="code-b"><pre id="code-db">&lt;?php
// ============================================================
//  NEO PGA - ALL IN ONE (DENGAN DATABASE)
// ============================================================

// KONFIGURASI
$API_KEY    = "<?= $apiKey ?>";
$SECRET_KEY = "<?= $secretKey ?>";
$API_URL    = "<?= $baseUrl ?>/api/create.php";
$MY_DOMAIN  = "https://DOMAINKAMU.com";

// DATABASE - GANTI!
$DB_HOST = "localhost";
$DB_NAME = "username_toko";     // Nama database dari cPanel
$DB_USER = "username_user";     // User database dari cPanel
$DB_PASS = "password123";       // Password database

// Koneksi database
try {
    $db = new PDO("mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4", $DB_USER, $DB_PASS);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Koneksi database gagal: " . $e->getMessage());
}

$action = $_GET['action'] ?? 'home';

// =====================
// CALLBACK
// =====================
if ($action === 'callback') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    $sig = hash_hmac('sha256', json_encode($data['data']), $SECRET_KEY);
    if (!isset($data['signature']) || $data['signature'] !== $sig) {
        http_response_code(401);
        exit('Invalid');
    }
    
    if ($data['event'] === 'payment.success') {
        $orderId = $data['data']['reference_id'];
        $invoice = $data['data']['invoice_number'];
        
        // Update status di database
        $stmt = $db->prepare("UPDATE orders SET status='paid', invoice_number=?, paid_at=NOW() WHERE order_id=? AND status='pending'");
        $stmt->execute([$invoice, $orderId]);
        
        // Notifikasi (opsional)
        // mail(...);
    }
    
    http_response_code(200);
    exit('OK');
}

// =====================
// CHECKOUT
// =====================
if ($action === 'checkout' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $orderId = 'ORD-' . time() . rand(100, 999);
    
    // Simpan ke database DULU (status: pending)
    $stmt = $db->prepare("INSERT INTO orders (order_id, customer_name, customer_email, customer_phone, product, amount) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        $orderId,
        $_POST['name'],
        $_POST['email'],
        $_POST['phone'],
        $_POST['product'] ?? 'Produk',
        (int) $_POST['amount']
    ]);
    
    // Buat pembayaran di NEO PGA
    $data = [
        'amount'         => (int) $_POST['amount'],
        'customer_name'  => $_POST['name'],
        'customer_email' => $_POST['email'],
        'customer_phone' => $_POST['phone'],
        'description'    => $_POST['product'] ?? 'Pembelian',
        'reference_id'   => $orderId,
        'callback_url'   => $MY_DOMAIN . '/index.php?action=callback',
        'redirect_url'   => $MY_DOMAIN . '/index.php?action=sukses&order=' . $orderId
    ];
    
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $API_URL,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => ['X-API-Key: ' . $API_KEY, 'Content-Type: application/json'],
        CURLOPT_POSTFIELDS => json_encode($data)
    ]);
    $result = json_decode(curl_exec($ch), true);
    curl_close($ch);
    
    if ($result && $result['success']) {
        header('Location: ' . $result['data']['payment_url']);
        exit;
    }
    $error = $result['message'] ?? 'Gagal';
}

// =====================
// SUKSES (dengan info order dari database)
// =====================
if ($action === 'sukses') {
    $orderId = $_GET['order'] ?? '';
    $order = null;
    if ($orderId) {
        $stmt = $db->prepare("SELECT * FROM orders WHERE order_id = ?");
        $stmt->execute([$orderId]);
        $order = $stmt->fetch(PDO::FETCH_ASSOC);
    }
    // Tampilkan halaman sukses dengan detail $order
    // ... (sama seperti versi tanpa database)
}

// LANDING PAGE (sama seperti versi tanpa database)
// ...
?></pre></div>
            </div>
        </div>
        
    </div>
    
    <!-- ============================================== -->
    <!-- TAB: METODE NOTIFIKASI -->
    <!-- ============================================== -->
    <div id="tab-notif" class="tc">
        
        <div class="card">
            <div class="card-h">
                <div class="card-icon orange">📱</div>
                <div><h3 class="card-t">Pilih Metode Notifikasi</h3><p class="card-st">Gimana kamu mau dapat notifikasi order?</p></div>
            </div>
            
            <div class="method-grid">
                <div class="method-card rec">
                    <div class="method-icon">📄</div>
                    <div class="method-name">File TXT</div>
                    <div class="method-desc">Simpan ke orders.txt<br>Download dari cPanel</div>
                    <div class="method-badge">RECOMMENDED</div>
                </div>
                <div class="method-card">
                    <div class="method-icon">📱</div>
                    <div class="method-name">Telegram</div>
                    <div class="method-desc">Notifikasi real-time<br>Gratis unlimited</div>
                </div>
                <div class="method-card">
                    <div class="method-icon">✉️</div>
                    <div class="method-name">Email</div>
                    <div class="method-desc">Kirim ke email kamu<br>+ email customer</div>
                </div>
                <div class="method-card">
                    <div class="method-icon">💬</div>
                    <div class="method-name">WhatsApp</div>
                    <div class="method-desc">Via Fonnte/WA Gateway<br>Perlu langganan</div>
                </div>
            </div>
        </div>
        
        <!-- FILE TXT - RECOMMENDED -->
        <div class="card" style="border:2px solid var(--neo)">
            <div class="card-h">
                <div class="card-icon green">📄</div>
                <div><h3 class="card-t">Metode 1: Simpan ke File TXT</h3><p class="card-st">Paling simpel! Cek orders via File Manager cPanel</p></div>
            </div>
            
            <div class="alert alert-s">
                <div class="alert-icon">✅</div>
                <div><div class="alert-txt"><strong>Kenapa Recommended?</strong><br>Tidak perlu setup apa-apa. Data tersimpan permanen di file. Tinggal download kapan saja dari cPanel.</div></div>
            </div>
            
            <div class="vstep"><div class="vstep-n">1</div><div class="vstep-c"><h4 class="vstep-t">Cara Kerja</h4><p class="vstep-d">Setiap ada pembayaran berhasil, data order otomatis ditambahkan ke file <code>orders.txt</code></p></div></div>
            <div class="vstep"><div class="vstep-n">2</div><div class="vstep-c"><h4 class="vstep-t">Cara Cek Order</h4><p class="vstep-d">Login cPanel → File Manager → buka file <code>orders.txt</code> → lihat/download</p></div></div>
            
            <div class="code">
                <div class="code-h"><span class="code-fn">Kode Simpan ke File TXT</span><button class="code-cp" onclick="copyCode('code-txt',this)">📋 Copy</button></div>
                <div class="code-b"><pre id="code-txt">// Setelah pembayaran berhasil, simpan ke file:

$orderData = date('Y-m-d H:i:s') . " | ";
$orderData .= "Order: $orderId | ";
$orderData .= "Customer: $custName | ";
$orderData .= "HP: $custPhone | ";
$orderData .= "Email: $custEmail | ";
$orderData .= "Total: Rp " . number_format($amount) . "\n";
$orderData .= "-------------------------------------------\n";

// Simpan ke file (otomatis buat file jika belum ada)
file_put_contents('orders.txt', $orderData, FILE_APPEND);

// Contoh isi file orders.txt:
// 2024-01-15 10:30:45 | Order: ORD-123 | Customer: John | HP: 081234567890 | Total: Rp 150.000
// -------------------------------------------
// 2024-01-15 11:15:22 | Order: ORD-124 | Customer: Jane | HP: 089876543210 | Total: Rp 299.000
// -------------------------------------------</pre></div>
            </div>
            
            <div class="alert alert-i">
                <div class="alert-icon">💡</div>
                <div><div class="alert-txt"><strong>Tips:</strong> Untuk keamanan, simpan file di luar folder public_html atau tambahkan <code>.htaccess</code> untuk mencegah akses langsung.</div></div>
            </div>
        </div>
        
        <!-- Setup Telegram -->
        <div class="card">
            <div class="card-h">
                <div class="card-icon blue">📱</div>
                <div><h3 class="card-t">Metode 2: Telegram Bot</h3><p class="card-st">Gratis & real-time! Notif langsung ke HP</p></div>
            </div>
            <div class="vstep"><div class="vstep-n">1</div><div class="vstep-c"><h4 class="vstep-t">Buat Bot</h4><p class="vstep-d">Chat <a href="https://t.me/BotFather" target="_blank" style="color:var(--neo);">@BotFather</a> → ketik <code>/newbot</code> → ikuti instruksi → dapat <strong>BOT TOKEN</strong></p></div></div>
            <div class="vstep"><div class="vstep-n">2</div><div class="vstep-c"><h4 class="vstep-t">Dapat Chat ID</h4><p class="vstep-d">Chat bot kamu dulu → lalu buka:<br><code>https://api.telegram.org/bot[TOKEN]/getUpdates</code><br>Cari angka di <code>"chat":{"id":123456789}</code></p></div></div>
            <div class="vstep"><div class="vstep-n">3</div><div class="vstep-c"><h4 class="vstep-t">Aktifkan di Kode</h4><p class="vstep-d">Uncomment baris Telegram di callback, ganti TOKEN dan CHAT_ID</p></div></div>
            
            <div class="code">
                <div class="code-h"><span class="code-fn">Kode Telegram</span><button class="code-cp" onclick="copyCode('code-tele',this)">📋 Copy</button></div>
                <div class="code-b"><pre id="code-tele">// Di bagian callback, tambahkan:

$telegramToken = '123456789:ABCdefGHIjklMNOpqrsTUVwxyz';  // Dari BotFather
$telegramChatId = '987654321';                            // Chat ID kamu

$msg = "💰 ORDER BARU!
ID: $orderId
Customer: $custName
HP: $custPhone
Total: Rp " . number_format($amount);

file_get_contents("https://api.telegram.org/bot{$telegramToken}/sendMessage?chat_id={$telegramChatId}&text=" . urlencode($msg));</pre></div>
            </div>
        </div>
        
        <!-- Email -->
        <div class="card">
            <div class="card-h">
                <div class="card-icon purple">✉️</div>
                <div><h3 class="card-t">Metode 3: Email</h3><p class="card-st">Pakai fungsi mail() bawaan PHP</p></div>
            </div>
            <div class="code">
                <div class="code-h"><span class="code-fn">Kode Email</span><button class="code-cp" onclick="copyCode('code-email',this)">📋 Copy</button></div>
                <div class="code-b"><pre id="code-email">// Email ke kamu (admin)
mail(
    'emailkamu@gmail.com',
    '💰 Order Baru - ' . $orderId,
    "Order ID: $orderId\nCustomer: $custName\nHP: $custPhone\nEmail: $custEmail\n\nTotal: Rp " . number_format($amount)
);

// Email ke customer
mail(
    $custEmail,
    'Pembayaran Berhasil - Terima Kasih!',
    "Halo $custName,\n\nPembayaran sebesar Rp " . number_format($amount) . " sudah kami terima.\n\nOrder ID: $orderId\n\nTerima kasih telah berbelanja!"
);</pre></div>
            </div>
            <div class="alert alert-w">
                <div class="alert-icon">⚠️</div>
                <div><div class="alert-txt">Fungsi <code>mail()</code> mungkin masuk spam. Untuk email lebih reliable, gunakan SMTP (PHPMailer) atau layanan seperti SendGrid, Mailgun.</div></div>
            </div>
        </div>
        
        <!-- WhatsApp -->
        <div class="card">
            <div class="card-h">
                <div class="card-icon green">💬</div>
                <div><h3 class="card-t">Metode 4: WhatsApp</h3><p class="card-st">Via Fonnte atau WA Gateway lainnya</p></div>
            </div>
            
            <div class="alert alert-w">
                <div class="alert-icon">💰</div>
                <div><div class="alert-txt"><strong>Perlu Langganan:</strong> WhatsApp Business API berbayar. Alternatif murah: <a href="https://fonnte.com" target="_blank" style="color:#f59e0b">Fonnte.com</a> (mulai Rp 25rb/bulan)</div></div>
            </div>
            
            <div class="vstep"><div class="vstep-n">1</div><div class="vstep-c"><h4 class="vstep-t">Daftar Fonnte</h4><p class="vstep-d">Buat akun di <a href="https://fonnte.com" target="_blank" style="color:var(--neo)">fonnte.com</a> → Connect WhatsApp → Dapat <strong>API Token</strong></p></div></div>
            <div class="vstep"><div class="vstep-n">2</div><div class="vstep-c"><h4 class="vstep-t">Pasang Kode</h4><p class="vstep-d">Tambahkan kode di bawah setelah pembayaran berhasil</p></div></div>
            
            <div class="code">
                <div class="code-h"><span class="code-fn">Kode WhatsApp (Fonnte)</span><button class="code-cp" onclick="copyCode('code-wa',this)">📋 Copy</button></div>
                <div class="code-b"><pre id="code-wa">// Notifikasi WhatsApp via Fonnte

$fonnte_token = 'TOKEN_DARI_FONNTE';  // Ganti dengan token kamu
$target = '08123456789';               // No HP tujuan (bisa array untuk banyak)

$message = "🛒 *ORDER BARU!*

📋 Order ID: $orderId
👤 Customer: $custName  
📱 HP: $custPhone
📧 Email: $custEmail

💰 *Total: Rp " . number_format($amount) . "*

_Notifikasi otomatis dari NEO PGA_";

// Kirim via Fonnte API
$curl = curl_init();
curl_setopt_array($curl, [
    CURLOPT_URL => 'https://api.fonnte.com/send',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => [
        'target' => $target,
        'message' => $message,
    ],
    CURLOPT_HTTPHEADER => [
        'Authorization: ' . $fonnte_token
    ],
]);
$response = curl_exec($curl);
curl_close($curl);</pre></div>
            </div>
            
            <div class="alert alert-i">
                <div class="alert-icon">💡</div>
                <div><div class="alert-txt"><strong>Alternatif WhatsApp Gateway:</strong><br>
                • <a href="https://wablas.com" target="_blank" style="color:#3b82f6">Wablas.com</a> - Mulai Rp 99rb/bulan<br>
                • <a href="https://wa.srv2.me" target="_blank" style="color:#3b82f6">WaSendit</a> - Mulai Rp 50rb/bulan<br>
                • <a href="https://ruangwa.id" target="_blank" style="color:#3b82f6">RuangWA</a> - Mulai Rp 30rb/bulan
                </div></div>
            </div>
        </div>
        
    </div>
    
</div>

<script>
function showTab(id) {
    document.querySelectorAll('.tc').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.getElementById('tab-' + id).classList.add('active');
    event.target.classList.add('active');
}

function copyC(id, btn) {
    navigator.clipboard.writeText(document.getElementById(id).innerText).then(() => {
        btn.innerText = '✓ Copied!';
        btn.classList.add('copied');
        setTimeout(() => { btn.innerText = '📋 Copy'; btn.classList.remove('copied'); }, 2000);
    });
}

function copyCode(id, btn) {
    const code = document.getElementById(id).innerText;
    navigator.clipboard.writeText(code).then(() => {
        btn.innerText = '✓ Copied!';
        btn.classList.add('copied');
        setTimeout(() => { btn.innerText = '📋 Copy'; btn.classList.remove('copied'); }, 2000);
    });
}

function toggleChk(el) {
    el.classList.toggle('checked');
    el.closest('.chk-item').classList.toggle('done');
    el.innerHTML = el.classList.contains('checked') ? '✓' : '';
}
</script>

<?php include __DIR__ . '/layout_footer.php'; ?>

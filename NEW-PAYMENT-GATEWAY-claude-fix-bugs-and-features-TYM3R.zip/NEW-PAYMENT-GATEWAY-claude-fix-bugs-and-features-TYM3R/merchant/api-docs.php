<?php
/**
 * NEO PGA - API Documentation Redirect
 * Redirects to main documentation page
 */

// Redirect ke halaman dokumentasi utama
header('Location: dokumentasi.php');
exit;

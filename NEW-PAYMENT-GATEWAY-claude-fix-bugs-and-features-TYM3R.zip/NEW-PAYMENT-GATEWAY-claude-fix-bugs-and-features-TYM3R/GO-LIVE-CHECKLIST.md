# NEO PGA - Go Live Checklist

Checklist ini WAJIB diikuti sebelum sistem go live ke production.

---

## 🔴 CRITICAL - Harus Diubah Sebelum Go Live

### 1. Config Production (`config/config.php`)

```php
// UBAH INI:
ini_set('display_errors', 0);  // JANGAN tampilkan error ke user
define('APP_ENV', 'production');
define('APP_DEBUG', false);
define('APP_URL', 'https://domain-production-anda.com');
```

### 2. Ganti Password Default

| Akun | Email | Password Default | Action |
|------|-------|------------------|--------|
| Super Admin | admin@neopga.com | admin123 | **GANTI SEGERA!** |
| Demo Merchant | demo@neopga.com | admin123 | **HAPUS atau DISABLE!** |

### 3. Ganti API Keys Demo Merchant

```
Demo API Key: nb_live_demo_api_key_2024
Demo Secret: nb_secret_demo_key_2024
```
**Action:** Hapus demo merchant atau generate key baru

### 4. Update Bank Accounts

Bank accounts di database masih dummy:
- BCA: 1234567890
- Mandiri: 1234567890123
- dll.

**Action:** Update dengan nomor rekening ASLI di Admin Panel → Bank Accounts

### 5. QRIS Settings

File `includes/QRISGenerator.php` sudah punya NMID VOKENTRA:
```
NMID: ID1025436258392
GoPay ID: 936009143670340254
```
**Action:** Pastikan ini adalah QRIS yang benar untuk menerima pembayaran

---

## 🟡 IMPORTANT - Harus Dikonfigurasi

### 6. Setup Cron Job

Di cPanel → Cron Jobs, tambahkan:

```
# Jalankan setiap 5 menit
*/5 * * * * /usr/bin/php /path/to/neopga/cron.php

# ATAU via URL (ganti key)
*/5 * * * * wget -q -O /dev/null "https://domain.com/cron.php?key=neobayar_cron_2024"
```

**Fungsi Cron:**
- Auto-expire transaksi timeout
- Auto-reset payment codes
- Retry failed webhooks
- Cleanup old logs

### 7. SSL Certificate

- [ ] Pastikan HTTPS aktif
- [ ] Force redirect HTTP → HTTPS
- [ ] SSL certificate valid (tidak expired)

### 8. .htaccess Security

Pastikan ada file `.htaccess` di root:
```apache
# Protect sensitive files
<FilesMatch "^(config\.php|\.env|\.git)">
    Order allow,deny
    Deny from all
</FilesMatch>

# Force HTTPS
RewriteEngine On
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
```

### 9. Create Logs Directory

```bash
mkdir -p logs
chmod 755 logs
```

### 10. File Permissions

```bash
# Directories
chmod 755 uploads/
chmod 755 logs/

# Config files (read only)
chmod 644 config/config.php
```

---

## 🟢 RECOMMENDED - Best Practices

### 11. Backup Strategy

- [ ] Setup daily database backup
- [ ] Backup to external storage (Google Drive, S3, dll)
- [ ] Test restore procedure

### 12. Monitoring

- [ ] Setup uptime monitoring (UptimeRobot, Pingdom)
- [ ] Setup error alerting
- [ ] Monitor disk space

### 13. Rate Limiting

Sudah ada di sistem:
- 100 requests/minute per API key
- 60 requests/minute per IP

### 14. Remove Test Data

```sql
-- Hapus transaksi test
DELETE FROM transactions WHERE merchant_id = 1;

-- Hapus demo merchant (opsional)
DELETE FROM merchants WHERE merchant_code = 'DEMO001';
```

---

## ✅ Final Verification

### Test Flow Sebelum Go Live:

1. **Register Merchant Baru**
   - [ ] Register berhasil
   - [ ] Email verifikasi (jika aktif)
   - [ ] Admin bisa approve

2. **Login Merchant**
   - [ ] Login berhasil
   - [ ] Dashboard tampil benar
   - [ ] Balance = 0

3. **Generate API Keys**
   - [ ] API Key ter-generate
   - [ ] Secret Key ter-generate
   - [ ] Bisa copy ke clipboard

4. **Buat Transaksi via API**
   - [ ] POST /api/create.php berhasil
   - [ ] QRIS code ter-generate
   - [ ] Unique code benar

5. **Payment Page**
   - [ ] Halaman bayar tampil
   - [ ] QR code scannable
   - [ ] Countdown timer jalan

6. **Verifikasi Pembayaran**
   - [ ] Admin bisa verifikasi
   - [ ] Balance merchant bertambah
   - [ ] Webhook terkirim

7. **Settlement**
   - [ ] Merchant bisa request settlement
   - [ ] Admin bisa approve/reject
   - [ ] Balance berkurang setelah approve

---

## 📋 Summary Status

| Area | Status | Notes |
|------|--------|-------|
| Merchant Dashboard | ✅ Ready | Auto-refresh, push notif |
| Admin Panel | ✅ Ready | Full CRUD, auto-reset |
| Demo Store | ✅ Ready | Full integration |
| API Endpoints | ✅ Ready | Rate limited |
| Database | ✅ Ready | v2.4.0, optimized |
| Core Classes | ✅ Ready | All tested |
| **Config Production** | ⚠️ TODO | Ubah sebelum go live |
| **Credentials** | ⚠️ TODO | Ganti semua default |
| **Cron Job** | ⚠️ TODO | Setup di cPanel |

---

## 🚀 Go Live Command

Setelah semua checklist selesai:

```bash
# 1. Set production mode
# Edit config/config.php

# 2. Clear any test data
# Via phpMyAdmin atau SQL

# 3. Test final
# Buat 1 transaksi test end-to-end

# 4. GO LIVE! 🎉
```

---

*Checklist dibuat: 15 Desember 2025*
*NEO PGA Version: 2.0.0*
*Database Version: 2.4.0*

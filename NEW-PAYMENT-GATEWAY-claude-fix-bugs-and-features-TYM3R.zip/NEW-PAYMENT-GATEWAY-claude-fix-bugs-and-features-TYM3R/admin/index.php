<?php
/**
 * NEO PGA Admin - Dashboard
 * Modern Admin Dashboard - Consistent Design
 */
require_once __DIR__ . '/../includes/init.php';

$auth = new Auth('admin');
$auth->requireAuth();

$adminUser = $auth->user();
$db = Database::getInstance();

// =============================================
// AUTO-RESET KODE UNIK YANG HAMPIR HABIS
// Threshold: 5 atau kurang kode tersedia
// Dijalankan di setiap halaman admin utama
// =============================================
$merchantsNeedingReset = $db->fetchAll(
    "SELECT m.id, m.business_name,
            COUNT(CASE WHEN pc.status = 'available' THEN 1 END) as available,
            COUNT(CASE WHEN pc.status = 'used' THEN 1 END) as used
     FROM merchants m
     LEFT JOIN payment_codes pc ON m.id = pc.merchant_id
     GROUP BY m.id
     HAVING available <= 5 AND used > 0"
);

foreach ($merchantsNeedingReset as $m) {
    $db->query(
        "UPDATE payment_codes
         SET status = 'available',
             transaction_id = NULL,
             reserved_at = NULL,
             expires_at = NULL,
             used_at = NULL
         WHERE merchant_id = ? AND status = 'used'",
        [$m['id']]
    );
    $resetCount = $db->rowCount();
    if ($resetCount > 0) {
        logActivity('system', null, 'payment_code_auto_reset_dashboard', 'payment_codes',
            "Auto-reset {$resetCount} codes for merchant #{$m['id']} - triggered by dashboard");
    }
}

// Today's stats
$today = date('Y-m-d');
$yesterday = date('Y-m-d', strtotime('-1 day'));

$todayStats = $db->fetch(
    "SELECT
        COUNT(*) as total,
        SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) as success,
        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
        SUM(CASE WHEN status = 'success' THEN total_amount ELSE 0 END) as amount,
        SUM(CASE WHEN status = 'success' THEN commission_amount ELSE 0 END) as commission
    FROM transactions
    WHERE DATE(created_at) = ?",
    [$today]
);

$yesterdayStats = $db->fetch(
    "SELECT
        SUM(CASE WHEN status = 'success' THEN total_amount ELSE 0 END) as amount
    FROM transactions
    WHERE DATE(created_at) = ?",
    [$yesterday]
);

// Calculate growth
$todayAmount = (float)($todayStats['amount'] ?? 0);
$yesterdayAmount = (float)($yesterdayStats['amount'] ?? 0);
$growth = $yesterdayAmount > 0 ? round((($todayAmount - $yesterdayAmount) / $yesterdayAmount) * 100, 1) : 0;

// This month stats
$thisMonth = date('Y-m');
$monthlyStats = $db->fetch(
    "SELECT
        COUNT(*) as total,
        SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) as success,
        SUM(CASE WHEN status = 'success' THEN total_amount ELSE 0 END) as amount,
        SUM(CASE WHEN status = 'success' THEN commission_amount ELSE 0 END) as commission
    FROM transactions
    WHERE DATE_FORMAT(created_at, '%Y-%m') = ?",
    [$thisMonth]
);

// Quick stats
$activeMerchants = $db->fetch("SELECT COUNT(*) as c FROM merchants WHERE status = 'active'")['c'] ?? 0;
$totalMerchants = $db->fetch("SELECT COUNT(*) as c FROM merchants")['c'] ?? 0;
$pendingSettlements = $db->fetch("SELECT COUNT(*) as c FROM settlements WHERE status = 'pending'")['c'] ?? 0;
$pendingTransactions = $db->fetch("SELECT COUNT(*) as c FROM transactions WHERE status = 'pending'")['c'] ?? 0;
$pendingMerchants = $db->fetch("SELECT COUNT(*) as c FROM merchants WHERE status = 'pending'")['c'] ?? 0;

// Total balance all merchants
$totalBalance = $db->fetch("SELECT SUM(balance) as total FROM merchants WHERE status = 'active'")['total'] ?? 0;

// Chart data - Last 7 days
$chartData = [];
for ($i = 6; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $dayStats = $db->fetch(
        "SELECT
            COALESCE(SUM(CASE WHEN status = 'success' THEN total_amount ELSE 0 END), 0) as amount,
            COUNT(CASE WHEN status = 'success' THEN 1 END) as count
        FROM transactions
        WHERE DATE(created_at) = ?",
        [$date]
    );
    $chartData[] = [
        'date' => date('d M', strtotime($date)),
        'amount' => (int)$dayStats['amount'],
        'count' => (int)$dayStats['count']
    ];
}

// Recent transactions
$recentTrx = $db->fetchAll(
    "SELECT t.*, m.business_name FROM transactions t
    LEFT JOIN merchants m ON t.merchant_id = m.id
    ORDER BY t.created_at DESC LIMIT 8"
);

// Payment method distribution (this month)
$paymentMethods = $db->fetchAll(
    "SELECT payment_method, COUNT(*) as count, SUM(total_amount) as amount
    FROM transactions
    WHERE status = 'success' AND DATE_FORMAT(created_at, '%Y-%m') = ?
    GROUP BY payment_method",
    [$thisMonth]
);

$pageTitle = 'Dashboard';
$currentPage = 'dashboard';

ob_start();
?>

<style>
/* Dashboard Specific Styles */
.dashboard-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 1.25rem;
    margin-bottom: 1.5rem;
}

.stat-card-v2 {
    background: white;
    border-radius: 16px;
    padding: 1.5rem;
    position: relative;
    overflow: hidden;
    border: 1px solid var(--gray-200);
    transition: all 0.3s ease;
}

.stat-card-v2:hover {
    box-shadow: 0 10px 40px rgba(0,0,0,0.08);
    transform: translateY(-2px);
}

.stat-card-v2::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 4px;
}

.stat-card-v2.primary::before { background: linear-gradient(90deg, var(--primary-500), var(--primary-400)); }
.stat-card-v2.success::before { background: linear-gradient(90deg, #10b981, #34d399); }
.stat-card-v2.warning::before { background: linear-gradient(90deg, #f59e0b, #fbbf24); }
.stat-card-v2.info::before { background: linear-gradient(90deg, #3b82f6, #60a5fa); }

.stat-card-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 1rem;
}

.stat-card-icon {
    width: 48px;
    height: 48px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.stat-card-icon svg {
    width: 24px;
    height: 24px;
}

.stat-card-icon.primary { background: var(--primary-100); color: var(--primary-600); }
.stat-card-icon.success { background: #d1fae5; color: #065f46; }
.stat-card-icon.warning { background: #fef3c7; color: #92400e; }
.stat-card-icon.info { background: #dbeafe; color: #1e40af; }

.stat-card-badge {
    display: inline-flex;
    align-items: center;
    gap: 0.25rem;
    padding: 0.25rem 0.6rem;
    border-radius: 99px;
    font-size: 0.7rem;
    font-weight: 600;
}
.stat-card-badge.up { background: #dcfce7; color: #16a34a; }
.stat-card-badge.down { background: #fee2e2; color: #dc2626; }
.stat-card-badge.neutral { background: var(--gray-100); color: var(--gray-600); }

.stat-card-value {
    font-size: 1.75rem;
    font-weight: 800;
    color: var(--gray-900);
    line-height: 1.2;
    margin-bottom: 0.25rem;
}

.stat-card-label {
    font-size: 0.8rem;
    color: var(--gray-500);
}

/* Welcome Banner */
.welcome-banner {
    background: linear-gradient(135deg, var(--primary-600) 0%, var(--primary-700) 50%, var(--primary-900) 100%);
    border-radius: 20px;
    padding: 2rem;
    color: white;
    margin-bottom: 1.5rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
    position: relative;
    overflow: hidden;
}

.welcome-banner::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -20%;
    width: 60%;
    height: 200%;
    background: radial-gradient(ellipse at center, rgba(255,255,255,0.1) 0%, transparent 60%);
    transform: rotate(-15deg);
}

.welcome-content h1 {
    font-size: 1.5rem;
    font-weight: 800;
    margin-bottom: 0.5rem;
}

.welcome-content p {
    opacity: 0.85;
    font-size: 0.95rem;
}

.welcome-stats {
    display: flex;
    gap: 2rem;
    position: relative;
    z-index: 1;
}

.welcome-stat {
    text-align: center;
    padding: 1rem 1.5rem;
    background: rgba(255,255,255,0.1);
    border-radius: 12px;
    backdrop-filter: blur(10px);
}

.welcome-stat-value {
    font-size: 1.5rem;
    font-weight: 800;
    margin-bottom: 0.25rem;
}

.welcome-stat-label {
    font-size: 0.75rem;
    opacity: 0.8;
}

/* Chart Container */
.chart-container {
    background: white;
    border-radius: 16px;
    padding: 1.5rem;
    border: 1px solid var(--gray-200);
    margin-bottom: 1.5rem;
}

.chart-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
}

.chart-title {
    font-size: 1rem;
    font-weight: 700;
    color: var(--gray-800);
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.chart-title svg {
    width: 20px;
    height: 20px;
    color: var(--primary-600);
}

.chart-legend {
    display: flex;
    gap: 1.5rem;
}

.chart-legend-item {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    font-size: 0.8rem;
    color: var(--gray-600);
}

.chart-legend-dot {
    width: 10px;
    height: 10px;
    border-radius: 50%;
}

.chart-area {
    height: 200px;
    display: flex;
    align-items: flex-end;
    gap: 12px;
    padding: 0 0.5rem;
}

.chart-bar-group {
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 0.5rem;
}

.chart-bar {
    width: 100%;
    max-width: 40px;
    background: linear-gradient(180deg, var(--primary-500) 0%, var(--primary-400) 100%);
    border-radius: 8px 8px 0 0;
    transition: all 0.3s ease;
    min-height: 4px;
    position: relative;
}

.chart-bar:hover {
    transform: scaleY(1.05);
    box-shadow: 0 -4px 20px rgba(16, 185, 129, 0.3);
}

.chart-bar-label {
    font-size: 0.7rem;
    color: var(--gray-500);
    font-weight: 500;
}

.chart-tooltip {
    position: absolute;
    bottom: 100%;
    left: 50%;
    transform: translateX(-50%);
    background: var(--gray-800);
    color: white;
    padding: 0.4rem 0.75rem;
    border-radius: 6px;
    font-size: 0.7rem;
    font-weight: 600;
    white-space: nowrap;
    opacity: 0;
    transition: opacity 0.2s;
    pointer-events: none;
    margin-bottom: 0.5rem;
}

.chart-bar:hover .chart-tooltip { opacity: 1; }

/* Quick Actions */
.quick-actions {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 1rem;
    margin-bottom: 1.5rem;
}

.quick-action {
    background: white;
    border-radius: 12px;
    padding: 1.25rem;
    text-align: center;
    text-decoration: none;
    border: 1px solid var(--gray-200);
    transition: all 0.2s;
}

.quick-action:hover {
    border-color: var(--primary-500);
    box-shadow: 0 4px 20px rgba(16, 185, 129, 0.15);
    transform: translateY(-2px);
}

.quick-action-icon {
    width: 48px;
    height: 48px;
    margin: 0 auto 0.75rem;
    background: var(--gray-50);
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.quick-action-icon svg {
    width: 24px;
    height: 24px;
    color: var(--primary-600);
}

.quick-action-title {
    font-weight: 600;
    color: var(--gray-800);
    font-size: 0.85rem;
}

.quick-action-badge {
    display: inline-block;
    background: var(--danger);
    color: white;
    font-size: 0.65rem;
    font-weight: 700;
    padding: 0.15rem 0.5rem;
    border-radius: 99px;
    margin-left: 0.25rem;
}

/* Main Grid */
.main-grid {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 1.5rem;
}

/* Data Card */
.data-card {
    background: white;
    border-radius: 16px;
    border: 1px solid var(--gray-200);
    overflow: hidden;
}

.data-card-header {
    padding: 1.25rem 1.5rem;
    border-bottom: 1px solid var(--gray-100);
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.data-card-title {
    font-weight: 700;
    color: var(--gray-800);
    font-size: 1rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.data-card-title svg {
    width: 20px;
    height: 20px;
    color: var(--primary-600);
}

.data-card-body { padding: 0; }
.data-card-body.padded { padding: 1.5rem; }

/* Mini Stats */
.mini-stat {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0.875rem 0;
    border-bottom: 1px solid var(--gray-50);
}

.mini-stat:last-child { border-bottom: none; }

.mini-stat-label {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    color: var(--gray-600);
    font-size: 0.875rem;
}

.mini-stat-icon {
    width: 32px;
    height: 32px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.mini-stat-icon svg {
    width: 16px;
    height: 16px;
}

.mini-stat-value {
    font-weight: 700;
    color: var(--gray-900);
}

/* Progress Ring */
.progress-ring {
    position: relative;
    width: 100px;
    height: 100px;
    margin: 0 auto 1rem;
}

.progress-ring-circle {
    fill: none;
    stroke-width: 8;
    stroke-linecap: round;
    transform: rotate(-90deg);
    transform-origin: 50% 50%;
}

.progress-ring-bg { stroke: var(--gray-100); }
.progress-ring-progress { stroke: var(--primary-500); transition: stroke-dashoffset 0.5s ease; }

.progress-ring-text {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    text-align: center;
}

.progress-ring-value {
    font-size: 1.5rem;
    font-weight: 800;
    color: var(--gray-900);
    line-height: 1;
}

.progress-ring-label {
    font-size: 0.65rem;
    color: var(--gray-500);
    margin-top: 0.25rem;
}

/* Payment Method Pills */
.payment-pills {
    display: flex;
    flex-direction: column;
    gap: 0.75rem;
}

.payment-pill {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    padding: 0.75rem;
    background: var(--gray-50);
    border-radius: 10px;
}

.payment-pill-icon {
    width: 36px;
    height: 36px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.payment-pill-icon svg {
    width: 18px;
    height: 18px;
}

.payment-pill-icon.qris { background: #d1fae5; color: #065f46; }
.payment-pill-icon.bank { background: #dbeafe; color: #1e40af; }

.payment-pill-info { flex: 1; }
.payment-pill-name { font-weight: 600; font-size: 0.85rem; color: var(--gray-800); }
.payment-pill-count { font-size: 0.75rem; color: var(--gray-500); }
.payment-pill-amount { font-weight: 700; color: var(--gray-900); font-size: 0.9rem; }

/* Empty state */
.empty-state {
    padding: 3rem;
    text-align: center;
    color: var(--gray-400);
}

.empty-state svg {
    width: 48px;
    height: 48px;
    margin: 0 auto 0.5rem;
    color: var(--gray-300);
}

@media (max-width: 1200px) {
    .dashboard-grid { grid-template-columns: repeat(2, 1fr); }
    .main-grid { grid-template-columns: 1fr; }
    .quick-actions { grid-template-columns: repeat(2, 1fr); }
}

@media (max-width: 768px) {
    .dashboard-grid { grid-template-columns: 1fr; }
    .welcome-banner { flex-direction: column; text-align: center; }
    .welcome-stats { margin-top: 1.5rem; flex-wrap: wrap; justify-content: center; }
    .quick-actions { grid-template-columns: 1fr 1fr; }
}
</style>

<!-- Welcome Banner -->
<div class="welcome-banner">
    <div class="welcome-content">
        <h1>Halo, <?= htmlspecialchars($adminUser['full_name'] ?? $adminUser['username'] ?? 'Admin') ?>!</h1>
        <p>Ini ringkasan aktivitas payment gateway <?= APP_NAME ?> hari ini</p>
    </div>
    <div class="welcome-stats">
        <div class="welcome-stat">
            <div class="welcome-stat-value"><?= number_format($todayStats['success'] ?? 0) ?></div>
            <div class="welcome-stat-label">Transaksi Sukses</div>
        </div>
        <div class="welcome-stat">
            <div class="welcome-stat-value">Rp <?= number_format($todayAmount / 1000000, 1) ?>jt</div>
            <div class="welcome-stat-label">Volume Hari Ini</div>
        </div>
        <div class="welcome-stat">
            <div class="welcome-stat-value"><?= $activeMerchants ?></div>
            <div class="welcome-stat-label">Merchant Aktif</div>
        </div>
    </div>
</div>

<!-- Alerts -->
<?php if ($pendingMerchants > 0 || $pendingSettlements > 0): ?>
<div class="alert alert-warning mb-4" style="display:flex;justify-content:space-between;align-items:center">
    <div>
        <strong>Perlu Tindakan:</strong>
        <?php if ($pendingMerchants > 0): ?>
            <span><?= $pendingMerchants ?> merchant pending approval</span>
        <?php endif; ?>
        <?php if ($pendingSettlements > 0): ?>
            <span style="margin-left:1rem"><?= $pendingSettlements ?> settlement pending</span>
        <?php endif; ?>
    </div>
    <div style="display:flex;gap:0.5rem">
        <?php if ($pendingMerchants > 0): ?>
        <a href="merchants.php?status=pending" class="btn btn-sm btn-primary">Review Merchant</a>
        <?php endif; ?>
        <?php if ($pendingSettlements > 0): ?>
        <a href="settlements.php?status=pending" class="btn btn-sm btn-secondary">Review Settlement</a>
        <?php endif; ?>
    </div>
</div>
<?php endif; ?>

<!-- Quick Actions -->
<div class="quick-actions">
    <a href="verify.php" class="quick-action">
        <div class="quick-action-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M22 11.08V12a10 10 0 11-5.93-9.14"/>
                <polyline points="22,4 12,14.01 9,11.01"/>
            </svg>
        </div>
        <div class="quick-action-title">Verifikasi Pembayaran</div>
    </a>
    <a href="transactions.php?status=pending" class="quick-action">
        <div class="quick-action-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/>
            </svg>
        </div>
        <div class="quick-action-title">Transaksi Pending<?php if ($pendingTransactions > 0): ?><span class="quick-action-badge"><?= $pendingTransactions ?></span><?php endif; ?></div>
    </a>
    <a href="merchants.php?status=pending" class="quick-action">
        <div class="quick-action-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M3 3h18v18H3zM3 9h18M9 21V9"/>
            </svg>
        </div>
        <div class="quick-action-title">Approve Merchant<?php if ($pendingMerchants > 0): ?><span class="quick-action-badge"><?= $pendingMerchants ?></span><?php endif; ?></div>
    </a>
    <a href="settlements.php" class="quick-action">
        <div class="quick-action-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <rect x="2" y="4" width="20" height="16" rx="2"/>
                <path d="M12 10v4M10 12h4"/>
            </svg>
        </div>
        <div class="quick-action-title">Proses Settlement<?php if ($pendingSettlements > 0): ?><span class="quick-action-badge"><?= $pendingSettlements ?></span><?php endif; ?></div>
    </a>
</div>

<!-- Stats Cards -->
<div class="dashboard-grid">
    <div class="stat-card-v2 primary">
        <div class="stat-card-header">
            <div class="stat-card-icon primary">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                </svg>
            </div>
            <?php if ($growth != 0): ?>
            <span class="stat-card-badge <?= $growth > 0 ? 'up' : 'down' ?>"><?= $growth > 0 ? '↑' : '↓' ?> <?= abs($growth) ?>%</span>
            <?php else: ?>
            <span class="stat-card-badge neutral">—</span>
            <?php endif; ?>
        </div>
        <div class="stat-card-value">Rp <?= number_format($todayAmount, 0, ',', '.') ?></div>
        <div class="stat-card-label">Pendapatan Hari Ini</div>
    </div>

    <div class="stat-card-v2 success">
        <div class="stat-card-header">
            <div class="stat-card-icon success">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M5 13l4 4L19 7"/>
                </svg>
            </div>
        </div>
        <div class="stat-card-value"><?= number_format($todayStats['total'] ?? 0) ?></div>
        <div class="stat-card-label">Total Transaksi Hari Ini</div>
    </div>

    <div class="stat-card-v2 warning">
        <div class="stat-card-header">
            <div class="stat-card-icon warning">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <rect x="2" y="4" width="20" height="16" rx="2"/>
                    <path d="M7 15h0M2 9h20"/>
                </svg>
            </div>
        </div>
        <div class="stat-card-value">Rp <?= number_format($todayStats['commission'] ?? 0, 0, ',', '.') ?></div>
        <div class="stat-card-label">Komisi Hari Ini</div>
    </div>

    <div class="stat-card-v2 info">
        <div class="stat-card-header">
            <div class="stat-card-icon info">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M18 20V10"/>
                    <path d="M12 20V4"/>
                    <path d="M6 20v-6"/>
                </svg>
            </div>
        </div>
        <div class="stat-card-value">Rp <?= number_format($monthlyStats['amount'] ?? 0, 0, ',', '.') ?></div>
        <div class="stat-card-label">Total Bulan Ini</div>
    </div>
</div>

<!-- Chart -->
<div class="chart-container">
    <div class="chart-header">
        <div class="chart-title">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"/>
            </svg>
            Transaksi 7 Hari Terakhir
        </div>
        <div class="chart-legend">
            <div class="chart-legend-item">
                <span class="chart-legend-dot" style="background:var(--primary-500)"></span>
                Volume Transaksi
            </div>
        </div>
    </div>
    <div class="chart-area">
        <?php
        $maxAmount = max(array_column($chartData, 'amount')) ?: 1;
        foreach ($chartData as $day):
            $height = max(4, ($day['amount'] / $maxAmount) * 180);
        ?>
        <div class="chart-bar-group">
            <div class="chart-bar" style="height: <?= $height ?>px">
                <div class="chart-tooltip">Rp <?= number_format($day['amount'], 0, ',', '.') ?><br><?= $day['count'] ?> trx</div>
            </div>
            <span class="chart-bar-label"><?= $day['date'] ?></span>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- Main Grid -->
<div class="main-grid">
    <!-- Recent Transactions -->
    <div class="data-card">
        <div class="data-card-header">
            <span class="data-card-title">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/>
                </svg>
                Transaksi Terbaru
            </span>
            <a href="transactions.php" class="btn btn-sm btn-secondary">Lihat Semua</a>
        </div>
        <div class="data-card-body">
            <?php if (empty($recentTrx)): ?>
            <div class="empty-state">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                    <path d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"/>
                </svg>
                <div>Belum ada transaksi</div>
            </div>
            <?php else: ?>
            <table class="table" style="margin:0">
                <thead>
                    <tr>
                        <th>Invoice</th>
                        <th>Merchant</th>
                        <th>Customer</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Waktu</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recentTrx as $trx): ?>
                    <tr>
                        <td>
                            <a href="transactions.php?invoice=<?= urlencode($trx['invoice_number']) ?>" style="color:var(--primary-600);text-decoration:none;font-family:monospace;font-size:0.75rem">
                                <?= htmlspecialchars(substr($trx['invoice_number'], -12)) ?>
                            </a>
                        </td>
                        <td style="font-size:0.85rem"><?= htmlspecialchars($trx['business_name'] ?? '-') ?></td>
                        <td style="font-size:0.85rem"><?= htmlspecialchars($trx['customer_name']) ?></td>
                        <td style="font-weight:600">Rp <?= number_format($trx['total_amount'], 0, ',', '.') ?></td>
                        <td>
                            <?php
                            $statusColors = [
                                'success' => 'success',
                                'pending' => 'warning',
                                'waiting' => 'info',
                                'failed' => 'danger',
                                'expired' => 'neutral',
                                'cancelled' => 'neutral'
                            ];
                            $color = $statusColors[$trx['status']] ?? 'neutral';
                            ?>
                            <span class="badge badge-<?= $color ?>"><?= ucfirst($trx['status']) ?></span>
                        </td>
                        <td style="font-size:0.75rem;color:var(--gray-500)"><?= date('d/m H:i', strtotime($trx['created_at'])) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
    </div>

    <!-- Sidebar -->
    <div>
        <!-- Success Rate -->
        <div class="data-card" style="margin-bottom:1.5rem">
            <div class="data-card-header">
                <span class="data-card-title">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M11 3.055A9.001 9.001 0 1020.945 13H11V3.055z"/>
                        <path d="M20.488 9H15V3.512A9.025 9.025 0 0120.488 9z"/>
                    </svg>
                    Success Rate
                </span>
            </div>
            <div class="data-card-body padded" style="text-align:center">
                <?php
                $totalTrx = (int)($monthlyStats['total'] ?? 0);
                $successTrx = (int)($monthlyStats['success'] ?? 0);
                $successRate = $totalTrx > 0 ? round(($successTrx / $totalTrx) * 100) : 0;
                $circumference = 2 * pi() * 42;
                $dashoffset = $circumference - ($successRate / 100) * $circumference;
                ?>
                <div class="progress-ring">
                    <svg width="100" height="100">
                        <circle class="progress-ring-circle progress-ring-bg" cx="50" cy="50" r="42" />
                        <circle class="progress-ring-circle progress-ring-progress" cx="50" cy="50" r="42"
                            stroke-dasharray="<?= $circumference ?>"
                            stroke-dashoffset="<?= $dashoffset ?>" />
                    </svg>
                    <div class="progress-ring-text">
                        <div class="progress-ring-value"><?= $successRate ?>%</div>
                        <div class="progress-ring-label">Bulan Ini</div>
                    </div>
                </div>
                <div style="font-size:0.8rem;color:var(--gray-500)">
                    <?= number_format($successTrx) ?> dari <?= number_format($totalTrx) ?> transaksi
                </div>
            </div>
        </div>

        <!-- Payment Methods -->
        <div class="data-card" style="margin-bottom:1.5rem">
            <div class="data-card-header">
                <span class="data-card-title">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <rect x="2" y="4" width="20" height="16" rx="2"/>
                        <path d="M7 15h0M2 9h20"/>
                    </svg>
                    Metode Pembayaran
                </span>
            </div>
            <div class="data-card-body padded">
                <div class="payment-pills">
                    <?php foreach ($paymentMethods as $method): ?>
                    <div class="payment-pill">
                        <div class="payment-pill-icon <?= $method['payment_method'] === 'qris' ? 'qris' : 'bank' ?>">
                            <?php if ($method['payment_method'] === 'qris'): ?>
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <rect x="3" y="3" width="7" height="7"/>
                                <rect x="14" y="3" width="7" height="7"/>
                                <rect x="14" y="14" width="7" height="7"/>
                                <rect x="3" y="14" width="7" height="7"/>
                            </svg>
                            <?php else: ?>
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <rect x="3" y="3" width="18" height="18" rx="2"/>
                                <path d="M3 9h18M9 21V9"/>
                            </svg>
                            <?php endif; ?>
                        </div>
                        <div class="payment-pill-info">
                            <div class="payment-pill-name"><?= strtoupper($method['payment_method'] === 'bank_transfer' ? 'Bank Transfer' : $method['payment_method']) ?></div>
                            <div class="payment-pill-count"><?= number_format($method['count']) ?> transaksi</div>
                        </div>
                        <div class="payment-pill-amount">Rp <?= number_format($method['amount'] / 1000000, 1) ?>jt</div>
                    </div>
                    <?php endforeach; ?>
                    <?php if (empty($paymentMethods)): ?>
                    <div style="text-align:center;color:var(--gray-400);padding:1rem">Belum ada data</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Quick Stats -->
        <div class="data-card">
            <div class="data-card-header">
                <span class="data-card-title">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M13 10V3L4 14h7v7l9-11h-7z"/>
                    </svg>
                    Statistik Cepat
                </span>
            </div>
            <div class="data-card-body padded">
                <div class="mini-stat">
                    <div class="mini-stat-label">
                        <div class="mini-stat-icon" style="background:#d1fae5;color:#065f46">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M3 3h18v18H3zM3 9h18M9 21V9"/>
                            </svg>
                        </div>
                        Merchant Aktif
                    </div>
                    <div class="mini-stat-value"><?= $activeMerchants ?> / <?= $totalMerchants ?></div>
                </div>
                <div class="mini-stat">
                    <div class="mini-stat-label">
                        <div class="mini-stat-icon" style="background:#fef3c7;color:#92400e">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <circle cx="12" cy="12" r="10"/>
                                <polyline points="12,6 12,12 16,14"/>
                            </svg>
                        </div>
                        Merchant Pending
                    </div>
                    <div class="mini-stat-value" style="color:var(--warning)"><?= $pendingMerchants ?></div>
                </div>
                <div class="mini-stat">
                    <div class="mini-stat-label">
                        <div class="mini-stat-icon" style="background:#dbeafe;color:#1e40af">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <rect x="2" y="4" width="20" height="16" rx="2"/>
                                <path d="M12 10v4M10 12h4"/>
                            </svg>
                        </div>
                        Settlement Pending
                    </div>
                    <div class="mini-stat-value" style="color:var(--info)"><?= $pendingSettlements ?></div>
                </div>
                <div class="mini-stat">
                    <div class="mini-stat-label">
                        <div class="mini-stat-icon" style="background:#f3e8ff;color:#7c3aed">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                            </svg>
                        </div>
                        Total Saldo Merchant
                    </div>
                    <div class="mini-stat-value">Rp <?= number_format($totalBalance / 1000000, 1) ?>jt</div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
$content = ob_get_clean();
include __DIR__ . '/layout.php';
?>

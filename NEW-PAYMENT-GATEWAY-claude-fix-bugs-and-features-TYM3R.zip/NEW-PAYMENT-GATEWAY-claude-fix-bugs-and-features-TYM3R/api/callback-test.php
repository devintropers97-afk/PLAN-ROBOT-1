<?php
/**
 * NEO PGA - Webhook Callback Tester
 *
 * Gunakan endpoint ini untuk testing webhook
 * Akan menampilkan data yang diterima
 *
 * CATATAN: Endpoint ini untuk development/testing saja!
 * Sebaiknya hapus atau proteksi di production.
 */

header('Content-Type: application/json');

// Rate limiting sederhana untuk mencegah log flooding
$rateLimitFile = __DIR__ . '/../cache/webhook_test_ratelimit.json';
$rateLimit = 100; // Max requests per hour
$rateLimitWindow = 3600; // 1 hour

$clientIP = $_SERVER['HTTP_CF_CONNECTING_IP'] ?? $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? 'unknown';
$clientIP = explode(',', $clientIP)[0]; // Get first IP if multiple

// Create cache directory if not exists
$cacheDir = __DIR__ . '/../cache';
if (!is_dir($cacheDir)) {
    @mkdir($cacheDir, 0755, true);
}

// Check rate limit
$rateLimitData = [];
if (file_exists($rateLimitFile)) {
    $rateLimitData = json_decode(file_get_contents($rateLimitFile), true) ?? [];
}

// Clean old entries
$now = time();
foreach ($rateLimitData as $ip => $data) {
    if ($data['window_start'] < ($now - $rateLimitWindow)) {
        unset($rateLimitData[$ip]);
    }
}

// Check this IP
if (isset($rateLimitData[$clientIP])) {
    if ($rateLimitData[$clientIP]['count'] >= $rateLimit) {
        http_response_code(429);
        echo json_encode([
            'success' => false,
            'message' => 'Rate limit exceeded. Try again later.',
            'retry_after' => ($rateLimitData[$clientIP]['window_start'] + $rateLimitWindow) - $now
        ]);
        exit;
    }
    $rateLimitData[$clientIP]['count']++;
} else {
    $rateLimitData[$clientIP] = [
        'count' => 1,
        'window_start' => $now
    ];
}

// Save rate limit data
@file_put_contents($rateLimitFile, json_encode($rateLimitData));

// Log incoming request
$logData = [
    'timestamp' => date('Y-m-d H:i:s'),
    'method' => $_SERVER['REQUEST_METHOD'],
    'headers' => getallheaders(),
    'body' => file_get_contents('php://input'),
    'get' => $_GET,
    'post' => $_POST,
    'ip' => $clientIP
];

// Limit log file size (max 10MB per day)
$logFile = __DIR__ . '/../logs/webhook_test_' . date('Y-m-d') . '.log';
$maxLogSize = 10 * 1024 * 1024; // 10MB

if (!file_exists($logFile) || filesize($logFile) < $maxLogSize) {
    // Create logs directory if not exists
    $logsDir = dirname($logFile);
    if (!is_dir($logsDir)) {
        @mkdir($logsDir, 0755, true);
    }
    @file_put_contents($logFile, json_encode($logData, JSON_PRETTY_PRINT) . "\n\n", FILE_APPEND);
}

// Return success
echo json_encode([
    'success' => true,
    'message' => 'Webhook received successfully',
    'received_at' => $logData['timestamp'],
    'data' => json_decode($logData['body'], true)
]);

<?php
/**
 * =========================================================
 * DIGISTORE - Landing Page Terintegrasi dengan NEO PGA
 * =========================================================
 * 
 * PANDUAN UNTUK PEMULA:
 * 1. Upload file ini ke hosting kamu
 * 2. Ganti API_KEY dan SECRET_KEY dengan milik kamu
 * 3. Ganti NEOPGA_URL dengan URL NEO PGA kamu
 * 4. Selesai! Landing page sudah bisa menerima pembayaran
 * 
 * BUTUH BANTUAN?
 * WhatsApp: 0895-3434-07575
 * Kirim: URL website + akses cPanel
 * Kami bantu setup sampai jalan!
 * =========================================================
 */

// ============================================
// KONFIGURASI - GANTI DENGAN DATA KAMU!
// ============================================
define('NEOPGA_URL', 'https://neopga.com');  // Ganti dengan URL NEO PGA kamu
define('API_KEY', 'nb_live_xxxxx');               // Ganti dengan API Key kamu
define('SECRET_KEY', 'nb_secret_xxxxx');          // Ganti dengan Secret Key kamu

// ============================================
// PROSES PEMBAYARAN
// ============================================
$paymentResult = null;
$paymentError = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'create_payment') {
    
    // Ambil data dari form
    $orderId = 'ORD-' . time() . '-' . strtoupper(substr(md5(rand()), 0, 6));
    $amount = intval($_POST['amount']);
    $productName = htmlspecialchars($_POST['product_name']);
    $customerName = htmlspecialchars($_POST['customer_name']);
    $customerEmail = filter_var($_POST['customer_email'], FILTER_SANITIZE_EMAIL);
    $customerPhone = preg_replace('/[^0-9]/', '', $_POST['customer_phone']);
    $paymentMethod = $_POST['payment_method'];
    
    // Validasi
    if ($amount < 1000) {
        $paymentError = 'Minimal pembayaran Rp 1.000';
    } elseif (!filter_var($customerEmail, FILTER_VALIDATE_EMAIL)) {
        $paymentError = 'Email tidak valid';
    } elseif (strlen($customerPhone) < 10) {
        $paymentError = 'No. HP tidak valid';
    } else {
        // Kirim ke NEO PGA API
        $data = [
            'order_id' => $orderId,
            'amount' => $amount,
            'customer_name' => $customerName,
            'customer_email' => $customerEmail,
            'customer_phone' => $customerPhone,
            'payment_method' => $paymentMethod,
            'description' => 'Pembelian: ' . $productName,
            'callback_url' => (isset($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'] . '?callback=1',
            'success_url' => (isset($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'] . '?status=success&order_id=' . $orderId,
            'cancel_url' => (isset($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'] . '?status=cancel'
        ];
        
        // Generate signature
        $signatureString = $orderId . $amount . SECRET_KEY;
        $data['signature'] = hash('sha256', $signatureString);
        
        // Kirim request ke API
        $ch = curl_init(NEOPGA_URL . '/api/create-payment.php');
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($data),
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'X-API-Key: ' . API_KEY
            ],
            CURLOPT_TIMEOUT => 30
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($response) {
            $result = json_decode($response, true);
            if (isset($result['success']) && $result['success']) {
                // Redirect ke halaman pembayaran
                header('Location: ' . $result['data']['payment_url']);
                exit;
            } else {
                $paymentError = $result['message'] ?? 'Gagal membuat pembayaran';
            }
        } else {
            $paymentError = 'Tidak dapat terhubung ke server pembayaran';
        }
    }
}

// Handle callback dari NEO PGA
if (isset($_GET['callback'])) {
    $input = json_decode(file_get_contents('php://input'), true);
    
    // Verifikasi signature
    $expectedSig = hash('sha256', $input['order_id'] . $input['amount'] . $input['status'] . SECRET_KEY);
    
    if ($input['signature'] === $expectedSig && $input['status'] === 'paid') {
        // SIMPAN KE DATABASE ATAU KIRIM EMAIL
        // Contoh: kirim email ke customer
        // mail($input['customer_email'], 'Pembayaran Berhasil', 'Terima kasih...');
        
        // Log transaksi
        file_put_contents('payments.log', date('Y-m-d H:i:s') . ' - ' . json_encode($input) . "\n", FILE_APPEND);
    }
    
    echo json_encode(['status' => 'ok']);
    exit;
}

// Tampilkan status setelah pembayaran
$paymentStatus = $_GET['status'] ?? null;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DigiStore - Premium Digital Products</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Sora:wght@300;400;500;600;700&family=Space+Mono:wght@400;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-primary: #0a0a0f;
            --bg-secondary: #12121a;
            --bg-card: #1a1a24;
            --accent: #00d4aa;
            --accent-glow: rgba(0, 212, 170, 0.3);
            --text-primary: #ffffff;
            --text-secondary: #8a8a9a;
            --text-muted: #5a5a6a;
            --border: rgba(255, 255, 255, 0.08);
            --success: #00d4aa;
            --warning: #ffd93d;
            --danger: #ff6b6b;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Sora', sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            min-height: 100vh;
            overflow-x: hidden;
        }

        /* Animated Background */
        .bg-pattern {
            position: fixed;
            top: 0; left: 0;
            width: 100%; height: 100%;
            pointer-events: none;
            z-index: 0;
            opacity: 0.4;
            background: 
                radial-gradient(ellipse 80% 50% at 50% -20%, var(--accent-glow), transparent),
                radial-gradient(ellipse 60% 40% at 100% 100%, rgba(99, 102, 241, 0.15), transparent);
        }

        .grid-overlay {
            position: fixed;
            top: 0; left: 0;
            width: 100%; height: 100%;
            pointer-events: none;
            z-index: 0;
            background-image: 
                linear-gradient(rgba(255,255,255,0.02) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255,255,255,0.02) 1px, transparent 1px);
            background-size: 60px 60px;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 24px;
            position: relative;
            z-index: 1;
        }

        /* Header */
        header {
            padding: 24px 0;
            border-bottom: 1px solid var(--border);
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            font-family: 'Space Mono', monospace;
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--accent);
            text-decoration: none;
            letter-spacing: -1px;
        }

        .logo span { color: var(--text-primary); }

        .nav-links {
            display: flex;
            gap: 32px;
        }

        .nav-links a {
            color: var(--text-secondary);
            text-decoration: none;
            font-size: 0.9rem;
            transition: color 0.2s;
        }

        .nav-links a:hover { color: var(--accent); }

        /* Hero */
        .hero {
            padding: 100px 0 80px;
            text-align: center;
        }

        .hero-tag {
            display: inline-block;
            background: linear-gradient(135deg, var(--accent-glow), transparent);
            border: 1px solid rgba(0, 212, 170, 0.3);
            padding: 8px 20px;
            border-radius: 100px;
            font-size: 0.8rem;
            color: var(--accent);
            margin-bottom: 24px;
            font-family: 'Space Mono', monospace;
            text-transform: uppercase;
            letter-spacing: 2px;
        }

        .hero h1 {
            font-size: clamp(2.5rem, 6vw, 4rem);
            font-weight: 700;
            line-height: 1.1;
            margin-bottom: 20px;
            background: linear-gradient(135deg, var(--text-primary) 0%, var(--text-secondary) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .hero p {
            font-size: 1.1rem;
            color: var(--text-secondary);
            max-width: 500px;
            margin: 0 auto;
            line-height: 1.7;
        }

        /* Status Alert */
        .status-alert {
            padding: 20px;
            border-radius: 16px;
            margin: 20px auto;
            max-width: 500px;
            text-align: center;
        }

        .status-alert.success {
            background: rgba(0, 212, 170, 0.1);
            border: 1px solid var(--accent);
            color: var(--accent);
        }

        .status-alert.error {
            background: rgba(255, 107, 107, 0.1);
            border: 1px solid var(--danger);
            color: var(--danger);
        }

        .status-alert.cancel {
            background: rgba(255, 217, 61, 0.1);
            border: 1px solid var(--warning);
            color: var(--warning);
        }

        .status-icon {
            font-size: 3rem;
            margin-bottom: 10px;
        }

        /* Products Section */
        .products-section {
            padding: 40px 0 100px;
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 40px;
        }

        .section-title {
            font-size: 0.85rem;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 3px;
            font-family: 'Space Mono', monospace;
        }

        .products-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
            gap: 24px;
        }

        /* Product Card */
        .product-card {
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: 20px;
            overflow: hidden;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .product-card:hover {
            transform: translateY(-8px);
            border-color: rgba(0, 212, 170, 0.3);
            box-shadow: 0 20px 60px -20px var(--accent-glow);
        }

        .product-visual {
            height: 180px;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }

        .product-visual.design { background: linear-gradient(135deg, #1e3a5f 0%, #0d1b2a 100%); }
        .product-visual.code { background: linear-gradient(135deg, #2d1b4e 0%, #1a0f2e 100%); }
        .product-visual.business { background: linear-gradient(135deg, #1b4d3e 0%, #0f2922 100%); }

        .product-icon { font-size: 4rem; opacity: 0.9; }

        .product-badge {
            position: absolute;
            top: 16px; right: 16px;
            background: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(10px);
            padding: 6px 12px;
            border-radius: 6px;
            font-size: 0.7rem;
            font-family: 'Space Mono', monospace;
            color: var(--accent);
            text-transform: uppercase;
        }

        .product-content { padding: 28px; }

        .product-category {
            font-size: 0.7rem;
            color: var(--accent);
            text-transform: uppercase;
            letter-spacing: 2px;
            margin-bottom: 12px;
            font-family: 'Space Mono', monospace;
        }

        .product-title {
            font-size: 1.3rem;
            font-weight: 600;
            margin-bottom: 12px;
        }

        .product-desc {
            font-size: 0.9rem;
            color: var(--text-secondary);
            line-height: 1.6;
            margin-bottom: 24px;
        }

        .product-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .product-price { font-family: 'Space Mono', monospace; }
        .price-current { font-size: 1.5rem; font-weight: 700; }
        .price-currency { font-size: 0.85rem; color: var(--text-muted); }

        .btn-buy {
            background: var(--accent);
            color: var(--bg-primary);
            border: none;
            padding: 14px 28px;
            border-radius: 12px;
            font-size: 0.9rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            font-family: 'Sora', sans-serif;
        }

        .btn-buy:hover {
            transform: scale(1.05);
            box-shadow: 0 10px 30px -10px var(--accent-glow);
        }

        /* Modal */
        .modal-overlay {
            display: none;
            position: fixed;
            top: 0; left: 0;
            width: 100%; height: 100%;
            background: rgba(0, 0, 0, 0.8);
            backdrop-filter: blur(8px);
            z-index: 1000;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .modal-overlay.active {
            display: flex;
            animation: fadeIn 0.3s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .modal {
            background: var(--bg-secondary);
            border: 1px solid var(--border);
            border-radius: 24px;
            width: 100%;
            max-width: 480px;
            animation: slideUp 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            max-height: 90vh;
            overflow-y: auto;
        }

        @keyframes slideUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .modal-header {
            padding: 28px 28px 0;
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
        }

        .modal-title { font-size: 1.3rem; font-weight: 600; }
        .modal-subtitle { font-size: 0.85rem; color: var(--text-secondary); margin-top: 4px; }

        .btn-close {
            background: var(--bg-card);
            border: 1px solid var(--border);
            width: 40px; height: 40px;
            border-radius: 12px;
            color: var(--text-secondary);
            cursor: pointer;
            font-size: 1.2rem;
            transition: all 0.2s ease;
        }

        .btn-close:hover { background: var(--border); color: var(--text-primary); }

        .modal-body { padding: 28px; }

        /* Order Summary */
        .order-summary {
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 20px;
            margin-bottom: 24px;
        }

        .order-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 12px;
        }

        .order-item:last-child {
            margin-bottom: 0;
            padding-top: 12px;
            border-top: 1px solid var(--border);
        }

        .order-label { color: var(--text-secondary); font-size: 0.9rem; }
        .order-value { font-family: 'Space Mono', monospace; font-weight: 600; }
        .order-total { color: var(--accent); font-size: 1.2rem; }

        /* Form */
        .form-group { margin-bottom: 20px; }

        .form-label {
            display: block;
            font-size: 0.8rem;
            color: var(--text-secondary);
            margin-bottom: 8px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .form-input {
            width: 100%;
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 16px;
            color: var(--text-primary);
            font-size: 1rem;
            font-family: 'Sora', sans-serif;
            transition: all 0.2s ease;
        }

        .form-input:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 3px var(--accent-glow);
        }

        .form-input::placeholder { color: var(--text-muted); }

        /* Payment Methods */
        .payment-methods { margin-bottom: 24px; }

        .payment-option {
            display: flex;
            align-items: center;
            gap: 16px;
            background: var(--bg-card);
            border: 2px solid var(--border);
            border-radius: 12px;
            padding: 16px;
            margin-bottom: 12px;
            cursor: pointer;
            transition: all 0.2s ease;
        }

        .payment-option:hover { border-color: rgba(0, 212, 170, 0.3); }

        .payment-option.selected {
            border-color: var(--accent);
            background: rgba(0, 212, 170, 0.05);
        }

        .payment-radio {
            width: 20px; height: 20px;
            border: 2px solid var(--border);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }

        .payment-option.selected .payment-radio { border-color: var(--accent); }

        .payment-option.selected .payment-radio::after {
            content: '';
            width: 10px; height: 10px;
            background: var(--accent);
            border-radius: 50%;
        }

        .payment-icon {
            width: 40px; height: 40px;
            background: var(--bg-secondary);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.2rem;
        }

        .payment-info { flex: 1; }
        .payment-name { font-weight: 500; margin-bottom: 2px; }
        .payment-desc { font-size: 0.8rem; color: var(--text-secondary); }

        .btn-pay {
            width: 100%;
            background: linear-gradient(135deg, var(--accent), #00b894);
            color: var(--bg-primary);
            border: none;
            padding: 18px;
            border-radius: 14px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            font-family: 'Sora', sans-serif;
        }

        .btn-pay:hover {
            transform: translateY(-2px);
            box-shadow: 0 15px 40px -15px var(--accent-glow);
        }

        .btn-pay:disabled { opacity: 0.6; cursor: not-allowed; transform: none; }

        /* Features */
        .features {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 24px;
            padding: 60px 0;
            border-top: 1px solid var(--border);
            margin-top: 40px;
        }

        .feature-item { text-align: center; padding: 24px; }
        .feature-icon { font-size: 2rem; margin-bottom: 16px; }
        .feature-title { font-size: 1rem; font-weight: 600; margin-bottom: 8px; }
        .feature-desc { font-size: 0.85rem; color: var(--text-secondary); line-height: 1.5; }

        /* Help Banner */
        .help-banner {
            background: linear-gradient(135deg, #1b4d3e 0%, #0f2922 100%);
            border: 1px solid rgba(0, 212, 170, 0.3);
            border-radius: 20px;
            padding: 30px;
            margin: 40px 0;
            display: flex;
            align-items: center;
            gap: 24px;
            flex-wrap: wrap;
        }

        .help-icon { font-size: 3rem; }

        .help-content { flex: 1; min-width: 200px; }
        .help-title { font-size: 1.2rem; font-weight: 600; margin-bottom: 8px; }
        .help-desc { color: var(--text-secondary); font-size: 0.9rem; }

        .btn-whatsapp {
            background: #25D366;
            color: white;
            border: none;
            padding: 14px 28px;
            border-radius: 12px;
            font-size: 0.95rem;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
        }

        .btn-whatsapp:hover {
            transform: scale(1.05);
            box-shadow: 0 10px 30px -10px rgba(37, 211, 102, 0.5);
        }

        /* Footer */
        footer {
            border-top: 1px solid var(--border);
            padding: 40px 0;
            text-align: center;
        }

        .footer-text { color: var(--text-muted); font-size: 0.85rem; }
        .footer-text a { color: var(--accent); text-decoration: none; }

        /* Error Message */
        .error-msg {
            background: rgba(255, 107, 107, 0.1);
            border: 1px solid var(--danger);
            color: var(--danger);
            padding: 12px 16px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-size: 0.9rem;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .header-content { flex-direction: column; gap: 16px; }
            .nav-links { gap: 20px; }
            .hero { padding: 60px 0 40px; }
            .products-grid { grid-template-columns: 1fr; }
            .features { grid-template-columns: 1fr 1fr; }
            .help-banner { flex-direction: column; text-align: center; }
        }
    </style>
</head>
<body>
    <div class="bg-pattern"></div>
    <div class="grid-overlay"></div>

    <header>
        <div class="container">
            <div class="header-content">
                <a href="#" class="logo">Digi<span>Store</span></a>
                <nav class="nav-links">
                    <a href="#products">Produk</a>
                    <a href="#features">Keunggulan</a>
                    <a href="#help">Bantuan</a>
                </nav>
            </div>
        </div>
    </header>

    <main>
        <section class="hero">
            <div class="container">
                <?php if ($paymentStatus === 'success'): ?>
                    <div class="status-alert success">
                        <div class="status-icon">✅</div>
                        <h3>Pembayaran Berhasil!</h3>
                        <p>Terima kasih! Link download sudah dikirim ke email kamu.</p>
                    </div>
                <?php elseif ($paymentStatus === 'cancel'): ?>
                    <div class="status-alert cancel">
                        <div class="status-icon">⚠️</div>
                        <h3>Pembayaran Dibatalkan</h3>
                        <p>Silakan coba lagi jika ingin melanjutkan pembelian.</p>
                    </div>
                <?php else: ?>
                    <span class="hero-tag">✨ Digital Marketplace</span>
                    <h1>Premium Digital Products</h1>
                    <p>Dapatkan template, source code, dan asset digital berkualitas untuk mempercepat project kamu.</p>
                <?php endif; ?>
            </div>
        </section>

        <section class="products-section" id="products">
            <div class="container">
                <div class="section-header">
                    <span class="section-title">Produk Terbaru</span>
                </div>

                <div class="products-grid">
                    <!-- Product 1 -->
                    <div class="product-card">
                        <div class="product-visual design">
                            <span class="product-icon">🎨</span>
                            <span class="product-badge">Best Seller</span>
                        </div>
                        <div class="product-content">
                            <span class="product-category">Design Assets</span>
                            <h3 class="product-title">UI Kit Pro Bundle</h3>
                            <p class="product-desc">500+ komponen UI siap pakai untuk Figma & Sketch. Termasuk dark mode dan responsive variants.</p>
                            <div class="product-footer">
                                <div class="product-price">
                                    <span class="price-currency">Rp</span>
                                    <span class="price-current">150.000</span>
                                </div>
                                <button class="btn-buy" onclick="openCheckout('UI Kit Pro Bundle', 150000)">Beli</button>
                            </div>
                        </div>
                    </div>

                    <!-- Product 2 -->
                    <div class="product-card">
                        <div class="product-visual code">
                            <span class="product-icon">💻</span>
                            <span class="product-badge">New</span>
                        </div>
                        <div class="product-content">
                            <span class="product-category">Source Code</span>
                            <h3 class="product-title">Laravel Starter Kit</h3>
                            <p class="product-desc">Boilerplate lengkap dengan auth, dashboard admin, API ready, dan dokumentasi lengkap.</p>
                            <div class="product-footer">
                                <div class="product-price">
                                    <span class="price-currency">Rp</span>
                                    <span class="price-current">299.000</span>
                                </div>
                                <button class="btn-buy" onclick="openCheckout('Laravel Starter Kit', 299000)">Beli</button>
                            </div>
                        </div>
                    </div>

                    <!-- Product 3 -->
                    <div class="product-card">
                        <div class="product-visual business">
                            <span class="product-icon">📊</span>
                        </div>
                        <div class="product-content">
                            <span class="product-category">Template</span>
                            <h3 class="product-title">Business Plan Template</h3>
                            <p class="product-desc">Template pitch deck profesional dengan 50+ slide, financial projection, dan market analysis.</p>
                            <div class="product-footer">
                                <div class="product-price">
                                    <span class="price-currency">Rp</span>
                                    <span class="price-current">75.000</span>
                                </div>
                                <button class="btn-buy" onclick="openCheckout('Business Plan Template', 75000)">Beli</button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Help Banner -->
                <div class="help-banner" id="help">
                    <div class="help-icon">💬</div>
                    <div class="help-content">
                        <h3 class="help-title">Butuh Bantuan Setup?</h3>
                        <p class="help-desc">Kirim URL website + akses cPanel kamu, kami bantu setup payment gateway sampai jalan!</p>
                    </div>
                    <a href="https://wa.me/6289534340757?text=Halo,%20saya%20butuh%20bantuan%20setup%20payment%20gateway%20untuk%20website%20saya" 
                       class="btn-whatsapp" target="_blank">
                        📱 WhatsApp Kami
                    </a>
                </div>

                <!-- Features Section -->
                <div class="features" id="features">
                    <div class="feature-item">
                        <div class="feature-icon">⚡</div>
                        <h4 class="feature-title">Instant Download</h4>
                        <p class="feature-desc">Akses langsung setelah pembayaran berhasil</p>
                    </div>
                    <div class="feature-item">
                        <div class="feature-icon">🔒</div>
                        <h4 class="feature-title">Pembayaran Aman</h4>
                        <p class="feature-desc">Transaksi terenkripsi dan terjamin</p>
                    </div>
                    <div class="feature-item">
                        <div class="feature-icon">🔄</div>
                        <h4 class="feature-title">Update Gratis</h4>
                        <p class="feature-desc">Dapatkan update selamanya tanpa biaya tambahan</p>
                    </div>
                    <div class="feature-item">
                        <div class="feature-icon">💬</div>
                        <h4 class="feature-title">Support 24/7</h4>
                        <p class="feature-desc">Tim support siap membantu kapan saja</p>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <!-- Checkout Modal -->
    <div class="modal-overlay" id="checkoutModal">
        <div class="modal">
            <div class="modal-header">
                <div>
                    <h2 class="modal-title">Checkout</h2>
                    <p class="modal-subtitle">Lengkapi data untuk pembayaran</p>
                </div>
                <button class="btn-close" onclick="closeModal()">&times;</button>
            </div>
            <div class="modal-body">
                <?php if ($paymentError): ?>
                    <div class="error-msg"><?= htmlspecialchars($paymentError) ?></div>
                <?php endif; ?>

                <!-- Order Summary -->
                <div class="order-summary">
                    <div class="order-item">
                        <span class="order-label">Produk</span>
                        <span class="order-value" id="orderProduct">-</span>
                    </div>
                    <div class="order-item">
                        <span class="order-label">Total Bayar</span>
                        <span class="order-value order-total" id="orderTotal">Rp 0</span>
                    </div>
                </div>

                <!-- FORM PEMBAYARAN - Dikirim ke NEO PGA API -->
                <form method="POST" action="" id="checkoutForm">
                    <input type="hidden" name="action" value="create_payment">
                    <input type="hidden" name="product_name" id="inputProductName" value="">
                    <input type="hidden" name="amount" id="inputAmount" value="">

                    <div class="form-group">
                        <label class="form-label">Nama Lengkap</label>
                        <input type="text" class="form-input" name="customer_name" placeholder="John Doe" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Email</label>
                        <input type="email" class="form-input" name="customer_email" placeholder="john@example.com" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">No. WhatsApp</label>
                        <input type="tel" class="form-input" name="customer_phone" placeholder="08123456789" required>
                    </div>

                    <!-- Payment Methods -->
                    <div class="payment-methods">
                        <label class="form-label">Metode Pembayaran</label>
                        
                        <div class="payment-option selected" onclick="selectPayment(this, 'qris')">
                            <div class="payment-radio"></div>
                            <div class="payment-icon">📱</div>
                            <div class="payment-info">
                                <div class="payment-name">QRIS</div>
                                <div class="payment-desc">Scan QR via GoPay, OVO, Dana, dll</div>
                            </div>
                        </div>

                        <div class="payment-option" onclick="selectPayment(this, 'bank_transfer')">
                            <div class="payment-radio"></div>
                            <div class="payment-icon">🏦</div>
                            <div class="payment-info">
                                <div class="payment-name">Transfer Bank</div>
                                <div class="payment-desc">BCA, BNI, Mandiri, BRI</div>
                            </div>
                        </div>
                    </div>

                    <input type="hidden" name="payment_method" id="selectedPayment" value="qris">

                    <button type="submit" class="btn-pay">
                        Bayar Sekarang
                    </button>
                </form>
            </div>
        </div>
    </div>

    <footer id="contact">
        <div class="container">
            <p class="footer-text">
                © 2025 DigiStore. Powered by <a href="<?= NEOPGA_URL ?>" target="_blank">NEO PGA</a>
            </p>
        </div>
    </footer>

    <script>
        function openCheckout(productName, amount) {
            document.getElementById('orderProduct').textContent = productName;
            document.getElementById('orderTotal').textContent = 'Rp ' + amount.toLocaleString('id-ID');
            document.getElementById('inputProductName').value = productName;
            document.getElementById('inputAmount').value = amount;
            
            document.getElementById('checkoutModal').classList.add('active');
            document.body.style.overflow = 'hidden';
        }

        function closeModal() {
            document.getElementById('checkoutModal').classList.remove('active');
            document.body.style.overflow = '';
        }

        function selectPayment(element, method) {
            document.querySelectorAll('.payment-option').forEach(el => el.classList.remove('selected'));
            element.classList.add('selected');
            document.getElementById('selectedPayment').value = method;
        }

        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') closeModal();
        });

        document.getElementById('checkoutModal').addEventListener('click', (e) => {
            if (e.target === document.getElementById('checkoutModal')) closeModal();
        });

        // Auto open modal if there was an error
        <?php if ($paymentError): ?>
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('checkoutModal').classList.add('active');
        });
        <?php endif; ?>
    </script>
</body>
</html>

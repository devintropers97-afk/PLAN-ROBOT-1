<?php
/**
 * NEO PGA Bootstrap/Initialization
 * Load all required files and setup application
 */

// Define application constant
define('NEOPGA', true);

// Load configuration
require_once __DIR__ . '/../config/config.php';

// ============================================
// START SESSION - CRITICAL!
// ============================================
if (session_status() === PHP_SESSION_NONE) {
    // Set secure session settings
    ini_set('session.cookie_httponly', 1);
    ini_set('session.cookie_secure', APP_ENV === 'production' ? 1 : 0);
    ini_set('session.cookie_samesite', 'Lax');
    ini_set('session.use_strict_mode', 1);
    ini_set('session.use_only_cookies', 1);

    // Set session name
    session_name('NEOPGA_SESSION');
    
    // Start session
    session_start();
    
    // Regenerate session ID periodically to prevent fixation
    if (!isset($_SESSION['_created'])) {
        $_SESSION['_created'] = time();
    } elseif (time() - $_SESSION['_created'] > 1800) {
        // Regenerate session ID every 30 minutes
        session_regenerate_id(true);
        $_SESSION['_created'] = time();
    }
}

// Load core classes
require_once INCLUDES_PATH . '/Database.php';
require_once INCLUDES_PATH . '/Auth.php';
require_once INCLUDES_PATH . '/helpers.php';
require_once INCLUDES_PATH . '/QRISGenerator.php';
require_once INCLUDES_PATH . '/Transaction.php';
require_once INCLUDES_PATH . '/ConcurrencyManager.php';
require_once INCLUDES_PATH . '/Security.php';
require_once INCLUDES_PATH . '/RateLimiter.php';

// Set security headers
Security::setHeaders();

// Error handler
set_exception_handler(function($e) {
    if (APP_DEBUG) {
        echo '<h1>Error</h1>';
        echo '<p>' . $e->getMessage() . '</p>';
        echo '<pre>' . $e->getTraceAsString() . '</pre>';
    } else {
        error_log($e->getMessage());
        echo 'An error occurred. Please try again later.';
    }
    exit;
});

// Check if request is AJAX
if (!function_exists('isAjax')) {
    function isAjax(): bool
    {
        return !empty($_SERVER['HTTP_X_REQUESTED_WITH']) &&
               strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
    }
}

// Get POST data
if (!function_exists('post')) {
    function post(string $key, $default = null)
    {
        return $_POST[$key] ?? $default;
    }
}

// Get GET data
if (!function_exists('get')) {
    function get(string $key, $default = null)
    {
        return $_GET[$key] ?? $default;
    }
}

// Get request data (POST or GET)
if (!function_exists('input')) {
    function input(string $key, $default = null)
    {
        return $_POST[$key] ?? $_GET[$key] ?? $default;
    }
}

// Get all input data
if (!function_exists('allInput')) {
    function allInput(): array
    {
        return array_merge($_GET, $_POST);
    }
}

// Get JSON input
if (!function_exists('jsonInput')) {
    function jsonInput(): array
    {
        $json = file_get_contents('php://input');
        return json_decode($json, true) ?? [];
    }
}

// Asset URL helper
if (!function_exists('asset')) {
    function asset(string $path): string
    {
        return ASSETS_URL . '/' . ltrim($path, '/');
    }
}

// URL helper
if (!function_exists('url')) {
    function url(string $path = ''): string
    {
        return APP_URL . '/' . ltrim($path, '/');
    }
}

// Include view/template
if (!function_exists('view')) {
    function view(string $template, array $data = []): void
    {
        extract($data);
        include ROOT_PATH . '/views/' . $template . '.php';
    }
}

// Get database instance shorthand
if (!function_exists('db')) {
    function db(): Database
    {
        return Database::getInstance();
    }
}

// Log API request
if (!function_exists('logApiRequest')) {
    function logApiRequest(?int $merchantId, string $endpoint, string $method, array $request, int $responseCode, array $response, float $startTime): void
    {
        try {
            $executionTime = round(microtime(true) - $startTime, 4);

            // getallheaders() polyfill for when it doesn't exist
            $headers = [];
            if (function_exists('getallheaders')) {
                $headers = getallheaders();
            } else {
                foreach ($_SERVER as $name => $value) {
                    if (substr($name, 0, 5) == 'HTTP_') {
                        $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
                    }
                }
            }

            db()->query(
                "INSERT INTO api_logs (merchant_id, endpoint, method, request_headers, request_body, response_code, response_body, ip_address, execution_time)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                [
                    $merchantId,
                    $endpoint,
                    $method,
                    json_encode($headers),
                    json_encode($request),
                    $responseCode,
                    json_encode($response),
                    getClientIP(),
                    $executionTime
                ]
            );
        } catch (Exception $e) {
            error_log("Failed to log API request: " . $e->getMessage());
        }
    }
}

// Send webhook notification with idempotency
if (!function_exists('sendWebhook')) {
    function sendWebhook(int $transactionId, array $payload): bool
    {
    try {
        $transaction = db()->fetch("SELECT t.*, m.webhook_url, m.secret_key FROM transactions t JOIN merchants m ON t.merchant_id = m.id WHERE t.id = ?", [$transactionId]);

        if (!$transaction || empty($transaction['webhook_url'])) {
            return false;
        }

        // Generate idempotency key based on transaction + event
        $event = $payload['event'] ?? 'unknown';
        $idempotencyKey = hash('sha256', $transactionId . '_' . $event . '_' . ($transaction['status'] ?? ''));

        // Check if webhook with this idempotency key was already sent successfully
        $existingWebhook = db()->fetch(
            "SELECT id, status FROM webhook_logs
             WHERE transaction_id = ? AND status = 'success'
             AND JSON_EXTRACT(request_payload, '$.event') = ?
             AND created_at > DATE_SUB(NOW(), INTERVAL 24 HOUR)
             LIMIT 1",
            [$transactionId, $event]
        );

        if ($existingWebhook) {
            // Webhook already sent successfully, skip duplicate
            error_log("Webhook skipped: Already sent for transaction #{$transactionId}, event: {$event}");
            return true;
        }

        // Add idempotency key to payload
        $payload['idempotency_key'] = $idempotencyKey;
        $payload['timestamp'] = date('c');

        $signature = hash_hmac('sha256', json_encode($payload), $transaction['secret_key']);
        $webhookId = uniqid('wh_', true);

        $ch = curl_init($transaction['webhook_url']);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($payload),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => WEBHOOK_TIMEOUT,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'X-Signature: ' . $signature,
                'X-Webhook-ID: ' . $webhookId,
                'X-Idempotency-Key: ' . $idempotencyKey,
                'User-Agent: NEO PGA-Webhook/1.0'
            ]
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        $status = ($httpCode >= 200 && $httpCode < 300) ? 'success' : 'failed';

        // Log webhook
        db()->query(
            "INSERT INTO webhook_logs (transaction_id, merchant_id, webhook_url, request_payload, response_code, response_body, status, error_message)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            [
                $transactionId,
                $transaction['merchant_id'],
                $transaction['webhook_url'],
                json_encode($payload),
                $httpCode,
                $response,
                $status,
                $error ?: null
            ]
        );

        // Update transaction webhook status
        db()->query(
            "UPDATE transactions SET webhook_status = ?, webhook_attempts = webhook_attempts + 1, webhook_last_attempt = NOW(), webhook_response = ? WHERE id = ?",
            [$status, $response, $transactionId]
        );

        return $status === 'success';

    } catch (Exception $e) {
        error_log("Webhook error: " . $e->getMessage());
        return false;
    }
    }
}

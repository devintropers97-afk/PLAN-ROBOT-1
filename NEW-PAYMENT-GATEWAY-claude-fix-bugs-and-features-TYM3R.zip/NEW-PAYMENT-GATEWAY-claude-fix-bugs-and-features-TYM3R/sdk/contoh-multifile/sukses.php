<?php
/**
 * ================================================================================
 *                    NEO PGA - HALAMAN PEMBAYARAN BERHASIL
 * ================================================================================
 *
 * Halaman ini ditampilkan setelah customer berhasil bayar.
 *
 * TIDAK PERLU EDIT FILE INI - Cukup edit config.php saja!
 *
 * ================================================================================
 */

require_once __DIR__ . '/config.php';
session_start();

// Ambil data dari session atau parameter
$order = $_SESSION['last_order'] ?? null;
$orderId = $_GET['order'] ?? ($order['order_id'] ?? '');
$invoice = $_GET['invoice'] ?? ($order['invoice'] ?? '');

// Cek status real-time jika ada invoice
$statusData = null;
if ($invoice) {
    $result = neopga_status($invoice);
    if ($result && $result['success']) {
        $statusData = $result['data'];
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pembayaran Berhasil - <?= htmlspecialchars(NAMA_TOKO) ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #ecfdf5 0%, #d1fae5 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .container {
            background: white;
            border-radius: 24px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.1);
            max-width: 480px;
            width: 100%;
            overflow: hidden;
        }
        .header {
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            color: white;
            padding: 40px 30px;
            text-align: center;
        }
        .header .icon {
            width: 80px;
            height: 80px;
            background: rgba(255,255,255,0.2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            font-size: 40px;
        }
        .header h1 {
            font-size: 28px;
            margin-bottom: 8px;
        }
        .header p {
            opacity: 0.9;
            font-size: 16px;
        }
        .content {
            padding: 30px;
        }
        .info-box {
            background: #f9fafb;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 20px;
        }
        .info-row {
            display: flex;
            justify-content: space-between;
            padding: 12px 0;
            border-bottom: 1px solid #e5e7eb;
        }
        .info-row:last-child {
            border-bottom: none;
        }
        .info-row .label {
            color: #6b7280;
            font-size: 14px;
        }
        .info-row .value {
            font-weight: 600;
            color: #1f2937;
        }
        .info-row .value.amount {
            color: #059669;
            font-size: 18px;
        }
        .actions {
            display: flex;
            gap: 12px;
            margin-top: 20px;
        }
        .btn {
            flex: 1;
            padding: 14px 20px;
            border-radius: 12px;
            text-decoration: none;
            text-align: center;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.2s;
        }
        .btn-primary {
            background: #059669;
            color: white;
        }
        .btn-primary:hover {
            background: #047857;
        }
        .btn-wa {
            background: #25d366;
            color: white;
        }
        .btn-wa:hover {
            background: #1da851;
        }
        .btn-secondary {
            background: #f3f4f6;
            color: #374151;
        }
        .btn-secondary:hover {
            background: #e5e7eb;
        }
        .footer {
            text-align: center;
            padding: 20px 30px 30px;
            color: #9ca3af;
            font-size: 13px;
        }
        .confetti {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            overflow: hidden;
            z-index: 1000;
        }
        .confetti-piece {
            position: absolute;
            width: 10px;
            height: 10px;
            background: #059669;
            animation: confetti-fall 3s ease-out forwards;
        }
        @keyframes confetti-fall {
            0% { transform: translateY(-100px) rotate(0deg); opacity: 1; }
            100% { transform: translateY(100vh) rotate(720deg); opacity: 0; }
        }
    </style>
</head>
<body>
    <div class="confetti" id="confetti"></div>

    <div class="container">
        <div class="header">
            <div class="icon">✓</div>
            <h1>Pembayaran Berhasil!</h1>
            <p>Terima kasih atas pembayaran Anda</p>
        </div>

        <div class="content">
            <div class="info-box">
                <?php if ($orderId): ?>
                <div class="info-row">
                    <span class="label">No. Order</span>
                    <span class="value"><?= htmlspecialchars($orderId) ?></span>
                </div>
                <?php endif; ?>

                <?php if ($invoice): ?>
                <div class="info-row">
                    <span class="label">No. Invoice</span>
                    <span class="value"><?= htmlspecialchars($invoice) ?></span>
                </div>
                <?php endif; ?>

                <?php if ($statusData): ?>
                <div class="info-row">
                    <span class="label">Produk</span>
                    <span class="value"><?= htmlspecialchars($statusData['description'] ?? '-') ?></span>
                </div>
                <div class="info-row">
                    <span class="label">Total Bayar</span>
                    <span class="value amount"><?= format_rupiah($statusData['amount'] ?? 0) ?></span>
                </div>
                <?php elseif ($order): ?>
                <div class="info-row">
                    <span class="label">Produk</span>
                    <span class="value"><?= htmlspecialchars($order['produk'] ?? '-') ?></span>
                </div>
                <div class="info-row">
                    <span class="label">Total Bayar</span>
                    <span class="value amount"><?= format_rupiah($order['harga'] ?? 0) ?></span>
                </div>
                <?php endif; ?>
            </div>

            <p style="color: #6b7280; font-size: 14px; text-align: center; margin-bottom: 20px;">
                Bukti pembayaran telah dikirim ke email Anda.<br>
                Silakan simpan halaman ini sebagai referensi.
            </p>

            <div class="actions">
                <?php if (defined('WA_TOKO') && WA_TOKO): ?>
                <a href="https://wa.me/<?= WA_TOKO ?>?text=Halo, saya sudah melakukan pembayaran dengan invoice: <?= urlencode($invoice) ?>" class="btn btn-wa" target="_blank">
                    💬 Hubungi Kami
                </a>
                <?php endif; ?>
                <a href="<?= get_homepage_url() ?>" class="btn btn-primary">
                    🏠 Kembali
                </a>
            </div>
        </div>

        <div class="footer">
            <?= htmlspecialchars(NAMA_TOKO) ?><br>
            <?= get_homepage_url() ?>
        </div>
    </div>

    <script>
        // Confetti animation
        const confetti = document.getElementById('confetti');
        const colors = ['#10b981', '#059669', '#34d399', '#6ee7b7', '#fbbf24', '#f59e0b'];

        for (let i = 0; i < 50; i++) {
            const piece = document.createElement('div');
            piece.className = 'confetti-piece';
            piece.style.left = Math.random() * 100 + '%';
            piece.style.background = colors[Math.floor(Math.random() * colors.length)];
            piece.style.animationDelay = Math.random() * 2 + 's';
            piece.style.transform = 'rotate(' + Math.random() * 360 + 'deg)';
            confetti.appendChild(piece);
        }

        // Remove confetti after animation
        setTimeout(() => confetti.remove(), 5000);
    </script>
</body>
</html>

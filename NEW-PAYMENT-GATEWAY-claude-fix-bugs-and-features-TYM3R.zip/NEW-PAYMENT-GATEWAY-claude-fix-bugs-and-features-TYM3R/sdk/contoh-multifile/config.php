<?php
/**
 * ================================================================================
 *                         NEO PGA - FILE KONFIGURASI
 * ================================================================================
 *
 *   PENTING: INI SATU-SATUNYA FILE YANG PERLU KAMU EDIT!
 *
 *   Isi data di bawah ini, lalu upload semua file ke website kamu.
 *   Tidak perlu edit file lainnya.
 *
 * ================================================================================
 */

// ===== 1. API KEY (dapat dari Dashboard Merchant NEO PGA) =====
define('NEOBAYAR_API_KEY', 'YOUR_API_KEY_HERE');
define('NEOBAYAR_SECRET_KEY', 'YOUR_SECRET_KEY_HERE');

// ===== 2. URL NEOBAYAR (tanya admin untuk URL yang benar) =====
define('NEOPGA_URL', 'https://your-neopga-domain.com');  // GANTI INI!

// ===== 3. URL TEMPAT FILE INI DI-UPLOAD =====
// PENTING: Isi dengan URL LENGKAP folder tempat file-file ini diupload!
//
// Contoh jika upload di ROOT website:
//   define('BASE_URL', 'https://tokoku.com');
//
// Contoh jika upload di SUBFOLDER /payment/:
//   define('BASE_URL', 'https://tokoku.com/payment');
//
// Contoh jika upload di SUBFOLDER /checkout/pay/:
//   define('BASE_URL', 'https://tokoku.com/checkout/pay');
//
// JANGAN pakai garis miring (/) di akhir URL!

define('BASE_URL', 'https://websitekamu.com');

// ===== 4. INFO TOKO KAMU =====
define('NAMA_TOKO', 'Nama Toko Kamu');
define('EMAIL_TOKO', 'email@tokoku.com');  // Untuk terima notifikasi pembayaran
define('WA_TOKO', '6281234567890');        // Untuk link WhatsApp (pakai kode negara, tanpa +)

// ===== 5. PENGATURAN PEMBAYARAN =====
define('WAKTU_EXPIRED', 60);               // Menit sebelum pembayaran expired (default: 60 menit)
define('METODE_BAYAR', 'qris');            // Metode: 'qris' atau 'bank_transfer'

// ===== 6. NOTIFIKASI EMAIL (opsional) =====
define('KIRIM_EMAIL', true);               // true = kirim email, false = tidak
define('EMAIL_SUBJECT', 'Pembayaran Baru!');


// ================================================================================
//   JANGAN EDIT DI BAWAH INI (kecuali kamu tahu apa yang dilakukan)
// ================================================================================

// Helper function untuk kirim request ke NEO PGA
function neopga_request($endpoint, $data) {
    $jsonData = json_encode($data);
    $signature = hash_hmac('sha256', $jsonData, NEOBAYAR_SECRET_KEY);

    $ch = curl_init(NEOPGA_URL . $endpoint);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $jsonData,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'X-API-Key: ' . NEOBAYAR_API_KEY,
            'X-Signature: ' . $signature
        ],
        CURLOPT_TIMEOUT => 30
    ]);

    $response = curl_exec($ch);
    $error = curl_error($ch);
    curl_close($ch);

    if ($error) {
        return ['success' => false, 'error' => 'Connection failed: ' . $error];
    }

    return json_decode($response, true) ?: ['success' => false, 'error' => 'Invalid response'];
}

// Helper function untuk cek status
function neopga_status($invoice) {
    $data = ['invoice_number' => $invoice];
    $jsonData = json_encode($data);
    $signature = hash_hmac('sha256', $jsonData, NEOBAYAR_SECRET_KEY);

    $ch = curl_init(NEOPGA_URL . '/api/status.php');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $jsonData,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'X-API-Key: ' . NEOBAYAR_API_KEY,
            'X-Signature: ' . $signature
        ],
        CURLOPT_TIMEOUT => 30
    ]);

    $response = curl_exec($ch);
    curl_close($ch);

    return json_decode($response, true) ?: ['success' => false];
}

// Helper function untuk verifikasi callback
function neopga_verify_callback() {
    $rawData = file_get_contents('php://input');
    $data = json_decode($rawData, true);

    if (!$data) return null;

    $signature = $_SERVER['HTTP_X_SIGNATURE'] ?? '';
    $expected = hash_hmac('sha256', $rawData, NEOBAYAR_SECRET_KEY);

    if (!hash_equals($expected, $signature)) return null;

    return $data;
}

// Helper function untuk kirim email notifikasi
function neopga_send_email($to, $subject, $message) {
    if (!KIRIM_EMAIL) return false;

    $headers = "MIME-Version: 1.0\r\n";
    $headers .= "Content-type: text/html; charset=UTF-8\r\n";
    $headers .= "From: " . NAMA_TOKO . " <noreply@" . parse_url(BASE_URL, PHP_URL_HOST) . ">\r\n";

    return @mail($to, $subject, $message, $headers);
}

// Helper function untuk format rupiah
function format_rupiah($angka) {
    return 'Rp ' . number_format($angka, 0, ',', '.');
}

// Helper untuk mendapatkan URL homepage (root domain tanpa path)
function get_homepage_url() {
    $parsed = parse_url(BASE_URL);
    return $parsed['scheme'] . '://' . $parsed['host'] . (isset($parsed['port']) ? ':' . $parsed['port'] : '');
}

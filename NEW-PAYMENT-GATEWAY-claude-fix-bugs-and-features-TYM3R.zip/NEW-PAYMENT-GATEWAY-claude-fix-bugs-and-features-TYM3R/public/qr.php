<?php
/**
 * NEO PGA - QR Code Image Generator
 * Generate QR code image from QRIS string
 * 
 * Usage: qr.php?invoice=INV123 or qr.php?data=QRIS_STRING
 */
// Config loaded via init.php
require_once __DIR__ . '/../includes/init.php';

// Get QRIS data
$qrisString = '';

if (isset($_GET['invoice'])) {
    // Sanitize invoice parameter
    $invoice = preg_replace('/[^a-zA-Z0-9\-_]/', '', $_GET['invoice']);
    $db = Database::getInstance();
    $transaction = $db->fetch(
        "SELECT qris_string FROM transactions WHERE invoice_number = ?",
        [$invoice]
    );
    if ($transaction && !empty($transaction['qris_string'])) {
        $qrisString = $transaction['qris_string'];
    }
} elseif (isset($_GET['data'])) {
    // Sanitize data parameter - only allow alphanumeric and common QRIS chars
    $qrisString = preg_replace('/[^a-zA-Z0-9]/', '', $_GET['data']);
}

if (empty($qrisString)) {
    // Return 1x1 transparent pixel
    header('Content-Type: image/png');
    echo base64_decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=');
    exit;
}

// Size
$size = min(500, max(100, (int)($_GET['size'] ?? 300)));
$margin = (int)($_GET['margin'] ?? 2);

// Use QR Server API (reliable and free) instead of deprecated Google Charts
$qrUrl = 'https://api.qrserver.com/v1/create-qr-code/?' . http_build_query([
    'size' => $size . 'x' . $size,
    'data' => $qrisString,
    'ecc' => 'M',
    'margin' => $margin
]);

// Proxy the image
header('Content-Type: image/png');
header('Cache-Control: public, max-age=3600');

$context = stream_context_create([
    'http' => [
        'timeout' => 10,
        'user_agent' => 'NEO PGA/2.0'
    ]
]);

$qrImage = @file_get_contents($qrUrl, false, $context);

if ($qrImage) {
    echo $qrImage;
} else {
    // Generate simple placeholder if API fails
    $img = imagecreatetruecolor($size, $size);
    $white = imagecolorallocate($img, 255, 255, 255);
    $black = imagecolorallocate($img, 0, 0, 0);
    
    imagefill($img, 0, 0, $white);
    
    // Draw border
    imagerectangle($img, 0, 0, $size - 1, $size - 1, $black);
    
    // Draw text
    $text = 'QR Error';
    $fontSize = 3;
    $textWidth = imagefontwidth($fontSize) * strlen($text);
    $textHeight = imagefontheight($fontSize);
    $x = ($size - $textWidth) / 2;
    $y = ($size - $textHeight) / 2;
    imagestring($img, $fontSize, $x, $y, $text, $black);
    
    imagepng($img);
    imagedestroy($img);
}

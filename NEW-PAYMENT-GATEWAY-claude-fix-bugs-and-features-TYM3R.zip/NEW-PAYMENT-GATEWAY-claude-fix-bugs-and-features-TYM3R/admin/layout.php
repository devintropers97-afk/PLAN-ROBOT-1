<?php
/**
 * NEO PGA Admin Layout
 * Modern Design System - Consistent with Homepage & Merchant
 */
if (!isset($adminUser) || !$adminUser) {
    header('Location: login.php');
    exit;
}

// Get pending counts
$db = Database::getInstance();
$pendingTrx = $db->fetch("SELECT COUNT(*) as c FROM transactions WHERE status = 'pending'");
$pendingSettlements = $db->fetch("SELECT COUNT(*) as c FROM settlements WHERE status = 'pending'");
$pendingMerchants = $db->fetch("SELECT COUNT(*) as c FROM merchants WHERE status = 'pending'");
$totalPending = ($pendingTrx['c'] ?? 0) + ($pendingSettlements['c'] ?? 0) + ($pendingMerchants['c'] ?? 0);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?? 'Dashboard' ?> - NEO PGA Admin</title>
    <link rel="icon" type="image/svg+xml" href="<?= ASSETS_URL ?>/images/favicon.svg">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <?php if (isset($extraHead)) echo $extraHead; ?>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }

        :root {
            /* Primary - Emerald Green (consistent with homepage) */
            --primary-50: #ecfdf5;
            --primary-100: #d1fae5;
            --primary-200: #a7f3d0;
            --primary-300: #6ee7b7;
            --primary-400: #34d399;
            --primary-500: #10b981;
            --primary-600: #059669;
            --primary-700: #047857;
            --primary-800: #065f46;
            --primary-900: #064e3b;

            --primary: #10b981;
            --primary-light: #34d399;
            --primary-dark: #059669;

            /* Secondary - Dark */
            --secondary: #1e293b;
            --secondary-dark: #0f172a;

            /* Status Colors */
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --info: #3b82f6;

            /* Gray Scale */
            --gray-50: #f8fafc;
            --gray-100: #f1f5f9;
            --gray-200: #e2e8f0;
            --gray-300: #cbd5e1;
            --gray-400: #94a3b8;
            --gray-500: #64748b;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1e293b;
            --gray-900: #0f172a;
            --gray-950: #020617;

            --white: #ffffff;

            /* Layout */
            --sidebar-width: 280px;
            --header-height: 64px;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: var(--gray-50);
            min-height: 100vh;
            color: var(--gray-700);
        }

        /* ============================================
           SIDEBAR
           ============================================ */
        .sidebar {
            width: var(--sidebar-width);
            background: linear-gradient(180deg, var(--secondary-dark) 0%, var(--secondary) 100%);
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            z-index: 100;
            display: flex;
            flex-direction: column;
            border-right: 1px solid rgba(255,255,255,0.05);
            overflow: hidden;
        }

        .sidebar-header {
            padding: 1.25rem 1.5rem;
            border-bottom: 1px solid rgba(255,255,255,0.05);
            flex-shrink: 0;
        }

        .sidebar-logo {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            text-decoration: none;
        }

        .logo-icon {
            width: 42px;
            height: 42px;
            background: linear-gradient(135deg, var(--primary-500) 0%, var(--primary-600) 100%);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 15px rgba(16, 185, 129, 0.3);
        }

        .logo-icon svg { width: 24px; height: 24px; color: white; }

        .logo-text {
            font-size: 1.25rem;
            font-weight: 800;
            background: linear-gradient(135deg, #fff 0%, #94a3b8 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .admin-badge {
            display: inline-block;
            background: rgba(16, 185, 129, 0.2);
            color: var(--primary-400);
            font-size: 0.6rem;
            font-weight: 700;
            padding: 0.2rem 0.5rem;
            border-radius: 4px;
            margin-left: 0.5rem;
            letter-spacing: 0.1em;
        }

        .sidebar-nav {
            flex: 1;
            padding: 1rem 0.75rem;
            overflow-y: auto;
            overflow-x: hidden;
            -webkit-overflow-scrolling: touch;
        }

        .sidebar-nav::-webkit-scrollbar { width: 6px; }
        .sidebar-nav::-webkit-scrollbar-track { background: transparent; }
        .sidebar-nav::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.2); border-radius: 3px; }
        .sidebar-nav::-webkit-scrollbar-thumb:hover { background: rgba(255,255,255,0.3); }

        .nav-section { margin-bottom: 1.5rem; }

        .nav-section-title {
            padding: 0.5rem 1rem;
            font-size: 0.7rem;
            font-weight: 600;
            color: var(--gray-500);
            text-transform: uppercase;
            letter-spacing: 0.1em;
        }

        .nav-link {
            display: flex;
            align-items: center;
            gap: 0.875rem;
            padding: 0.75rem 1rem;
            color: var(--gray-400);
            text-decoration: none;
            border-radius: 10px;
            font-weight: 500;
            font-size: 0.875rem;
            transition: all 0.2s ease;
            margin-bottom: 0.25rem;
        }

        .nav-link:hover {
            background: rgba(255,255,255,0.05);
            color: white;
        }

        .nav-link.active {
            background: linear-gradient(135deg, var(--primary-500) 0%, var(--primary-600) 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(16, 185, 129, 0.3);
        }

        .nav-link svg {
            width: 20px;
            height: 20px;
            flex-shrink: 0;
        }

        .nav-badge {
            margin-left: auto;
            background: var(--danger);
            color: white;
            font-size: 0.65rem;
            font-weight: 700;
            padding: 0.15rem 0.5rem;
            border-radius: 50px;
            min-width: 20px;
            text-align: center;
        }

        .sidebar-footer {
            padding: 1rem;
            border-top: 1px solid rgba(255,255,255,0.05);
            flex-shrink: 0;
            background: var(--secondary-dark);
        }

        .user-card {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.75rem;
            background: rgba(255,255,255,0.03);
            border-radius: 10px;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, var(--primary-500) 0%, var(--primary-600) 100%);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 700;
            flex-shrink: 0;
        }

        .user-info { flex: 1; min-width: 0; }

        .user-name {
            color: white;
            font-weight: 600;
            font-size: 0.875rem;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .user-role {
            color: var(--gray-500);
            font-size: 0.75rem;
            text-transform: capitalize;
        }

        .logout-btn {
            background: rgba(239, 68, 68, 0.1);
            border: none;
            width: 36px;
            height: 36px;
            border-radius: 8px;
            color: var(--danger);
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s;
            text-decoration: none;
            flex-shrink: 0;
        }

        .logout-btn:hover {
            background: var(--danger);
            color: white;
        }

        /* ============================================
           MAIN CONTENT
           ============================================ */
        .main-content {
            margin-left: var(--sidebar-width);
            min-height: 100vh;
        }

        .top-header {
            background: white;
            padding: 1rem 2rem;
            border-bottom: 1px solid var(--gray-200);
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: sticky;
            top: 0;
            z-index: 50;
            height: var(--header-height);
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .page-title {
            font-size: 1.25rem;
            font-weight: 700;
            color: var(--gray-900);
        }

        .breadcrumb {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.8rem;
            color: var(--gray-500);
            margin-top: 0.25rem;
        }
        .breadcrumb a {
            color: var(--primary-600);
            text-decoration: none;
        }
        .breadcrumb a:hover {
            text-decoration: underline;
        }

        .header-actions {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .header-btn {
            background: var(--gray-100);
            border: none;
            width: 42px;
            height: 42px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--gray-600);
            cursor: pointer;
            transition: all 0.2s;
            position: relative;
        }
        .header-btn:hover {
            background: var(--gray-200);
            color: var(--gray-900);
        }
        .header-btn svg {
            width: 20px;
            height: 20px;
        }

        .notification-dot {
            position: absolute;
            top: 8px;
            right: 8px;
            width: 8px;
            height: 8px;
            background: var(--danger);
            border-radius: 50%;
            border: 2px solid white;
        }

        .header-time {
            font-size: 0.8rem;
            color: var(--gray-500);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .header-time svg {
            width: 16px;
            height: 16px;
        }

        .content-area {
            padding: 1.5rem 2rem;
        }

        /* ============================================
           ALERTS
           ============================================ */
        .alert {
            padding: 1rem 1.25rem;
            border-radius: 12px;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }
        .alert svg {
            width: 20px;
            height: 20px;
            flex-shrink: 0;
        }
        .alert-success {
            background: rgba(16, 185, 129, 0.1);
            color: var(--success);
            border: 1px solid rgba(16, 185, 129, 0.2);
        }
        .alert-danger {
            background: rgba(239, 68, 68, 0.1);
            color: var(--danger);
            border: 1px solid rgba(239, 68, 68, 0.2);
        }
        .alert-warning {
            background: rgba(245, 158, 11, 0.1);
            color: var(--warning);
            border: 1px solid rgba(245, 158, 11, 0.2);
        }
        .alert-info {
            background: rgba(59, 130, 246, 0.1);
            color: var(--info);
            border: 1px solid rgba(59, 130, 246, 0.2);
        }
        .alert-close {
            margin-left: auto;
            background: none;
            border: none;
            cursor: pointer;
            color: inherit;
            opacity: 0.7;
        }
        .alert-close:hover {
            opacity: 1;
        }

        /* ============================================
           MOBILE
           ============================================ */
        .mobile-menu-btn {
            display: none;
            background: var(--gray-100);
            border: none;
            width: 42px;
            height: 42px;
            border-radius: 10px;
            align-items: center;
            justify-content: center;
            color: var(--gray-600);
            cursor: pointer;
        }

        .sidebar-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.5);
            z-index: 90;
            backdrop-filter: blur(4px);
        }
        .sidebar-overlay.active {
            display: block;
        }

        @media (max-width: 1024px) {
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s ease;
                height: 100vh;
                height: 100dvh;
            }
            .sidebar.open {
                transform: translateX(0);
            }
            .main-content {
                margin-left: 0;
            }
            .mobile-menu-btn {
                display: flex !important;
            }
            .sidebar-nav {
                max-height: calc(100vh - 180px);
                max-height: calc(100dvh - 180px);
            }
        }

        @media (max-width: 768px) {
            .content-area {
                padding: 1rem;
            }
            .top-header {
                padding: 1rem;
            }
            .header-time {
                display: none;
            }
        }

        /* ============================================
           COMMON COMPONENTS
           ============================================ */
        .card {
            background: white;
            border-radius: 16px;
            border: 1px solid var(--gray-200);
            overflow: hidden;
        }
        .card-header {
            padding: 1rem 1.5rem;
            border-bottom: 1px solid var(--gray-100);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .card-title {
            font-size: 1rem;
            font-weight: 600;
            color: var(--gray-900);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        .card-title svg {
            width: 20px;
            height: 20px;
            color: var(--primary-600);
        }
        .card-body {
            padding: 1.5rem;
        }

        /* Buttons */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            padding: 0.625rem 1.25rem;
            border-radius: 10px;
            font-size: 0.875rem;
            font-weight: 600;
            border: none;
            cursor: pointer;
            transition: all 0.2s;
            text-decoration: none;
        }
        .btn svg {
            width: 18px;
            height: 18px;
        }
        .btn-primary {
            background: linear-gradient(135deg, var(--primary-500), var(--primary-600));
            color: white;
            box-shadow: 0 2px 8px rgba(16, 185, 129, 0.3);
        }
        .btn-primary:hover {
            background: linear-gradient(135deg, var(--primary-600), var(--primary-700));
            box-shadow: 0 4px 12px rgba(16, 185, 129, 0.4);
            transform: translateY(-1px);
        }
        .btn-success {
            background: var(--success);
            color: white;
        }
        .btn-danger {
            background: var(--danger);
            color: white;
        }
        .btn-secondary {
            background: var(--gray-100);
            color: var(--gray-700);
        }
        .btn-secondary:hover {
            background: var(--gray-200);
        }
        .btn-sm {
            padding: 0.4rem 0.875rem;
            font-size: 0.8rem;
        }

        /* Badges */
        .badge {
            display: inline-flex;
            align-items: center;
            padding: 0.25rem 0.75rem;
            font-size: 0.75rem;
            font-weight: 600;
            border-radius: 9999px;
        }
        .badge-success {
            background: var(--primary-100);
            color: var(--primary-700);
        }
        .badge-warning {
            background: #fef3c7;
            color: #92400e;
        }
        .badge-danger {
            background: #fee2e2;
            color: #dc2626;
        }
        .badge-info {
            background: #dbeafe;
            color: #1e40af;
        }
        .badge-neutral {
            background: var(--gray-100);
            color: var(--gray-600);
        }

        /* Tables */
        .table {
            width: 100%;
            border-collapse: collapse;
        }
        .table th {
            padding: 0.75rem 1rem;
            text-align: left;
            font-size: 0.75rem;
            font-weight: 600;
            color: var(--gray-500);
            text-transform: uppercase;
            letter-spacing: 0.05em;
            background: var(--gray-50);
            border-bottom: 1px solid var(--gray-200);
        }
        .table td {
            padding: 0.875rem 1rem;
            font-size: 0.875rem;
            color: var(--gray-700);
            border-bottom: 1px solid var(--gray-100);
        }
        .table tbody tr:hover {
            background: var(--gray-50);
        }

        /* Forms */
        .form-group {
            margin-bottom: 1rem;
        }
        .form-label {
            display: block;
            font-size: 0.875rem;
            font-weight: 500;
            color: var(--gray-700);
            margin-bottom: 0.5rem;
        }
        .form-input, .form-select {
            width: 100%;
            padding: 0.625rem 1rem;
            border: 1px solid var(--gray-300);
            border-radius: 10px;
            font-size: 0.875rem;
            transition: all 0.2s;
            font-family: inherit;
        }
        .form-input:focus, .form-select:focus {
            outline: none;
            border-color: var(--primary-500);
            box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.1);
        }

        /* Grid */
        .grid {
            display: grid;
            gap: 1.5rem;
        }
        .grid-cols-2 {
            grid-template-columns: repeat(2, 1fr);
        }
        .grid-cols-3 {
            grid-template-columns: repeat(3, 1fr);
        }
        .grid-cols-4 {
            grid-template-columns: repeat(4, 1fr);
        }
        @media (max-width: 1024px) {
            .grid-cols-4 {
                grid-template-columns: repeat(2, 1fr);
            }
        }
        @media (max-width: 768px) {
            .grid-cols-2, .grid-cols-3, .grid-cols-4 {
                grid-template-columns: 1fr;
            }
        }

        /* Flex */
        .flex { display: flex; }
        .items-center { align-items: center; }
        .justify-between { justify-content: space-between; }
        .gap-2 { gap: 0.5rem; }
        .gap-4 { gap: 1rem; }

        /* Spacing */
        .mb-4 { margin-bottom: 1rem; }
        .mb-6 { margin-bottom: 1.5rem; }
        .p-4 { padding: 1rem; }
        .p-6 { padding: 1.5rem; }

        /* Text */
        .text-sm { font-size: 0.875rem; }
        .text-lg { font-size: 1.125rem; }
        .text-xl { font-size: 1.25rem; }
        .text-2xl { font-size: 1.5rem; }
        .font-bold { font-weight: 700; }
        .font-semibold { font-weight: 600; }
        .text-gray-500 { color: var(--gray-500); }
        .text-gray-700 { color: var(--gray-700); }
        .text-gray-900 { color: var(--gray-900); }

        /* Modal */
        .modal {
            display: none;
            position: fixed;
            inset: 0;
            z-index: 200;
            align-items: center;
            justify-content: center;
            padding: 1rem;
            background: rgba(0,0,0,0.5);
            backdrop-filter: blur(4px);
        }
        .modal.active {
            display: flex;
        }
        .modal-content {
            background: white;
            border-radius: 20px;
            width: 100%;
            max-width: 500px;
            max-height: 90vh;
            overflow-y: auto;
        }
        .modal-header {
            padding: 1.25rem 1.5rem;
            border-bottom: 1px solid var(--gray-100);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .modal-title {
            font-size: 1.125rem;
            font-weight: 600;
        }
        .modal-close {
            background: none;
            border: none;
            cursor: pointer;
            color: var(--gray-400);
            padding: 0.25rem;
        }
        .modal-close:hover {
            color: var(--gray-600);
        }
        .modal-body {
            padding: 1.5rem;
        }
        .modal-footer {
            padding: 1rem 1.5rem;
            border-top: 1px solid var(--gray-100);
            display: flex;
            justify-content: flex-end;
            gap: 0.75rem;
        }

        /* Table wrapper for responsive */
        .table-wrapper {
            overflow-x: auto;
        }

        /* Stats Grid - for merchants, transactions etc */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 1rem;
            margin-bottom: 1.5rem;
        }
        @media (max-width: 1024px) {
            .stats-grid { grid-template-columns: repeat(2, 1fr); }
        }
        @media (max-width: 768px) {
            .stats-grid { grid-template-columns: 1fr; }
        }

        .stat-card {
            background: white;
            border-radius: 12px;
            padding: 1.25rem;
            border: 1px solid var(--gray-200);
            transition: all 0.2s;
        }
        .stat-card:hover {
            box-shadow: 0 4px 20px rgba(0,0,0,0.05);
        }
        .stat-card .stat-icon {
            width: 44px;
            height: 44px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 0.75rem;
        }
        .stat-card .stat-icon svg {
            width: 22px;
            height: 22px;
        }
        .stat-card .stat-icon.primary { background: var(--primary-100); color: var(--primary-600); }
        .stat-card .stat-icon.success { background: #d1fae5; color: #059669; }
        .stat-card .stat-icon.warning { background: #fef3c7; color: #d97706; }
        .stat-card .stat-icon.danger { background: #fee2e2; color: #dc2626; }
        .stat-card .stat-icon.info { background: #dbeafe; color: #2563eb; }
        .stat-card .stat-value {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--gray-900);
            margin-bottom: 0.25rem;
        }
        .stat-card .stat-label {
            font-size: 0.8rem;
            color: var(--gray-500);
        }

        /* Filters Bar */
        .filter-bar {
            display: flex;
            gap: 1rem;
            margin-bottom: 1.5rem;
            flex-wrap: wrap;
            align-items: center;
        }
        .filter-bar .form-input,
        .filter-bar .form-select {
            width: auto;
            min-width: 150px;
        }

        /* Pending Row Highlight */
        .pending-row {
            background: #fffbeb !important;
        }
        .pending-row:hover {
            background: #fef3c7 !important;
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 3rem;
            color: var(--gray-400);
        }
        .empty-state svg {
            width: 64px;
            height: 64px;
            margin-bottom: 1rem;
            opacity: 0.5;
        }

        /* Action Buttons in Table */
        .action-btns {
            display: flex;
            gap: 0.5rem;
        }

        /* Warning Button */
        .btn-warning {
            background: var(--warning);
            color: white;
        }
        .btn-warning:hover {
            background: #d97706;
        }

        /* Info Button */
        .btn-info {
            background: var(--info);
            color: white;
        }
        .btn-info:hover {
            background: #2563eb;
        }

        /* Text Colors */
        .text-success { color: var(--success) !important; }
        .text-danger { color: var(--danger) !important; }
        .text-warning { color: var(--warning) !important; }
        .text-info { color: var(--info) !important; }
        .text-primary { color: var(--primary) !important; }

        /* Status Dot */
        .status-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            display: inline-block;
            margin-right: 0.5rem;
        }
        .status-dot.active { background: var(--success); }
        .status-dot.pending { background: var(--warning); }
        .status-dot.inactive { background: var(--gray-400); }
        .status-dot.banned { background: var(--danger); }

        /* Tabs */
        .tabs {
            display: flex;
            gap: 0;
            border-bottom: 2px solid var(--gray-200);
            margin-bottom: 1.5rem;
        }
        .tab {
            padding: 0.75rem 1.5rem;
            font-weight: 500;
            color: var(--gray-500);
            text-decoration: none;
            border-bottom: 2px solid transparent;
            margin-bottom: -2px;
            transition: all 0.2s;
        }
        .tab:hover {
            color: var(--gray-700);
        }
        .tab.active {
            color: var(--primary);
            border-bottom-color: var(--primary);
        }

        /* Detail Box */
        .detail-box {
            background: var(--gray-50);
            border-radius: 10px;
            padding: 1rem;
        }
        .detail-row {
            display: flex;
            justify-content: space-between;
            padding: 0.5rem 0;
            border-bottom: 1px solid var(--gray-100);
        }
        .detail-row:last-child {
            border-bottom: none;
        }
        .detail-label {
            color: var(--gray-500);
            font-size: 0.875rem;
        }
        .detail-value {
            font-weight: 600;
            color: var(--gray-900);
        }

        /* Pagination */
        .pagination {
            display: flex;
            justify-content: center;
            gap: 0.5rem;
            margin-top: 1.5rem;
        }
        .pagination .btn {
            min-width: 36px;
        }
    </style>
    <?php if (isset($extraCss)) echo "<style>$extraCss</style>"; ?>
</head>
<body>
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <a href="index.php" class="sidebar-logo">
                <div class="logo-icon">
                    <svg viewBox="0 0 24 24" fill="none">
                        <path d="M4 20 C4 20, 7 15, 10 10 C11 8, 11.5 6, 12 4" stroke="#14B8A6" stroke-width="2.5" stroke-linecap="round"/>
                        <path d="M20 20 C20 20, 17 15, 14 10 C13 8, 12.5 6, 12 4" stroke="#0D9488" stroke-width="2.5" stroke-linecap="round"/>
                        <circle cx="12" cy="4" r="2.5" fill="#F59E0B"/>
                        <line x1="12" y1="7" x2="12" y2="18" stroke="#0D9488" stroke-width="2" stroke-linecap="round"/>
                    </svg>
                </div>
                <span class="logo-text">NEO PGA</span>
                <span class="admin-badge">ADMIN</span>
            </a>
        </div>

        <nav class="sidebar-nav">
            <div class="nav-section">
                <div class="nav-section-title">Dashboard</div>
                <a href="index.php" class="nav-link <?= ($currentPage ?? '') === 'dashboard' ? 'active' : '' ?>">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2V9z"/>
                        <path d="M9 22V12h6v10"/>
                    </svg>
                    Dashboard
                </a>
            </div>

            <div class="nav-section">
                <div class="nav-section-title">Transaksi</div>
                <a href="transactions.php" class="nav-link <?= ($currentPage ?? '') === 'transactions' ? 'active' : '' ?>">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/>
                    </svg>
                    Transaksi
                    <?php if (($pendingTrx['c'] ?? 0) > 0): ?><span class="nav-badge"><?= $pendingTrx['c'] ?></span><?php endif; ?>
                </a>
                <a href="verify.php" class="nav-link <?= ($currentPage ?? '') === 'verify' ? 'active' : '' ?>">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M22 11.08V12a10 10 0 11-5.93-9.14"/>
                        <polyline points="22,4 12,14.01 9,11.01"/>
                    </svg>
                    Verifikasi
                </a>
                <a href="payment-codes.php" class="nav-link <?= ($currentPage ?? '') === 'payment-codes' ? 'active' : '' ?>">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
                    </svg>
                    Kode Unik
                </a>
            </div>

            <div class="nav-section">
                <div class="nav-section-title">Kelola</div>
                <a href="merchants.php" class="nav-link <?= ($currentPage ?? '') === 'merchants' ? 'active' : '' ?>">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M3 3h18v18H3zM3 9h18M9 21V9"/>
                    </svg>
                    Merchant
                    <?php if (($pendingMerchants['c'] ?? 0) > 0): ?><span class="nav-badge"><?= $pendingMerchants['c'] ?></span><?php endif; ?>
                </a>
                <a href="settlements.php" class="nav-link <?= ($currentPage ?? '') === 'settlements' ? 'active' : '' ?>">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <rect x="2" y="4" width="20" height="16" rx="2"/>
                        <path d="M12 10v4M10 12h4"/>
                    </svg>
                    Settlement
                    <?php if (($pendingSettlements['c'] ?? 0) > 0): ?><span class="nav-badge"><?= $pendingSettlements['c'] ?></span><?php endif; ?>
                </a>
                <a href="banks.php" class="nav-link <?= ($currentPage ?? '') === 'banks' ? 'active' : '' ?>">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <rect x="3" y="3" width="18" height="18" rx="2"/>
                        <path d="M3 9h18M9 21V9"/>
                    </svg>
                    Rekening Bank
                </a>
            </div>

            <div class="nav-section">
                <div class="nav-section-title">Laporan</div>
                <a href="reports.php" class="nav-link <?= ($currentPage ?? '') === 'reports' ? 'active' : '' ?>">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M18 20V10"/>
                        <path d="M12 20V4"/>
                        <path d="M6 20v-6"/>
                    </svg>
                    Laporan
                </a>
                <a href="activity.php" class="nav-link <?= ($currentPage ?? '') === 'activity' ? 'active' : '' ?>">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="12" cy="12" r="10"/>
                        <polyline points="12,6 12,12 16,14"/>
                    </svg>
                    Activity Log
                </a>
            </div>

            <div class="nav-section">
                <div class="nav-section-title">Pengaturan</div>
                <a href="qris-settings.php" class="nav-link <?= ($currentPage ?? '') === 'qris' ? 'active' : '' ?>">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <rect x="3" y="3" width="7" height="7"/>
                        <rect x="14" y="3" width="7" height="7"/>
                        <rect x="14" y="14" width="7" height="7"/>
                        <rect x="3" y="14" width="7" height="7"/>
                    </svg>
                    Pengaturan QRIS
                </a>
                <a href="settings.php" class="nav-link <?= ($currentPage ?? '') === 'settings' ? 'active' : '' ?>">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="12" cy="12" r="3"/>
                        <path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-2 2 2 2 0 01-2-2v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83 0 2 2 0 010-2.83l.06-.06a1.65 1.65 0 00.33-1.82 1.65 1.65 0 00-1.51-1H3a2 2 0 01-2-2 2 2 0 012-2h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 010-2.83 2 2 0 012.83 0l.06.06a1.65 1.65 0 001.82.33H9a1.65 1.65 0 001-1.51V3a2 2 0 012-2 2 2 0 012 2v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 0 2 2 0 010 2.83l-.06.06a1.65 1.65 0 00-.33 1.82V9a1.65 1.65 0 001.51 1H21a2 2 0 012 2 2 2 0 01-2 2h-.09a1.65 1.65 0 00-1.51 1z"/>
                    </svg>
                    Pengaturan
                </a>
                <a href="admins.php" class="nav-link <?= ($currentPage ?? '') === 'admins' ? 'active' : '' ?>">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/>
                        <circle cx="9" cy="7" r="4"/>
                        <path d="M23 21v-2a4 4 0 00-3-3.87"/>
                        <path d="M16 3.13a4 4 0 010 7.75"/>
                    </svg>
                    Admin Users
                </a>
            </div>
        </nav>

        <div class="sidebar-footer">
            <div class="user-card">
                <div class="user-avatar"><?= strtoupper(substr($adminUser['full_name'] ?? 'A', 0, 1)) ?></div>
                <div class="user-info">
                    <div class="user-name"><?= htmlspecialchars($adminUser['full_name'] ?? 'Admin') ?></div>
                    <div class="user-role"><?= $adminUser['role'] ?? 'admin' ?></div>
                </div>
                <a href="logout.php" class="logout-btn" title="Logout">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/>
                        <polyline points="16,17 21,12 16,7"/>
                        <line x1="21" y1="12" x2="9" y2="12"/>
                    </svg>
                </a>
            </div>
        </div>
    </aside>

    <main class="main-content">
        <header class="top-header">
            <div class="header-left">
                <button class="mobile-menu-btn" id="mobileMenuBtn">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="3" y1="12" x2="21" y2="12"/>
                        <line x1="3" y1="6" x2="21" y2="6"/>
                        <line x1="3" y1="18" x2="21" y2="18"/>
                    </svg>
                </button>
                <div>
                    <h1 class="page-title"><?= $pageTitle ?? 'Dashboard' ?></h1>
                    <?php if (isset($breadcrumb)): ?>
                    <div class="breadcrumb">
                        <a href="index.php">Dashboard</a>
                        <span>→</span>
                        <span><?= $breadcrumb ?></span>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="header-actions">
                <div class="header-time">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="12" cy="12" r="10"/>
                        <polyline points="12,6 12,12 16,14"/>
                    </svg>
                    <?= date('d M Y, H:i') ?> WIB
                </div>
                <button class="header-btn" title="Notifikasi">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/>
                        <path d="M13.73 21a2 2 0 01-3.46 0"/>
                    </svg>
                    <?php if ($totalPending > 0): ?><span class="notification-dot"></span><?php endif; ?>
                </button>
                <button class="header-btn" onclick="location.reload()" title="Refresh">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <polyline points="23,4 23,10 17,10"/>
                        <path d="M20.49 15a9 9 0 11-2.12-9.36L23 10"/>
                    </svg>
                </button>
            </div>
        </header>

        <div class="content-area">
            <?php $flash = getFlashMessage(); if ($flash): ?>
            <div class="alert alert-<?= $flash['type'] ?>" id="flashAlert">
                <?php if ($flash['type'] === 'success'): ?>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M22 11.08V12a10 10 0 11-5.93-9.14"/>
                    <polyline points="22,4 12,14.01 9,11.01"/>
                </svg>
                <?php elseif ($flash['type'] === 'danger'): ?>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="10"/>
                    <line x1="15" y1="9" x2="9" y2="15"/>
                    <line x1="9" y1="9" x2="15" y2="15"/>
                </svg>
                <?php else: ?>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="10"/>
                    <line x1="12" y1="16" x2="12" y2="12"/>
                    <line x1="12" y1="8" x2="12.01" y2="8"/>
                </svg>
                <?php endif; ?>
                <span><?= htmlspecialchars($flash['message']) ?></span>
                <button class="alert-close" onclick="this.parentElement.remove()">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="18" y1="6" x2="6" y2="18"/>
                        <line x1="6" y1="6" x2="18" y2="18"/>
                    </svg>
                </button>
            </div>
            <?php endif; ?>

            <?= $content ?? '' ?>
        </div>
    </main>

    <script>
        const mobileMenuBtn = document.getElementById('mobileMenuBtn');
        const sidebar = document.getElementById('sidebar');
        const sidebarOverlay = document.getElementById('sidebarOverlay');

        mobileMenuBtn?.addEventListener('click', () => {
            sidebar.classList.toggle('open');
            sidebarOverlay.classList.toggle('active');
            document.body.style.overflow = sidebar.classList.contains('open') ? 'hidden' : '';
        });

        sidebarOverlay?.addEventListener('click', () => {
            sidebar.classList.remove('open');
            sidebarOverlay.classList.remove('active');
            document.body.style.overflow = '';
        });

        // Auto-close flash alert
        setTimeout(() => {
            const flash = document.getElementById('flashAlert');
            if (flash) {
                flash.style.opacity = '0';
                flash.style.transition = 'opacity 0.3s';
                setTimeout(() => flash.remove(), 300);
            }
        }, 5000);

        // Helper functions
        function formatRupiah(num) {
            return 'Rp ' + num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
        }

        function formatNumber(num) {
            return new Intl.NumberFormat('id-ID').format(num);
        }

        function openModal(id) {
            document.getElementById(id)?.classList.add('active');
            document.body.style.overflow = 'hidden';
        }

        function closeModal(id) {
            document.getElementById(id)?.classList.remove('active');
            document.body.style.overflow = '';
        }

        // Close modal on backdrop click
        document.querySelectorAll('.modal').forEach(modal => {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    modal.classList.remove('active');
                    document.body.style.overflow = '';
                }
            });
        });

        // CSRF Token
        const csrfToken = '<?= generateCsrfToken() ?>';

        // ============================================
        // AUTO-REFRESH SYSTEM (Every 2 seconds)
        // Smart refresh - tidak mengganggu user activity
        // ============================================
        const AutoRefresh = {
            interval: 2000, // 2 detik
            timer: null,
            lastActivity: Date.now(),
            paused: false,

            init() {
                // Start auto-refresh
                this.start();

                // Track user activity
                document.addEventListener('keydown', () => this.onUserActivity());
                document.addEventListener('mousedown', () => this.onUserActivity());
                document.addEventListener('focus', (e) => {
                    if (e.target.matches('input, textarea, select')) {
                        this.pause();
                    }
                }, true);
                document.addEventListener('blur', (e) => {
                    if (e.target.matches('input, textarea, select')) {
                        // Resume after 1 second if user left input
                        setTimeout(() => {
                            if (!document.activeElement.matches('input, textarea, select')) {
                                this.resume();
                            }
                        }, 1000);
                    }
                }, true);

                // Pause when modal is open
                const observer = new MutationObserver(() => {
                    const modalOpen = document.querySelector('.modal.active');
                    if (modalOpen) {
                        this.pause();
                    } else if (this.paused && !document.activeElement.matches('input, textarea, select')) {
                        this.resume();
                    }
                });
                observer.observe(document.body, { attributes: true, subtree: true, attributeFilter: ['class'] });

                // Show refresh indicator
                this.createIndicator();
            },

            createIndicator() {
                const indicator = document.createElement('div');
                indicator.id = 'autoRefreshIndicator';
                indicator.innerHTML = `
                    <div style="display:flex;align-items:center;gap:6px">
                        <span class="pulse-dot"></span>
                        <span>Auto-Refresh: <strong>ON</strong></span>
                    </div>
                `;
                indicator.style.cssText = `
                    position: fixed;
                    bottom: 20px;
                    right: 20px;
                    background: linear-gradient(135deg, #10b981, #059669);
                    color: white;
                    padding: 8px 16px;
                    border-radius: 50px;
                    font-size: 12px;
                    font-weight: 500;
                    z-index: 9999;
                    box-shadow: 0 4px 15px rgba(16, 185, 129, 0.4);
                    display: flex;
                    align-items: center;
                    gap: 8px;
                `;
                document.body.appendChild(indicator);

                // Add pulse animation style
                const style = document.createElement('style');
                style.textContent = `
                    .pulse-dot {
                        width: 8px;
                        height: 8px;
                        background: white;
                        border-radius: 50%;
                        animation: pulse 1s infinite;
                    }
                    @keyframes pulse {
                        0%, 100% { opacity: 1; transform: scale(1); }
                        50% { opacity: 0.5; transform: scale(1.2); }
                    }
                    #autoRefreshIndicator.paused {
                        background: linear-gradient(135deg, #f59e0b, #d97706) !important;
                    }
                    #autoRefreshIndicator.paused .pulse-dot {
                        animation: none;
                        background: rgba(255,255,255,0.5);
                    }
                `;
                document.head.appendChild(style);
            },

            start() {
                this.timer = setInterval(() => this.refresh(), this.interval);
            },

            stop() {
                if (this.timer) {
                    clearInterval(this.timer);
                    this.timer = null;
                }
            },

            pause() {
                this.paused = true;
                const indicator = document.getElementById('autoRefreshIndicator');
                if (indicator) {
                    indicator.classList.add('paused');
                    indicator.querySelector('strong').textContent = 'PAUSED';
                }
            },

            resume() {
                this.paused = false;
                const indicator = document.getElementById('autoRefreshIndicator');
                if (indicator) {
                    indicator.classList.remove('paused');
                    indicator.querySelector('strong').textContent = 'ON';
                }
            },

            onUserActivity() {
                this.lastActivity = Date.now();
            },

            shouldRefresh() {
                // Jangan refresh jika:
                // 1. User sedang typing (focus di input)
                // 2. Modal terbuka
                // 3. Paused manually
                // 4. User baru saja aktif (< 500ms)

                if (this.paused) return false;
                if (document.activeElement.matches('input, textarea, select')) return false;
                if (document.querySelector('.modal.active')) return false;
                if (Date.now() - this.lastActivity < 500) return false;

                return true;
            },

            refresh() {
                if (!this.shouldRefresh()) return;

                // Save scroll position
                const scrollPos = window.scrollY;

                // Use AJAX to refresh content
                fetch(window.location.href, {
                    headers: { 'X-Requested-With': 'XMLHttpRequest' }
                })
                .then(response => response.text())
                .then(html => {
                    // Parse new content
                    const parser = new DOMParser();
                    const newDoc = parser.parseFromString(html, 'text/html');

                    // Update content area only
                    const newContent = newDoc.querySelector('.content-area');
                    const currentContent = document.querySelector('.content-area');

                    if (newContent && currentContent) {
                        // Update specific elements that change
                        this.updateElements(newDoc);
                    }

                    // Restore scroll position
                    window.scrollTo(0, scrollPos);

                    // Flash indicator to show refresh happened
                    const indicator = document.getElementById('autoRefreshIndicator');
                    if (indicator) {
                        indicator.style.transform = 'scale(1.1)';
                        setTimeout(() => indicator.style.transform = 'scale(1)', 200);
                    }
                })
                .catch(err => console.log('Auto-refresh error:', err));
            },

            updateElements(newDoc) {
                // Update tables
                const tables = document.querySelectorAll('.table tbody');
                const newTables = newDoc.querySelectorAll('.table tbody');
                tables.forEach((table, i) => {
                    if (newTables[i]) {
                        table.innerHTML = newTables[i].innerHTML;
                    }
                });

                // Update stat cards
                const stats = document.querySelectorAll('.stat-card .stat-value, .stat-box .stat-value, .code-stat-value');
                const newStats = newDoc.querySelectorAll('.stat-card .stat-value, .stat-box .stat-value, .code-stat-value');
                stats.forEach((stat, i) => {
                    if (newStats[i] && stat.textContent !== newStats[i].textContent) {
                        stat.textContent = newStats[i].textContent;
                        // Highlight changed value
                        stat.style.transition = 'background 0.3s';
                        stat.style.background = 'rgba(16, 185, 129, 0.2)';
                        setTimeout(() => stat.style.background = '', 500);
                    }
                });

                // Update badges
                const badges = document.querySelectorAll('.nav-badge, .badge');
                const newBadges = newDoc.querySelectorAll('.nav-badge, .badge');
                badges.forEach((badge, i) => {
                    if (newBadges[i]) {
                        badge.textContent = newBadges[i].textContent;
                    }
                });

                // Update progress bars
                const progressFills = document.querySelectorAll('.progress-fill');
                const newProgressFills = newDoc.querySelectorAll('.progress-fill');
                progressFills.forEach((fill, i) => {
                    if (newProgressFills[i]) {
                        fill.style.width = newProgressFills[i].style.width;
                    }
                });

                // Update header time
                const time = document.querySelector('.header-time');
                const newTime = newDoc.querySelector('.header-time');
                if (time && newTime) {
                    time.innerHTML = newTime.innerHTML;
                }
            }
        };

        // Initialize auto-refresh when page loads
        document.addEventListener('DOMContentLoaded', () => AutoRefresh.init());
    </script>
    <?php if (isset($extraJs)) echo $extraJs; ?>

    <!-- Security Protection -->
    <script src="<?= ASSETS_URL ?>/js/security.js"></script>
</body>
</html>

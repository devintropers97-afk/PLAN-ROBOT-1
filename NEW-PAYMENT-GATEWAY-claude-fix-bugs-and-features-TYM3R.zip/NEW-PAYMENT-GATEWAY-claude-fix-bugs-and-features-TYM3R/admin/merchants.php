<?php
/**
 * NEO PGA Admin - Merchant Management
 * Dengan fitur: Edit komisi, Review data pendaftar, Approve/Reject
 */
require_once __DIR__ . '/../includes/init.php';

$auth = new Auth('admin');
$auth->requireAuth();

$adminUser = $auth->user();
$db = Database::getInstance();
$message = '';
$messageType = '';

// Handle Create Merchant
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_merchant'])) {
    verifyCsrf();
    
    $businessName = sanitize($_POST['business_name'] ?? '');
    $ownerName = sanitize($_POST['owner_name'] ?? '');
    $email = sanitize($_POST['email'] ?? '');
    $phone = sanitize($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';
    $commission = (float)($_POST['commission_rate'] ?? 2.5);
    
    if (empty($businessName) || empty($email) || empty($password)) {
        $message = 'Nama bisnis, email, dan password wajib diisi';
        $messageType = 'danger';
    } else {
        $exists = $db->fetch("SELECT id FROM merchants WHERE email = ?", [$email]);
        if ($exists) {
            $message = 'Email sudah terdaftar';
            $messageType = 'danger';
        } else {
            $merchantCode = 'M-' . strtoupper(substr(md5(uniqid()), 0, 6));
            $apiKey = 'nb_live_' . bin2hex(random_bytes(24));
            $secretKey = 'nb_secret_' . bin2hex(random_bytes(24));
            $hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
            
            try {
                $db->insert('merchants', [
                    'merchant_code' => $merchantCode,
                    'business_name' => $businessName,
                    'owner_name' => $ownerName,
                    'email' => $email,
                    'phone' => $phone,
                    'password' => $hash,
                    'api_key' => $apiKey,
                    'secret_key' => $secretKey,
                    'commission_rate' => $commission,
                    'status' => 'active'
                ]);
                $message = "Merchant berhasil dibuat! Kode: $merchantCode";
                $messageType = 'success';
            } catch (Exception $e) {
                $message = 'Gagal membuat merchant: ' . $e->getMessage();
                $messageType = 'danger';
            }
        }
    }
}

// Handle Approve Merchant
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['approve_merchant'])) {
    verifyCsrf();
    $id = (int)$_POST['merchant_id'];
    $commission = (float)($_POST['commission_rate'] ?? 2.5);
    
    // Generate API keys saat approve
    $apiKey = 'nb_live_' . bin2hex(random_bytes(24));
    $secretKey = 'nb_secret_' . bin2hex(random_bytes(24));
    
    $db->update('merchants', [
        'status' => 'active',
        'commission_rate' => $commission,
        'api_key' => $apiKey,
        'secret_key' => $secretKey,
        'approved_at' => date('Y-m-d H:i:s'),
        'approved_by' => $adminUser['id']
    ], 'id = ?', [$id]);
    
    $message = 'Merchant berhasil di-approve!';
    $messageType = 'success';
}

// Handle Reject Merchant
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reject_merchant'])) {
    verifyCsrf();
    $id = (int)$_POST['merchant_id'];
    $reason = sanitize($_POST['reject_reason'] ?? '');
    
    $db->update('merchants', [
        'status' => 'rejected',
        'reject_reason' => $reason,
        'rejected_at' => date('Y-m-d H:i:s')
    ], 'id = ?', [$id]);
    
    $message = 'Merchant ditolak';
    $messageType = 'warning';
}

// Handle Update Status
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    verifyCsrf();
    $id = (int)$_POST['merchant_id'];
    $status = sanitize($_POST['status'] ?? '');
    if (in_array($status, ['active', 'suspended', 'pending'])) {
        $db->update('merchants', ['status' => $status], 'id = ?', [$id]);
        $message = 'Status merchant berhasil diubah';
        $messageType = 'success';
    }
}

// Handle Update Commission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_commission'])) {
    verifyCsrf();
    $id = (int)$_POST['merchant_id'];
    $commission = (float)$_POST['commission_rate'];
    if ($commission >= 0 && $commission <= 100) {
        $db->update('merchants', ['commission_rate' => $commission], 'id = ?', [$id]);
        $message = 'Komisi merchant berhasil diubah menjadi ' . $commission . '%';
        $messageType = 'success';
    }
}

// Handle Delete
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_merchant'])) {
    verifyCsrf();
    $id = (int)$_POST['merchant_id'];
    $db->delete('merchants', 'id = ?', [$id]);
    $message = 'Merchant berhasil dihapus';
    $messageType = 'success';
}

// Handle Edit Merchant Details
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_merchant'])) {
    verifyCsrf();
    $id = (int)$_POST['merchant_id'];
    $businessName = sanitize($_POST['business_name'] ?? '');
    $ownerName = sanitize($_POST['owner_name'] ?? '');
    $phone = sanitize($_POST['phone'] ?? '');
    $address = sanitize($_POST['address'] ?? '');
    $webhookUrl = sanitize($_POST['webhook_url'] ?? '');
    $callbackUrl = sanitize($_POST['callback_url'] ?? '');

    if (!empty($businessName)) {
        $db->update('merchants', [
            'business_name' => $businessName,
            'owner_name' => $ownerName,
            'phone' => $phone,
            'address' => $address,
            'webhook_url' => $webhookUrl,
            'callback_url' => $callbackUrl
        ], 'id = ?', [$id]);
        $message = 'Data merchant berhasil diperbarui';
        $messageType = 'success';
    }
}

// Handle Refresh API Keys
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['refresh_api_keys'])) {
    verifyCsrf();
    $id = (int)$_POST['merchant_id'];
    $apiKey = 'nb_live_' . bin2hex(random_bytes(24));
    $secretKey = 'nb_secret_' . bin2hex(random_bytes(24));

    $db->update('merchants', [
        'api_key' => $apiKey,
        'secret_key' => $secretKey
    ], 'id = ?', [$id]);

    $message = 'API Keys berhasil di-refresh!';
    $messageType = 'success';
}

// Handle Adjust Balance
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['adjust_balance'])) {
    verifyCsrf();
    $id = (int)$_POST['merchant_id'];
    $adjustType = sanitize($_POST['adjust_type'] ?? 'add');
    $amount = (float)$_POST['adjust_amount'];
    $notes = sanitize($_POST['adjust_notes'] ?? '');

    if ($amount > 0) {
        $merchant = $db->fetch("SELECT * FROM merchants WHERE id = ?", [$id]);
        if ($merchant) {
            $currentBalance = (float)$merchant['balance'];
            $newBalance = $adjustType === 'add' ? $currentBalance + $amount : max(0, $currentBalance - $amount);

            $db->update('merchants', ['balance' => $newBalance], 'id = ?', [$id]);

            // Log adjustment
            logActivity('admin', $adminUser['id'], 'balance_adjustment', 'merchants',
                "Merchant #{$merchant['merchant_code']} balance {$adjustType}: " . formatRupiah($amount) . ". Notes: $notes");

            $message = "Balance berhasil di-adjust. Balance baru: " . formatRupiah($newBalance);
            $messageType = 'success';
        }
    }
}

// Filters
$search = sanitize($_GET['search'] ?? '');
$statusFilter = sanitize($_GET['status'] ?? '');
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 20;
$offset = ($page - 1) * $perPage;

$where = "1=1";
$params = [];

if ($search) {
    $where .= " AND (business_name LIKE ? OR email LIKE ? OR merchant_code LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}
if ($statusFilter) {
    $where .= " AND status = ?";
    $params[] = $statusFilter;
}

$total = $db->fetch("SELECT COUNT(*) as c FROM merchants WHERE $where", $params)['c'] ?? 0;
$merchants = $db->fetchAll("SELECT * FROM merchants WHERE $where ORDER BY created_at DESC LIMIT $perPage OFFSET $offset", $params);
$totalPages = ceil($total / $perPage);

// Stats
$stats = [
    'total' => $db->fetch("SELECT COUNT(*) as c FROM merchants")['c'] ?? 0,
    'active' => $db->fetch("SELECT COUNT(*) as c FROM merchants WHERE status = 'active'")['c'] ?? 0,
    'pending' => $db->fetch("SELECT COUNT(*) as c FROM merchants WHERE status = 'pending'")['c'] ?? 0,
    'suspended' => $db->fetch("SELECT COUNT(*) as c FROM merchants WHERE status = 'suspended'")['c'] ?? 0,
];

$pageTitle = 'Kelola Merchant';
$currentPage = 'merchants';

$extraCss = '
.merchant-card { background: white; border-radius: 12px; border: 1px solid var(--gray-200); margin-bottom: 1rem; overflow: hidden; }
.merchant-header { padding: 1rem 1.5rem; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid var(--gray-100); }
.merchant-body { padding: 1.5rem; }
.merchant-info-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 1rem; }
.merchant-info-item label { font-size: 0.75rem; color: var(--gray-500); display: block; margin-bottom: 0.25rem; }
.merchant-info-item .value { font-weight: 600; }
.merchant-actions { display: flex; gap: 0.5rem; flex-wrap: wrap; }
.pending-badge { background: #fef3c7; color: #92400e; padding: 0.25rem 0.75rem; border-radius: 20px; font-size: 0.75rem; font-weight: 600; }
.review-section { background: var(--gray-50); border-radius: 8px; padding: 1rem; margin-top: 1rem; }
.review-section h4 { font-size: 0.875rem; font-weight: 600; margin-bottom: 0.75rem; color: var(--gray-700); }
';

ob_start();
?>

<div class="flex justify-between items-center mb-6">
    <div>
        <h1 class="text-2xl font-bold text-gray-900">Kelola Merchant</h1>
        <p class="text-gray-500">Manajemen akun merchant payment gateway</p>
    </div>
    <button onclick="openModal('addMerchantModal')" class="btn btn-primary">+ Tambah Merchant</button>
</div>

<?php if ($message): ?>
<div class="alert alert-<?= $messageType ?> mb-4"><?= htmlspecialchars($message) ?></div>
<?php endif; ?>

<!-- Stats -->
<div class="stats-grid mb-6">
    <div class="stat-card">
        <div class="stat-icon" style="background:var(--gray-100);color:var(--gray-600)">📊</div>
        <div class="stat-content">
            <div class="stat-value"><?= $stats['total'] ?></div>
            <div class="stat-label">Total Merchant</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background:#dcfce7;color:#16a34a">✓</div>
        <div class="stat-content">
            <div class="stat-value"><?= $stats['active'] ?></div>
            <div class="stat-label">Aktif</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background:#fef3c7;color:#d97706">⏳</div>
        <div class="stat-content">
            <div class="stat-value"><?= $stats['pending'] ?></div>
            <div class="stat-label">Menunggu Review</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background:#fee2e2;color:#dc2626">⏸</div>
        <div class="stat-content">
            <div class="stat-value"><?= $stats['suspended'] ?></div>
            <div class="stat-label">Suspended</div>
        </div>
    </div>
</div>

<!-- Filter -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" class="flex gap-4 items-end flex-wrap">
            <div class="form-group mb-0" style="flex:1;min-width:200px">
                <label class="form-label">Pencarian</label>
                <input type="text" name="search" class="form-input" value="<?= htmlspecialchars($search) ?>" placeholder="Nama, email, kode...">
            </div>
            <div class="form-group mb-0">
                <label class="form-label">Status</label>
                <select name="status" class="form-select">
                    <option value="">Semua Status</option>
                    <option value="active" <?= $statusFilter === 'active' ? 'selected' : '' ?>>Active</option>
                    <option value="pending" <?= $statusFilter === 'pending' ? 'selected' : '' ?>>Pending Review</option>
                    <option value="suspended" <?= $statusFilter === 'suspended' ? 'selected' : '' ?>>Suspended</option>
                    <option value="rejected" <?= $statusFilter === 'rejected' ? 'selected' : '' ?>>Rejected</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Filter</button>
            <?php if ($search || $statusFilter): ?>
            <a href="merchants.php" class="btn btn-secondary">Reset</a>
            <?php endif; ?>
        </form>
    </div>
</div>

<!-- Merchant List -->
<?php if (empty($merchants)): ?>
<div class="card">
    <div class="card-body" style="text-align:center;padding:3rem">
        <p style="color:var(--gray-500);margin-bottom:1rem">Tidak ada merchant ditemukan</p>
    </div>
</div>
<?php else: ?>
<?php foreach ($merchants as $m): ?>
<div class="merchant-card <?= $m['status'] === 'pending' ? 'border-warning' : '' ?>" style="<?= $m['status'] === 'pending' ? 'border-color:#f59e0b;border-width:2px' : '' ?>">
    <div class="merchant-header">
        <div style="display:flex;align-items:center;gap:1rem">
            <div style="width:48px;height:48px;border-radius:12px;background:var(--primary);color:white;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:1.25rem">
                <?= strtoupper(substr($m['business_name'], 0, 1)) ?>
            </div>
            <div>
                <h3 style="font-weight:600;font-size:1.1rem"><?= htmlspecialchars($m['business_name']) ?></h3>
                <div style="font-size:0.875rem;color:var(--gray-500)">
                    <code><?= htmlspecialchars($m['merchant_code'] ?? 'Belum ada kode') ?></code>
                    • <?= htmlspecialchars($m['email']) ?>
                </div>
            </div>
        </div>
        <div style="display:flex;align-items:center;gap:1rem">
            <?php if ($m['status'] === 'pending'): ?>
            <span class="pending-badge">⏳ MENUNGGU REVIEW</span>
            <?php else: ?>
            <span class="badge badge-<?= $m['status'] === 'active' ? 'success' : ($m['status'] === 'suspended' ? 'danger' : 'neutral') ?>">
                <?= ucfirst($m['status']) ?>
            </span>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="merchant-body">
        <div class="merchant-info-grid">
            <div class="merchant-info-item">
                <label>Pemilik</label>
                <div class="value"><?= htmlspecialchars($m['owner_name'] ?: '-') ?></div>
            </div>
            <div class="merchant-info-item">
                <label>Telepon</label>
                <div class="value"><?= htmlspecialchars($m['phone'] ?: '-') ?></div>
            </div>
            <div class="merchant-info-item">
                <label>Komisi</label>
                <div class="value" style="color:var(--primary)"><?= number_format($m['commission_rate'] ?? 2.5, 1) ?>%</div>
            </div>
            <div class="merchant-info-item">
                <label>Terdaftar</label>
                <div class="value"><?= date('d M Y', strtotime($m['created_at'])) ?></div>
            </div>
        </div>
        <?php if ($m['status'] !== 'pending'): ?>
        <div style="margin-top:1rem;display:grid;grid-template-columns:repeat(3,1fr);gap:1rem;background:var(--gray-50);padding:1rem;border-radius:8px">
            <div class="merchant-info-item">
                <label>💰 Saldo Tersedia</label>
                <div class="value" style="color:var(--success);font-size:1.1rem"><?= formatRupiah($m['balance'] ?? 0) ?></div>
            </div>
            <div class="merchant-info-item">
                <label>⏳ Pending Withdrawal</label>
                <div class="value" style="color:var(--warning);font-size:1.1rem"><?= formatRupiah($m['pending_balance'] ?? 0) ?></div>
            </div>
            <div class="merchant-info-item">
                <label>📊 Total Transaksi</label>
                <?php
                $trxCount = $db->fetch("SELECT COUNT(*) as c, SUM(CASE WHEN status='success' THEN total_amount ELSE 0 END) as amount FROM transactions WHERE merchant_id = ?", [$m['id']]);
                ?>
                <div class="value"><?= number_format($trxCount['c'] ?? 0) ?> (<?= formatRupiah($trxCount['amount'] ?? 0) ?>)</div>
            </div>
        </div>
        <?php endif; ?>
        
        <?php if ($m['status'] === 'pending'): ?>
        <!-- Review Section for Pending Merchants -->
        <div class="review-section">
            <h4>📋 Data Pendaftaran untuk Review:</h4>
            <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:1rem;margin-bottom:1rem">
                <div>
                    <label style="font-size:0.75rem;color:var(--gray-500)">Jenis Usaha</label>
                    <div style="font-weight:500"><?= htmlspecialchars($m['business_type'] ?? 'Tidak disebutkan') ?></div>
                </div>
                <div>
                    <label style="font-size:0.75rem;color:var(--gray-500)">Website/Toko Online</label>
                    <div style="font-weight:500"><?= htmlspecialchars($m['website'] ?? 'Tidak ada') ?></div>
                </div>
                <div>
                    <label style="font-size:0.75rem;color:var(--gray-500)">Estimasi Transaksi/Bulan</label>
                    <div style="font-weight:500"><?= htmlspecialchars($m['expected_volume'] ?? 'Tidak disebutkan') ?></div>
                </div>
                <div>
                    <label style="font-size:0.75rem;color:var(--gray-500)">Alamat</label>
                    <div style="font-weight:500"><?= htmlspecialchars($m['address'] ?? 'Tidak ada') ?></div>
                </div>
            </div>
            <div style="margin-bottom:1rem">
                <label style="font-size:0.75rem;color:var(--gray-500)">Tujuan Penggunaan</label>
                <div style="font-weight:500;background:white;padding:0.75rem;border-radius:6px;border:1px solid var(--gray-200)">
                    <?= nl2br(htmlspecialchars($m['business_description'] ?? 'Tidak ada keterangan')) ?>
                </div>
            </div>
            
            <!-- Approve/Reject Actions -->
            <div style="display:flex;gap:1rem;flex-wrap:wrap;align-items:flex-end">
                <form method="POST" style="display:flex;gap:0.5rem;align-items:flex-end">
                    <?= csrfField() ?>
                    <input type="hidden" name="approve_merchant" value="1">
                    <input type="hidden" name="merchant_id" value="<?= $m['id'] ?>">
                    <div>
                        <label style="font-size:0.75rem;color:var(--gray-600)">Set Komisi (%)</label>
                        <input type="number" name="commission_rate" value="2.5" step="0.1" min="0" max="100" class="form-input" style="width:80px">
                    </div>
                    <button type="submit" class="btn btn-success">✓ Approve</button>
                </form>
                <button onclick="rejectMerchant(<?= $m['id'] ?>, '<?= htmlspecialchars($m['business_name']) ?>')" class="btn btn-danger">✕ Reject</button>
            </div>
        </div>
        <?php else: ?>
        <!-- Actions for Active/Suspended Merchants -->
        <div style="margin-top:1rem;padding-top:1rem;border-top:1px solid var(--gray-100);display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:0.75rem">
            <div class="merchant-actions">
                <button onclick="viewMerchant(<?= htmlspecialchars(json_encode($m)) ?>)" class="btn btn-sm btn-secondary">👁 Detail</button>
                <button onclick="editMerchant(<?= htmlspecialchars(json_encode($m)) ?>)" class="btn btn-sm btn-info">✏️ Edit</button>
                <button onclick="editCommission(<?= $m['id'] ?>, <?= $m['commission_rate'] ?? 2.5 ?>, '<?= htmlspecialchars($m['business_name']) ?>')" class="btn btn-sm btn-secondary">💰 Komisi</button>
                <button onclick="adjustBalance(<?= $m['id'] ?>, '<?= htmlspecialchars($m['business_name']) ?>', <?= $m['balance'] ?? 0 ?>)" class="btn btn-sm btn-success">💵 Adjust</button>
                <a href="transactions.php?merchant_id=<?= $m['id'] ?>" class="btn btn-sm btn-secondary">📋 Transaksi</a>
                <?php if ($m['status'] === 'active'): ?>
                <form method="POST" style="display:inline">
                    <?= csrfField() ?>
                    <input type="hidden" name="update_status" value="1">
                    <input type="hidden" name="merchant_id" value="<?= $m['id'] ?>">
                    <input type="hidden" name="status" value="suspended">
                    <button type="submit" class="btn btn-sm btn-warning" onclick="return confirm('Suspend merchant ini?')">⏸ Suspend</button>
                </form>
                <?php else: ?>
                <form method="POST" style="display:inline">
                    <?= csrfField() ?>
                    <input type="hidden" name="update_status" value="1">
                    <input type="hidden" name="merchant_id" value="<?= $m['id'] ?>">
                    <input type="hidden" name="status" value="active">
                    <button type="submit" class="btn btn-sm btn-success">▶ Aktifkan</button>
                </form>
                <?php endif; ?>
            </div>
            <div class="merchant-actions">
                <form method="POST" style="display:inline" onsubmit="return confirm('Refresh API Keys untuk <?= htmlspecialchars($m['business_name']) ?>? Keys lama tidak akan valid!')">
                    <?= csrfField() ?>
                    <input type="hidden" name="refresh_api_keys" value="1">
                    <input type="hidden" name="merchant_id" value="<?= $m['id'] ?>">
                    <button type="submit" class="btn btn-sm btn-warning">🔄 Refresh Keys</button>
                </form>
                <form method="POST" style="display:inline" onsubmit="return confirm('HAPUS merchant <?= htmlspecialchars($m['business_name']) ?>? Data tidak bisa dikembalikan!')">
                    <?= csrfField() ?>
                    <input type="hidden" name="delete_merchant" value="1">
                    <input type="hidden" name="merchant_id" value="<?= $m['id'] ?>">
                    <button type="submit" class="btn btn-sm btn-danger">🗑</button>
                </form>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php endforeach; ?>

<!-- Pagination -->
<?php if ($totalPages > 1): ?>
<div style="display:flex;justify-content:center;gap:0.5rem;margin-top:1.5rem">
    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
    <a href="?page=<?= $i ?>&search=<?= urlencode($search) ?>&status=<?= urlencode($statusFilter) ?>" 
       class="btn btn-sm <?= $i === $page ? 'btn-primary' : 'btn-secondary' ?>"><?= $i ?></a>
    <?php endfor; ?>
</div>
<?php endif; ?>
<?php endif; ?>

<!-- Add Merchant Modal -->
<div id="addMerchantModal" class="modal">
    <div class="modal-content" style="max-width:500px">
        <div class="modal-header">
            <h3 class="modal-title">Tambah Merchant Baru</h3>
            <button onclick="closeModal('addMerchantModal')" class="modal-close">&times;</button>
        </div>
        <form method="POST">
            <?= csrfField() ?>
            <input type="hidden" name="create_merchant" value="1">
            <div class="modal-body">
                <div class="form-group">
                    <label class="form-label">Nama Bisnis *</label>
                    <input type="text" name="business_name" class="form-input" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Nama Pemilik</label>
                    <input type="text" name="owner_name" class="form-input">
                </div>
                <div class="grid grid-cols-2 gap-4">
                    <div class="form-group">
                        <label class="form-label">Email *</label>
                        <input type="email" name="email" class="form-input" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Telepon</label>
                        <input type="text" name="phone" class="form-input">
                    </div>
                </div>
                <div class="grid grid-cols-2 gap-4">
                    <div class="form-group">
                        <label class="form-label">Password *</label>
                        <input type="password" name="password" class="form-input" required minlength="6">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Komisi (%)</label>
                        <input type="number" name="commission_rate" class="form-input" value="2.5" step="0.1" min="0" max="100">
                    </div>
                </div>
                <p style="font-size:0.75rem;color:var(--gray-500)">* Merchant yang dibuat dari sini langsung aktif (skip review)</p>
            </div>
            <div class="modal-footer">
                <button type="button" onclick="closeModal('addMerchantModal')" class="btn btn-secondary">Batal</button>
                <button type="submit" class="btn btn-primary">Buat Merchant</button>
            </div>
        </form>
    </div>
</div>

<!-- View Merchant Modal -->
<div id="viewMerchantModal" class="modal">
    <div class="modal-content" style="max-width:600px">
        <div class="modal-header">
            <h3 class="modal-title">Detail Merchant</h3>
            <button onclick="closeModal('viewMerchantModal')" class="modal-close">&times;</button>
        </div>
        <div class="modal-body" id="merchantDetailContent"></div>
    </div>
</div>

<!-- Edit Commission Modal -->
<div id="editCommissionModal" class="modal">
    <div class="modal-content" style="max-width:400px">
        <div class="modal-header">
            <h3 class="modal-title">Edit Komisi</h3>
            <button onclick="closeModal('editCommissionModal')" class="modal-close">&times;</button>
        </div>
        <form method="POST">
            <?= csrfField() ?>
            <input type="hidden" name="update_commission" value="1">
            <input type="hidden" name="merchant_id" id="commissionMerchantId">
            <div class="modal-body">
                <p style="margin-bottom:1rem">Merchant: <strong id="commissionMerchantName"></strong></p>
                <div class="form-group">
                    <label class="form-label">Komisi (%)</label>
                    <input type="number" name="commission_rate" id="commissionRate" class="form-input" step="0.1" min="0" max="100" required>
                    <small style="color:var(--gray-500)">Persentase yang dipotong dari setiap transaksi sukses</small>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" onclick="closeModal('editCommissionModal')" class="btn btn-secondary">Batal</button>
                <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
        </form>
    </div>
</div>

<!-- Reject Modal -->
<div id="rejectModal" class="modal">
    <div class="modal-content" style="max-width:450px">
        <div class="modal-header">
            <h3 class="modal-title">Tolak Pendaftaran</h3>
            <button onclick="closeModal('rejectModal')" class="modal-close">&times;</button>
        </div>
        <form method="POST">
            <?= csrfField() ?>
            <input type="hidden" name="reject_merchant" value="1">
            <input type="hidden" name="merchant_id" id="rejectMerchantId">
            <div class="modal-body">
                <p style="margin-bottom:1rem">Tolak pendaftaran: <strong id="rejectMerchantName"></strong></p>
                <div class="form-group">
                    <label class="form-label">Alasan Penolakan *</label>
                    <textarea name="reject_reason" class="form-input" rows="3" required placeholder="Jelaskan alasan penolakan..."></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" onclick="closeModal('rejectModal')" class="btn btn-secondary">Batal</button>
                <button type="submit" class="btn btn-danger">Tolak</button>
            </div>
        </form>
    </div>
</div>

<!-- Edit Merchant Modal -->
<div id="editMerchantModal" class="modal">
    <div class="modal-content" style="max-width:550px">
        <div class="modal-header">
            <h3 class="modal-title">Edit Data Merchant</h3>
            <button onclick="closeModal('editMerchantModal')" class="modal-close">&times;</button>
        </div>
        <form method="POST">
            <?= csrfField() ?>
            <input type="hidden" name="edit_merchant" value="1">
            <input type="hidden" name="merchant_id" id="editMerchantId">
            <div class="modal-body">
                <div class="form-group">
                    <label class="form-label">Nama Bisnis *</label>
                    <input type="text" name="business_name" id="editBusinessName" class="form-input" required>
                </div>
                <div class="grid grid-cols-2 gap-4">
                    <div class="form-group">
                        <label class="form-label">Nama Pemilik</label>
                        <input type="text" name="owner_name" id="editOwnerName" class="form-input">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Telepon</label>
                        <input type="text" name="phone" id="editPhone" class="form-input">
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">Alamat</label>
                    <textarea name="address" id="editAddress" class="form-input" rows="2"></textarea>
                </div>
                <div class="form-group">
                    <label class="form-label">Webhook URL</label>
                    <input type="url" name="webhook_url" id="editWebhookUrl" class="form-input" placeholder="https://yoursite.com/webhook">
                </div>
                <div class="form-group">
                    <label class="form-label">Callback URL</label>
                    <input type="url" name="callback_url" id="editCallbackUrl" class="form-input" placeholder="https://yoursite.com/callback">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" onclick="closeModal('editMerchantModal')" class="btn btn-secondary">Batal</button>
                <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
            </div>
        </form>
    </div>
</div>

<!-- Adjust Balance Modal -->
<div id="adjustBalanceModal" class="modal">
    <div class="modal-content" style="max-width:450px">
        <div class="modal-header">
            <h3 class="modal-title">💵 Adjust Balance</h3>
            <button onclick="closeModal('adjustBalanceModal')" class="modal-close">&times;</button>
        </div>
        <form method="POST">
            <?= csrfField() ?>
            <input type="hidden" name="adjust_balance" value="1">
            <input type="hidden" name="merchant_id" id="adjustMerchantId">
            <div class="modal-body">
                <p style="margin-bottom:0.5rem">Merchant: <strong id="adjustMerchantName"></strong></p>
                <p style="margin-bottom:1rem;color:var(--gray-500)">Saldo saat ini: <strong id="adjustCurrentBalance" style="color:var(--success)"></strong></p>

                <div class="form-group">
                    <label class="form-label">Tipe Adjustment</label>
                    <select name="adjust_type" class="form-select" required>
                        <option value="add">➕ Tambah Saldo</option>
                        <option value="subtract">➖ Kurangi Saldo</option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Jumlah (Rp)</label>
                    <input type="number" name="adjust_amount" class="form-input" min="1" required placeholder="100000">
                </div>
                <div class="form-group">
                    <label class="form-label">Catatan / Alasan *</label>
                    <textarea name="adjust_notes" class="form-input" rows="2" required placeholder="Contoh: Koreksi pembayaran manual, refund, dll"></textarea>
                </div>
                <div style="background:#fef3c7;border:1px solid #fcd34d;border-radius:8px;padding:0.75rem;font-size:0.85rem;color:#92400e">
                    ⚠️ Adjustment akan langsung mempengaruhi saldo merchant. Pastikan data sudah benar!
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" onclick="closeModal('adjustBalanceModal')" class="btn btn-secondary">Batal</button>
                <button type="submit" class="btn btn-success">Proses Adjustment</button>
            </div>
        </form>
    </div>
</div>

<script>
function viewMerchant(m) {
    const balance = parseFloat(m.balance || 0);
    const pendingBalance = parseFloat(m.pending_balance || 0);
    let html = `
        <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:1rem">
            <div><label style="font-size:0.75rem;color:var(--gray-500)">Kode Merchant</label><div style="font-weight:600">${m.merchant_code || '-'}</div></div>
            <div><label style="font-size:0.75rem;color:var(--gray-500)">Status</label><div style="font-weight:600">${m.status}</div></div>
            <div><label style="font-size:0.75rem;color:var(--gray-500)">Nama Bisnis</label><div style="font-weight:600">${m.business_name}</div></div>
            <div><label style="font-size:0.75rem;color:var(--gray-500)">Pemilik</label><div style="font-weight:600">${m.owner_name || '-'}</div></div>
            <div><label style="font-size:0.75rem;color:var(--gray-500)">Email</label><div style="font-weight:600">${m.email}</div></div>
            <div><label style="font-size:0.75rem;color:var(--gray-500)">Telepon</label><div style="font-weight:600">${m.phone || '-'}</div></div>
            <div><label style="font-size:0.75rem;color:var(--gray-500)">Komisi</label><div style="font-weight:600;color:var(--primary)">${m.commission_rate || 2.5}%</div></div>
            <div><label style="font-size:0.75rem;color:var(--gray-500)">Terdaftar</label><div style="font-weight:600">${m.created_at}</div></div>
        </div>
        <div style="margin-top:1rem;display:grid;grid-template-columns:repeat(2,1fr);gap:1rem;background:var(--gray-50);padding:1rem;border-radius:8px">
            <div><label style="font-size:0.75rem;color:var(--gray-500)">💰 Saldo Tersedia</label><div style="font-weight:700;font-size:1.1rem;color:var(--success)">Rp ${balance.toLocaleString('id-ID')}</div></div>
            <div><label style="font-size:0.75rem;color:var(--gray-500)">⏳ Pending Withdrawal</label><div style="font-weight:700;font-size:1.1rem;color:var(--warning)">Rp ${pendingBalance.toLocaleString('id-ID')}</div></div>
        </div>
        <div style="margin-top:1.5rem;padding-top:1rem;border-top:1px solid var(--gray-200)">
            <h4 style="font-weight:600;margin-bottom:0.75rem">🔑 API Credentials</h4>
            <div style="margin-bottom:0.75rem">
                <label style="font-size:0.75rem;color:var(--gray-500)">API Key</label>
                <div style="background:var(--gray-100);padding:0.5rem;border-radius:4px;font-family:monospace;font-size:0.75rem;word-break:break-all">${m.api_key || 'Belum di-generate'}</div>
            </div>
            <div style="margin-bottom:0.75rem">
                <label style="font-size:0.75rem;color:var(--gray-500)">Secret Key</label>
                <div style="background:var(--gray-100);padding:0.5rem;border-radius:4px;font-family:monospace;font-size:0.75rem;word-break:break-all">${m.secret_key || 'Belum di-generate'}</div>
            </div>
        </div>
        <div style="margin-top:1rem;padding-top:1rem;border-top:1px solid var(--gray-200)">
            <h4 style="font-weight:600;margin-bottom:0.75rem">🔗 URLs</h4>
            <div style="margin-bottom:0.5rem">
                <label style="font-size:0.75rem;color:var(--gray-500)">Webhook URL</label>
                <div style="font-size:0.85rem">${m.webhook_url || 'Tidak diset'}</div>
            </div>
            <div>
                <label style="font-size:0.75rem;color:var(--gray-500)">Callback URL</label>
                <div style="font-size:0.85rem">${m.callback_url || 'Tidak diset'}</div>
            </div>
        </div>
    `;
    document.getElementById('merchantDetailContent').innerHTML = html;
    openModal('viewMerchantModal');
}

function editMerchant(m) {
    document.getElementById('editMerchantId').value = m.id;
    document.getElementById('editBusinessName').value = m.business_name || '';
    document.getElementById('editOwnerName').value = m.owner_name || '';
    document.getElementById('editPhone').value = m.phone || '';
    document.getElementById('editAddress').value = m.address || '';
    document.getElementById('editWebhookUrl').value = m.webhook_url || '';
    document.getElementById('editCallbackUrl').value = m.callback_url || '';
    openModal('editMerchantModal');
}

function editCommission(id, rate, name) {
    document.getElementById('commissionMerchantId').value = id;
    document.getElementById('commissionMerchantName').textContent = name;
    document.getElementById('commissionRate').value = rate;
    openModal('editCommissionModal');
}

function adjustBalance(id, name, balance) {
    document.getElementById('adjustMerchantId').value = id;
    document.getElementById('adjustMerchantName').textContent = name;
    document.getElementById('adjustCurrentBalance').textContent = 'Rp ' + parseFloat(balance).toLocaleString('id-ID');
    openModal('adjustBalanceModal');
}

function rejectMerchant(id, name) {
    document.getElementById('rejectMerchantId').value = id;
    document.getElementById('rejectMerchantName').textContent = name;
    openModal('rejectModal');
}
</script>

<?php
$content = ob_get_clean();
include __DIR__ . '/layout.php';
?>

<?php
/**
 * ================================================================================
 *                    NEO PGA - TERIMA NOTIFIKASI PEMBAYARAN
 * ================================================================================
 *
 * File ini dipanggil OTOMATIS oleh NEO PGA saat ada pembayaran.
 * Kamu akan dapat email notifikasi setiap ada pembayaran berhasil.
 *
 * TIDAK PERLU EDIT FILE INI - Cukup edit config.php saja!
 *
 * ================================================================================
 */

require_once __DIR__ . '/config.php';

// Verifikasi callback dari NEO PGA
$data = neopga_verify_callback();

// Jika tidak valid, tolak
if (!$data) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Invalid callback']);
    exit;
}

// Ambil data pembayaran
$invoice = $data['invoice_number'] ?? '';
$orderId = $data['reference_id'] ?? '';
$status = $data['status'] ?? '';
$amount = $data['amount'] ?? 0;
$customerName = $data['customer_name'] ?? '';
$customerEmail = $data['customer_email'] ?? '';
$customerPhone = $data['customer_phone'] ?? '';
$description = $data['description'] ?? '';
$paidAt = $data['paid_at'] ?? date('Y-m-d H:i:s');

// Log ke file
$logFile = __DIR__ . '/pembayaran.log';
$logLine = date('Y-m-d H:i:s') . " | $status | $invoice | $orderId | " . format_rupiah($amount) . " | $customerName | $customerEmail\n";
@file_put_contents($logFile, $logLine, FILE_APPEND);

// Proses berdasarkan status
if ($status === 'success') {
    // ========================================
    // PEMBAYARAN BERHASIL!
    // ========================================

    // 1. Kirim email ke pemilik toko
    if (KIRIM_EMAIL && EMAIL_TOKO) {
        $emailBody = "
        <html>
        <body style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;'>
            <div style='background: linear-gradient(135deg, #0d9488, #0f766e); color: white; padding: 30px; text-align: center; border-radius: 12px 12px 0 0;'>
                <h1 style='margin: 0;'>💰 Pembayaran Berhasil!</h1>
            </div>
            <div style='background: #f9fafb; padding: 30px; border-radius: 0 0 12px 12px;'>
                <table style='width: 100%; border-collapse: collapse;'>
                    <tr>
                        <td style='padding: 12px 0; border-bottom: 1px solid #e5e7eb; color: #6b7280;'>Invoice</td>
                        <td style='padding: 12px 0; border-bottom: 1px solid #e5e7eb; font-weight: bold;'>$invoice</td>
                    </tr>
                    <tr>
                        <td style='padding: 12px 0; border-bottom: 1px solid #e5e7eb; color: #6b7280;'>Order ID</td>
                        <td style='padding: 12px 0; border-bottom: 1px solid #e5e7eb;'>$orderId</td>
                    </tr>
                    <tr>
                        <td style='padding: 12px 0; border-bottom: 1px solid #e5e7eb; color: #6b7280;'>Produk</td>
                        <td style='padding: 12px 0; border-bottom: 1px solid #e5e7eb;'>$description</td>
                    </tr>
                    <tr>
                        <td style='padding: 12px 0; border-bottom: 1px solid #e5e7eb; color: #6b7280;'>Jumlah</td>
                        <td style='padding: 12px 0; border-bottom: 1px solid #e5e7eb; font-size: 20px; color: #0d9488; font-weight: bold;'>" . format_rupiah($amount) . "</td>
                    </tr>
                    <tr>
                        <td style='padding: 12px 0; border-bottom: 1px solid #e5e7eb; color: #6b7280;'>Pembeli</td>
                        <td style='padding: 12px 0; border-bottom: 1px solid #e5e7eb;'>$customerName</td>
                    </tr>
                    <tr>
                        <td style='padding: 12px 0; border-bottom: 1px solid #e5e7eb; color: #6b7280;'>Email</td>
                        <td style='padding: 12px 0; border-bottom: 1px solid #e5e7eb;'>$customerEmail</td>
                    </tr>
                    <tr>
                        <td style='padding: 12px 0; border-bottom: 1px solid #e5e7eb; color: #6b7280;'>No. HP</td>
                        <td style='padding: 12px 0; border-bottom: 1px solid #e5e7eb;'>$customerPhone</td>
                    </tr>
                    <tr>
                        <td style='padding: 12px 0; color: #6b7280;'>Waktu Bayar</td>
                        <td style='padding: 12px 0;'>$paidAt</td>
                    </tr>
                </table>

                <div style='margin-top: 24px; text-align: center;'>
                    <p style='color: #6b7280; font-size: 14px;'>Email ini dikirim otomatis oleh sistem " . NAMA_TOKO . "</p>
                </div>
            </div>
        </body>
        </html>
        ";

        neopga_send_email(EMAIL_TOKO, EMAIL_SUBJECT . ' - ' . format_rupiah($amount), $emailBody);
    }

    // 2. Kirim email ke pembeli (opsional)
    if (KIRIM_EMAIL && $customerEmail) {
        $buyerEmail = "
        <html>
        <body style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;'>
            <div style='background: linear-gradient(135deg, #0d9488, #0f766e); color: white; padding: 30px; text-align: center; border-radius: 12px 12px 0 0;'>
                <h1 style='margin: 0;'>✅ Pembayaran Diterima!</h1>
                <p style='margin: 10px 0 0; opacity: 0.9;'>Terima kasih, $customerName</p>
            </div>
            <div style='background: #f9fafb; padding: 30px; border-radius: 0 0 12px 12px;'>
                <p>Pembayaran kamu untuk <strong>$description</strong> sebesar <strong>" . format_rupiah($amount) . "</strong> sudah kami terima.</p>

                <div style='background: white; padding: 20px; border-radius: 8px; margin: 20px 0;'>
                    <p style='margin: 0 0 8px; color: #6b7280; font-size: 14px;'>Nomor Invoice</p>
                    <p style='margin: 0; font-size: 18px; font-weight: bold; color: #0d9488;'>$invoice</p>
                </div>

                <p style='color: #6b7280; font-size: 14px;'>Simpan email ini sebagai bukti pembayaran.</p>

                <hr style='border: none; border-top: 1px solid #e5e7eb; margin: 24px 0;'>

                <p style='color: #6b7280; font-size: 12px; text-align: center;'>
                    " . NAMA_TOKO . "<br>
                    " . get_homepage_url() . "
                </p>
            </div>
        </body>
        </html>
        ";

        neopga_send_email($customerEmail, 'Pembayaran Berhasil - ' . NAMA_TOKO, $buyerEmail);
    }

    // 3. Log sukses
    @file_put_contents($logFile, "   ✅ Email notifikasi terkirim\n", FILE_APPEND);

    // ========================================
    // TAMBAHKAN KODE KAMU DI SINI (OPSIONAL)
    // ========================================
    // Contoh: Update database, kirim ke sistem lain, dll
    //
    // $pdo->query("UPDATE orders SET status = 'paid' WHERE order_id = '$orderId'");
    //
    // ========================================
}

if ($status === 'failed') {
    @file_put_contents($logFile, "   ❌ Pembayaran gagal\n", FILE_APPEND);
}

if ($status === 'expired') {
    @file_put_contents($logFile, "   ⏰ Pembayaran expired\n", FILE_APPEND);
}

// Balas ke NEO PGA
header('Content-Type: application/json');
echo json_encode(['success' => true, 'message' => 'Callback received']);

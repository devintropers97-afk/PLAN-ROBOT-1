<?php
/**
 * NEO PGA - Contoh Tombol Bayar Siap Pakai
 * Copy kode HTML di bawah ke website kamu
 */
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contoh Tombol Bayar - NEO PGA</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #f3f4f6; min-height: 100vh; padding: 40px 20px; }
        .container { max-width: 800px; margin: 0 auto; }
        h1 { text-align: center; color: #1f2937; margin-bottom: 10px; }
        .subtitle { text-align: center; color: #6b7280; margin-bottom: 40px; }
        .section { background: #fff; border-radius: 16px; padding: 30px; margin-bottom: 24px; box-shadow: 0 4px 15px rgba(0,0,0,.05); }
        .section-title { font-size: 1.2rem; font-weight: 700; color: #1f2937; margin-bottom: 16px; display: flex; align-items: center; gap: 10px; }
        .section-title span { font-size: 1.4rem; }
        .note { background: #fef3c7; border: 1px solid #fcd34d; border-radius: 10px; padding: 14px 18px; margin-bottom: 20px; font-size: .9rem; color: #92400e; }
        .code-box { background: #1e293b; border-radius: 12px; padding: 20px; overflow-x: auto; position: relative; }
        .code-box pre { color: #e2e8f0; font-family: 'Courier New', monospace; font-size: 13px; line-height: 1.6; white-space: pre; margin: 0; }
        .copy-btn { position: absolute; top: 12px; right: 12px; background: #334155; border: none; color: #94a3b8; padding: 8px 14px; border-radius: 6px; cursor: pointer; font-size: .8rem; }
        .copy-btn:hover { background: #475569; color: #fff; }
        .copy-btn.copied { background: #10b981; color: #fff; }
        .preview { border: 2px dashed #e5e7eb; border-radius: 12px; padding: 30px; margin-top: 20px; background: #f9fafb; }
        .preview-title { font-size: .8rem; color: #9ca3af; text-transform: uppercase; margin-bottom: 16px; text-align: center; }
        .neopga-form { max-width: 400px; margin: 0 auto; padding: 30px; background: #fff; border-radius: 16px; box-shadow: 0 4px 20px rgba(0,0,0,.1); }
        .neopga-form h3 { margin: 0 0 20px; color: #1f2937; font-size: 1.4rem; text-align: center; }
        .neopga-form .form-group { margin-bottom: 16px; }
        .neopga-form label { display: block; margin-bottom: 6px; color: #374151; font-weight: 500; font-size: 14px; }
        .neopga-form input { width: 100%; padding: 12px 16px; border: 2px solid #e5e7eb; border-radius: 10px; font-size: 16px; }
        .neopga-form input:focus { outline: none; border-color: #0d9488; }
        .neopga-form .btn-bayar { width: 100%; padding: 16px; background: linear-gradient(135deg, #0d9488, #0f766e); color: #fff; border: none; border-radius: 12px; font-size: 18px; font-weight: 600; cursor: pointer; }
        .neopga-form .btn-bayar:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(13,148,136,.4); }
        .neopga-form .harga-display { text-align: center; font-size: 2rem; font-weight: 800; color: #0d9488; margin: 20px 0; }
        .neopga-form .secure-badge { text-align: center; margin-top: 16px; color: #6b7280; font-size: 12px; }
        .btn-simple { display: inline-block; padding: 16px 32px; background: linear-gradient(135deg, #0d9488, #0f766e); color: #fff; text-decoration: none; border-radius: 12px; font-weight: 700; font-size: 1rem; }
        .btn-simple:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(13,148,136,.4); }
    </style>
</head>
<body>
    <div class="container">
        <h1>🛒 Contoh Tombol Bayar</h1>
        <p class="subtitle">Copy kode di bawah ke website kamu</p>
        
        <div class="section">
            <div class="section-title"><span>📝</span> Form Pembayaran Lengkap</div>
            <div class="note">
                <strong>Cara Pakai:</strong> Copy kode di bawah → Paste di halaman website kamu → Ganti <code>DOMAINKAMU.com</code> dengan domain kamu
            </div>
            
            <div class="code-box">
                <button class="copy-btn" onclick="copyCode('code1', this)">📋 Copy</button>
                <pre id="code1">&lt;form class="neobayar-form" action="https://DOMAINKAMU.com/index.php?action=checkout" method="POST"&gt;
    &lt;h3&gt;🛒 Form Pembayaran&lt;/h3&gt;
    
    &lt;input type="hidden" name="product" value="Nama Produk Kamu"&gt;
    &lt;input type="hidden" name="amount" value="150000"&gt;
    
    &lt;div class="harga-display"&gt;Rp 150.000&lt;/div&gt;
    
    &lt;div class="form-group"&gt;
        &lt;label&gt;Nama Lengkap&lt;/label&gt;
        &lt;input type="text" name="name" placeholder="Masukkan nama" required&gt;
    &lt;/div&gt;
    
    &lt;div class="form-group"&gt;
        &lt;label&gt;Email&lt;/label&gt;
        &lt;input type="email" name="email" placeholder="email@contoh.com" required&gt;
    &lt;/div&gt;
    
    &lt;div class="form-group"&gt;
        &lt;label&gt;No. WhatsApp&lt;/label&gt;
        &lt;input type="tel" name="phone" placeholder="08123456789" required&gt;
    &lt;/div&gt;
    
    &lt;button type="submit" class="btn-bayar"&gt;🔒 Bayar Sekarang&lt;/button&gt;
    &lt;div class="secure-badge"&gt;🔐 Pembayaran aman via NEO PGA&lt;/div&gt;
&lt;/form&gt;

&lt;style&gt;
.neopga-form { max-width:400px; margin:20px auto; padding:30px; background:#fff; border-radius:16px; box-shadow:0 4px 20px rgba(0,0,0,.1); font-family:Arial,sans-serif; }
.neopga-form h3 { margin:0 0 20px; text-align:center; }
.neopga-form .form-group { margin-bottom:16px; }
.neopga-form label { display:block; margin-bottom:6px; font-weight:500; font-size:14px; }
.neopga-form input[type="text"], .neopga-form input[type="email"], .neopga-form input[type="tel"] { width:100%; padding:12px 16px; border:2px solid #e5e7eb; border-radius:10px; font-size:16px; box-sizing:border-box; }
.neopga-form .btn-bayar { width:100%; padding:16px; background:linear-gradient(135deg,#0d9488,#0f766e); color:#fff; border:none; border-radius:12px; font-size:18px; font-weight:600; cursor:pointer; }
.neopga-form .harga-display { text-align:center; font-size:2rem; font-weight:800; color:#0d9488; margin:20px 0; }
.neopga-form .secure-badge { text-align:center; margin-top:16px; color:#6b7280; font-size:12px; }
&lt;/style&gt;</pre>
            </div>
            
            <div class="preview">
                <div class="preview-title">Preview</div>
                <form class="neobayar-form" style="box-shadow:none;" onsubmit="return false;">
                    <h3>🛒 Form Pembayaran</h3>
                    <div class="harga-display">Rp 150.000</div>
                    <div class="form-group"><label>Nama Lengkap</label><input type="text" placeholder="Masukkan nama" disabled></div>
                    <div class="form-group"><label>Email</label><input type="email" placeholder="email@contoh.com" disabled></div>
                    <div class="form-group"><label>No. WhatsApp</label><input type="tel" placeholder="08123456789" disabled></div>
                    <button type="button" class="btn-bayar">🔒 Bayar Sekarang</button>
                    <div class="secure-badge">🔐 Pembayaran aman via NEO PGA</div>
                </form>
            </div>
        </div>
        
        <div class="section">
            <div class="section-title"><span>🔘</span> Tombol Bayar Simple</div>
            <div class="note">Untuk tombol langsung tanpa form (harga fixed)</div>
            
            <div class="code-box">
                <button class="copy-btn" onclick="copyCode('code2', this)">📋 Copy</button>
                <pre id="code2">&lt;a href="https://DOMAINKAMU.com/index.php?action=checkout&amp;amount=150000&amp;product=Nama%20Produk" class="btn-bayar-simple"&gt;
    Beli Sekarang - Rp 150.000
&lt;/a&gt;

&lt;style&gt;
.btn-bayar-simple { display:inline-block; padding:16px 32px; background:linear-gradient(135deg,#0d9488,#0f766e); color:#fff; text-decoration:none; border-radius:12px; font-weight:700; }
&lt;/style&gt;</pre>
            </div>
            
            <div class="preview">
                <div class="preview-title">Preview</div>
                <div style="text-align:center;">
                    <a href="#" class="btn-simple" onclick="return false;">Beli Sekarang - Rp 150.000</a>
                </div>
            </div>
        </div>
        
        <div class="section" style="background:linear-gradient(135deg,#dbeafe,#eff6ff);border:1px solid #93c5fd;">
            <div class="section-title"><span>💡</span> Catatan Penting</div>
            <ul style="color:#1e40af;font-size:.95rem;line-height:1.8;padding-left:20px;">
                <li>Ganti <code>DOMAINKAMU.com</code> dengan domain website kamu</li>
                <li>Ganti <code>150000</code> dengan harga produk (Rupiah, tanpa titik)</li>
                <li>Ganti <code>Nama Produk</code> dengan nama produk yang dijual</li>
                <li>Pastikan file <code>index.php</code> sudah ada (lihat Panduan Simpel di dashboard)</li>
            </ul>
        </div>
    </div>
    
    <script>
    function copyCode(id, btn) {
        navigator.clipboard.writeText(document.getElementById(id).innerText).then(() => {
            btn.innerText = '✓ Copied!';
            btn.classList.add('copied');
            setTimeout(() => { btn.innerText = '📋 Copy'; btn.classList.remove('copied'); }, 2000);
        });
    }
    </script>
</body>
</html>

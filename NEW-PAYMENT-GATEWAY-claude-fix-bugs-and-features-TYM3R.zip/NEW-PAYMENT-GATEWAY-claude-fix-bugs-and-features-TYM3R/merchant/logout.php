<?php
/**
 * NEO PGA Merchant - Logout
 * Secure logout with session destruction
 */
require_once __DIR__ . '/../includes/init.php';

// Clear merchant session data
unset($_SESSION['merchant_user']);

// Clear any flash messages
unset($_SESSION['flash_message'], $_SESSION['flash_type']);

// Regenerate session ID for security
session_regenerate_id(true);

// Redirect to login with logout message
$_SESSION['flash_message'] = 'Anda telah berhasil logout';
$_SESSION['flash_type'] = 'success';

header('Location: login.php');
exit;

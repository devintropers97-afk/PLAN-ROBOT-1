<?php
/**
 * NEO PGA - Installation Wizard
 * Jalankan file ini sekali untuk setup database dan konfigurasi
 */

session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

$step = $_GET['step'] ?? 1;
$error = '';
$success = '';

// Simple sanitize function for install script (standalone)
function install_sanitize($input) {
    if ($input === null) return '';
    $input = trim((string) $input);
    $input = strip_tags($input);
    return htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
}

// Simple XSS detection for install script
function install_detectXSS($input) {
    if (empty($input)) return false;
    $patterns = ['/<script/i', '/javascript:/i', '/on\w+\s*=/i', '/<iframe/i', '/<object/i'];
    foreach ($patterns as $pattern) {
        if (preg_match($pattern, $input)) return true;
    }
    return false;
}

// Validate database/table name (prevent SQL injection in identifiers)
function install_validateDbName($name) {
    // MySQL identifier rules: alphanumeric, underscore, max 64 chars
    // Must not start with a number
    if (empty($name)) return false;
    if (strlen($name) > 64) return false;
    if (!preg_match('/^[a-zA-Z_][a-zA-Z0-9_]*$/', $name)) return false;
    return true;
}

// Check if already installed
if (file_exists(__DIR__ . '/config/.installed') && $step == 1) {
    die('NEO PGA sudah terinstall. Hapus file config/.installed untuk install ulang.');
}

// Process installation
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Check for XSS in all POST inputs
    foreach ($_POST as $key => $value) {
        if (is_string($value) && install_detectXSS($value)) {
            $error = 'Input tidak valid terdeteksi!';
            break;
        }
    }

    // Step 2: Test database connection
    if ($step == 2 && empty($error)) {
        $dbHost = install_sanitize($_POST['db_host']);
        $dbName = trim($_POST['db_name'] ?? '');
        $dbUser = install_sanitize($_POST['db_user']);
        $dbPass = $_POST['db_pass']; // Password tidak di-sanitize untuk mendukung karakter khusus

        // Validate database name to prevent SQL injection
        if (!install_validateDbName($dbName)) {
            $error = 'Nama database tidak valid. Gunakan huruf, angka, dan underscore saja (max 64 karakter, tidak boleh diawali angka).';
        }

        if (empty($error)) {
            try {
                $pdo = new PDO("mysql:host=$dbHost", $dbUser, $dbPass, [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
                ]);

                // Create database if not exists (dbName is validated above)
                $pdo->exec("CREATE DATABASE IF NOT EXISTS `$dbName` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
                $pdo->exec("USE `$dbName`");
            
            // Import SQL - execute each statement separately
            $sql = file_get_contents(__DIR__ . '/DATABASE.sql');
            
            // Remove comments and split by semicolon
            $sql = preg_replace('/--.*$/m', '', $sql); // Remove single-line comments
            $sql = preg_replace('/\/\*.*?\*\//s', '', $sql); // Remove multi-line comments
            
            // Split into individual statements
            $statements = array_filter(array_map('trim', explode(';', $sql)));
            
            foreach ($statements as $statement) {
                $statement = trim($statement);
                if (!empty($statement) && 
                    stripos($statement, 'SET ') !== 0 && 
                    stripos($statement, 'START ') !== 0 && 
                    stripos($statement, 'COMMIT') !== 0 &&
                    stripos($statement, '/*!') !== 0) {
                    try {
                        $pdo->exec($statement);
                    } catch (PDOException $e) {
                        // Skip duplicate key errors (table already exists, etc)
                        if (strpos($e->getMessage(), 'Duplicate') === false && 
                            strpos($e->getMessage(), 'already exists') === false) {
                            throw $e;
                        }
                    }
                }
            }
            
            // Save to session
            $_SESSION['install'] = [
                'db_host' => $dbHost,
                'db_name' => $dbName,
                'db_user' => $dbUser,
                'db_pass' => $dbPass,
            ];
            
            header('Location: ?step=3');
            exit;
            
        } catch (PDOException $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
        }
    }

    // Step 3: Configure app
    if ($step == 3 && empty($error)) {
        $appUrl = rtrim(install_sanitize($_POST['app_url']), '/');
        $appName = install_sanitize($_POST['app_name']);
        $adminEmail = install_sanitize($_POST['admin_email']);
        $adminPassword = $_POST['admin_password']; // Password tidak di-sanitize
        $qrisCode = install_sanitize($_POST['qris_code']);
        
        if (strlen($adminPassword) < 6) {
            $error = 'Password minimal 6 karakter';
        } else {
            $install = $_SESSION['install'];
            
            // Generate config file
            $configContent = '<?php
/**
 * NEO PGA Configuration
 * Generated: ' . date('Y-m-d H:i:s') . '
 */

// Error reporting
error_reporting(E_ALL);
ini_set("display_errors", 0);
ini_set("log_errors", 1);

// Session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Application
define("APP_NAME", "' . addslashes($appName) . '");
define("APP_VERSION", "2.0.0");
define("APP_TAGLINE", "Modern Payment Gateway");
define("APP_DEBUG", false);
define("APP_ENV", "production");

// URLs - Sesuaikan dengan domain Anda
define("APP_URL", "' . $appUrl . '");
define("ADMIN_URL", APP_URL . "/admin");
define("MERCHANT_URL", APP_URL . "/merchant");
define("API_URL", APP_URL . "/api");
define("PUBLIC_URL", APP_URL . "/public");
define("ASSETS_URL", APP_URL . "/assets");

// Database
define("DB_HOST", "' . $install['db_host'] . '");
define("DB_NAME", "' . $install['db_name'] . '");
define("DB_USER", "' . $install['db_user'] . '");
define("DB_PASS", "' . addslashes($install['db_pass']) . '");
define("DB_CHARSET", "utf8mb4");

// Paths
define("ROOT_PATH", __DIR__ . "/..");
define("CONFIG_PATH", __DIR__);
define("INCLUDES_PATH", ROOT_PATH . "/includes");
define("ASSETS_PATH", ROOT_PATH . "/assets");
define("UPLOADS_PATH", ROOT_PATH . "/uploads");
define("LOGS_PATH", ROOT_PATH . "/logs");

// Security
define("HASH_COST", 12);
define("SESSION_LIFETIME", 7200);
define("CSRF_TOKEN_NAME", "_csrf_token");

// Payment Settings
define("MIN_AMOUNT", 10000);
define("MAX_AMOUNT", 100000000);
define("DEFAULT_EXPIRY_MINUTES", 60);
define("DEFAULT_COMMISSION_RATE", 2.50);

// QRIS
define("QRIS_ENABLED", true);
define("QRIS_STATIC_CODE", "' . addslashes($qrisCode) . '");
define("QRIS_MERCHANT_NAME", "' . addslashes($appName) . '");

// Webhook
define("WEBHOOK_ENABLED", true);
define("WEBHOOK_TIMEOUT", 30);
define("WEBHOOK_RETRY_ATTEMPTS", 3);
define("WEBHOOK_RETRY_DELAY", 60);

// Email (optional)
define("MAIL_ENABLED", false);
define("MAIL_HOST", "");
define("MAIL_PORT", 587);
define("MAIL_USER", "");
define("MAIL_PASS", "");
define("MAIL_FROM", "");
define("MAIL_FROM_NAME", APP_NAME);

// Timezone
date_default_timezone_set("Asia/Jakarta");

// Helper function
function asset($path) {
    return ASSETS_URL . "/" . ltrim($path, "/");
}
';

            file_put_contents(__DIR__ . '/config/config.php', $configContent);
            
            // Update admin password
            try {
                $pdo = new PDO(
                    "mysql:host={$install['db_host']};dbname={$install['db_name']};charset=utf8mb4",
                    $install['db_user'],
                    $install['db_pass']
                );
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                
                $hashedPassword = password_hash($adminPassword, PASSWORD_BCRYPT, ['cost' => 12]);
                $stmt = $pdo->prepare("UPDATE admins SET email = ?, password = ? WHERE username = 'admin'");
                $stmt->execute([$adminEmail, $hashedPassword]);
                
                // Create .installed flag
                file_put_contents(__DIR__ . '/config/.installed', date('Y-m-d H:i:s'));
                
                // Create logs directory
                if (!is_dir(__DIR__ . '/logs')) {
                    mkdir(__DIR__ . '/logs', 0755, true);
                }
                
                header('Location: ?step=4');
                exit;
                
            } catch (PDOException $e) {
                $error = 'Error: ' . $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Install NEO PGA</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: linear-gradient(135deg, #0f172a, #1e293b);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem;
        }
        .installer {
            background: white;
            border-radius: 1rem;
            box-shadow: 0 25px 50px rgba(0,0,0,0.25);
            max-width: 600px;
            width: 100%;
            overflow: hidden;
        }
        .header {
            background: linear-gradient(135deg, #0d9488, #14b8a6);
            color: white;
            padding: 2rem;
            text-align: center;
        }
        .header h1 { font-size: 2rem; font-weight: 700; }
        .header p { opacity: 0.9; margin-top: 0.5rem; }
        .content { padding: 2rem; }
        .steps {
            display: flex;
            justify-content: center;
            gap: 1rem;
            margin-bottom: 2rem;
        }
        .step-item {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            background: #e2e8f0;
            color: #64748b;
        }
        .step-item.active { background: #0d9488; color: white; }
        .step-item.done { background: #10b981; color: white; }
        .form-group { margin-bottom: 1.25rem; }
        .form-label { display: block; font-weight: 500; margin-bottom: 0.5rem; color: #374151; }
        .form-input {
            width: 100%;
            padding: 0.75rem 1rem;
            border: 1px solid #d1d5db;
            border-radius: 0.5rem;
            font-size: 1rem;
            font-family: inherit;
        }
        .form-input:focus { outline: none; border-color: #0d9488; box-shadow: 0 0 0 3px rgba(13,148,136,0.1); }
        .form-helper { font-size: 0.875rem; color: #6b7280; margin-top: 0.25rem; }
        .btn {
            display: inline-block;
            padding: 0.875rem 1.5rem;
            background: #0d9488;
            color: white;
            border: none;
            border-radius: 0.5rem;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
        }
        .btn:hover { background: #0f766e; }
        .btn-block { width: 100%; }
        .alert { padding: 1rem; border-radius: 0.5rem; margin-bottom: 1rem; }
        .alert-danger { background: #fef2f2; color: #dc2626; border: 1px solid #fecaca; }
        .alert-success { background: #f0fdf4; color: #16a34a; border: 1px solid #bbf7d0; }
        .check-item { display: flex; align-items: center; gap: 0.5rem; padding: 0.5rem 0; }
        .check-icon { width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 14px; }
        .check-ok { background: #10b981; color: white; }
        .check-fail { background: #ef4444; color: white; }
        .success-box { text-align: center; padding: 2rem 0; }
        .success-icon { font-size: 4rem; margin-bottom: 1rem; }
    </style>
</head>
<body>
    <div class="installer">
        <div class="header">
            <h1>NEO<span style="opacity:0.8">BAYAR</span></h1>
            <p>Installation Wizard</p>
        </div>
        
        <div class="content">
            <div class="steps">
                <div class="step-item <?= $step >= 1 ? ($step > 1 ? 'done' : 'active') : '' ?>">1</div>
                <div class="step-item <?= $step >= 2 ? ($step > 2 ? 'done' : 'active') : '' ?>">2</div>
                <div class="step-item <?= $step >= 3 ? ($step > 3 ? 'done' : 'active') : '' ?>">3</div>
                <div class="step-item <?= $step >= 4 ? 'done' : '' ?>">4</div>
            </div>
            
            <?php if ($error): ?>
            <div class="alert alert-danger"><?= $error ?></div>
            <?php endif; ?>
            
            <?php if ($step == 1): ?>
            <!-- Step 1: Requirements Check -->
            <h2 style="margin-bottom: 1rem;">Cek Persyaratan</h2>
            
            <?php
            $checks = [
                'PHP >= 7.4' => version_compare(PHP_VERSION, '7.4.0', '>='),
                'PDO Extension' => extension_loaded('pdo'),
                'PDO MySQL' => extension_loaded('pdo_mysql'),
                'JSON Extension' => extension_loaded('json'),
                'OpenSSL' => extension_loaded('openssl'),
                'cURL' => extension_loaded('curl'),
                'config/ writable' => is_writable(__DIR__ . '/config'),
            ];
            $allPassed = !in_array(false, $checks);
            ?>
            
            <?php foreach ($checks as $name => $passed): ?>
            <div class="check-item">
                <div class="check-icon <?= $passed ? 'check-ok' : 'check-fail' ?>">
                    <?= $passed ? '✓' : '✕' ?>
                </div>
                <span><?= $name ?></span>
            </div>
            <?php endforeach; ?>
            
            <div style="margin-top: 1.5rem;">
                <?php if ($allPassed): ?>
                <a href="?step=2" class="btn btn-block">Lanjutkan →</a>
                <?php else: ?>
                <div class="alert alert-danger">Harap penuhi semua persyaratan sebelum melanjutkan.</div>
                <?php endif; ?>
            </div>
            
            <?php elseif ($step == 2): ?>
            <!-- Step 2: Database -->
            <h2 style="margin-bottom: 1rem;">Konfigurasi Database</h2>
            
            <form method="POST">
                <div class="form-group">
                    <label class="form-label">Database Host</label>
                    <input type="text" name="db_host" class="form-input" value="localhost" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Database Name</label>
                    <input type="text" name="db_name" class="form-input" value="neopga" required>
                    <p class="form-helper">Database akan dibuat otomatis jika belum ada</p>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Database Username</label>
                    <input type="text" name="db_user" class="form-input" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Database Password</label>
                    <input type="password" name="db_pass" class="form-input">
                </div>
                
                <button type="submit" class="btn btn-block">Test & Import Database →</button>
            </form>
            
            <?php elseif ($step == 3): ?>
            <!-- Step 3: Configuration -->
            <h2 style="margin-bottom: 1rem;">Konfigurasi Aplikasi</h2>
            
            <form method="POST">
                <div class="form-group">
                    <label class="form-label">URL Aplikasi</label>
                    <input type="url" name="app_url" class="form-input" value="<?= htmlspecialchars((isset($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['REQUEST_URI']), ENT_QUOTES, 'UTF-8') ?>" required>
                    <p class="form-helper">Tanpa trailing slash, contoh: https://pay.domain.com</p>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Nama Aplikasi</label>
                    <input type="text" name="app_name" class="form-input" value="NEO PGA" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Email Admin</label>
                    <input type="email" name="admin_email" class="form-input" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Password Admin</label>
                    <input type="password" name="admin_password" class="form-input" required minlength="6">
                    <p class="form-helper">Minimal 6 karakter (username: admin)</p>
                </div>
                
                <div class="form-group">
                    <label class="form-label">QRIS Static Code (opsional)</label>
                    <textarea name="qris_code" class="form-input" rows="2" placeholder="Masukkan string QRIS dari bank Anda"></textarea>
                    <p class="form-helper">Bisa diisi nanti di pengaturan</p>
                </div>
                
                <button type="submit" class="btn btn-block">Install NEO PGA →</button>
            </form>
            
            <?php elseif ($step == 4): ?>
            <!-- Step 4: Complete -->
            <div class="success-box">
                <div class="success-icon">🎉</div>
                <h2>Instalasi Berhasil!</h2>
                <p style="color: #6b7280; margin: 1rem 0;">NEO PGA siap digunakan</p>
                
                <div style="background: #f8fafc; padding: 1rem; border-radius: 0.5rem; text-align: left; margin: 1.5rem 0;">
                    <p style="margin-bottom: 0.5rem;"><strong>Login Admin:</strong></p>
                    <p>URL: <code><?= htmlspecialchars($_SESSION['install']['app_url'] ?? '', ENT_QUOTES, 'UTF-8') ?>/admin</code></p>
                    <p>Username: <code>admin</code></p>
                    <p>Password: <em>(yang Anda set)</em></p>
                </div>
                
                <div class="alert alert-danger" style="text-align: left;">
                    <strong>⚠️ Penting!</strong> Hapus file <code>install.php</code> setelah instalasi untuk keamanan.
                </div>
                
                <a href="admin/login.php" class="btn btn-block">Buka Admin Panel →</a>
            </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>

<?php
/**
 * NEO PGA Admin - Transactions Management
 */
require_once __DIR__ . '/../includes/init.php';

$auth = new Auth('admin');
$auth->requireAuth();

$adminUser = $auth->user();
$db = Database::getInstance();

// =============================================
// AUTO-RESET KODE UNIK YANG HAMPIR HABIS
// =============================================
$merchantsNeedingReset = $db->fetchAll(
    "SELECT m.id, COUNT(CASE WHEN pc.status = 'available' THEN 1 END) as available,
            COUNT(CASE WHEN pc.status = 'used' THEN 1 END) as used
     FROM merchants m
     LEFT JOIN payment_codes pc ON m.id = pc.merchant_id
     GROUP BY m.id
     HAVING available <= 5 AND used > 0"
);

foreach ($merchantsNeedingReset as $m) {
    $db->query(
        "UPDATE payment_codes
         SET status = 'available', transaction_id = NULL,
             reserved_at = NULL, expires_at = NULL, used_at = NULL
         WHERE merchant_id = ? AND status = 'used'",
        [$m['id']]
    );
}

// Filters
$search = sanitize($_GET['search'] ?? '');
$status = sanitize($_GET['status'] ?? '');
$method = sanitize($_GET['method'] ?? '');
$merchantId = (int)($_GET['merchant_id'] ?? 0);
$dateFrom = sanitize($_GET['date_from'] ?? '');
$dateTo = sanitize($_GET['date_to'] ?? '');
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 25;
$offset = ($page - 1) * $perPage;

// Get merchants for filter dropdown
$allMerchants = $db->fetchAll("SELECT id, business_name, merchant_code FROM merchants ORDER BY business_name ASC");

$where = "1=1";
$params = [];

if ($search) {
    $where .= " AND (t.invoice_number LIKE ? OR t.customer_name LIKE ? OR t.customer_email LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}
if ($status) {
    $where .= " AND t.status = ?";
    $params[] = $status;
}
if ($method) {
    $where .= " AND t.payment_method = ?";
    $params[] = $method;
}
if ($merchantId > 0) {
    $where .= " AND t.merchant_id = ?";
    $params[] = $merchantId;
}
if ($dateFrom) {
    $where .= " AND DATE(t.created_at) >= ?";
    $params[] = $dateFrom;
}
if ($dateTo) {
    $where .= " AND DATE(t.created_at) <= ?";
    $params[] = $dateTo;
}

// Get selected merchant name for display
$selectedMerchantName = '';
if ($merchantId > 0) {
    foreach ($allMerchants as $m) {
        if ($m['id'] == $merchantId) {
            $selectedMerchantName = $m['business_name'];
            break;
        }
    }
}

// Count total
$countSql = "SELECT COUNT(*) as c FROM transactions t WHERE $where";
$total = $db->fetch($countSql, $params)['c'] ?? 0;
$totalPages = ceil($total / $perPage);

// Get transactions
$sql = "SELECT t.*, m.business_name 
        FROM transactions t 
        LEFT JOIN merchants m ON t.merchant_id = m.id 
        WHERE $where 
        ORDER BY t.created_at DESC 
        LIMIT $perPage OFFSET $offset";
$transactions = $db->fetchAll($sql, $params);

// Stats
$today = date('Y-m-d');
$stats = [
    'total' => $db->fetch("SELECT COUNT(*) as c FROM transactions")['c'] ?? 0,
    'success' => $db->fetch("SELECT COUNT(*) as c FROM transactions WHERE status = 'success'")['c'] ?? 0,
    'pending' => $db->fetch("SELECT COUNT(*) as c FROM transactions WHERE status = 'pending'")['c'] ?? 0,
    'today_amount' => $db->fetch("SELECT COALESCE(SUM(total_amount), 0) as a FROM transactions WHERE status = 'success' AND DATE(created_at) = ?", [$today])['a'] ?? 0,
];

$pageTitle = 'Transaksi';
$currentPage = 'transactions';

ob_start();
?>

<div class="flex justify-between items-center mb-6">
    <div>
        <h1 class="text-2xl font-bold text-gray-900">Daftar Transaksi</h1>
        <p class="text-gray-500">
            <?php if ($selectedMerchantName): ?>
            Transaksi merchant: <strong><?= htmlspecialchars($selectedMerchantName) ?></strong>
            <?php else: ?>
            Kelola semua transaksi payment gateway
            <?php endif; ?>
        </p>
    </div>
    <div class="flex gap-2">
        <a href="reports.php" class="btn btn-secondary">📊 Laporan</a>
        <a href="verify.php" class="btn btn-primary">✓ Verifikasi</a>
    </div>
</div>

<!-- Stats -->
<div class="stats-grid mb-6">
    <div class="stat-card">
        <div class="stat-icon" style="background:var(--gray-100);color:var(--gray-600)">📊</div>
        <div class="stat-content">
            <div class="stat-value"><?= number_format($stats['total']) ?></div>
            <div class="stat-label">Total Transaksi</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background:#dcfce7;color:#16a34a">✓</div>
        <div class="stat-content">
            <div class="stat-value"><?= number_format($stats['success']) ?></div>
            <div class="stat-label">Sukses</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background:#fef3c7;color:#d97706">⏳</div>
        <div class="stat-content">
            <div class="stat-value"><?= number_format($stats['pending']) ?></div>
            <div class="stat-label">Pending</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background:#dbeafe;color:#2563eb">💰</div>
        <div class="stat-content">
            <div class="stat-value">Rp <?= number_format($stats['today_amount'], 0, ',', '.') ?></div>
            <div class="stat-label">Hari Ini</div>
        </div>
    </div>
</div>

<!-- Filter -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" class="flex gap-4 items-end flex-wrap">
            <div class="form-group mb-0" style="flex:1;min-width:180px">
                <label class="form-label">Pencarian</label>
                <input type="text" name="search" class="form-input" value="<?= htmlspecialchars($search) ?>" placeholder="Invoice, customer...">
            </div>
            <div class="form-group mb-0">
                <label class="form-label">Merchant</label>
                <select name="merchant_id" class="form-select">
                    <option value="">Semua Merchant</option>
                    <?php foreach ($allMerchants as $m): ?>
                    <option value="<?= $m['id'] ?>" <?= $merchantId == $m['id'] ? 'selected' : '' ?>><?= htmlspecialchars($m['business_name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group mb-0">
                <label class="form-label">Status</label>
                <select name="status" class="form-select">
                    <option value="">Semua</option>
                    <option value="pending" <?= $status === 'pending' ? 'selected' : '' ?>>Pending</option>
                    <option value="success" <?= $status === 'success' ? 'selected' : '' ?>>Success</option>
                    <option value="expired" <?= $status === 'expired' ? 'selected' : '' ?>>Expired</option>
                    <option value="failed" <?= $status === 'failed' ? 'selected' : '' ?>>Failed</option>
                </select>
            </div>
            <div class="form-group mb-0">
                <label class="form-label">Metode</label>
                <select name="method" class="form-select">
                    <option value="">Semua</option>
                    <option value="bank_transfer" <?= $method === 'bank_transfer' ? 'selected' : '' ?>>Bank Transfer</option>
                    <option value="qris" <?= $method === 'qris' ? 'selected' : '' ?>>QRIS</option>
                </select>
            </div>
            <div class="form-group mb-0">
                <label class="form-label">Dari</label>
                <input type="date" name="date_from" class="form-input" value="<?= htmlspecialchars($dateFrom) ?>">
            </div>
            <div class="form-group mb-0">
                <label class="form-label">Sampai</label>
                <input type="date" name="date_to" class="form-input" value="<?= htmlspecialchars($dateTo) ?>">
            </div>
            <button type="submit" class="btn btn-primary">Filter</button>
            <?php if ($search || $status || $method || $merchantId || $dateFrom || $dateTo): ?>
            <a href="transactions.php" class="btn btn-secondary">Reset</a>
            <?php endif; ?>
        </form>
    </div>
</div>

<!-- Transactions Table -->
<div class="card">
    <div class="card-body" style="padding:0">
        <?php if (empty($transactions)): ?>
        <div style="padding:3rem;text-align:center;color:var(--gray-500)">
            Tidak ada transaksi ditemukan
        </div>
        <?php else: ?>
        <div style="overflow-x:auto">
            <table class="table">
                <thead>
                    <tr>
                        <th>Invoice</th>
                        <th>Merchant</th>
                        <th>Customer</th>
                        <th>Metode</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Waktu</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($transactions as $t): ?>
                    <tr>
                        <td>
                            <code style="font-size:0.75rem"><?= htmlspecialchars($t['invoice_number']) ?></code>
                        </td>
                        <td style="font-size:0.875rem"><?= htmlspecialchars($t['business_name'] ?? '-') ?></td>
                        <td>
                            <div style="font-size:0.875rem;font-weight:500"><?= htmlspecialchars($t['customer_name']) ?></div>
                            <div style="font-size:0.75rem;color:var(--gray-500)"><?= htmlspecialchars($t['customer_email']) ?></div>
                        </td>
                        <td>
                            <span class="badge badge-<?= $t['payment_method'] === 'qris' ? 'info' : 'neutral' ?>">
                                <?= $t['payment_method'] === 'qris' ? 'QRIS' : 'Transfer' ?>
                            </span>
                        </td>
                        <td>
                            <div style="font-weight:600">Rp <?= number_format($t['total_amount'], 0, ',', '.') ?></div>
                            <?php if ($t['unique_code'] > 0): ?>
                            <div style="font-size:0.7rem;color:var(--gray-500)">+<?= $t['unique_code'] ?> kode unik</div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php
                            $statusColors = [
                                'pending' => 'warning',
                                'success' => 'success',
                                'expired' => 'danger',
                                'failed' => 'danger',
                                'waiting' => 'info'
                            ];
                            $color = $statusColors[$t['status']] ?? 'neutral';
                            ?>
                            <span class="badge badge-<?= $color ?>"><?= ucfirst($t['status']) ?></span>
                        </td>
                        <td style="font-size:0.8rem;color:var(--gray-500)">
                            <?= date('d/m/Y H:i', strtotime($t['created_at'])) ?>
                        </td>
                        <td>
                            <button onclick="viewTransaction(<?= htmlspecialchars(json_encode($t)) ?>)" class="btn btn-sm btn-secondary">👁</button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Pagination -->
<?php if ($totalPages > 1): ?>
<div style="display:flex;justify-content:center;gap:0.5rem;margin-top:1.5rem">
    <?php 
    $queryParams = $_GET;
    unset($queryParams['page']);
    $queryString = http_build_query($queryParams);
    ?>
    <?php for ($i = 1; $i <= min($totalPages, 10); $i++): ?>
    <a href="?page=<?= $i ?>&<?= $queryString ?>" class="btn btn-sm <?= $i === $page ? 'btn-primary' : 'btn-secondary' ?>"><?= $i ?></a>
    <?php endfor; ?>
    <?php if ($totalPages > 10): ?>
    <span style="padding:0.5rem">...</span>
    <a href="?page=<?= $totalPages ?>&<?= $queryString ?>" class="btn btn-sm btn-secondary"><?= $totalPages ?></a>
    <?php endif; ?>
</div>
<?php endif; ?>

<!-- View Transaction Modal -->
<div id="viewTransactionModal" class="modal">
    <div class="modal-content" style="max-width:600px">
        <div class="modal-header">
            <h3 class="modal-title">Detail Transaksi</h3>
            <button onclick="closeModal('viewTransactionModal')" class="modal-close">&times;</button>
        </div>
        <div class="modal-body" id="transactionDetailContent"></div>
    </div>
</div>

<script>
function viewTransaction(t) {
    let statusColor = {pending:'#f59e0b',success:'#16a34a',expired:'#dc2626',failed:'#dc2626'}[t.status] || '#6b7280';
    let html = `
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1.5rem;padding-bottom:1rem;border-bottom:1px solid var(--gray-200)">
            <div>
                <div style="font-size:0.75rem;color:var(--gray-500)">Invoice Number</div>
                <code style="font-size:1rem;font-weight:600">${t.invoice_number}</code>
            </div>
            <span style="background:${statusColor};color:white;padding:0.25rem 0.75rem;border-radius:20px;font-size:0.875rem;font-weight:600">${t.status.toUpperCase()}</span>
        </div>
        <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:1rem">
            <div><label style="font-size:0.75rem;color:var(--gray-500)">Merchant</label><div style="font-weight:600">${t.business_name || '-'}</div></div>
            <div><label style="font-size:0.75rem;color:var(--gray-500)">Payment Method</label><div style="font-weight:600">${t.payment_method === 'qris' ? 'QRIS' : 'Bank Transfer'}</div></div>
            <div><label style="font-size:0.75rem;color:var(--gray-500)">Customer</label><div style="font-weight:600">${t.customer_name}</div></div>
            <div><label style="font-size:0.75rem;color:var(--gray-500)">Email</label><div style="font-weight:600">${t.customer_email}</div></div>
            <div><label style="font-size:0.75rem;color:var(--gray-500)">Amount</label><div style="font-weight:600">Rp ${Number(t.amount).toLocaleString('id-ID')}</div></div>
            <div><label style="font-size:0.75rem;color:var(--gray-500)">Kode Unik</label><div style="font-weight:600">+${t.unique_code}</div></div>
            <div><label style="font-size:0.75rem;color:var(--gray-500)">Total Bayar</label><div style="font-weight:700;color:var(--primary);font-size:1.25rem">Rp ${Number(t.total_amount).toLocaleString('id-ID')}</div></div>
            <div><label style="font-size:0.75rem;color:var(--gray-500)">Komisi</label><div style="font-weight:600">Rp ${Number(t.commission_amount || 0).toLocaleString('id-ID')}</div></div>
            <div><label style="font-size:0.75rem;color:var(--gray-500)">Dibuat</label><div style="font-weight:600">${t.created_at}</div></div>
            <div><label style="font-size:0.75rem;color:var(--gray-500)">Expired</label><div style="font-weight:600">${t.expired_at || '-'}</div></div>
        </div>
        ${t.description ? `<div style="margin-top:1rem"><label style="font-size:0.75rem;color:var(--gray-500)">Deskripsi</label><div style="background:var(--gray-50);padding:0.75rem;border-radius:6px">${t.description}</div></div>` : ''}
    `;
    document.getElementById('transactionDetailContent').innerHTML = html;
    openModal('viewTransactionModal');
}
</script>

<?php
$content = ob_get_clean();
include __DIR__ . '/layout.php';
?>

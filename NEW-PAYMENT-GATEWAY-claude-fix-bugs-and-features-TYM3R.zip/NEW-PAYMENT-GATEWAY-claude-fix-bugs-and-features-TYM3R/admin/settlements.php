<?php
/**
 * NEO PGA Admin - Settlements Management
 * VERSI DIPERBAIKI - Balance dikembalikan saat reject
 */
require_once __DIR__ . '/../includes/init.php';

$auth = new Auth('admin');
$auth->requireAuth();

$adminUser = $auth->user();
$db = Database::getInstance();
$message = '';
$messageType = '';

// APPROVE Settlement
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['process_settlement'])) {
    verifyCsrf();
    $id = (int)$_POST['settlement_id'];
    
    try {
        $db->beginTransaction();
        
        $settlement = $db->fetch("SELECT * FROM settlements WHERE id = ? AND status = 'pending'", [$id]);
        if (!$settlement) throw new Exception('Settlement tidak ditemukan');
        
        $merchant = $db->fetch("SELECT * FROM merchants WHERE id = ?", [$settlement['merchant_id']]);
        if (!$merchant) throw new Exception('Merchant tidak ditemukan');
        
        // Update status
        $db->update('settlements', [
            'status' => 'completed',
            'processed_at' => date('Y-m-d H:i:s'),
            'processed_by' => $adminUser['id']
        ], 'id = ?', [$id]);
        
        // Kurangi pending_balance
        $pendingAfter = max(0, ($merchant['pending_balance'] ?? 0) - $settlement['amount']);
        $db->query("UPDATE merchants SET pending_balance = ? WHERE id = ?", [$pendingAfter, $merchant['id']]);
        
        $db->commit();
        $message = "Settlement #{$settlement['settlement_number']} berhasil diproses!";
        $messageType = 'success';
    } catch (Exception $e) {
        $db->rollback();
        $message = 'Gagal: ' . $e->getMessage();
        $messageType = 'danger';
    }
}

// REJECT Settlement - KEMBALIKAN SALDO!
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reject_settlement'])) {
    verifyCsrf();
    $id = (int)$_POST['settlement_id'];
    $reason = sanitize($_POST['reason'] ?? 'Ditolak oleh admin');
    
    try {
        $db->beginTransaction();
        
        $settlement = $db->fetch("SELECT * FROM settlements WHERE id = ? AND status = 'pending'", [$id]);
        if (!$settlement) throw new Exception('Settlement tidak ditemukan');
        
        $merchant = $db->fetch("SELECT * FROM merchants WHERE id = ?", [$settlement['merchant_id']]);
        if (!$merchant) throw new Exception('Merchant tidak ditemukan');
        
        // Update status
        $db->update('settlements', [
            'status' => 'rejected',
            'notes' => $reason,
            'processed_at' => date('Y-m-d H:i:s'),
            'processed_by' => $adminUser['id']
        ], 'id = ?', [$id]);
        
        // KEMBALIKAN SALDO KE MERCHANT
        $balanceBefore = $merchant['balance'];
        $balanceAfter = $balanceBefore + $settlement['amount'];
        $pendingAfter = max(0, ($merchant['pending_balance'] ?? 0) - $settlement['amount']);
        
        $db->query("UPDATE merchants SET balance = ?, pending_balance = ? WHERE id = ?", 
            [$balanceAfter, $pendingAfter, $merchant['id']]);
        
        // Log pengembalian saldo
        $db->query(
            "INSERT INTO balance_logs (merchant_id, settlement_id, type, amount, balance_before, balance_after, description, created_at) VALUES (?, ?, 'credit', ?, ?, ?, ?, NOW())",
            [$merchant['id'], $id, $settlement['amount'], $balanceBefore, $balanceAfter, "Settlement rejected: {$settlement['settlement_number']} - $reason"]
        );
        
        $db->commit();
        $message = "Settlement ditolak. Saldo " . formatRupiah($settlement['amount']) . " dikembalikan ke merchant.";
        $messageType = 'warning';
    } catch (Exception $e) {
        $db->rollback();
        $message = 'Gagal: ' . $e->getMessage();
        $messageType = 'danger';
    }
}

// Filters
$status = $_GET['status'] ?? '';
$where = "1=1";
$params = [];
if ($status) { $where .= " AND s.status = ?"; $params[] = $status; }

$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 20;
$offset = ($page - 1) * $perPage;

$total = $db->fetch("SELECT COUNT(*) as c FROM settlements s WHERE $where", $params)['c'];
$totalPages = ceil($total / $perPage);

$settlements = $db->fetchAll(
    "SELECT s.*, m.business_name, m.email as merchant_email 
     FROM settlements s 
     LEFT JOIN merchants m ON s.merchant_id = m.id 
     WHERE $where 
     ORDER BY CASE WHEN s.status = 'pending' THEN 0 ELSE 1 END, s.created_at DESC 
     LIMIT $perPage OFFSET $offset",
    $params
);

$stats = [
    'pending' => $db->fetch("SELECT COUNT(*) as c FROM settlements WHERE status = 'pending'")['c'],
    'completed' => $db->fetch("SELECT COUNT(*) as c FROM settlements WHERE status = 'completed'")['c'],
    'rejected' => $db->fetch("SELECT COUNT(*) as c FROM settlements WHERE status = 'rejected'")['c'],
    'pending_amount' => $db->fetch("SELECT COALESCE(SUM(amount),0) as s FROM settlements WHERE status = 'pending'")['s'],
    'today' => $db->fetch("SELECT COALESCE(SUM(amount),0) as s FROM settlements WHERE status = 'completed' AND DATE(processed_at) = CURDATE()")['s'],
];

$pageTitle = 'Settlements';
$currentPage = 'settlements';

$extraCss = '
.stats-row{display:grid;grid-template-columns:repeat(4,1fr);gap:1rem;margin-bottom:1.5rem}
.stat-box{background:#fff;border-radius:12px;border:1px solid var(--gray-200);padding:1.25rem}
.stat-box .label{font-size:.875rem;color:var(--gray-500)}
.stat-box .value{font-size:1.5rem;font-weight:700;margin-top:.25rem}
.filter-bar{display:flex;gap:1rem;margin-bottom:1.5rem;flex-wrap:wrap}
.pending-row{background:#fffbeb!important}
@media(max-width:768px){.stats-row{grid-template-columns:repeat(2,1fr)}}
';

ob_start();
?>

<?php if ($message): ?>
<div class="alert alert-<?= $messageType ?> mb-6"><?= $message ?></div>
<?php endif; ?>

<div class="stats-row">
    <div class="stat-box"><div class="label">⏳ Pending</div><div class="value" style="color:var(--warning)"><?= $stats['pending'] ?></div></div>
    <div class="stat-box"><div class="label">✅ Completed</div><div class="value" style="color:var(--success)"><?= $stats['completed'] ?></div></div>
    <div class="stat-box"><div class="label">💰 Pending Amount</div><div class="value"><?= formatRupiah($stats['pending_amount']) ?></div></div>
    <div class="stat-box"><div class="label">📅 Today</div><div class="value" style="color:var(--primary)"><?= formatRupiah($stats['today']) ?></div></div>
</div>

<div class="filter-bar">
    <form method="GET" class="flex gap-2">
        <select name="status" class="form-select">
            <option value="">Semua</option>
            <option value="pending" <?= $status === 'pending' ? 'selected' : '' ?>>Pending (<?= $stats['pending'] ?>)</option>
            <option value="completed" <?= $status === 'completed' ? 'selected' : '' ?>>Completed (<?= $stats['completed'] ?>)</option>
            <option value="rejected" <?= $status === 'rejected' ? 'selected' : '' ?>>Rejected (<?= $stats['rejected'] ?>)</option>
        </select>
        <button type="submit" class="btn btn-primary">Filter</button>
        <?php if ($status): ?><a href="settlements.php" class="btn btn-secondary">Reset</a><?php endif; ?>
    </form>
</div>

<div class="card">
    <div class="table-wrapper">
        <table class="table">
            <thead>
                <tr>
                    <th>No. Settlement</th>
                    <th>Merchant</th>
                    <th>Jumlah</th>
                    <th>Rekening</th>
                    <th>Status</th>
                    <th>Tanggal</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($settlements)): ?>
                <tr><td colspan="7" style="text-align:center;padding:2rem;color:var(--gray-400)">📭 Tidak ada settlement</td></tr>
                <?php else: foreach ($settlements as $s): 
                    $bankAccNum = $s['bank_account_number'] ?? $s['account_number'] ?? '-';
                    $bankAccName = $s['bank_account_name'] ?? $s['account_name'] ?? '-';
                ?>
                <tr class="<?= $s['status'] === 'pending' ? 'pending-row' : '' ?>">
                    <td><code style="font-size:.8rem"><?= htmlspecialchars($s['settlement_number']) ?></code></td>
                    <td>
                        <div style="font-weight:600"><?= htmlspecialchars($s['business_name'] ?? '-') ?></div>
                        <div style="font-size:.75rem;color:var(--gray-500)"><?= htmlspecialchars($s['merchant_email'] ?? '') ?></div>
                    </td>
                    <td style="font-weight:700;color:var(--primary);font-size:1.1rem"><?= formatRupiah($s['amount']) ?></td>
                    <td>
                        <div style="font-weight:600"><?= htmlspecialchars($s['bank_name'] ?? '-') ?></div>
                        <div style="font-size:.85rem;font-family:monospace"><?= htmlspecialchars($bankAccNum) ?></div>
                        <div style="font-size:.75rem;color:var(--gray-500)"><?= htmlspecialchars($bankAccName) ?></div>
                    </td>
                    <td>
                        <?php 
                        $stMap = ['pending'=>['warning','Pending'],'completed'=>['success','Selesai'],'rejected'=>['danger','Ditolak'],'processing'=>['info','Proses']];
                        $st = $stMap[$s['status']] ?? ['neutral', $s['status']];
                        ?>
                        <span class="badge badge-<?= $st[0] ?>"><?= $st[1] ?></span>
                        <?php if ($s['status'] === 'rejected' && $s['notes']): ?>
                        <div style="font-size:.7rem;color:#991b1b;margin-top:.25rem;max-width:150px"><?= htmlspecialchars($s['notes']) ?></div>
                        <?php endif; ?>
                    </td>
                    <td style="font-size:.8rem">
                        <?= date('d/m/Y H:i', strtotime($s['created_at'])) ?>
                        <?php if ($s['processed_at']): ?>
                        <div style="font-size:.7rem;color:var(--success)">✓ <?= date('d/m H:i', strtotime($s['processed_at'])) ?></div>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if ($s['status'] === 'pending'): ?>
                        <div class="flex gap-1">
                            <form method="POST" style="display:inline" onsubmit="return confirm('APPROVE settlement <?= $s['settlement_number'] ?>?\n\nJumlah: <?= formatRupiah($s['amount']) ?>\nBank: <?= $s['bank_name'] ?>\nNo: <?= $bankAccNum ?>\nNama: <?= $bankAccName ?>\n\nPastikan sudah transfer!')">
                                <?= csrfField() ?>
                                <input type="hidden" name="process_settlement" value="1">
                                <input type="hidden" name="settlement_id" value="<?= $s['id'] ?>">
                                <button type="submit" class="btn btn-sm btn-success">✓</button>
                            </form>
                            <button onclick="rejectSettlement(<?= $s['id'] ?>,'<?= $s['settlement_number'] ?>','<?= formatRupiah($s['amount']) ?>')" class="btn btn-sm btn-danger">✕</button>
                        </div>
                        <?php else: ?>
                        <span style="color:var(--gray-400)">-</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php if ($totalPages > 1): ?>
<div style="display:flex;justify-content:center;gap:.5rem;margin-top:1.5rem">
    <?php for ($i = 1; $i <= min($totalPages, 10); $i++): ?>
    <a href="?page=<?= $i ?><?= $status ? '&status='.urlencode($status) : '' ?>" class="btn btn-sm <?= $i === $page ? 'btn-primary' : 'btn-secondary' ?>"><?= $i ?></a>
    <?php endfor; ?>
</div>
<?php endif; ?>

<!-- Reject Modal -->
<div id="rejectModal" class="modal">
    <div class="modal-content" style="max-width:450px">
        <div class="modal-header">
            <h3 class="modal-title">❌ Tolak Settlement</h3>
            <button onclick="closeModal('rejectModal')" class="modal-close">&times;</button>
        </div>
        <form method="POST">
            <?= csrfField() ?>
            <input type="hidden" name="reject_settlement" value="1">
            <input type="hidden" name="settlement_id" id="rejectId">
            <div class="modal-body">
                <div style="background:#fef3c7;border:1px solid #fcd34d;border-radius:8px;padding:1rem;margin-bottom:1rem">
                    <strong>⚠️ Saldo akan dikembalikan ke merchant!</strong>
                </div>
                <p style="margin-bottom:1rem">
                    <strong id="rejectNum"></strong> - <span id="rejectAmt" style="color:var(--primary);font-weight:700"></span>
                </p>
                <div class="form-group">
                    <label class="form-label">Alasan *</label>
                    <textarea name="reason" class="form-input" rows="3" required placeholder="Contoh: No. rekening tidak valid"></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" onclick="closeModal('rejectModal')" class="btn btn-secondary">Batal</button>
                <button type="submit" class="btn btn-danger">Tolak & Kembalikan Saldo</button>
            </div>
        </form>
    </div>
</div>

<script>
function rejectSettlement(id, num, amt) {
    document.getElementById('rejectId').value = id;
    document.getElementById('rejectNum').textContent = num;
    document.getElementById('rejectAmt').textContent = amt;
    openModal('rejectModal');
}
</script>

<?php
$content = ob_get_clean();
include __DIR__ . '/layout.php';
?>

# ✅ NEO PGA v2.2 - Production Checklist

## Sebelum Upload ke cPanel

### 1. Konfigurasi Database
- [ ] Buat database baru di cPanel MySQL
- [ ] Import `DATABASE.sql` via phpMyAdmin
- [ ] Catat: DB_NAME, DB_USER, DB_PASS

### 2. Edit File Config
File: `config/config.php`
```php
define('APP_ENV', 'production');        // ← Ganti ke production
define('APP_DEBUG', false);             // ← Matikan debug
define('DB_NAME', 'your_db_name');      // ← Database kamu
define('DB_USER', 'your_db_user');      // ← User kamu
define('DB_PASS', 'your_db_password');  // ← Password kamu
define('APP_URL', 'https://yourdomain.com');  // ← Domain kamu
define('ENCRYPTION_KEY', 'ganti_dengan_random_string_32_karakter');
```

### 3. Update QRIS Settings (Jika Pakai QRIS)
File: `config/config.php`
```php
define('QRIS_MERCHANT_ID', 'ID_MERCHANT_KAMU');
define('QRIS_NMID', 'NMID_DARI_PROVIDER');
define('QRIS_MERCHANT_NAME', 'NAMA_TOKO_KAMU');
```

### 4. Security Checklist
- [ ] Ganti password admin default (admin@neopga.com / admin123)
- [ ] Update ENCRYPTION_KEY di config.php
- [ ] Cek permission folder:
  - `uploads/` → 755
  - `logs/` → 755
  - `data/` → 755
  - `config/` → 750 (protect dari public)

### 5. File Structure Check
✅ Pastikan folder ini ada:
```
/
├── admin/          (Admin panel)
├── merchant/       (Merchant dashboard)
├── api/            (REST API)
├── public/         (Payment pages)
├── demo/           (DigiStore showcase)
├── includes/       (Core classes)
├── config/         (Configuration)
├── assets/         (CSS, JS, images)
├── sdk/            (PHP SDK)
├── uploads/        (File uploads)
├── logs/           (Log files)
└── data/           (Runtime data)
```

### 6. Test Akses
- [ ] Landing page: `https://yourdomain.com/`
- [ ] Admin login: `https://yourdomain.com/admin`
- [ ] Merchant login: `https://yourdomain.com/merchant`
- [ ] Demo store: `https://yourdomain.com/demo`

### 7. Setup Cron Job (Optional - Auto Expire)
```bash
*/5 * * * * /usr/bin/php /path/to/neopga/cron.php key=neobayar_cron_2024
```

### 8. Setup MacroDroid (Auto-Verify)
- [ ] Install MacroDroid di Android
- [ ] Ikuti `PANDUAN-MACRODROID.md`
- [ ] Setup notifikasi GoPay/Bank SMS
- [ ] Test dengan transaksi kecil

### 9. Post-Install
1. Login admin: `/admin`
   - Email: `admin@neopga.com`
   - Password: `admin123`
   - **SEGERA GANTI PASSWORD!**

2. Tambah rekening bank di Admin → Rekening Bank

3. Update QRIS settings di Admin → Pengaturan QRIS

4. Buat merchant test di Admin → Merchant → Tambah Merchant

5. Test payment flow:
   - Create payment
   - Bayar via QRIS/Transfer
   - Cek auto-verification

## Troubleshooting

### Database Connection Failed
- Cek DB_HOST (biasanya `localhost`)
- Cek DB credentials di `config/config.php`
- Pastikan user punya akses ke database

### 404 Page Not Found
- Cek file `.htaccess` ada
- Pastikan mod_rewrite enabled
- Cek permission folder (755)

### Permission Denied
```bash
chmod 755 uploads/ logs/ data/
chmod 644 *.php
```

### API Tidak Bisa Akses
- Pastikan `.htaccess` tidak block API
- Cek firewall/security rules cPanel

## Support

📱 WhatsApp: 0895-3434-0757  
📧 Email: support@neopga.com

---

© 2025 NEO PGA - Payment Gateway Termudah di Indonesia

<?php
/**
 * NEO PGA Public Payment Page
 * Halaman pembayaran untuk customer
 */
require_once __DIR__ . '/../includes/init.php';

$invoice = sanitize($_GET['invoice'] ?? '');
$db = Database::getInstance();
$trx = null;
$bank = null;
$merchant = null;
$error = '';

if (!$invoice) {
    $error = 'Invoice tidak ditemukan';
} else {
    $trx = $db->fetch("SELECT * FROM transactions WHERE invoice_number = ?", [$invoice]);

    if (!$trx) {
        $error = 'Transaksi tidak ditemukan';
    } else {
        // Get merchant info
        $merchant = $db->fetch("SELECT business_name, merchant_code FROM merchants WHERE id = ?", [$trx['merchant_id']]);
        
        // Get bank info if bank transfer
        if ($trx['payment_method'] === 'bank_transfer' && $trx['bank_account_id']) {
            $bank = $db->fetch("SELECT * FROM bank_accounts WHERE id = ? AND is_active = 1", [$trx['bank_account_id']]);
        }
        
        // Check if expired
        if ($trx['status'] === 'pending' && strtotime($trx['expired_at']) < time()) {
            $db->update('transactions', ['status' => 'expired'], 'id = ?', [$trx['id']]);
            $trx['status'] = 'expired';
        }
    }
}

$statusInfo = [
    'pending' => ['color' => '#f59e0b', 'bg' => '#fef3c7', 'text' => 'Menunggu Pembayaran', 'icon' => '⏳'],
    'waiting' => ['color' => '#3b82f6', 'bg' => '#dbeafe', 'text' => 'Menunggu Konfirmasi', 'icon' => '🔄'],
    'success' => ['color' => '#10b981', 'bg' => '#dcfce7', 'text' => 'Pembayaran Berhasil', 'icon' => '✅'],
    'failed' => ['color' => '#ef4444', 'bg' => '#fee2e2', 'text' => 'Pembayaran Gagal', 'icon' => '❌'],
    'expired' => ['color' => '#6b7280', 'bg' => '#f3f4f6', 'text' => 'Kedaluwarsa', 'icon' => '⏰'],
    'cancelled' => ['color' => '#6b7280', 'bg' => '#f3f4f6', 'text' => 'Dibatalkan', 'icon' => '🚫'],
];

$status = $trx ? ($statusInfo[$trx['status']] ?? $statusInfo['pending']) : null;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $invoice ? "Pembayaran #{$invoice}" : 'Pembayaran' ?> - <?= APP_NAME ?></title>
    <link rel="icon" type="image/svg+xml" href="<?= ASSETS_URL ?>/images/favicon.svg">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #0d9488;
            --primary-light: #14b8a6;
            --gray-50: #f9fafb;
            --gray-100: #f3f4f6;
            --gray-200: #e5e7eb;
            --gray-500: #6b7280;
            --gray-700: #374151;
            --gray-900: #111827;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: linear-gradient(135deg, #f0fdfa 0%, #f9fafb 100%);
            min-height: 100vh;
            padding: 2rem;
        }
        .container { max-width: 480px; margin: 0 auto; }
        .logo { text-align: center; margin-bottom: 2rem; }
        .logo a {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            text-decoration: none;
            font-size: 1.5rem;
            font-weight: 800;
            color: var(--gray-900);
        }
        .logo-icon {
            width: 36px;
            height: 36px;
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .logo-icon svg { width: 22px; height: 22px; color: white; fill: white; }
        .logo span { color: var(--primary); }
        .card {
            background: white;
            border-radius: 20px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.08);
            overflow: hidden;
        }
        .status-bar {
            padding: 1rem 1.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            font-weight: 600;
        }
        .card-body { padding: 2rem; }
        .amount-box {
            text-align: center;
            padding: 1.5rem;
            background: var(--gray-50);
            border-radius: 16px;
            margin-bottom: 1.5rem;
        }
        .amount-label { font-size: 0.85rem; color: var(--gray-500); margin-bottom: 0.5rem; }
        .amount-value { font-size: 2.5rem; font-weight: 800; color: var(--gray-900); }
        .amount-note { font-size: 0.75rem; color: var(--primary); margin-top: 0.5rem; }
        .info-row {
            display: flex;
            justify-content: space-between;
            padding: 0.75rem 0;
            border-bottom: 1px solid var(--gray-100);
            font-size: 0.9rem;
        }
        .info-row:last-child { border-bottom: none; }
        .info-label { color: var(--gray-500); }
        .info-value { font-weight: 600; color: var(--gray-900); text-align: right; }
        .section-title {
            font-weight: 700;
            color: var(--gray-900);
            margin: 1.5rem 0 1rem;
            font-size: 1rem;
        }
        .qr-box {
            text-align: center;
            padding: 1.5rem;
            background: white;
            border: 2px solid var(--gray-200);
            border-radius: 16px;
            margin-bottom: 1rem;
        }
        .qr-box img { max-width: 200px; margin-bottom: 1rem; }
        .qr-box p { font-size: 0.8rem; color: var(--gray-500); }
        .bank-box {
            background: linear-gradient(135deg, #0d9488 0%, #14b8a6 100%);
            color: white;
            border-radius: 16px;
            padding: 1.5rem;
            margin-bottom: 1rem;
        }
        .bank-name { font-size: 1.25rem; font-weight: 700; margin-bottom: 1rem; }
        .bank-account {
            background: rgba(255,255,255,0.2);
            border-radius: 10px;
            padding: 1rem;
            font-family: 'JetBrains Mono', monospace;
        }
        .bank-account-number { 
            font-size: 1.5rem; 
            font-weight: 700; 
            letter-spacing: 2px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .bank-account-name { font-size: 0.85rem; opacity: 0.9; margin-top: 0.5rem; }
        .copy-btn {
            background: white;
            color: var(--primary);
            border: none;
            padding: 0.5rem 1rem;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 600;
            font-size: 0.8rem;
        }
        .copy-btn:hover { background: #f0fdfa; }
        .expired-box {
            text-align: center;
            padding: 3rem 1.5rem;
        }
        .expired-box .icon { font-size: 4rem; margin-bottom: 1rem; }
        .expired-box h2 { color: var(--gray-700); margin-bottom: 0.5rem; }
        .expired-box p { color: var(--gray-500); }
        .countdown { 
            text-align: center; 
            padding: 1rem; 
            background: #fef3c7; 
            border-radius: 10px; 
            margin-bottom: 1.5rem;
        }
        .countdown .time { font-size: 1.5rem; font-weight: 700; color: #d97706; }
        .countdown .label { font-size: 0.8rem; color: #92400e; }
        .footer { text-align: center; margin-top: 2rem; color: var(--gray-500); font-size: 0.8rem; }
        @media (max-width: 480px) {
            body { padding: 1rem; }
            .amount-value { font-size: 2rem; }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="logo">
            <a href="<?= APP_URL ?>">
                <div class="logo-icon">
                    <svg viewBox="0 0 24 24" fill="none">
                        <path d="M4 20 C4 20, 7 15, 10 10 C11 8, 11.5 6, 12 4" stroke="#14B8A6" stroke-width="2.5" stroke-linecap="round"/>
                        <path d="M20 20 C20 20, 17 15, 14 10 C13 8, 12.5 6, 12 4" stroke="#0D9488" stroke-width="2.5" stroke-linecap="round"/>
                        <circle cx="12" cy="4" r="2.5" fill="#F59E0B"/>
                        <line x1="12" y1="7" x2="12" y2="18" stroke="#0D9488" stroke-width="2" stroke-linecap="round"/>
                    </svg>
                </div>
                NEO<span>PGA</span>
            </a>
        </div>
        
        <?php if ($error): ?>
        <div class="card">
            <div class="card-body">
                <div class="expired-box">
                    <div class="icon">❓</div>
                    <h2>Transaksi Tidak Ditemukan</h2>
                    <p>Invoice yang Anda cari tidak ada atau sudah dihapus.</p>
                </div>
            </div>
        </div>
        
        <?php elseif ($trx['status'] === 'expired'): ?>
        <div class="card">
            <div class="status-bar" style="background: <?= $status['bg'] ?>; color: <?= $status['color'] ?>;">
                <?= $status['icon'] ?> <?= $status['text'] ?>
            </div>
            <div class="card-body">
                <div class="expired-box">
                    <div class="icon">⏰</div>
                    <h2>Pembayaran Kedaluwarsa</h2>
                    <p>Maaf, waktu pembayaran untuk transaksi ini sudah habis.</p>
                </div>
            </div>
        </div>
        
        <?php elseif ($trx['status'] === 'success'): ?>
        <div class="card">
            <div class="status-bar" style="background: <?= $status['bg'] ?>; color: <?= $status['color'] ?>;">
                <?= $status['icon'] ?> <?= $status['text'] ?>
            </div>
            <div class="card-body">
                <div class="amount-box" style="background: #dcfce7;">
                    <div class="amount-label">Pembayaran Diterima</div>
                    <div class="amount-value" style="color: #166534;">Rp <?= number_format($trx['total_amount'], 0, ',', '.') ?></div>
                </div>
                <div class="info-row">
                    <span class="info-label">Invoice</span>
                    <span class="info-value"><?= $trx['invoice_number'] ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Tanggal Bayar</span>
                    <span class="info-value"><?= date('d M Y, H:i', strtotime($trx['paid_at'] ?? $trx['updated_at'])) ?></span>
                </div>
                <div style="text-align: center; margin-top: 2rem; font-size: 0.9rem; color: var(--gray-500);">
                    Terima kasih atas pembayaran Anda! 🙏
                </div>
            </div>
        </div>
        
        <?php else: ?>
        <!-- Pending Payment -->
        <div class="card">
            <div class="status-bar" style="background: <?= $status['bg'] ?>; color: <?= $status['color'] ?>;">
                <?= $status['icon'] ?> <?= $status['text'] ?>
            </div>
            <div class="card-body">
                <!-- Countdown -->
                <?php if ($trx['expired_at']): ?>
                <div class="countdown">
                    <div class="time" id="countdown">--:--:--</div>
                    <div class="label">Waktu tersisa untuk pembayaran</div>
                </div>
                <?php endif; ?>
                
                <!-- Amount -->
                <div class="amount-box">
                    <div class="amount-label">Total Pembayaran</div>
                    <div class="amount-value">Rp <?= number_format($trx['total_amount'], 0, ',', '.') ?></div>
                    <?php if ($trx['unique_code'] > 0): ?>
                    <div class="amount-note">*Termasuk kode unik Rp <?= number_format($trx['unique_code'], 0, ',', '.') ?></div>
                    <?php endif; ?>
                </div>
                
                <!-- Info -->
                <div class="info-row">
                    <span class="info-label">Invoice</span>
                    <span class="info-value"><?= $trx['invoice_number'] ?></span>
                </div>
                <?php if (!empty($trx['description'])): ?>
                <div class="info-row">
                    <span class="info-label">Deskripsi</span>
                    <span class="info-value"><?= htmlspecialchars($trx['description']) ?></span>
                </div>
                <?php endif; ?>
                <div class="info-row">
                    <span class="info-label">Merchant</span>
                    <span class="info-value"><?= htmlspecialchars($merchant['business_name'] ?? '-') ?></span>
                </div>
                
                <!-- Payment Method -->
                <?php if ($trx['payment_method'] === 'qris' && $trx['qris_string']): ?>
                <h3 class="section-title">📱 Scan QRIS</h3>
                <div class="qr-box">
                    <img src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=<?= urlencode($trx['qris_string']) ?>" alt="QRIS">
                    <p>Scan dengan GoPay, OVO, DANA, ShopeePay, atau aplikasi e-wallet lainnya</p>
                </div>
                
                <?php elseif ($trx['payment_method'] === 'bank_transfer' && $bank): ?>
                <h3 class="section-title">🏦 Transfer ke Rekening</h3>
                <div class="bank-box">
                    <div class="bank-name"><?= htmlspecialchars($bank['bank_name']) ?></div>
                    <div class="bank-account">
                        <div class="bank-account-number">
                            <span id="accountNumber"><?= htmlspecialchars($bank['account_number']) ?></span>
                            <button class="copy-btn" onclick="copyAccount()">📋 Copy</button>
                        </div>
                        <div class="bank-account-name">a.n. <?= htmlspecialchars($bank['account_name']) ?></div>
                    </div>
                </div>
                <div style="background: #fef3c7; border-radius: 10px; padding: 1rem; font-size: 0.85rem; color: #92400e;">
                    ⚠️ <strong>Penting:</strong> Transfer tepat <strong>Rp <?= number_format($trx['total_amount'], 0, ',', '.') ?></strong> agar pembayaran dapat terverifikasi otomatis.
                </div>
                
                <?php else: ?>
                <div style="text-align: center; padding: 2rem; color: var(--gray-500);">
                    <p>Metode pembayaran tidak tersedia</p>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <script>
        // Countdown
        <?php if ($trx['expired_at']): ?>
        const expiry = new Date("<?= $trx['expired_at'] ?>").getTime();
        function updateCountdown() {
            const now = new Date().getTime();
            const diff = expiry - now;
            if (diff <= 0) {
                document.getElementById('countdown').textContent = 'EXPIRED';
                location.reload();
                return;
            }
            const hours = Math.floor(diff / (1000 * 60 * 60));
            const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
            const secs = Math.floor((diff % (1000 * 60)) / 1000);
            document.getElementById('countdown').textContent = 
                String(hours).padStart(2, '0') + ':' + 
                String(mins).padStart(2, '0') + ':' + 
                String(secs).padStart(2, '0');
        }
        updateCountdown();
        setInterval(updateCountdown, 1000);
        <?php endif; ?>
        
        function copyAccount() {
            const text = document.getElementById('accountNumber').textContent;
            navigator.clipboard.writeText(text);
            alert('Nomor rekening berhasil dicopy!');
        }
        
        // Auto refresh every 30 seconds to check status
        setTimeout(() => location.reload(), 30000);
        </script>
        <?php endif; ?>
        
        <div class="footer">
            <p>Powered by <?= APP_NAME ?></p>
            <p style="margin-top: 0.5rem;">Butuh bantuan? Hubungi merchant terkait.</p>
        </div>
    </div>

    <!-- Security Protection -->
    <script src="<?= ASSETS_URL ?>/js/security.js"></script>
</body>
</html>

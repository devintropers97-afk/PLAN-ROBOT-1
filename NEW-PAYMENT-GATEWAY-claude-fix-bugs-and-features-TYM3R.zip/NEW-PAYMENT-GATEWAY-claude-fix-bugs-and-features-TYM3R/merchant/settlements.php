<?php
/**
 * NEO PGA - Merchant Settlements (Withdrawal)
 * VERSI DIPERBAIKI - Session, CSRF, Balance Logic
 */
require_once __DIR__ . '/../includes/init.php';

$pageTitle = 'Penarikan Dana';
$currentPage = 'settlements';
$minSettlement = 100000;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $db = Database::getInstance();
    
    if (!isset($_SESSION['merchant_user']['id'])) {
        $_SESSION['flash_message'] = 'Sesi tidak valid';
        $_SESSION['flash_type'] = 'error';
        header('Location: login.php');
        exit;
    }
    
    $merchantId = (int)$_SESSION['merchant_user']['id'];
    $merchant = $db->fetch("SELECT * FROM merchants WHERE id = ?", [$merchantId]);
    
    if (!$merchant) {
        $_SESSION['flash_message'] = 'Merchant tidak ditemukan';
        $_SESSION['flash_type'] = 'error';
        header('Location: login.php');
        exit;
    }
    
    if (sanitize($_POST['action'] ?? '') === 'withdraw') {
        // Check for XSS attempts
        $xssDetected = detectXSS($_POST['bank_name'] ?? '') ||
                       detectXSS($_POST['account_name'] ?? '') ||
                       detectXSS($_POST['notes'] ?? '');

        if ($xssDetected) {
            $_SESSION['flash_message'] = 'Input tidak valid terdeteksi!';
            $_SESSION['flash_type'] = 'error';
            header('Location: settlements.php');
            exit;
        }

        $amount = (int)str_replace(['.', ',', ' '], '', $_POST['amount'] ?? 0);
        $bankName = sanitize($_POST['bank_name'] ?? '');
        $accountNumber = preg_replace('/[^0-9]/', '', $_POST['account_number'] ?? '');
        $accountName = sanitize($_POST['account_name'] ?? '');
        $notes = sanitize($_POST['notes'] ?? '');

        // Basic validation (non-database checks)
        $errors = [];
        if ($amount < $minSettlement) $errors[] = 'Minimal ' . formatRupiah($minSettlement);
        if (empty($bankName)) $errors[] = 'Pilih bank';
        if (strlen($accountNumber) < 8 || strlen($accountNumber) > 20) $errors[] = 'No. rekening tidak valid';
        if (empty($accountName)) $errors[] = 'Nama pemilik harus diisi';

        if (empty($errors)) {
            try {
                // BEGIN TRANSACTION FIRST - Critical for preventing TOCTOU race conditions
                $db->beginTransaction();

                // Re-fetch merchant with FOR UPDATE lock to get fresh balance and prevent concurrent withdrawals
                $lockedMerchant = $db->fetch(
                    "SELECT * FROM merchants WHERE id = ? FOR UPDATE",
                    [$merchantId]
                );

                if (!$lockedMerchant) {
                    $db->rollback();
                    $_SESSION['flash_message'] = 'Merchant tidak ditemukan';
                    $_SESSION['flash_type'] = 'error';
                    header('Location: settlements.php');
                    exit;
                }

                // Check balance INSIDE transaction with locked data
                if ($amount > $lockedMerchant['balance']) {
                    $db->rollback();
                    $_SESSION['flash_message'] = 'Saldo tidak cukup';
                    $_SESSION['flash_type'] = 'error';
                    header('Location: settlements.php');
                    exit;
                }

                // Check for pending settlement INSIDE transaction with lock
                $pending = $db->fetch(
                    "SELECT id FROM settlements WHERE merchant_id = ? AND status = 'pending' FOR UPDATE",
                    [$merchantId]
                );

                if ($pending) {
                    $db->rollback();
                    $_SESSION['flash_message'] = 'Ada pencairan yang masih pending';
                    $_SESSION['flash_type'] = 'error';
                    header('Location: settlements.php');
                    exit;
                }

                // All checks passed - proceed with withdrawal
                $settlementNumber = 'STL' . date('Ymd') . strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, 6));

                $db->query(
                    "INSERT INTO settlements (settlement_number, merchant_id, amount, net_amount, bank_name, bank_account_number, bank_account_name, notes, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending', NOW())",
                    [$settlementNumber, $merchantId, $amount, $amount, $bankName, $accountNumber, $accountName, $notes]
                );
                $settlementId = $db->lastInsertId();

                $balanceBefore = (float)$lockedMerchant['balance'];
                $balanceAfter = $balanceBefore - $amount;
                $pendingBefore = (float)($lockedMerchant['pending_balance'] ?? 0);
                $pendingAfter = $pendingBefore + $amount;

                // Use ATOMIC balance update
                $db->query(
                    "UPDATE merchants SET balance = balance - ?, pending_balance = pending_balance + ?, updated_at = NOW() WHERE id = ?",
                    [$amount, $amount, $merchantId]
                );
                $db->query(
                    "INSERT INTO balance_logs (merchant_id, settlement_id, type, amount, balance_before, balance_after, description, created_at) VALUES (?, ?, 'debit', ?, ?, ?, ?, NOW())",
                    [$merchantId, $settlementId, $amount, $balanceBefore, $balanceAfter, "Settlement: $settlementNumber"]
                );

                $db->commit();
                $_SESSION['flash_message'] = "Pencairan #$settlementNumber berhasil diajukan!";
                $_SESSION['flash_type'] = 'success';
            } catch (Exception $e) {
                if ($db->getPdo()->inTransaction()) {
                    $db->rollback();
                }
                $_SESSION['flash_message'] = 'Gagal: ' . $e->getMessage();
                $_SESSION['flash_type'] = 'error';
            }
        } else {
            $_SESSION['flash_message'] = implode(', ', $errors);
            $_SESSION['flash_type'] = 'error';
        }
        header('Location: settlements.php');
        exit;
    }
}

include 'layout_header.php';

$settlements = $db->fetchAll("SELECT * FROM settlements WHERE merchant_id = ? ORDER BY created_at DESC LIMIT 50", [$merchantId]);
$stats = [
    'withdrawn' => $db->fetch("SELECT COALESCE(SUM(amount),0) as s FROM settlements WHERE merchant_id = ? AND status = 'completed'", [$merchantId])['s'],
    'pending' => $db->fetch("SELECT COALESCE(SUM(amount),0) as s FROM settlements WHERE merchant_id = ? AND status = 'pending'", [$merchantId])['s'],
];
$hasPending = $db->fetch("SELECT id FROM settlements WHERE merchant_id = ? AND status = 'pending'", [$merchantId]);
$prefillBank = $merchant['bank_name'] ?? '';
$prefillAccNum = $merchant['bank_account_number'] ?? '';
$prefillAccName = $merchant['bank_account_name'] ?? '';
?>
<style>
.balance-card{background:linear-gradient(135deg,var(--primary),var(--primary-light));border-radius:16px;padding:2rem;color:#fff;margin-bottom:2rem}
.balance-value{font-size:2.5rem;font-weight:700}
.balance-stats{display:flex;gap:2rem;margin-top:1rem;padding-top:1rem;border-top:1px solid rgba(255,255,255,.2)}
.grid-2{display:grid;grid-template-columns:1fr 2fr;gap:1.5rem}
.card{background:#fff;border-radius:16px;border:1px solid var(--gray-200);overflow:hidden}
.card-header{padding:1rem 1.5rem;border-bottom:1px solid var(--gray-100);font-weight:600}
.card-body{padding:1.5rem}
.form-group{margin-bottom:1.25rem}
.form-label{display:block;font-size:.8rem;font-weight:600;color:var(--gray-700);margin-bottom:.5rem}
.form-input,.form-select{width:100%;padding:.75rem 1rem;border:1px solid var(--gray-300);border-radius:10px;font-size:.9rem}
.form-input:focus,.form-select:focus{outline:none;border-color:var(--primary);box-shadow:0 0 0 3px rgba(13,148,136,.1)}
.form-helper{font-size:.75rem;color:var(--gray-500);margin-top:.25rem}
.input-prefix{position:relative}.input-prefix span{position:absolute;left:1rem;top:50%;transform:translateY(-50%);color:var(--gray-500)}
.input-prefix input{padding-left:2.5rem}
.btn{display:flex;align-items:center;justify-content:center;gap:.5rem;padding:.75rem 1.5rem;border-radius:10px;font-weight:500;border:none;cursor:pointer;width:100%}
.btn-primary{background:var(--primary);color:#fff}.btn-primary:hover:not(:disabled){background:var(--primary-dark)}
.btn-primary:disabled{background:var(--gray-300);color:var(--gray-500);cursor:not-allowed}
.table{width:100%;border-collapse:collapse}.table th{padding:.75rem;text-align:left;font-size:.7rem;text-transform:uppercase;color:var(--gray-500);background:var(--gray-50);border-bottom:1px solid var(--gray-200)}
.table td{padding:.75rem;border-bottom:1px solid var(--gray-100);font-size:.85rem}
.table code{font-family:monospace;font-size:.75rem;background:var(--gray-100);padding:.2rem .5rem;border-radius:4px}
.badge{display:inline-block;padding:.3rem .6rem;font-size:.7rem;font-weight:600;border-radius:6px}
.badge-success{background:#d1fae5;color:#065f46}.badge-warning{background:#fef3c7;color:#92400e}.badge-danger{background:#fee2e2;color:#991b1b}
.warning-box{background:#fef3c7;border:1px solid #fcd34d;border-radius:10px;padding:1rem;margin-bottom:1rem;display:flex;align-items:center;gap:.75rem}
.info-box{background:#dbeafe;border:1px solid #93c5fd;border-radius:12px;padding:1.25rem;margin-top:1.5rem}
.empty{text-align:center;padding:2rem;color:var(--gray-400)}
@media(max-width:1024px){.grid-2{grid-template-columns:1fr}}
</style>

<div class="balance-card">
    <div style="font-size:.9rem;opacity:.9">Saldo Tersedia</div>
    <div class="balance-value"><?= formatRupiah($merchant['balance']) ?></div>
    <div class="balance-stats">
        <div><div style="font-size:.75rem;opacity:.8">Total Dicairkan</div><div style="font-size:1.25rem;font-weight:600"><?= formatRupiah($stats['withdrawn']) ?></div></div>
        <div><div style="font-size:.75rem;opacity:.8">Pending</div><div style="font-size:1.25rem;font-weight:600"><?= formatRupiah($stats['pending']) ?></div></div>
    </div>
</div>

<div class="grid-2">
    <div class="card">
        <div class="card-header">💰 Tarik Saldo</div>
        <form method="POST" class="card-body" id="wdForm" onsubmit="return validateWD()">
            <?= csrfField() ?>
            <input type="hidden" name="action" value="withdraw">
            
            <?php if ($hasPending): ?>
            <div class="warning-box"><span>⏳</span> Ada pencairan pending</div>
            <?php endif; ?>
            
            <div class="form-group">
                <label class="form-label">Jumlah *</label>
                <div class="input-prefix"><span>Rp</span><input type="text" name="amount" id="amtInput" class="form-input" placeholder="100.000" required <?= $hasPending ? 'disabled' : '' ?>></div>
                <div class="form-helper">Min <?= formatRupiah($minSettlement) ?> • Tersedia: <?= formatRupiah($merchant['balance']) ?></div>
            </div>
            <div class="form-group">
                <label class="form-label">Bank *</label>
                <select name="bank_name" class="form-select" required <?= $hasPending ? 'disabled' : '' ?>>
                    <option value="">Pilih Bank</option>
                    <?php foreach(['BCA','Mandiri','BNI','BRI','BSI','BTN','CIMB','Permata','Danamon','Jenius','Jago','SeaBank','DANA','OVO','GoPay','Lainnya'] as $b): ?>
                    <option value="<?= $b ?>" <?= $prefillBank === $b ? 'selected' : '' ?>><?= $b ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label class="form-label">No. Rekening *</label>
                <input type="text" name="account_number" id="accNum" class="form-input" value="<?= htmlspecialchars($prefillAccNum) ?>" required <?= $hasPending ? 'disabled' : '' ?>>
            </div>
            <div class="form-group">
                <label class="form-label">Nama Pemilik *</label>
                <input type="text" name="account_name" class="form-input" value="<?= htmlspecialchars($prefillAccName) ?>" required <?= $hasPending ? 'disabled' : '' ?>>
            </div>
            <div class="form-group">
                <label class="form-label">Catatan</label>
                <textarea name="notes" class="form-input" rows="2" <?= $hasPending ? 'disabled' : '' ?>></textarea>
            </div>
            <?php $canWD = $merchant['balance'] >= $minSettlement && !$hasPending; ?>
            <button type="submit" class="btn btn-primary" id="wdBtn" <?= !$canWD ? 'disabled' : '' ?>>
                <?= $canWD ? '💳 Ajukan Pencairan' : ($hasPending ? '⏳ Ada Pending' : '❌ Saldo Kurang') ?>
            </button>
        </form>
    </div>
    
    <div class="card">
        <div class="card-header">📋 Riwayat</div>
        <div style="overflow-x:auto">
            <table class="table">
                <thead><tr><th>No.</th><th>Jumlah</th><th>Bank</th><th>Status</th><th>Tanggal</th></tr></thead>
                <tbody>
                <?php if (empty($settlements)): ?>
                <tr><td colspan="5" class="empty">📭 Belum ada data</td></tr>
                <?php else: foreach ($settlements as $s): ?>
                <tr>
                    <td><code><?= htmlspecialchars($s['settlement_number']) ?></code></td>
                    <td style="font-weight:600;color:var(--primary)"><?= formatRupiah($s['amount']) ?></td>
                    <td><?= htmlspecialchars($s['bank_name']) ?><br><small style="color:var(--gray-500)"><?= substr($s['bank_account_number'],0,4) ?>****</small></td>
                    <td>
                        <?php $st = ['pending'=>['warning','Pending'],'completed'=>['success','Selesai'],'rejected'=>['danger','Ditolak']][$s['status']] ?? ['','?']; ?>
                        <span class="badge badge-<?= $st[0] ?>"><?= $st[1] ?></span>
                        <?php if($s['status']==='rejected' && $s['notes']): ?><div style="font-size:.7rem;color:#991b1b"><?= htmlspecialchars($s['notes']) ?></div><?php endif; ?>
                    </td>
                    <td style="color:var(--gray-500)"><?= date('d/m/Y', strtotime($s['created_at'])) ?></td>
                </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="info-box">
    <strong>ℹ️ Info:</strong> Min <?= formatRupiah($minSettlement) ?> • Proses 1-3 hari kerja • Pastikan data rekening benar
</div>

<script>
document.getElementById('amtInput')?.addEventListener('input',e=>e.target.value=new Intl.NumberFormat('id-ID').format(e.target.value.replace(/\D/g,'')));
document.getElementById('accNum')?.addEventListener('input',e=>e.target.value=e.target.value.replace(/\D/g,''));
let submitting=false;
function validateWD(){
    if(submitting)return!1;
    const amt=parseInt(document.getElementById('amtInput').value.replace(/\D/g,''))||0;
    if(amt<<?=$minSettlement?>){alert('Min <?=formatRupiah($minSettlement)?>');return!1}
    if(amt><?=(int)$merchant['balance']?>){alert('Melebihi saldo');return!1}
    if(!confirm('Tarik Rp '+amt.toLocaleString('id-ID')+'?'))return!1;
    submitting=true;document.getElementById('wdBtn').disabled=true;document.getElementById('wdBtn').textContent='⏳ Proses...';
    return!0
}
</script>
<?php include 'layout_footer.php'; ?>

<?php
/**
 * ================================================================================
 *                    NEO PGA - CEK STATUS PEMBAYARAN
 * ================================================================================
 *
 * Halaman untuk customer mengecek status pembayaran mereka.
 *
 * CARA PAKAI:
 * https://websitekamu.com/cek-status.php
 * https://websitekamu.com/cek-status.php?invoice=INV20241209XXXX
 *
 * TIDAK PERLU EDIT FILE INI - Cukup edit config.php saja!
 *
 * ================================================================================
 */

require_once __DIR__ . '/config.php';

// Sanitize invoice parameter untuk keamanan XSS
$invoice = htmlspecialchars(strip_tags($_GET['invoice'] ?? $_POST['invoice'] ?? ''), ENT_QUOTES, 'UTF-8');
$statusData = null;
$error = null;

if ($invoice) {
    $result = neopga_status($invoice);
    if ($result && $result['success']) {
        $statusData = $result['data'];
    } else {
        $error = $result['error'] ?? 'Invoice tidak ditemukan';
    }
}

// Helper untuk badge status
function getStatusBadge($status) {
    $badges = [
        'pending' => ['color' => '#f59e0b', 'bg' => '#fef3c7', 'text' => 'Menunggu Pembayaran'],
        'success' => ['color' => '#10b981', 'bg' => '#d1fae5', 'text' => 'Berhasil'],
        'paid' => ['color' => '#10b981', 'bg' => '#d1fae5', 'text' => 'Berhasil'],
        'failed' => ['color' => '#ef4444', 'bg' => '#fee2e2', 'text' => 'Gagal'],
        'expired' => ['color' => '#6b7280', 'bg' => '#f3f4f6', 'text' => 'Kedaluwarsa'],
    ];
    return $badges[$status] ?? $badges['pending'];
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cek Status Pembayaran - <?= htmlspecialchars(NAMA_TOKO) ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #f3f4f6;
            min-height: 100vh;
            padding: 20px;
        }
        .container {
            max-width: 500px;
            margin: 0 auto;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
            padding-top: 20px;
        }
        .header h1 {
            font-size: 24px;
            color: #1f2937;
            margin-bottom: 8px;
        }
        .header p {
            color: #6b7280;
            font-size: 15px;
        }
        .card {
            background: white;
            border-radius: 16px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08);
            overflow: hidden;
        }
        .search-form {
            padding: 24px;
        }
        .form-group {
            margin-bottom: 16px;
        }
        .form-group label {
            display: block;
            font-weight: 500;
            color: #374151;
            margin-bottom: 8px;
            font-size: 14px;
        }
        .form-group input {
            width: 100%;
            padding: 14px 16px;
            border: 2px solid #e5e7eb;
            border-radius: 10px;
            font-size: 16px;
            transition: border-color 0.2s;
        }
        .form-group input:focus {
            outline: none;
            border-color: #0d9488;
        }
        .form-group input::placeholder {
            color: #9ca3af;
        }
        .btn-check {
            width: 100%;
            padding: 16px;
            background: linear-gradient(135deg, #0d9488 0%, #0f766e 100%);
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
        }
        .btn-check:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(13, 148, 136, 0.4);
        }

        /* Result styles */
        .result {
            border-top: 1px solid #e5e7eb;
        }
        .result-header {
            padding: 24px;
            text-align: center;
        }
        .status-badge {
            display: inline-block;
            padding: 8px 20px;
            border-radius: 50px;
            font-weight: 600;
            font-size: 14px;
            margin-bottom: 12px;
        }
        .result-header h2 {
            font-size: 18px;
            color: #1f2937;
        }
        .result-details {
            padding: 0 24px 24px;
        }
        .detail-row {
            display: flex;
            justify-content: space-between;
            padding: 14px 0;
            border-bottom: 1px solid #f3f4f6;
        }
        .detail-row:last-child {
            border-bottom: none;
        }
        .detail-row .label {
            color: #6b7280;
            font-size: 14px;
        }
        .detail-row .value {
            font-weight: 500;
            color: #1f2937;
            text-align: right;
        }
        .detail-row .value.amount {
            font-size: 18px;
            color: #0d9488;
            font-weight: 700;
        }

        /* Error styles */
        .error-box {
            background: #fef2f2;
            border: 1px solid #fecaca;
            border-radius: 12px;
            padding: 16px;
            margin: 0 24px 24px;
            text-align: center;
            color: #991b1b;
        }

        /* Footer */
        .footer {
            text-align: center;
            padding: 30px;
            color: #9ca3af;
            font-size: 13px;
        }
        .footer a {
            color: #0d9488;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Cek Status Pembayaran</h1>
            <p>Masukkan nomor invoice untuk melihat status</p>
        </div>

        <div class="card">
            <form method="GET" class="search-form">
                <div class="form-group">
                    <label for="invoice">Nomor Invoice</label>
                    <input
                        type="text"
                        id="invoice"
                        name="invoice"
                        placeholder="Contoh: INV20241209ABCD1234"
                        value="<?= htmlspecialchars($invoice) ?>"
                        required
                    >
                </div>
                <button type="submit" class="btn-check">
                    🔍 Cek Status
                </button>
            </form>

            <?php if ($error): ?>
            <div class="error-box">
                ❌ <?= htmlspecialchars($error) ?>
            </div>
            <?php endif; ?>

            <?php if ($statusData): ?>
            <?php $badge = getStatusBadge($statusData['status']); ?>
            <div class="result">
                <div class="result-header">
                    <span class="status-badge" style="background: <?= $badge['bg'] ?>; color: <?= $badge['color'] ?>;">
                        <?= $badge['text'] ?>
                    </span>
                    <h2><?= htmlspecialchars($statusData['description'] ?? 'Pembayaran') ?></h2>
                </div>

                <div class="result-details">
                    <div class="detail-row">
                        <span class="label">No. Invoice</span>
                        <span class="value"><?= htmlspecialchars($statusData['invoice_number'] ?? '-') ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="label">No. Order</span>
                        <span class="value"><?= htmlspecialchars($statusData['reference_id'] ?? '-') ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="label">Total Bayar</span>
                        <span class="value amount"><?= format_rupiah($statusData['amount'] ?? 0) ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="label">Metode</span>
                        <span class="value"><?= strtoupper($statusData['payment_method'] ?? '-') ?></span>
                    </div>
                    <?php if (!empty($statusData['paid_at'])): ?>
                    <div class="detail-row">
                        <span class="label">Waktu Bayar</span>
                        <span class="value"><?= date('d/m/Y H:i', strtotime($statusData['paid_at'])) ?></span>
                    </div>
                    <?php endif; ?>
                    <?php if ($statusData['status'] === 'pending' && !empty($statusData['expired_at'])): ?>
                    <div class="detail-row">
                        <span class="label">Batas Bayar</span>
                        <span class="value" style="color: #f59e0b;"><?= date('d/m/Y H:i', strtotime($statusData['expired_at'])) ?></span>
                    </div>
                    <?php endif; ?>
                </div>

                <?php if ($statusData['status'] === 'pending' && !empty($statusData['payment_url'])): ?>
                <div style="padding: 0 24px 24px;">
                    <a href="<?= htmlspecialchars($statusData['payment_url']) ?>" class="btn-check" style="display: block; text-align: center; text-decoration: none;">
                        💳 Lanjutkan Pembayaran
                    </a>
                </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>

        <div class="footer">
            <p><?= htmlspecialchars(NAMA_TOKO) ?></p>
            <p><a href="<?= get_homepage_url() ?>"><?= get_homepage_url() ?></a></p>
            <?php if (defined('WA_TOKO') && WA_TOKO): ?>
            <p style="margin-top: 12px;">
                <a href="https://wa.me/<?= WA_TOKO ?>">💬 Hubungi Kami via WhatsApp</a>
            </p>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($statusData && $statusData['status'] === 'pending'): ?>
    <script>
        // Auto refresh setiap 30 detik untuk status pending
        setTimeout(function() {
            location.reload();
        }, 30000);
    </script>
    <?php endif; ?>
</body>
</html>

-- ============================================
-- Migration: Add Concurrent Performance Indexes
-- Version: 2.2.1
-- Purpose: Optimize database for 100+ merchants with high concurrent transactions
-- ============================================

-- ============================================
-- TRANSACTIONS TABLE INDEXES
-- ============================================

-- Index for faster transaction lookup by total_amount and status (used in auto-verify)
-- This is critical for concurrent payment verification
ALTER TABLE `transactions`
ADD INDEX IF NOT EXISTS `idx_amount_status_method_created` (`total_amount`, `status`, `payment_method`, `created_at`);

-- Index for faster unique_code lookup (bank transfer verification)
ALTER TABLE `transactions`
ADD INDEX IF NOT EXISTS `idx_unique_code_status_method` (`unique_code`, `status`, `payment_method`);

-- Composite index for merchant transactions with status filtering
ALTER TABLE `transactions`
ADD INDEX IF NOT EXISTS `idx_merchant_status_created` (`merchant_id`, `status`, `created_at`);

-- Index for webhook processing
ALTER TABLE `transactions`
ADD INDEX IF NOT EXISTS `idx_webhook_status_attempts` (`webhook_status`, `webhook_attempts`);

-- ============================================
-- PAYMENT_CODES TABLE INDEXES
-- ============================================

-- Composite index for faster payment code reservation (critical for concurrency)
ALTER TABLE `payment_codes`
ADD INDEX IF NOT EXISTS `idx_merchant_status_expires` (`merchant_id`, `status`, `expires_at`);

-- Index for code cleanup/reset operations
ALTER TABLE `payment_codes`
ADD INDEX IF NOT EXISTS `idx_status_expires_used` (`status`, `expires_at`, `used_at`);

-- ============================================
-- MERCHANTS TABLE INDEXES
-- ============================================

-- Index for faster merchant lookup by ID with balance (used in balance updates)
-- Note: Primary key already provides fast lookup by ID
-- But we add an index for status filtering with balance operations
ALTER TABLE `merchants`
ADD INDEX IF NOT EXISTS `idx_status_balance` (`status`, `balance`);

-- ============================================
-- SETTLEMENTS TABLE INDEXES
-- ============================================

-- Composite index for checking pending settlements (used in TOCTOU prevention)
ALTER TABLE `settlements`
ADD INDEX IF NOT EXISTS `idx_merchant_status_created` (`merchant_id`, `status`, `created_at`);

-- ============================================
-- BALANCE_LOGS TABLE INDEXES
-- ============================================

-- Index for faster balance log queries
ALTER TABLE `balance_logs`
ADD INDEX IF NOT EXISTS `idx_merchant_created_type` (`merchant_id`, `created_at`, `type`);

-- Index for transaction-related balance queries
ALTER TABLE `balance_logs`
ADD INDEX IF NOT EXISTS `idx_transaction_type` (`transaction_id`, `type`);

-- ============================================
-- PERFORMANCE NOTES
-- ============================================

/*
These indexes are designed to optimize:

1. Transaction Creation (api/create.php):
   - idx_amount_status_method_created: Fast lookup of used total_amounts
   - idx_merchant_status_expires: Fast payment code selection

2. Transaction Verification (api/verify.php, api/auto-verify.php):
   - idx_amount_status_method_created: Fast matching by total_amount
   - idx_unique_code_status_method: Fast bank transfer verification

3. Settlement Processing (merchant/settlements.php):
   - idx_merchant_status_created: Fast pending settlement check

4. Balance Operations:
   - idx_status_balance: Fast merchant balance queries
   - idx_merchant_created_type: Fast balance log queries

FOR UPDATE locks work best with proper indexes because:
- Without index: Full table scan with lock
- With index: Only locked rows are scanned

Run this migration:
mysql -u username -p database_name < 001_add_concurrent_indexes.sql
*/

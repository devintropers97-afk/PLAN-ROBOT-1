# 🚀 NEO PGA (Payment Gateway) v2.2

Payment Gateway Termudah di Indonesia - Setup 5 Menit, Terima Pembayaran Selamanya!

## ✨ Fitur

- **QRIS Dinamis** - Generate QRIS dengan nominal otomatis
- **Bank Transfer** - Multiple bank support  
- **Auto-Verify** - Verifikasi otomatis via nominal unik
- **Dashboard Merchant** - Panel lengkap
- **Admin Panel** - Manajemen transaksi & settlement
- **API & Webhook** - Integrasi mudah
- **Settlement** - Penarikan saldo ke rekening

## 📁 Struktur

```
neopga/
├── /                   # Landing page marketing
├── /demo               # DigiStore showcase (contoh toko)
├── /admin              # Admin panel
├── /merchant           # Merchant dashboard
├── /api                # REST API
├── /pay                # Payment page (customer)
├── /includes           # Core classes
├── /config             # Konfigurasi
├── /sdk                # SDK & contoh integrasi
└── /assets             # CSS, JS
```

## 🔧 Instalasi

### 1. Upload ke hosting
### 2. Buat database & import `DATABASE.sql`
### 3. Edit `config/config.php`:

```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'nama_database');
define('DB_USER', 'username');
define('DB_PASS', 'password');
define('APP_URL', 'https://domain.com/neopga');
```

### 4. Login admin: `/admin` (admin / admin123)

## 📞 Support

WhatsApp: 0895-3434-07575

---
*© 2025 NEO PGA (Payment Gateway Autopilot) by SITUNEO*

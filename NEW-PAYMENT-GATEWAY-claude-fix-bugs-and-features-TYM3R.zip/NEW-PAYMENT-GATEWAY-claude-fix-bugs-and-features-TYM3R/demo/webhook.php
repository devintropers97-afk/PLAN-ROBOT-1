<?php
/**
 * ============================================
 * DIGISTORE DEMO - WEBHOOK HANDLER
 * ============================================
 *
 * File ini menerima notifikasi pembayaran dari NEO PGA
 * Ketika pembayaran berhasil, order akan di-update
 */

require_once __DIR__ . '/config.php';

// Log incoming request
writeLog('Webhook received', [
    'method' => $_SERVER['REQUEST_METHOD'],
    'content_type' => $_SERVER['CONTENT_TYPE'] ?? 'not set'
]);

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

// Get raw payload
$rawPayload = file_get_contents('php://input');
writeLog('Raw payload', ['payload' => $rawPayload]);

// Verify signature if provided
$signature = $_SERVER['HTTP_X_SIGNATURE'] ?? '';
if (!empty($signature) && !empty(NEOPGA_SECRET_KEY)) {
    if (!verifyWebhookSignature($rawPayload, $signature)) {
        writeLog('Invalid signature', ['provided' => $signature]);
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Invalid signature']);
        exit;
    }
}

// Parse JSON payload
$data = json_decode($rawPayload, true);
if (!$data) {
    writeLog('Invalid JSON payload');
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid JSON']);
    exit;
}

// Log parsed data
writeLog('Parsed webhook data', $data);

// Extract payment info
$invoiceNumber = $data['invoice_number'] ?? '';
$referenceId = $data['reference_id'] ?? '';
$status = $data['status'] ?? '';
$amount = $data['amount'] ?? 0;

// Find order
$order = null;
if (!empty($referenceId)) {
    $order = getOrder($referenceId);
}
if (!$order && !empty($invoiceNumber)) {
    $order = getOrderByInvoice($invoiceNumber);
}

if (!$order) {
    writeLog('Order not found', ['invoice' => $invoiceNumber, 'reference' => $referenceId]);
    http_response_code(404);
    echo json_encode(['success' => false, 'message' => 'Order not found']);
    exit;
}

// Update order status based on payment status
$orderId = $order['order_id'];
$previousStatus = $order['status'];

if ($status === 'success' || $status === 'paid') {
    // Payment successful
    updateOrderStatus($orderId, 'paid', [
        'paid_at' => date('Y-m-d H:i:s'),
        'paid_amount' => $amount,
        'payment_data' => $data
    ]);
    writeLog('Order marked as paid', ['order_id' => $orderId, 'amount' => $amount]);

} elseif ($status === 'expired') {
    // Payment expired
    updateOrderStatus($orderId, 'expired', [
        'expired_at' => date('Y-m-d H:i:s')
    ]);
    writeLog('Order marked as expired', ['order_id' => $orderId]);

} elseif ($status === 'failed' || $status === 'cancelled') {
    // Payment failed
    updateOrderStatus($orderId, 'failed', [
        'failed_at' => date('Y-m-d H:i:s'),
        'failure_reason' => $data['message'] ?? 'Unknown'
    ]);
    writeLog('Order marked as failed', ['order_id' => $orderId]);
}

// Send success response
http_response_code(200);
echo json_encode([
    'success' => true,
    'message' => 'Webhook processed',
    'order_id' => $orderId,
    'previous_status' => $previousStatus,
    'new_status' => $status
]);

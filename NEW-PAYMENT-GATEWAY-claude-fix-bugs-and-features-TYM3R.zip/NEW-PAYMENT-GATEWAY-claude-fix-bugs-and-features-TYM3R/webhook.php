<?php
/**
 * ============================================
 * DIGISTORE - WEBHOOK HANDLER
 * ============================================
 * 
 * File ini menerima notifikasi dari NEO PGA ketika:
 * - Pembayaran berhasil
 * - Pembayaran gagal
 * - Pembayaran expired
 * 
 * 📁 Lokasi: /webhook.php
 * 🔗 URL: https://toko-kamu.com/webhook.php
 * 
 * CARA KERJA:
 * 1. Customer bayar via QRIS
 * 2. NEO PGA proses pembayaran
 * 3. NEO PGA kirim POST request ke URL ini
 * 4. File ini terima data, verifikasi, dan update status pesanan
 * 
 * PENTING:
 * - URL ini harus didaftarkan di Dashboard Merchant NEO PGA → Webhook URL
 * - File ini TIDAK untuk diakses langsung oleh customer
 */

// Load konfigurasi
require_once __DIR__ . '/config.php';

// =====================================================
// 🔒 VALIDASI REQUEST
// =====================================================

// Webhook hanya menerima method POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);  // Method Not Allowed
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Ambil raw body dari request
$rawBody = file_get_contents('php://input');

// Log request masuk (untuk debugging)
writeLog('Webhook received', [
    'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
    'body_length' => strlen($rawBody)
]);

// Cek apakah body kosong
if (empty($rawBody)) {
    writeLog('ERROR: Empty request body');
    http_response_code(400);  // Bad Request
    echo json_encode(['error' => 'Empty request body']);
    exit;
}

// Parse JSON body
$payload = json_decode($rawBody, true);

if (!$payload) {
    writeLog('ERROR: Invalid JSON', ['body' => substr($rawBody, 0, 500)]);
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON']);
    exit;
}

// Log payload yang diterima
writeLog('Payload parsed', $payload);

// =====================================================
// 🔐 VERIFIKASI SIGNATURE (Opsional tapi Recommended)
// =====================================================
// Signature memastikan webhook benar dari NEO PGA, bukan hacker

$signature = $_SERVER['HTTP_X_SIGNATURE'] ?? '';

if (!empty($signature) && NEOPGA_SECRET_KEY !== 'GANTI_DENGAN_SECRET_KEY_KAMU') {
    // Verifikasi signature
    if (!verifyWebhookSignature($rawBody, $signature)) {
        writeLog('ERROR: Invalid signature', [
            'received' => $signature,
            'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown'
        ]);
        http_response_code(401);  // Unauthorized
        echo json_encode(['error' => 'Invalid signature']);
        exit;
    }
    writeLog('Signature verified OK');
}

// =====================================================
// 📦 PROSES DATA WEBHOOK
// =====================================================

// Ambil data dari payload
// Struktur payload dari NEO PGA:
// {
//   "event": "payment.success",
//   "data": {
//     "invoice_number": "INV20241210XXXXX",
//     "reference_id": "DGS-20241210-XXXXXX",
//     "amount": 150000,
//     "total_amount": 150123,
//     "status": "success",
//     "paid_at": "2024-12-10 10:30:00",
//     ...
//   }
// }

$event = $payload['event'] ?? '';
$data = $payload['data'] ?? [];

// Ambil informasi penting
$invoiceNumber = $data['invoice_number'] ?? '';
$referenceId = $data['reference_id'] ?? '';  // Ini adalah order_id kita
$status = $data['status'] ?? '';
$amount = $data['amount'] ?? 0;
$totalAmount = $data['total_amount'] ?? 0;
$paidAt = $data['paid_at'] ?? date('Y-m-d H:i:s');

writeLog("Processing event: {$event}", [
    'invoice' => $invoiceNumber,
    'reference_id' => $referenceId,
    'status' => $status
]);

// =====================================================
// ✅ HANDLE BERDASARKAN EVENT
// =====================================================

switch ($event) {
    
    // -------------------------------------------------
    // 💰 PEMBAYARAN BERHASIL
    // -------------------------------------------------
    case 'payment.success':
        
        // Cari pesanan berdasarkan reference_id (order_id kita)
        $order = getOrder($referenceId);
        
        if (!$order) {
            // Coba cari berdasarkan invoice_number
            $order = getOrderByInvoice($invoiceNumber);
        }
        
        if (!$order) {
            writeLog("WARNING: Order not found", [
                'reference_id' => $referenceId,
                'invoice' => $invoiceNumber
            ]);
            // Tetap response 200 supaya NEO PGA tidak retry terus
            http_response_code(200);
            echo json_encode(['status' => 'ok', 'message' => 'Order not found but acknowledged']);
            exit;
        }
        
        // Update status pesanan menjadi 'paid'
        $updated = updateOrderStatus($referenceId, 'paid', [
            'paid_at' => $paidAt,
            'payment_amount' => $totalAmount,
            'invoice_number' => $invoiceNumber,
            'webhook_received_at' => date('Y-m-d H:i:s')
        ]);
        
        if ($updated) {
            writeLog("SUCCESS: Order updated to PAID", [
                'order_id' => $referenceId,
                'amount' => $totalAmount
            ]);
            
            // -------------------------------------------------
            // 📧 KIRIM EMAIL KE CUSTOMER (Opsional)
            // -------------------------------------------------
            // Uncomment kode di bawah jika mau kirim email
            
            /*
            $customerEmail = $order['customer_email'] ?? '';
            $customerName = $order['customer_name'] ?? '';
            $productName = $order['product_name'] ?? '';
            $downloadUrl = $order['download_url'] ?? '';
            
            if (!empty($customerEmail)) {
                $subject = "Pembayaran Berhasil - " . STORE_NAME;
                $message = "Halo {$customerName},\n\n";
                $message .= "Terima kasih! Pembayaran kamu untuk {$productName} sudah kami terima.\n\n";
                $message .= "Link Download: {$downloadUrl}\n\n";
                $message .= "Salam,\n" . STORE_NAME;
                
                $headers = "From: " . STORE_EMAIL;
                
                mail($customerEmail, $subject, $message, $headers);
                writeLog("Email sent to: {$customerEmail}");
            }
            */
            
            // -------------------------------------------------
            // 📱 KIRIM NOTIFIKASI WHATSAPP (Opsional)
            // -------------------------------------------------
            // Bisa integrasikan dengan Fonnte, WaBlas, dll
            
        } else {
            writeLog("ERROR: Failed to update order status", ['order_id' => $referenceId]);
        }
        
        break;
    
    // -------------------------------------------------
    // ❌ PEMBAYARAN GAGAL
    // -------------------------------------------------
    case 'payment.failed':
        
        updateOrderStatus($referenceId, 'failed', [
            'failed_at' => date('Y-m-d H:i:s'),
            'failure_reason' => $data['failure_reason'] ?? 'Unknown'
        ]);
        
        writeLog("Payment FAILED", ['order_id' => $referenceId]);
        break;
    
    // -------------------------------------------------
    // ⏰ PEMBAYARAN EXPIRED
    // -------------------------------------------------
    case 'payment.expired':
        
        updateOrderStatus($referenceId, 'expired', [
            'expired_at' => date('Y-m-d H:i:s')
        ]);
        
        writeLog("Payment EXPIRED", ['order_id' => $referenceId]);
        break;
    
    // -------------------------------------------------
    // ❓ EVENT TIDAK DIKENAL
    // -------------------------------------------------
    default:
        writeLog("Unknown event received: {$event}");
        break;
}

// =====================================================
// ✅ RESPONSE KE NEO PGA
// =====================================================
// PENTING: Selalu response 200 OK supaya NEO PGA tahu webhook berhasil diterima
// Jika response bukan 200, NEO PGA akan retry kirim webhook

http_response_code(200);
echo json_encode([
    'status' => 'ok',
    'message' => 'Webhook processed successfully',
    'timestamp' => date('c')
]);

<?php
/**
 * NEO PGA Merchant Dashboard - Modern Layout Header
 */
ob_start();
error_reporting(E_ALL);
ini_set('display_errors', 0);

try {
    if (!defined('APP_NAME')) {
        require_once __DIR__ . '/../includes/init.php';
    }

    if (!isset($_SESSION['merchant_user']['id'])) {
        header('Location: login.php');
        exit;
    }

    $db = Database::getInstance();
    $merchantId = (int)$_SESSION['merchant_user']['id'];
    $merchant = $db->fetch("SELECT * FROM merchants WHERE id = ?", [$merchantId]);

    if (!$merchant) {
        unset($_SESSION['merchant_user']);
        header('Location: login.php');
        exit;
    }

    $merchantStatus = $merchant['status'] ?? 'pending';
    $flashMessage = $_SESSION['flash_message'] ?? null;
    $flashType = $_SESSION['flash_type'] ?? 'info';
    unset($_SESSION['flash_message'], $_SESSION['flash_type']);

    $pageTitle = $pageTitle ?? 'Dashboard';
    $currentPage = $currentPage ?? 'dashboard';

} catch (Exception $e) {
    error_log("Merchant Layout Error: " . $e->getMessage());
    header('Location: login.php?error=session');
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
    <title><?= htmlspecialchars($pageTitle) ?> - <?= APP_NAME ?></title>
    <link rel="icon" type="image/svg+xml" href="<?= ASSETS_URL ?>/images/favicon.svg">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-50: #ecfdf5;
            --primary-100: #d1fae5;
            --primary-200: #a7f3d0;
            --primary-300: #6ee7b7;
            --primary-400: #34d399;
            --primary-500: #10b981;
            --primary-600: #059669;
            --primary-700: #047857;
            --primary-800: #065f46;
            --primary-900: #064e3b;

            --gray-50: #f9fafb;
            --gray-100: #f3f4f6;
            --gray-200: #e5e7eb;
            --gray-300: #d1d5db;
            --gray-400: #9ca3af;
            --gray-500: #6b7280;
            --gray-600: #4b5563;
            --gray-700: #374151;
            --gray-800: #1f2937;
            --gray-900: #111827;
            --gray-950: #030712;

            --success: #22c55e;
            --success-light: #dcfce7;
            --warning: #f59e0b;
            --warning-light: #fef3c7;
            --danger: #ef4444;
            --danger-light: #fee2e2;
            --info: #3b82f6;
            --info-light: #dbeafe;

            --sidebar-width: 280px;
            --header-height: 64px;
            --safe-top: env(safe-area-inset-top, 0px);
            --safe-bottom: env(safe-area-inset-bottom, 0px);

            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
            --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }
        html { scroll-behavior: smooth; }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            background: var(--gray-50);
            color: var(--gray-900);
            min-height: 100vh;
            -webkit-font-smoothing: antialiased;
        }

        a { text-decoration: none; color: inherit; }
        button { font-family: inherit; }

        /* ===== SIDEBAR (Desktop) ===== */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: var(--sidebar-width);
            height: 100vh;
            background: var(--gray-950);
            z-index: 100;
            display: none;
            flex-direction: column;
            overflow-y: auto;
        }

        .sidebar-header {
            padding: 24px;
            border-bottom: 1px solid rgba(255,255,255,0.08);
        }

        .sidebar-logo {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .sidebar-logo-icon {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, var(--primary-500), var(--primary-600));
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .sidebar-logo-icon svg {
            width: 22px;
            height: 22px;
            fill: #fff;
        }

        .sidebar-logo-text {
            font-size: 1.25rem;
            font-weight: 800;
            color: #fff;
            letter-spacing: -0.02em;
        }

        .sidebar-logo-text span {
            color: var(--primary-400);
        }

        .sidebar-nav {
            flex: 1;
            padding: 16px 12px;
        }

        .nav-section {
            margin-bottom: 24px;
        }

        .nav-section-title {
            font-size: 0.6875rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            color: var(--gray-500);
            padding: 8px 12px;
        }

        .nav-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 16px;
            color: var(--gray-400);
            font-size: 0.9375rem;
            font-weight: 500;
            border-radius: 10px;
            margin-bottom: 4px;
            transition: all 0.2s;
        }

        .nav-item:hover {
            background: rgba(255,255,255,0.05);
            color: #fff;
        }

        .nav-item.active {
            background: rgba(16, 185, 129, 0.15);
            color: var(--primary-400);
        }

        .nav-item svg {
            width: 20px;
            height: 20px;
            flex-shrink: 0;
        }

        .sidebar-footer {
            padding: 16px;
            border-top: 1px solid rgba(255,255,255,0.08);
        }

        .user-card {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px;
            background: rgba(255,255,255,0.05);
            border-radius: 12px;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, var(--primary-500), var(--primary-600));
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 1rem;
            color: #fff;
        }

        .user-info {
            flex: 1;
            min-width: 0;
        }

        .user-name {
            font-weight: 600;
            font-size: 0.875rem;
            color: #fff;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .user-code {
            font-size: 0.75rem;
            color: var(--gray-500);
            font-family: 'JetBrains Mono', monospace;
        }

        .logout-btn {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            width: 100%;
            padding: 12px;
            margin-top: 12px;
            background: rgba(239, 68, 68, 0.1);
            color: #fca5a5;
            border: none;
            border-radius: 10px;
            font-size: 0.875rem;
            font-weight: 500;
            cursor: pointer;
            transition: background 0.2s;
        }

        .logout-btn:hover {
            background: rgba(239, 68, 68, 0.2);
        }

        .logout-btn svg {
            width: 18px;
            height: 18px;
        }

        /* ===== MOBILE HEADER ===== */
        .mobile-header {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            height: var(--header-height);
            background: var(--gray-950);
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 16px;
            z-index: 1000;
            padding-top: var(--safe-top);
        }

        .mobile-logo {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .mobile-logo-icon {
            width: 36px;
            height: 36px;
            background: linear-gradient(135deg, var(--primary-500), var(--primary-600));
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .mobile-logo-icon svg {
            width: 20px;
            height: 20px;
            fill: #fff;
        }

        .mobile-logo-text {
            font-size: 1.125rem;
            font-weight: 800;
            color: #fff;
        }

        .mobile-logo-text span {
            color: var(--primary-400);
        }

        .header-actions {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .header-status {
            font-size: 0.6875rem;
            font-weight: 600;
            padding: 6px 12px;
            border-radius: 100px;
        }

        .status-active { background: var(--success-light); color: #166534; }
        .status-pending { background: var(--warning-light); color: #92400e; }
        .status-suspended { background: var(--danger-light); color: #991b1b; }

        .menu-toggle {
            width: 40px;
            height: 40px;
            background: rgba(255,255,255,0.1);
            border: none;
            border-radius: 10px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 5px;
            cursor: pointer;
        }

        .menu-toggle span {
            width: 20px;
            height: 2px;
            background: #fff;
            border-radius: 2px;
            transition: 0.3s;
        }

        .menu-toggle.active span:nth-child(1) {
            transform: rotate(45deg) translate(5px, 5px);
        }

        .menu-toggle.active span:nth-child(2) {
            opacity: 0;
        }

        .menu-toggle.active span:nth-child(3) {
            transform: rotate(-45deg) translate(5px, -5px);
        }

        /* ===== MOBILE MENU OVERLAY ===== */
        .mobile-menu-overlay {
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.5);
            z-index: 998;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s;
        }

        .mobile-menu-overlay.active {
            opacity: 1;
            visibility: visible;
        }

        /* ===== MOBILE SLIDE MENU ===== */
        .mobile-menu {
            position: fixed;
            top: var(--header-height);
            left: 0;
            bottom: 0;
            width: 300px;
            max-width: 85%;
            background: var(--gray-950);
            z-index: 999;
            transform: translateX(-100%);
            transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            overflow-y: auto;
            padding-bottom: calc(80px + var(--safe-bottom));
        }

        .mobile-menu.active {
            transform: translateX(0);
        }

        /* ===== BOTTOM NAV (Mobile) ===== */
        .bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            height: calc(64px + var(--safe-bottom));
            padding-bottom: var(--safe-bottom);
            background: #fff;
            border-top: 1px solid var(--gray-200);
            display: flex;
            justify-content: space-around;
            align-items: center;
            z-index: 100;
        }

        .bottom-nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 4px;
            padding: 8px 16px;
            color: var(--gray-400);
            font-size: 0.6875rem;
            font-weight: 500;
            transition: color 0.2s;
        }

        .bottom-nav-item svg {
            width: 24px;
            height: 24px;
        }

        .bottom-nav-item.active {
            color: var(--primary-600);
        }

        /* ===== MAIN CONTENT ===== */
        .main-content {
            padding-top: var(--header-height);
            padding-bottom: calc(80px + var(--safe-bottom));
            min-height: 100vh;
        }

        .page-header {
            background: #fff;
            padding: 20px 16px;
            border-bottom: 1px solid var(--gray-200);
        }

        .page-title {
            font-size: 1.25rem;
            font-weight: 700;
            color: var(--gray-900);
        }

        .page-subtitle {
            font-size: 0.875rem;
            color: var(--gray-500);
            margin-top: 4px;
        }

        .page-body {
            padding: 16px;
        }

        /* ===== ALERTS ===== */
        .alert {
            padding: 16px;
            border-radius: 12px;
            margin-bottom: 16px;
            font-size: 0.875rem;
            display: flex;
            align-items: flex-start;
            gap: 12px;
        }

        .alert svg {
            width: 20px;
            height: 20px;
            flex-shrink: 0;
            margin-top: 1px;
        }

        .alert-success { background: var(--success-light); color: #166534; }
        .alert-danger { background: var(--danger-light); color: #991b1b; }
        .alert-warning { background: var(--warning-light); color: #92400e; }
        .alert-info { background: var(--info-light); color: #1e40af; }

        /* ===== CARDS ===== */
        .card {
            background: #fff;
            border-radius: 16px;
            border: 1px solid var(--gray-200);
            overflow: hidden;
            margin-bottom: 16px;
        }

        .card-header {
            padding: 16px 20px;
            border-bottom: 1px solid var(--gray-100);
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 16px;
        }

        .card-header h3 {
            font-size: 1rem;
            font-weight: 600;
            color: var(--gray-900);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .card-body {
            padding: 20px;
        }

        /* ===== STATS ===== */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 12px;
            margin-bottom: 16px;
        }

        .stat-card {
            background: #fff;
            border-radius: 16px;
            padding: 20px;
            border: 1px solid var(--gray-200);
        }

        .stat-icon {
            width: 44px;
            height: 44px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 16px;
        }

        .stat-icon svg {
            width: 22px;
            height: 22px;
        }

        .stat-icon.primary {
            background: var(--primary-100);
            color: var(--primary-600);
        }

        .stat-icon.success {
            background: var(--success-light);
            color: var(--success);
        }

        .stat-icon.info {
            background: var(--info-light);
            color: var(--info);
        }

        .stat-icon.warning {
            background: var(--warning-light);
            color: var(--warning);
        }

        .stat-value {
            font-size: 1.5rem;
            font-weight: 800;
            color: var(--gray-900);
            line-height: 1.2;
            letter-spacing: -0.02em;
        }

        .stat-label {
            font-size: 0.8125rem;
            color: var(--gray-500);
            margin-top: 4px;
        }

        /* ===== BADGES ===== */
        .badge {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 4px 10px;
            border-radius: 100px;
            font-size: 0.75rem;
            font-weight: 600;
        }

        .badge-success { background: var(--success-light); color: #166534; }
        .badge-warning { background: var(--warning-light); color: #92400e; }
        .badge-danger { background: var(--danger-light); color: #991b1b; }
        .badge-info { background: var(--info-light); color: #1e40af; }
        .badge-gray { background: var(--gray-100); color: var(--gray-600); }

        /* ===== BUTTONS ===== */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 12px 20px;
            border-radius: 10px;
            font-size: 0.875rem;
            font-weight: 600;
            border: none;
            cursor: pointer;
            transition: all 0.2s;
            min-height: 44px;
        }

        .btn svg {
            width: 18px;
            height: 18px;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary-500), var(--primary-600));
            color: #fff;
            box-shadow: 0 2px 8px rgba(16, 185, 129, 0.25);
        }

        .btn-primary:hover {
            box-shadow: 0 4px 12px rgba(16, 185, 129, 0.35);
            transform: translateY(-1px);
        }

        .btn-secondary {
            background: var(--gray-100);
            color: var(--gray-700);
        }

        .btn-secondary:hover {
            background: var(--gray-200);
        }

        .btn-danger {
            background: var(--danger);
            color: #fff;
        }

        .btn-success {
            background: var(--success);
            color: #fff;
        }

        .btn-outline {
            background: transparent;
            border: 1px solid var(--gray-300);
            color: var(--gray-700);
        }

        .btn-outline:hover {
            background: var(--gray-50);
            border-color: var(--gray-400);
        }

        .btn-sm {
            padding: 8px 14px;
            font-size: 0.8125rem;
            min-height: 36px;
        }

        .btn-block { width: 100%; }

        /* ===== FORMS ===== */
        .form-group { margin-bottom: 16px; }

        .form-label {
            display: block;
            font-size: 0.875rem;
            font-weight: 600;
            color: var(--gray-700);
            margin-bottom: 8px;
        }

        .form-input, .form-select, textarea.form-input {
            width: 100%;
            padding: 12px 16px;
            border: 1px solid var(--gray-300);
            border-radius: 10px;
            font-size: 1rem;
            font-family: inherit;
            background: #fff;
            transition: border-color 0.2s, box-shadow 0.2s;
            -webkit-appearance: none;
        }

        .form-input:focus, .form-select:focus {
            outline: none;
            border-color: var(--primary-500);
            box-shadow: 0 0 0 3px var(--primary-100);
        }

        .form-helper {
            font-size: 0.8125rem;
            color: var(--gray-500);
            margin-top: 6px;
        }

        /* ===== TABLES ===== */
        .table-wrapper {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
            min-width: 600px;
        }

        .table th {
            padding: 12px 16px;
            text-align: left;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: var(--gray-500);
            background: var(--gray-50);
            border-bottom: 1px solid var(--gray-200);
            white-space: nowrap;
        }

        .table td {
            padding: 14px 16px;
            border-bottom: 1px solid var(--gray-100);
            font-size: 0.875rem;
            color: var(--gray-700);
        }

        .table tbody tr:hover {
            background: var(--gray-50);
        }

        .table code {
            font-family: 'JetBrains Mono', monospace;
            font-size: 0.8125rem;
            background: var(--gray-100);
            padding: 4px 8px;
            border-radius: 6px;
        }

        /* ===== EMPTY STATE ===== */
        .empty-state {
            text-align: center;
            padding: 48px 24px;
            color: var(--gray-400);
        }

        .empty-state svg {
            width: 64px;
            height: 64px;
            margin-bottom: 16px;
            opacity: 0.5;
        }

        .empty-state p {
            font-size: 0.9375rem;
            margin-bottom: 24px;
        }

        /* ===== UTILITIES ===== */
        .text-center { text-align: center; }
        .text-right { text-align: right; }
        .font-mono { font-family: 'JetBrains Mono', monospace; }
        .mb-3 { margin-bottom: 12px; }
        .mb-4 { margin-bottom: 16px; }
        .mb-6 { margin-bottom: 24px; }
        .mt-4 { margin-top: 16px; }
        .flex { display: flex; }
        .flex-wrap { flex-wrap: wrap; }
        .gap-2 { gap: 8px; }
        .gap-3 { gap: 12px; }
        .gap-4 { gap: 16px; }
        .items-center { align-items: center; }
        .justify-between { justify-content: space-between; }

        /* ===== DESKTOP STYLES ===== */
        @media (min-width: 1024px) {
            body {
                padding-bottom: 0;
            }

            .sidebar {
                display: flex;
            }

            .mobile-header {
                display: none;
            }

            .mobile-menu-overlay,
            .mobile-menu {
                display: none;
            }

            .bottom-nav {
                display: none;
            }

            .main-content {
                margin-left: var(--sidebar-width);
                padding-top: 0;
                padding-bottom: 0;
            }

            .page-header {
                padding: 28px 32px;
            }

            .page-title {
                font-size: 1.5rem;
            }

            .page-body {
                padding: 24px 32px;
            }

            .stats-grid {
                grid-template-columns: repeat(4, 1fr);
                gap: 20px;
            }

            .stat-card {
                padding: 24px;
            }

            .stat-value {
                font-size: 1.75rem;
            }
        }

        @media (min-width: 1280px) {
            :root {
                --sidebar-width: 300px;
            }
        }
    </style>
</head>
<body>
    <!-- Desktop Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <a href="index.php" class="sidebar-logo">
                <div class="sidebar-logo-icon">
                    <svg viewBox="0 0 24 24" fill="none">
                        <path d="M4 20 C4 20, 7 15, 10 10 C11 8, 11.5 6, 12 4" stroke="#14B8A6" stroke-width="2.5" stroke-linecap="round"/>
                        <path d="M20 20 C20 20, 17 15, 14 10 C13 8, 12.5 6, 12 4" stroke="#0D9488" stroke-width="2.5" stroke-linecap="round"/>
                        <circle cx="12" cy="4" r="2.5" fill="#F59E0B"/>
                        <line x1="12" y1="7" x2="12" y2="18" stroke="#0D9488" stroke-width="2" stroke-linecap="round"/>
                    </svg>
                </div>
                <span class="sidebar-logo-text">NEO <span>PGA</span></span>
            </a>
        </div>

        <nav class="sidebar-nav">
            <div class="nav-section">
                <div class="nav-section-title">Menu Utama</div>
                <a href="index.php" class="nav-item <?= $currentPage === 'dashboard' ? 'active' : '' ?>">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"/></svg>
                    Dashboard
                </a>
            </div>

            <?php if ($merchantStatus === 'active'): ?>
            <div class="nav-section">
                <div class="nav-section-title">Transaksi</div>
                <a href="create-payment.php" class="nav-item <?= $currentPage === 'create-payment' ? 'active' : '' ?>">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"/></svg>
                    Buat Pembayaran
                </a>
                <a href="payment-link.php" class="nav-item <?= $currentPage === 'payment-link' ? 'active' : '' ?>">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"/></svg>
                    Payment Link
                </a>
                <a href="transactions.php" class="nav-item <?= $currentPage === 'transactions' ? 'active' : '' ?>">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>
                    Riwayat
                </a>
                <a href="settlements.php" class="nav-item <?= $currentPage === 'settlements' ? 'active' : '' ?>">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
                    Penarikan
                </a>
            </div>

            <div class="nav-section">
                <div class="nav-section-title">Integrasi</div>
                <a href="integration-center.php" class="nav-item <?= $currentPage === 'integration-center' ? 'active' : '' ?>">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
                    Integration Center
                </a>
                <a href="api-keys.php" class="nav-item <?= $currentPage === 'api-keys' ? 'active' : '' ?>">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z"/></svg>
                    API Keys
                </a>
                <a href="dokumentasi.php" class="nav-item <?= $currentPage === 'api-docs' ? 'active' : '' ?>">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/></svg>
                    Dokumentasi
                </a>
            </div>

            <div class="nav-section">
                <div class="nav-section-title">Pengaturan</div>
                <a href="settings.php" class="nav-item <?= $currentPage === 'settings' ? 'active' : '' ?>">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                    Pengaturan
                </a>
            </div>
            <?php endif; ?>
        </nav>

        <div class="sidebar-footer">
            <div class="user-card">
                <div class="user-avatar"><?= strtoupper(substr($merchant['business_name'] ?? 'M', 0, 1)) ?></div>
                <div class="user-info">
                    <div class="user-name"><?= htmlspecialchars($merchant['business_name'] ?? 'Merchant') ?></div>
                    <div class="user-code"><?= htmlspecialchars($merchant['merchant_code'] ?? '-') ?></div>
                </div>
            </div>
            <a href="logout.php" class="logout-btn">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/></svg>
                Logout
            </a>
        </div>
    </aside>

    <!-- Mobile Header -->
    <header class="mobile-header">
        <a href="index.php" class="mobile-logo">
            <div class="mobile-logo-icon">
                <svg viewBox="0 0 24 24" fill="none">
                    <path d="M4 20 C4 20, 7 15, 10 10 C11 8, 11.5 6, 12 4" stroke="#14B8A6" stroke-width="2.5" stroke-linecap="round"/>
                    <path d="M20 20 C20 20, 17 15, 14 10 C13 8, 12.5 6, 12 4" stroke="#0D9488" stroke-width="2.5" stroke-linecap="round"/>
                    <circle cx="12" cy="4" r="2.5" fill="#F59E0B"/>
                    <line x1="12" y1="7" x2="12" y2="18" stroke="#0D9488" stroke-width="2" stroke-linecap="round"/>
                </svg>
            </div>
            <span class="mobile-logo-text">NEO <span>PGA</span></span>
        </a>
        <div class="header-actions">
            <span class="header-status status-<?= $merchantStatus ?>">
                <?= $merchantStatus === 'active' ? 'Active' : ($merchantStatus === 'pending' ? 'Pending' : ucfirst($merchantStatus)) ?>
            </span>
            <button class="menu-toggle" onclick="toggleMenu()" aria-label="Menu">
                <span></span><span></span><span></span>
            </button>
        </div>
    </header>

    <!-- Mobile Menu Overlay -->
    <div class="mobile-menu-overlay" id="menuOverlay" onclick="toggleMenu()"></div>

    <!-- Mobile Slide Menu -->
    <aside class="mobile-menu" id="mobileMenu">
        <nav class="sidebar-nav">
            <div class="nav-section">
                <div class="nav-section-title">Menu Utama</div>
                <a href="index.php" class="nav-item <?= $currentPage === 'dashboard' ? 'active' : '' ?>">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"/></svg>
                    Dashboard
                </a>
            </div>

            <?php if ($merchantStatus === 'active'): ?>
            <div class="nav-section">
                <div class="nav-section-title">Transaksi</div>
                <a href="create-payment.php" class="nav-item <?= $currentPage === 'create-payment' ? 'active' : '' ?>">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"/></svg>
                    Buat Pembayaran
                </a>
                <a href="payment-link.php" class="nav-item <?= $currentPage === 'payment-link' ? 'active' : '' ?>">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"/></svg>
                    Payment Link
                </a>
                <a href="transactions.php" class="nav-item <?= $currentPage === 'transactions' ? 'active' : '' ?>">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>
                    Riwayat
                </a>
                <a href="settlements.php" class="nav-item <?= $currentPage === 'settlements' ? 'active' : '' ?>">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
                    Penarikan
                </a>
            </div>

            <div class="nav-section">
                <div class="nav-section-title">Integrasi</div>
                <a href="integration-center.php" class="nav-item <?= $currentPage === 'integration-center' ? 'active' : '' ?>">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
                    Integration Center
                </a>
                <a href="api-keys.php" class="nav-item <?= $currentPage === 'api-keys' ? 'active' : '' ?>">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z"/></svg>
                    API Keys
                </a>
                <a href="dokumentasi.php" class="nav-item <?= $currentPage === 'api-docs' ? 'active' : '' ?>">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/></svg>
                    Dokumentasi
                </a>
            </div>

            <div class="nav-section">
                <div class="nav-section-title">Pengaturan</div>
                <a href="settings.php" class="nav-item <?= $currentPage === 'settings' ? 'active' : '' ?>">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                    Pengaturan
                </a>
            </div>
            <?php endif; ?>
        </nav>

        <div class="sidebar-footer">
            <div class="user-card">
                <div class="user-avatar"><?= strtoupper(substr($merchant['business_name'] ?? 'M', 0, 1)) ?></div>
                <div class="user-info">
                    <div class="user-name"><?= htmlspecialchars($merchant['business_name'] ?? 'Merchant') ?></div>
                    <div class="user-code"><?= htmlspecialchars($merchant['merchant_code'] ?? '-') ?></div>
                </div>
            </div>
            <a href="logout.php" class="logout-btn">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/></svg>
                Logout
            </a>
        </div>
    </aside>

    <!-- Bottom Navigation (Mobile) -->
    <nav class="bottom-nav">
        <a href="index.php" class="bottom-nav-item <?= $currentPage === 'dashboard' ? 'active' : '' ?>">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/></svg>
            <span>Home</span>
        </a>
        <?php if ($merchantStatus === 'active'): ?>
        <a href="create-payment.php" class="bottom-nav-item <?= $currentPage === 'create-payment' ? 'active' : '' ?>">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"/></svg>
            <span>Bayar</span>
        </a>
        <a href="transactions.php" class="bottom-nav-item <?= $currentPage === 'transactions' ? 'active' : '' ?>">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>
            <span>Transaksi</span>
        </a>
        <a href="settlements.php" class="bottom-nav-item <?= $currentPage === 'settlements' ? 'active' : '' ?>">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
            <span>Tarik</span>
        </a>
        <?php endif; ?>
        <a href="settings.php" class="bottom-nav-item <?= $currentPage === 'settings' ? 'active' : '' ?>">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
            <span>Setting</span>
        </a>
    </nav>

    <!-- Main Content -->
    <main class="main-content">
        <div class="page-header">
            <h1 class="page-title"><?= htmlspecialchars($pageTitle) ?></h1>
        </div>

        <div class="page-body">
            <?php if ($flashMessage): ?>
            <div class="alert alert-<?= $flashType === 'error' ? 'danger' : $flashType ?>">
                <?php if ($flashType === 'success'): ?>
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                <?php elseif ($flashType === 'error' || $flashType === 'danger'): ?>
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                <?php elseif ($flashType === 'warning'): ?>
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
                <?php else: ?>
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                <?php endif; ?>
                <span><?= $flashMessage ?></span>
            </div>
            <?php endif; ?>

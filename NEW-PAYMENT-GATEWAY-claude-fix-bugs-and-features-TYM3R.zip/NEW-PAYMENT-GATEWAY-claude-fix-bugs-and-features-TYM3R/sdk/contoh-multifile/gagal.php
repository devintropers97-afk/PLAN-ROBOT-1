<?php
/**
 * ================================================================================
 *                    NEO PGA - HALAMAN PEMBAYARAN GAGAL/EXPIRED
 * ================================================================================
 *
 * Halaman ini ditampilkan jika pembayaran gagal atau expired.
 *
 * TIDAK PERLU EDIT FILE INI - Cukup edit config.php saja!
 *
 * ================================================================================
 */

require_once __DIR__ . '/config.php';

$orderId = $_GET['order'] ?? '';
$reason = $_GET['reason'] ?? 'expired';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pembayaran Gagal - <?= htmlspecialchars(NAMA_TOKO) ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #fef2f2 0%, #fee2e2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .container {
            background: white;
            border-radius: 24px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.1);
            max-width: 480px;
            width: 100%;
            overflow: hidden;
        }
        .header {
            background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
            color: white;
            padding: 40px 30px;
            text-align: center;
        }
        .header .icon {
            width: 80px;
            height: 80px;
            background: rgba(255,255,255,0.2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            font-size: 40px;
        }
        .header h1 {
            font-size: 28px;
            margin-bottom: 8px;
        }
        .header p {
            opacity: 0.9;
            font-size: 16px;
        }
        .content {
            padding: 30px;
            text-align: center;
        }
        .message {
            background: #fef2f2;
            border: 1px solid #fecaca;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 24px;
        }
        .message p {
            color: #991b1b;
            font-size: 15px;
            line-height: 1.6;
        }
        .help-text {
            color: #6b7280;
            font-size: 14px;
            margin-bottom: 24px;
            line-height: 1.6;
        }
        .actions {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }
        .btn {
            padding: 16px 24px;
            border-radius: 12px;
            text-decoration: none;
            text-align: center;
            font-weight: 600;
            font-size: 15px;
            transition: all 0.2s;
            display: block;
        }
        .btn-primary {
            background: linear-gradient(135deg, #0d9488 0%, #0f766e 100%);
            color: white;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(13, 148, 136, 0.4);
        }
        .btn-wa {
            background: #25d366;
            color: white;
        }
        .btn-wa:hover {
            background: #1da851;
        }
        .btn-secondary {
            background: #f3f4f6;
            color: #374151;
        }
        .btn-secondary:hover {
            background: #e5e7eb;
        }
        .footer {
            text-align: center;
            padding: 20px 30px 30px;
            color: #9ca3af;
            font-size: 13px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="icon"><?= $reason === 'expired' ? '⏰' : '✕' ?></div>
            <h1><?= $reason === 'expired' ? 'Pembayaran Expired' : 'Pembayaran Gagal' ?></h1>
            <p><?= $reason === 'expired' ? 'Waktu pembayaran telah habis' : 'Terjadi kesalahan saat memproses pembayaran' ?></p>
        </div>

        <div class="content">
            <div class="message">
                <?php if ($reason === 'expired'): ?>
                <p>
                    Maaf, waktu pembayaran Anda telah habis.<br>
                    Silakan buat pesanan baru untuk melanjutkan.
                </p>
                <?php else: ?>
                <p>
                    Maaf, pembayaran Anda tidak dapat diproses.<br>
                    Silakan coba lagi atau hubungi kami.
                </p>
                <?php endif; ?>
            </div>

            <p class="help-text">
                Jika Anda mengalami kesulitan atau sudah melakukan pembayaran,<br>
                silakan hubungi customer service kami.
            </p>

            <div class="actions">
                <a href="javascript:history.back()" class="btn btn-primary">
                    🔄 Coba Lagi
                </a>

                <?php if (defined('WA_TOKO') && WA_TOKO): ?>
                <a href="https://wa.me/<?= WA_TOKO ?>?text=Halo, saya mengalami masalah dengan pembayaran. Order ID: <?= urlencode($orderId) ?>" class="btn btn-wa" target="_blank">
                    💬 Hubungi via WhatsApp
                </a>
                <?php endif; ?>

                <a href="<?= get_homepage_url() ?>" class="btn btn-secondary">
                    🏠 Kembali ke Beranda
                </a>
            </div>
        </div>

        <div class="footer">
            <?= htmlspecialchars(NAMA_TOKO) ?><br>
            <?= get_homepage_url() ?>
        </div>
    </div>
</body>
</html>

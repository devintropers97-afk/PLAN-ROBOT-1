<?php
/**
 * NEO PGA Database Setup
 * Run this script to initialize database tables
 * DELETE THIS FILE AFTER SUCCESSFUL SETUP!
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>NEO PGA Database Setup</h1>";
echo "<pre>";

// Database credentials - BACA DARI CONFIG JIKA ADA, ATAU GUNAKAN PLACEHOLDER
// PENTING: Gunakan install.php untuk instalasi otomatis, atau edit kredensial ini!
if (file_exists(__DIR__ . '/config/config.php')) {
    require_once __DIR__ . '/config/config.php';
    $dbHost = defined('DB_HOST') ? DB_HOST : 'localhost';
    $dbName = defined('DB_NAME') ? DB_NAME : 'your_database_name';
    $dbUser = defined('DB_USER') ? DB_USER : 'your_database_user';
    $dbPass = defined('DB_PASS') ? DB_PASS : 'your_database_password';
    echo "✓ Config file loaded\n";
} else {
    // Placeholder - GANTI DENGAN KREDENSIAL ANDA SEBELUM MENJALANKAN!
    $dbHost = 'localhost';
    $dbName = 'your_database_name';  // GANTI INI!
    $dbUser = 'your_database_user';  // GANTI INI!
    $dbPass = 'your_database_password';  // GANTI INI!

    // Check if placeholders are still default
    if ($dbName === 'your_database_name' || $dbUser === 'your_database_user') {
        echo "⚠️ ERROR: Database credentials not configured!\n\n";
        echo "Option 1: Run install.php for guided installation\n";
        echo "Option 2: Edit setup-db.php and set your database credentials\n";
        echo "Option 3: Create config/config.php first\n";
        echo "</pre>";
        exit;
    }
}

try {
    echo "Connecting to database...\n";
    
    $pdo = new PDO("mysql:host=$dbHost;dbname=$dbName;charset=utf8mb4", $dbUser, $dbPass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
    ]);
    
    echo "✓ Connected to database: $dbName\n\n";
    
    // Read SQL file
    $sqlFile = __DIR__ . '/DATABASE.sql';
    if (!file_exists($sqlFile)) {
        throw new Exception("DATABASE.sql not found!");
    }
    
    $sql = file_get_contents($sqlFile);
    echo "✓ SQL file loaded (" . strlen($sql) . " bytes)\n\n";
    
    // Remove comments
    $sql = preg_replace('/--.*$/m', '', $sql);
    $sql = preg_replace('/\/\*.*?\*\//s', '', $sql);
    
    // Split by semicolon
    $statements = array_filter(array_map('trim', explode(';', $sql)));
    
    $executed = 0;
    $skipped = 0;
    $errors = 0;
    
    // IMPORTANT: Disable foreign key checks first!
    echo "Disabling foreign key checks...\n";
    $pdo->exec("SET FOREIGN_KEY_CHECKS = 0");
    echo "✓ Foreign key checks disabled\n\n";
    
    echo "Executing SQL statements...\n";
    
    foreach ($statements as $i => $statement) {
        $statement = trim($statement);
        
        // Skip empty or certain SET statements (but not FOREIGN_KEY_CHECKS)
        if (empty($statement) || 
            stripos($statement, 'SET SQL_MODE') === 0 ||
            stripos($statement, 'SET time_zone') === 0 ||
            stripos($statement, '/*!') === 0) {
            $skipped++;
            continue;
        }
        
        try {
            $pdo->exec($statement);
            $executed++;
            
            // Show progress for important statements
            if (stripos($statement, 'CREATE TABLE') !== false) {
                preg_match('/CREATE TABLE[^`]*`([^`]+)`/', $statement, $matches);
                $tableName = $matches[1] ?? 'unknown';
                echo "  ✓ Created table: $tableName\n";
            } elseif (stripos($statement, 'DROP TABLE') !== false) {
                preg_match('/DROP TABLE[^`]*`([^`]+)`/', $statement, $matches);
                $tableName = $matches[1] ?? 'unknown';
                echo "  ✓ Dropped table: $tableName\n";
            } elseif (stripos($statement, 'INSERT INTO') !== false) {
                preg_match('/INSERT INTO[^`]*`([^`]+)`/', $statement, $matches);
                $tableName = $matches[1] ?? 'unknown';
                echo "  ✓ Inserted data into: $tableName\n";
            }
            
        } catch (PDOException $e) {
            $errors++;
            echo "  ✗ Error: " . substr($e->getMessage(), 0, 100) . "\n";
        }
    }
    
    // Re-enable foreign key checks
    $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");
    echo "\n✓ Foreign key checks re-enabled\n";
    
    echo "\n";
    echo "========================================\n";
    echo "Executed: $executed statements\n";
    echo "Skipped: $skipped statements\n";
    echo "Errors: $errors\n";
    echo "========================================\n\n";
    
    if ($errors == 0) {
        echo "✓ DATABASE SETUP COMPLETED SUCCESSFULLY!\n\n";
        echo "Default Login Credentials:\n";
        echo "─────────────────────────────\n";
        echo "Admin Panel: [YOUR_URL]/admin\n";
        echo "Username: admin\n";
        echo "Password: admin123\n\n";
        echo "Merchant Panel: [YOUR_URL]/merchant\n";
        echo "Email: demo@neopga.com\n";
        echo "Password: demo123\n";
        echo "─────────────────────────────\n\n";
        echo "⚠️  IMPORTANT: DELETE THIS FILE (setup-db.php) NOW!\n";
        echo "⚠️  CHANGE DEFAULT PASSWORDS IMMEDIATELY!\n";
    } else {
        echo "⚠️  Setup completed with $errors errors.\n";
        echo "Some tables may need manual verification.\n";
    }
    
} catch (Exception $e) {
    echo "✗ FATAL ERROR: " . $e->getMessage() . "\n";
}

echo "</pre>";
?>

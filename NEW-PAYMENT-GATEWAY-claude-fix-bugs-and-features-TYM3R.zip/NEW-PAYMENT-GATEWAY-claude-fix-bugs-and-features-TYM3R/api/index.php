<?php
/**
 * API Index - Redirect to documentation
 */
header('Location: ../docs/');
exit;

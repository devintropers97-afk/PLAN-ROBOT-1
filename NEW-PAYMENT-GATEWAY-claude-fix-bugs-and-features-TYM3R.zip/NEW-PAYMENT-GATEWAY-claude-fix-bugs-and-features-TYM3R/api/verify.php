<?php
/**
 * NEO PGA API - Verify/Confirm Payment (Manual Callback)
 *
 * POST /api/verify.php
 *
 * Used by admin panel or mutasi checker to confirm payment
 *
 * HOW TO GENERATE internal_key:
 * =============================
 * PHP Example:
 * $secretBase = 'YOUR_ENCRYPTION_KEY_FROM_CONFIG'; // Same as ENCRYPTION_KEY in config.php
 * $internal_key = hash_hmac('sha256', 'neobayar_verify_' . date('Y-m-d'), $secretBase);
 *
 * The key is valid for 48 hours (today + yesterday) to handle timezone edge cases.
 */

header('Content-Type: application/json');

// Config loaded via init.php
require_once __DIR__ . '/../includes/init.php';

$startTime = microtime(true);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

// Get input
$input = json_decode(file_get_contents('php://input'), true) ?? $_POST;

$invoiceNumber = $input['invoice_number'] ?? '';
$amount = (int)($input['amount'] ?? 0);
$verificationCode = $input['verification_code'] ?? '';

// Internal verification for manual callback from mutasi checker
// Uses ENCRYPTION_KEY for security and accepts keys from today AND yesterday
// to handle midnight timezone edge cases
$internalKey = $input['internal_key'] ?? '';

// Generate valid keys - accept today's and yesterday's key for grace period
// PENTING: Pastikan ENCRYPTION_KEY sudah diset di config/config.php!
$secretBase = defined('ENCRYPTION_KEY') ? ENCRYPTION_KEY : 'CHANGE_THIS_DEFAULT_SECRET';
$keyToday = hash_hmac('sha256', 'neobayar_verify_' . date('Y-m-d'), $secretBase);
$keyYesterday = hash_hmac('sha256', 'neobayar_verify_' . date('Y-m-d', strtotime('-1 day')), $secretBase);

// Validate - accept either today's or yesterday's key
if (!hash_equals($keyToday, $internalKey) && !hash_equals($keyYesterday, $internalKey)) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

if (empty($invoiceNumber) && empty($amount)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'invoice_number or amount is required']);
    exit;
}

$db = Database::getInstance();

// Find transaction
$transaction = null;

if ($invoiceNumber) {
    $transaction = $db->fetch("SELECT * FROM transactions WHERE invoice_number = ? AND status IN ('pending', 'waiting')", [$invoiceNumber]);
} elseif ($amount > 0) {
    // Find by exact amount (including unique code)
    $transaction = $db->fetch(
        "SELECT * FROM transactions WHERE total_amount = ? AND status IN ('pending', 'waiting') ORDER BY created_at DESC LIMIT 1",
        [$amount]
    );
}

if (!$transaction) {
    http_response_code(404);
    echo json_encode(['success' => false, 'error' => 'Transaction not found or already processed']);
    exit;
}

// Verify and update transaction with proper transaction wrapping
try {
    // BEGIN TRANSACTION - Critical for preventing race conditions
    $db->beginTransaction();

    // Re-fetch transaction with FOR UPDATE lock to prevent double processing
    $lockedTransaction = $db->fetch(
        "SELECT * FROM transactions WHERE id = ? AND status IN ('pending', 'waiting') FOR UPDATE",
        [$transaction['id']]
    );

    if (!$lockedTransaction) {
        $db->rollback();
        http_response_code(409);
        echo json_encode(['success' => false, 'error' => 'Transaction already processed or locked']);
        exit;
    }

    // Update transaction status
    $db->query(
        "UPDATE transactions SET
            status = 'success',
            paid_at = NOW(),
            verified_at = NOW(),
            verification_notes = ?
        WHERE id = ?",
        ['Auto verified via callback', $lockedTransaction['id']]
    );

    // Get merchant with FOR UPDATE lock to prevent concurrent balance updates
    $merchant = $db->fetch(
        "SELECT * FROM merchants WHERE id = ? FOR UPDATE",
        [$lockedTransaction['merchant_id']]
    );

    if (!$merchant) {
        $db->rollback();
        throw new Exception('Merchant not found');
    }

    // ATOMIC balance update - Use SQL arithmetic to prevent race conditions
    $netAmount = (float) ($lockedTransaction['net_amount'] ?? 0);
    $currentBalance = (float) ($merchant['balance'] ?? 0);
    $newBalance = $currentBalance + $netAmount;

    // Use atomic UPDATE with arithmetic instead of read-modify-write
    $db->query(
        "UPDATE merchants SET balance = balance + ?, updated_at = NOW() WHERE id = ?",
        [$netAmount, $merchant['id']]
    );

    // Log balance
    $db->query(
        "INSERT INTO balance_logs (merchant_id, transaction_id, type, amount, balance_before, balance_after, description, created_at)
         VALUES (?, ?, 'credit', ?, ?, ?, ?, NOW())",
        [
            $merchant['id'],
            $lockedTransaction['id'],
            $netAmount,
            $currentBalance,
            $newBalance,
            "Payment received: {$lockedTransaction['invoice_number']}"
        ]
    );

    // Release payment code (mark as used)
    if ($lockedTransaction['payment_code_id']) {
        $db->query(
            "UPDATE payment_codes SET status = 'used', transaction_id = ?, used_at = NOW() WHERE id = ?",
            [$lockedTransaction['id'], $lockedTransaction['payment_code_id']]
        );
    }

    // COMMIT TRANSACTION
    $db->commit();

    // Send webhook AFTER commit (outside transaction)
    if (WEBHOOK_ENABLED && $merchant['webhook_url']) {
        sendWebhook($lockedTransaction['id'], [
            'event' => 'payment.success',
            'data' => [
                'invoice_number' => $lockedTransaction['invoice_number'],
                'reference_id' => $lockedTransaction['reference_id'],
                'amount' => (int)$lockedTransaction['amount'],
                'total_amount' => (int)$lockedTransaction['total_amount'],
                'status' => 'success',
                'paid_at' => date('c')
            ]
        ]);
    }

    // Log
    logActivity('system', null, 'verify_payment', 'transactions', "Auto verified: {$lockedTransaction['invoice_number']}");
    
    $response = [
        'success' => true,
        'message' => 'Payment verified successfully',
        'data' => [
            'invoice_number' => $lockedTransaction['invoice_number'],
            'reference_id' => $lockedTransaction['reference_id'],
            'amount' => (int)$lockedTransaction['total_amount'],
            'status' => 'success'
        ]
    ];

    logApiRequest(null, '/api/verify', 'POST', $input, 200, $response, $startTime);
    echo json_encode($response);

} catch (Exception $e) {
    // Rollback if transaction is active
    if ($db->getPdo()->inTransaction()) {
        $db->rollback();
    }
    http_response_code(500);
    $error = APP_DEBUG ? $e->getMessage() : 'Internal server error';
    echo json_encode(['success' => false, 'error' => $error]);
}

<?php
/**
 * NEO PGA - Merchant Settings
 * Using Layout Template v2
 */
require_once __DIR__ . '/../includes/init.php';

// Page settings for layout
$pageTitle = 'Pengaturan';
$currentPage = 'settings';

$activeTab = $_GET['tab'] ?? 'profile';

// Handle form submissions before layout
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verify CSRF token
    verifyCsrf();

    $db = Database::getInstance();
    // Fix: Use correct session key
    $merchantId = $_SESSION['merchant_user']['id'] ?? null;
    if (!$merchantId) {
        header('Location: login.php');
        exit;
    }
    $merchant = $db->fetch("SELECT * FROM merchants WHERE id = ?", [$merchantId]);
    $action = sanitize($_POST['action'] ?? '');

    if ($action === 'update_profile') {
        $businessName = sanitize($_POST['business_name']);
        $phone = sanitize($_POST['phone']);
        $address = sanitize($_POST['address'] ?? '');
        $website = sanitize($_POST['website'] ?? '');

        // Check for XSS attempts
        if (detectXSS($_POST['business_name']) || detectXSS($_POST['phone']) ||
            detectXSS($_POST['address'] ?? '') || detectXSS($_POST['website'] ?? '')) {
            $_SESSION['flash_message'] = 'Input tidak valid terdeteksi!';
            $_SESSION['flash_type'] = 'error';
            header('Location: settings.php?tab=profile');
            exit;
        }

        $db->query(
            "UPDATE merchants SET business_name = ?, phone = ?, address = ?, website = ? WHERE id = ?",
            [$businessName, $phone, $address, $website, $merchantId]
        );

        $_SESSION['flash_message'] = 'Profil berhasil diupdate!';
        $_SESSION['flash_type'] = 'success';
        header('Location: settings.php?tab=profile');
        exit;
    }

    if ($action === 'update_bank') {
        $bankName = sanitize($_POST['bank_name']);
        $bankAccountNumber = sanitize($_POST['bank_account_number']);
        $bankAccountName = sanitize($_POST['bank_account_name']);

        // Check for XSS attempts
        if (detectXSS($_POST['bank_name']) || detectXSS($_POST['bank_account_number']) ||
            detectXSS($_POST['bank_account_name'])) {
            $_SESSION['flash_message'] = 'Input tidak valid terdeteksi!';
            $_SESSION['flash_type'] = 'error';
            header('Location: settings.php?tab=bank');
            exit;
        }

        $db->query(
            "UPDATE merchants SET bank_name = ?, bank_account_number = ?, bank_account_name = ? WHERE id = ?",
            [$bankName, $bankAccountNumber, $bankAccountName, $merchantId]
        );

        $_SESSION['flash_message'] = 'Info rekening berhasil diupdate!';
        $_SESSION['flash_type'] = 'success';
        header('Location: settings.php?tab=bank');
        exit;
    }

    if ($action === 'change_password') {
        $currentPassword = $_POST['current_password'];
        $newPassword = $_POST['new_password'];
        $confirmPassword = $_POST['confirm_password'];

        if (!password_verify($currentPassword, $merchant['password'])) {
            $_SESSION['flash_message'] = 'Password saat ini salah';
            $_SESSION['flash_type'] = 'error';
        } elseif (strlen($newPassword) < 6) {
            $_SESSION['flash_message'] = 'Password baru minimal 6 karakter';
            $_SESSION['flash_type'] = 'error';
        } elseif ($newPassword !== $confirmPassword) {
            $_SESSION['flash_message'] = 'Konfirmasi password tidak cocok';
            $_SESSION['flash_type'] = 'error';
        } else {
            $hashedPassword = password_hash($newPassword, PASSWORD_BCRYPT, ['cost' => HASH_COST]);
            $db->query("UPDATE merchants SET password = ? WHERE id = ?", [$hashedPassword, $merchantId]);
            $_SESSION['flash_message'] = 'Password berhasil diubah!';
            $_SESSION['flash_type'] = 'success';
        }
        header('Location: settings.php?tab=security');
        exit;
    }

    if ($action === 'update_webhook') {
        $webhookUrl = sanitize($_POST['webhook_url'] ?? '');
        $callbackUrl = sanitize($_POST['callback_url'] ?? '');

        // Check for XSS attempts
        if (detectXSS($_POST['webhook_url'] ?? '') || detectXSS($_POST['callback_url'] ?? '')) {
            $_SESSION['flash_message'] = 'Input tidak valid terdeteksi!';
            $_SESSION['flash_type'] = 'error';
            header('Location: settings.php?tab=integration');
            exit;
        }

        // Validate URLs if provided
        if ($webhookUrl && !filter_var($webhookUrl, FILTER_VALIDATE_URL)) {
            $_SESSION['flash_message'] = 'Webhook URL tidak valid';
            $_SESSION['flash_type'] = 'error';
        } elseif ($callbackUrl && !filter_var($callbackUrl, FILTER_VALIDATE_URL)) {
            $_SESSION['flash_message'] = 'Callback URL tidak valid';
            $_SESSION['flash_type'] = 'error';
        } else {
            $db->query(
                "UPDATE merchants SET webhook_url = ?, callback_url = ? WHERE id = ?",
                [$webhookUrl ?: null, $callbackUrl ?: null, $merchantId]
            );
            $_SESSION['flash_message'] = 'Pengaturan integrasi berhasil disimpan!';
            $_SESSION['flash_type'] = 'success';
        }
        header('Location: settings.php?tab=integration');
        exit;
    }
}

// Include layout header (handles auth check)
include 'layout_header.php';
?>

<style>
    /* Settings page specific styles */
    .settings-layout {
        display: grid;
        grid-template-columns: 280px 1fr;
        gap: 2rem;
    }

    /* Sidebar Navigation */
    .settings-nav {
        background: white;
        border-radius: 16px;
        border: 1px solid var(--gray-200);
        padding: 0.5rem;
        margin-bottom: 1.5rem;
    }

    .settings-nav-link {
        display: block;
        padding: 0.875rem 1rem;
        border-radius: 10px;
        color: var(--gray-600);
        text-decoration: none;
        font-size: 0.9rem;
        font-weight: 500;
        transition: all 0.2s;
    }

    .settings-nav-link:hover {
        background: var(--gray-50);
        color: var(--gray-800);
    }

    .settings-nav-link.active {
        background: var(--primary-50);
        color: var(--primary);
    }

    /* Profile Card */
    .profile-card {
        background: white;
        border-radius: 16px;
        border: 1px solid var(--gray-200);
        padding: 1.5rem;
        text-align: center;
    }

    .profile-avatar {
        width: 64px;
        height: 64px;
        background: linear-gradient(135deg, var(--primary) 0%, var(--primary-light) 100%);
        border-radius: 16px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.5rem;
        font-weight: 700;
        color: white;
        margin: 0 auto 1rem;
    }

    .profile-name {
        font-size: 1rem;
        font-weight: 600;
        color: var(--gray-900);
        margin-bottom: 0.25rem;
    }

    .profile-code {
        font-size: 0.8rem;
        color: var(--gray-500);
        font-family: var(--font-mono);
        margin-bottom: 0.75rem;
    }

    /* Content Card */
    .content-card {
        background: white;
        border-radius: 16px;
        border: 1px solid var(--gray-200);
        overflow: hidden;
    }

    .content-card-header {
        padding: 1.25rem 1.5rem;
        border-bottom: 1px solid var(--gray-100);
    }

    .content-card-title {
        font-size: 1rem;
        font-weight: 600;
        color: var(--gray-900);
    }

    .content-card-body {
        padding: 1.5rem;
    }

    /* Form Styles */
    .form-group {
        margin-bottom: 1.25rem;
    }

    .form-label {
        display: block;
        font-size: 0.8rem;
        font-weight: 600;
        color: var(--gray-700);
        margin-bottom: 0.5rem;
    }

    .form-input,
    .form-select,
    textarea.form-input {
        width: 100%;
        padding: 0.75rem 1rem;
        border: 1px solid var(--gray-300);
        border-radius: 10px;
        font-size: 0.9rem;
        font-family: inherit;
        transition: all 0.2s;
    }

    .form-input:focus,
    .form-select:focus {
        outline: none;
        border-color: var(--primary);
        box-shadow: 0 0 0 3px rgba(13, 148, 136, 0.1);
    }

    .form-input:read-only {
        background: var(--gray-100);
        color: var(--gray-500);
    }

    .form-input.font-mono {
        font-family: var(--font-mono);
    }

    .form-helper {
        display: block;
        font-size: 0.75rem;
        color: var(--gray-500);
        margin-top: 0.5rem;
    }

    .form-row {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 1rem;
    }

    /* Badges */
    .badge {
        display: inline-flex;
        align-items: center;
        padding: 0.25rem 0.75rem;
        font-size: 0.7rem;
        font-weight: 600;
        border-radius: 6px;
        text-transform: uppercase;
        letter-spacing: 0.02em;
    }

    .badge-success {
        background: var(--success-light);
        color: #065f46;
    }

    .badge-warning {
        background: var(--warning-light);
        color: #92400e;
    }

    /* Buttons */
    .btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 0.5rem;
        padding: 0.75rem 1.5rem;
        border-radius: 10px;
        font-size: 0.9rem;
        font-weight: 500;
        text-decoration: none;
        cursor: pointer;
        border: none;
        transition: all 0.2s;
        font-family: inherit;
    }

    .btn-primary {
        background: var(--primary);
        color: white;
    }

    .btn-primary:hover {
        background: var(--primary-dark);
    }

    /* Info Box */
    .info-box {
        background: var(--info-light);
        border: 1px solid rgba(59, 130, 246, 0.2);
        border-radius: 10px;
        padding: 1rem;
        font-size: 0.85rem;
        color: #1e40af;
        margin-bottom: 1.5rem;
    }

    .info-box strong {
        font-weight: 600;
    }

    /* Security Info List */
    .security-info-list {
        font-size: 0.9rem;
    }

    .security-info-item {
        display: flex;
        justify-content: space-between;
        padding: 0.75rem 0;
        border-bottom: 1px solid var(--gray-100);
    }

    .security-info-item:last-child {
        border-bottom: 0;
    }

    .security-info-label {
        color: var(--gray-500);
    }

    .security-info-value {
        color: var(--gray-800);
        font-weight: 500;
    }

    .security-info-value code {
        font-family: var(--font-mono);
        font-size: 0.8rem;
        background: var(--gray-100);
        padding: 0.2rem 0.5rem;
        border-radius: 4px;
    }

    /* Responsive */
    @media (max-width: 1024px) {
        .settings-layout {
            grid-template-columns: 1fr;
        }
    }
</style>

<div class="settings-layout">
    <!-- Sidebar -->
    <div>
        <nav class="settings-nav">
            <a href="?tab=profile" class="settings-nav-link <?= $activeTab === 'profile' ? 'active' : '' ?>">
                Profil Bisnis
            </a>
            <a href="?tab=bank" class="settings-nav-link <?= $activeTab === 'bank' ? 'active' : '' ?>">
                Rekening Bank
            </a>
            <a href="?tab=integration" class="settings-nav-link <?= $activeTab === 'integration' ? 'active' : '' ?>">
                Integrasi & Notifikasi
            </a>
            <a href="?tab=security" class="settings-nav-link <?= $activeTab === 'security' ? 'active' : '' ?>">
                Keamanan
            </a>
        </nav>

        <!-- Profile Card -->
        <div class="profile-card">
            <div class="profile-avatar">
                <?= strtoupper(substr($merchant['business_name'], 0, 1)) ?>
            </div>
            <div class="profile-name"><?= htmlspecialchars($merchant['business_name']) ?></div>
            <div class="profile-code"><?= $merchant['merchant_code'] ?></div>
            <span class="badge badge-<?= $merchant['status'] === 'active' ? 'success' : 'warning' ?>">
                <?= ucfirst($merchant['status']) ?>
            </span>
        </div>
    </div>

    <!-- Content -->
    <div>
        <?php if ($activeTab === 'profile'): ?>
        <div class="content-card">
            <div class="content-card-header">
                <h3 class="content-card-title">Profil Bisnis</h3>
            </div>
            <form method="POST" class="content-card-body">
                <?= csrfField() ?>
                <input type="hidden" name="action" value="update_profile">

                <div class="form-group">
                    <label class="form-label">Nama Bisnis</label>
                    <input type="text" name="business_name" class="form-input" value="<?= htmlspecialchars($merchant['business_name']) ?>" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Email</label>
                    <input type="email" class="form-input" value="<?= htmlspecialchars($merchant['email']) ?>" readonly>
                    <span class="form-helper">Email tidak dapat diubah</span>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">No. Telepon/WhatsApp</label>
                        <input type="text" name="phone" class="form-input" value="<?= htmlspecialchars($merchant['phone'] ?? '') ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Website</label>
                        <input type="url" name="website" class="form-input" value="<?= htmlspecialchars($merchant['website'] ?? '') ?>" placeholder="https://">
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Alamat</label>
                    <textarea name="address" class="form-input" rows="2"><?= htmlspecialchars($merchant['address'] ?? '') ?></textarea>
                </div>
                
                <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
            </form>
        </div>

        <?php elseif ($activeTab === 'bank'): ?>
        <div class="content-card">
            <div class="content-card-header">
                <h3 class="content-card-title">Rekening Bank untuk Pencairan</h3>
            </div>
            <form method="POST" class="content-card-body">
                <?= csrfField() ?>
                <input type="hidden" name="action" value="update_bank">

                <div class="form-group">
                    <label class="form-label">Nama Bank</label>
                    <select name="bank_name" class="form-select" required>
                        <option value="">Pilih Bank</option>
                        <option value="BCA" <?= ($merchant['bank_name'] ?? '') === 'BCA' ? 'selected' : '' ?>>Bank BCA</option>
                        <option value="BNI" <?= ($merchant['bank_name'] ?? '') === 'BNI' ? 'selected' : '' ?>>Bank BNI</option>
                        <option value="BRI" <?= ($merchant['bank_name'] ?? '') === 'BRI' ? 'selected' : '' ?>>Bank BRI</option>
                        <option value="Mandiri" <?= ($merchant['bank_name'] ?? '') === 'Mandiri' ? 'selected' : '' ?>>Bank Mandiri</option>
                        <option value="CIMB" <?= ($merchant['bank_name'] ?? '') === 'CIMB' ? 'selected' : '' ?>>CIMB Niaga</option>
                        <option value="Permata" <?= ($merchant['bank_name'] ?? '') === 'Permata' ? 'selected' : '' ?>>Bank Permata</option>
                        <option value="Danamon" <?= ($merchant['bank_name'] ?? '') === 'Danamon' ? 'selected' : '' ?>>Bank Danamon</option>
                        <option value="BSI" <?= ($merchant['bank_name'] ?? '') === 'BSI' ? 'selected' : '' ?>>Bank BSI</option>
                        <option value="Jago" <?= ($merchant['bank_name'] ?? '') === 'Jago' ? 'selected' : '' ?>>Bank Jago</option>
                        <option value="Seabank" <?= ($merchant['bank_name'] ?? '') === 'Seabank' ? 'selected' : '' ?>>SeaBank</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Nomor Rekening</label>
                    <input type="text" name="bank_account_number" class="form-input font-mono" value="<?= htmlspecialchars($merchant['bank_account_number'] ?? '') ?>" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Nama Pemilik Rekening</label>
                    <input type="text" name="bank_account_name" class="form-input" value="<?= htmlspecialchars($merchant['bank_account_name'] ?? '') ?>" required>
                    <span class="form-helper">Harus sesuai dengan nama di buku rekening</span>
                </div>
                
                <div class="info-box">
                    <strong>Penting:</strong> Pastikan data rekening benar. Dana settlement akan ditransfer ke rekening ini.
                </div>
                
                <button type="submit" class="btn btn-primary">Simpan Rekening</button>
            </form>
        </div>

        <?php elseif ($activeTab === 'integration'): ?>
        <!-- Secret Key untuk Webhook -->
        <div class="content-card">
            <div class="content-card-header">
                <h3 class="content-card-title">Secret Key (untuk Webhook)</h3>
            </div>
            <div class="content-card-body">
                <div style="background: linear-gradient(135deg, #fef3c7, #fefce8); border: 2px solid #f59e0b; border-radius: 12px; padding: 1.25rem; margin-bottom: 1rem;">
                    <h4 style="color: #92400e; margin: 0 0 0.5rem; display: flex; align-items: center; gap: 8px;">
                        <span style="font-size: 1.25rem;">🔐</span> Secret Key Anda
                    </h4>
                    <p style="color: #a16207; font-size: 0.85rem; margin: 0 0 1rem;">
                        Gunakan Secret Key ini untuk memverifikasi signature webhook dari NEO PGA.
                    </p>

                    <?php if (!empty($merchant['secret_key'])): ?>
                    <div style="position: relative;">
                        <input type="password" id="secretKeyDisplay" value="<?= htmlspecialchars($merchant['secret_key']) ?>" readonly
                               style="width: 100%; padding: 12px 100px 12px 16px; border: 1px solid #d1d5db; border-radius: 10px;
                                      font-family: var(--font-mono); font-size: 0.85rem; background: white;">
                        <div style="position: absolute; right: 8px; top: 50%; transform: translateY(-50%); display: flex; gap: 4px;">
                            <button onclick="toggleSecretKey()" type="button" style="padding: 8px; border: none; background: #f3f4f6; border-radius: 6px; cursor: pointer;" title="Tampilkan/Sembunyikan">
                                <svg id="eyeIconSettings" width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                                </svg>
                            </button>
                            <button onclick="copySecretKey()" type="button" style="padding: 8px; border: none; background: #3b82f6; color: white; border-radius: 6px; cursor: pointer;" title="Copy">
                                <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3"/>
                                </svg>
                            </button>
                        </div>
                    </div>
                    <?php else: ?>
                    <div style="background: #fef2f2; border: 1px solid #fca5a5; border-radius: 10px; padding: 12px;">
                        <strong style="color: #991b1b;">Secret Key belum ada!</strong>
                        <p style="color: #b91c1c; font-size: 0.85rem; margin: 4px 0 0;">
                            Generate Secret Key di halaman <a href="api-keys.php" style="color: #1d4ed8; font-weight: 600;">API Keys</a>
                        </p>
                    </div>
                    <?php endif; ?>
                </div>

                <a href="api-keys.php" class="btn btn-primary" style="display: inline-flex; align-items: center; gap: 8px;">
                    <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z"/>
                    </svg>
                    Kelola API Keys
                </a>
            </div>
        </div>

        <!-- Push Notification Guide -->
        <div class="content-card" style="margin-top: 1.5rem;">
            <div class="content-card-header">
                <h3 class="content-card-title">Notifikasi Real-time (Push Notification)</h3>
            </div>
            <div class="content-card-body">
                <div style="background: linear-gradient(135deg, #dbeafe, #e0f2fe); border: 2px solid #3b82f6; border-radius: 12px; padding: 1.25rem; margin-bottom: 1.5rem;">
                    <h4 style="color: #1e40af; margin: 0 0 0.75rem; display: flex; align-items: center; gap: 8px;">
                        <span style="font-size: 1.25rem;">🔔</span> Cara Aktifkan Notifikasi HP
                    </h4>
                    <ol style="color: #1e3a8a; font-size: 0.9rem; margin: 0; padding-left: 1.25rem; line-height: 1.8;">
                        <li>Buka dashboard merchant di <strong>browser HP</strong> Anda</li>
                        <li>Klik tombol <strong>"Aktifkan Notifikasi HP"</strong> yang muncul di pojok kanan</li>
                        <li>Pilih <strong>"Izinkan"</strong> saat browser meminta permission</li>
                        <li>Selesai! Anda akan menerima notifikasi setiap ada pembayaran sukses</li>
                    </ol>
                </div>

                <div style="background: #f0fdf4; border: 1px solid #86efac; border-radius: 12px; padding: 1.25rem;">
                    <h4 style="color: #166534; margin: 0 0 0.5rem;">Tips Agar Notifikasi Selalu Aktif:</h4>
                    <ul style="color: #166534; font-size: 0.85rem; margin: 0; padding-left: 1.25rem; line-height: 1.7;">
                        <li>Biarkan tab dashboard <strong>tetap terbuka</strong> di browser</li>
                        <li>Pastikan browser tidak di-close atau di-minimize terlalu lama</li>
                        <li>Untuk HP: Tambahkan ke Home Screen agar seperti aplikasi</li>
                        <li>Pastikan <strong>Do Not Disturb</strong> dimatikan di HP</li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Webhook & Callback Settings -->
        <div class="content-card" style="margin-top: 1.5rem;">
            <div class="content-card-header">
                <h3 class="content-card-title">Webhook & Callback URL (Opsional)</h3>
            </div>
            <form method="POST" class="content-card-body">
                <?= csrfField() ?>
                <input type="hidden" name="action" value="update_webhook">

                <div style="background: #fef3c7; border: 1px solid #fbbf24; border-radius: 10px; padding: 1rem; margin-bottom: 1.5rem;">
                    <strong style="color: #92400e;">Catatan:</strong>
                    <span style="color: #92400e; font-size: 0.9rem;">
                        Webhook & Callback hanya diperlukan jika Anda punya website/sistem sendiri yang perlu menerima notifikasi otomatis.
                        Untuk notifikasi HP, cukup aktifkan Push Notification di atas.
                    </span>
                </div>

                <div class="form-group">
                    <label class="form-label">Webhook URL</label>
                    <input type="url" name="webhook_url" class="form-input font-mono"
                           value="<?= htmlspecialchars($merchant['webhook_url'] ?? '') ?>"
                           placeholder="https://yoursite.com/webhook/payment">
                    <span class="form-helper">URL endpoint yang akan menerima notifikasi POST saat pembayaran sukses</span>
                </div>

                <div class="form-group">
                    <label class="form-label">Callback URL (Success Page)</label>
                    <input type="url" name="callback_url" class="form-input font-mono"
                           value="<?= htmlspecialchars($merchant['callback_url'] ?? '') ?>"
                           placeholder="https://yoursite.com/payment/success">
                    <span class="form-helper">URL untuk redirect customer setelah pembayaran berhasil</span>
                </div>

                <button type="submit" class="btn btn-primary">Simpan Pengaturan</button>
            </form>
        </div>

        <!-- Webhook Documentation -->
        <div class="content-card" style="margin-top: 1.5rem;">
            <div class="content-card-header">
                <h3 class="content-card-title">Dokumentasi Webhook</h3>
            </div>
            <div class="content-card-body">
                <h4 style="font-size: 0.9rem; color: var(--gray-700); margin-bottom: 0.75rem;">Apa itu Webhook?</h4>
                <p style="font-size: 0.85rem; color: var(--gray-600); margin-bottom: 1rem; line-height: 1.6;">
                    Webhook adalah notifikasi otomatis dari server NEO PGA ke server Anda saat ada pembayaran sukses.
                    Cocok untuk sistem e-commerce yang perlu update status order otomatis.
                </p>

                <h4 style="font-size: 0.9rem; color: var(--gray-700); margin-bottom: 0.75rem;">Format Data Webhook (JSON POST)</h4>
                <pre style="background: #1f2937; color: #e5e7eb; padding: 1rem; border-radius: 10px; font-size: 0.8rem; overflow-x: auto; margin-bottom: 1rem;">
{
  "event": "payment.success",
  "data": {
    "invoice_number": "NB20241215ABC123",
    "reference_id": "ORDER-001",
    "amount": 100000,
    "unique_code": 123,
    "total_amount": 100123,
    "status": "success",
    "paid_at": "2024-12-15 14:30:00",
    "customer": {
      "name": "John Doe",
      "email": "john@email.com",
      "phone": "081234567890"
    },
    "payment_method": "qris"
  },
  "timestamp": "2024-12-15T14:30:00+07:00"
}
                </pre>

                <h4 style="font-size: 0.9rem; color: var(--gray-700); margin-bottom: 0.75rem;">Header yang Dikirim</h4>
                <pre style="background: #f3f4f6; padding: 0.75rem; border-radius: 8px; font-size: 0.8rem; margin-bottom: 1rem;">
Content-Type: application/json
X-Signature: sha256_hmac_signature
X-Webhook-ID: wh_unique_id
                </pre>

                <h4 style="font-size: 0.9rem; color: var(--gray-700); margin-bottom: 0.75rem;">Verifikasi Signature</h4>
                <div style="background: #dbeafe; border: 1px solid #3b82f6; border-radius: 10px; padding: 1rem; margin-bottom: 1rem;">
                    <strong style="color: #1e40af;">Di mana Secret Key?</strong>
                    <p style="color: #2563eb; font-size: 0.85rem; margin: 4px 0 0;">
                        Lihat Secret Key Anda di bagian <strong>atas halaman ini</strong> atau di menu <a href="api-keys.php" style="color: #1d4ed8; font-weight: 600;">API Keys</a>
                    </p>
                </div>
                <p style="font-size: 0.85rem; color: var(--gray-600); margin-bottom: 0.5rem;">
                    Untuk keamanan, verifikasi signature menggunakan Secret Key Anda:
                </p>
                <pre style="background: #1f2937; color: #e5e7eb; padding: 1rem; border-radius: 10px; font-size: 0.8rem; overflow-x: auto;">
<span style="color: #9ca3af;">// PHP Example - Contoh Lengkap</span>
<span style="color: #fbbf24;">&lt;?php</span>
<span style="color: #9ca3af;">// 1. Ambil Secret Key Anda (simpan di config, JANGAN hardcode!)</span>
<span style="color: #a78bfa;">$secretKey</span> = <span style="color: #86efac;">'nb_secret_xxxx...'</span>; <span style="color: #9ca3af;">// Copy dari halaman API Keys</span>

<span style="color: #9ca3af;">// 2. Ambil data dari webhook</span>
<span style="color: #a78bfa;">$payload</span> = file_get_contents(<span style="color: #86efac;">'php://input'</span>);
<span style="color: #a78bfa;">$signature</span> = <span style="color: #a78bfa;">$_SERVER</span>[<span style="color: #86efac;">'HTTP_X_SIGNATURE'</span>] ?? <span style="color: #86efac;">''</span>;

<span style="color: #9ca3af;">// 3. Hitung expected signature</span>
<span style="color: #a78bfa;">$expected</span> = hash_hmac(<span style="color: #86efac;">'sha256'</span>, <span style="color: #a78bfa;">$payload</span>, <span style="color: #a78bfa;">$secretKey</span>);

<span style="color: #9ca3af;">// 4. Bandingkan (gunakan hash_equals untuk keamanan)</span>
<span style="color: #f472b6;">if</span> (hash_equals(<span style="color: #a78bfa;">$expected</span>, <span style="color: #a78bfa;">$signature</span>)) {
    <span style="color: #9ca3af;">// Signature valid! Proses data webhook</span>
    <span style="color: #a78bfa;">$data</span> = json_decode(<span style="color: #a78bfa;">$payload</span>, <span style="color: #f472b6;">true</span>);

    <span style="color: #9ca3af;">// Update status order di database Anda</span>
    <span style="color: #9ca3af;">// ...</span>

    http_response_code(<span style="color: #86efac;">200</span>);
    <span style="color: #f472b6;">echo</span> <span style="color: #86efac;">'OK'</span>;
} <span style="color: #f472b6;">else</span> {
    <span style="color: #9ca3af;">// Signature tidak valid! Mungkin ada yang coba manipulasi</span>
    http_response_code(<span style="color: #86efac;">401</span>);
    <span style="color: #f472b6;">echo</span> <span style="color: #86efac;">'Invalid signature'</span>;
}
                </pre>
            </div>
        </div>

        <!-- Callback Documentation -->
        <div class="content-card" style="margin-top: 1.5rem;">
            <div class="content-card-header">
                <h3 class="content-card-title">Dokumentasi Callback URL</h3>
            </div>
            <div class="content-card-body">
                <h4 style="font-size: 0.9rem; color: var(--gray-700); margin-bottom: 0.75rem;">Apa itu Callback URL?</h4>
                <p style="font-size: 0.85rem; color: var(--gray-600); margin-bottom: 1rem; line-height: 1.6;">
                    Callback URL adalah halaman di website Anda yang akan dituju customer setelah pembayaran berhasil.
                    Biasanya digunakan untuk menampilkan halaman "Terima Kasih" atau konfirmasi pesanan.
                </p>

                <h4 style="font-size: 0.9rem; color: var(--gray-700); margin-bottom: 0.75rem;">Parameter yang Dikirim (GET)</h4>
                <pre style="background: #f3f4f6; padding: 0.75rem; border-radius: 8px; font-size: 0.8rem; margin-bottom: 1rem;">
https://yoursite.com/success?
  invoice=NB20241215ABC123
  &status=success
  &amount=100000
  &reference_id=ORDER-001
                </pre>

                <div style="background: #fef2f2; border: 1px solid #fca5a5; border-radius: 10px; padding: 1rem;">
                    <strong style="color: #991b1b;">Penting!</strong>
                    <p style="color: #991b1b; font-size: 0.85rem; margin: 0.5rem 0 0;">
                        Jangan gunakan callback URL untuk update database langsung!
                        Selalu verifikasi ulang status pembayaran via API atau tunggu webhook.
                        Callback bisa di-manipulasi oleh user.
                    </p>
                </div>
            </div>
        </div>

        <?php elseif ($activeTab === 'security'): ?>
        <div class="content-card">
            <div class="content-card-header">
                <h3 class="content-card-title">Ubah Password</h3>
            </div>
            <form method="POST" class="content-card-body">
                <?= csrfField() ?>
                <input type="hidden" name="action" value="change_password">

                <div class="form-group">
                    <label class="form-label">Password Saat Ini</label>
                    <input type="password" name="current_password" class="form-input" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Password Baru</label>
                    <input type="password" name="new_password" class="form-input" required minlength="6">
                    <span class="form-helper">Minimal 6 karakter</span>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Konfirmasi Password Baru</label>
                    <input type="password" name="confirm_password" class="form-input" required>
                </div>
                
                <button type="submit" class="btn btn-primary">Ubah Password</button>
            </form>
        </div>

        <!-- Security Info -->
        <div class="content-card" style="margin-top: 1.5rem;">
            <div class="content-card-header">
                <h3 class="content-card-title">Info Keamanan</h3>
            </div>
            <div class="content-card-body">
                <div class="security-info-list">
                    <div class="security-info-item">
                        <span class="security-info-label">Login Terakhir</span>
                        <span class="security-info-value"><?= $merchant['last_login'] ? date('d M Y, H:i', strtotime($merchant['last_login'])) : '-' ?></span>
                    </div>
                    <div class="security-info-item">
                        <span class="security-info-label">IP Terakhir</span>
                        <span class="security-info-value"><code><?= $merchant['login_ip'] ?? '-' ?></code></span>
                    </div>
                    <div class="security-info-item">
                        <span class="security-info-label">Terdaftar Sejak</span>
                        <span class="security-info-value"><?= date('d M Y', strtotime($merchant['created_at'])) ?></span>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<script>
// Secret Key toggle & copy functions
function toggleSecretKey() {
    const input = document.getElementById('secretKeyDisplay');
    if (input) {
        input.type = input.type === 'password' ? 'text' : 'password';
    }
}

function copySecretKey() {
    const input = document.getElementById('secretKeyDisplay');
    if (input) {
        const originalType = input.type;
        input.type = 'text';
        input.select();
        input.setSelectionRange(0, 99999);

        try {
            document.execCommand('copy');
            alert('Secret Key berhasil disalin!');
        } catch (err) {
            navigator.clipboard.writeText(input.value).then(function() {
                alert('Secret Key berhasil disalin!');
            }).catch(function() {
                alert('Gagal menyalin. Silakan copy manual.');
            });
        }

        input.type = originalType;
    }
}
</script>

<?php include 'layout_footer.php'; ?>

<?php
/**
 * ================================================================================
 *                    NEO PGA - PROSES PEMBAYARAN
 * ================================================================================
 *
 * File ini memproses pembayaran dan redirect ke halaman QRIS.
 *
 * CARA PAKAI:
 * https://websitekamu.com/bayar.php?produk=Kaos&harga=150000&nama=Budi&email=budi@email.com&hp=08123456789
 *
 * TIDAK PERLU EDIT FILE INI - Cukup edit config.php saja!
 *
 * ================================================================================
 */

require_once __DIR__ . '/config.php';

// Ambil data dari URL atau POST
$produk = $_REQUEST['produk'] ?? 'Produk';
$harga = (int)($_REQUEST['harga'] ?? 0);
$nama = $_REQUEST['nama'] ?? '';
$email = $_REQUEST['email'] ?? '';
$hp = $_REQUEST['hp'] ?? '';
$orderId = $_REQUEST['order_id'] ?? 'ORD-' . date('Ymd') . '-' . substr(uniqid(), -6);

// Validasi
if ($harga < 1000) {
    die('
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Error - ' . htmlspecialchars(NAMA_TOKO) . '</title>
        <style>
            body { font-family: -apple-system, sans-serif; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; background: #f3f4f6; }
            .box { background: white; padding: 40px; border-radius: 16px; text-align: center; box-shadow: 0 4px 20px rgba(0,0,0,0.1); }
            .icon { font-size: 48px; margin-bottom: 16px; }
            h1 { color: #dc2626; margin: 0 0 8px; }
            p { color: #6b7280; margin: 0 0 24px; }
            a { display: inline-block; padding: 12px 24px; background: #0d9488; color: white; text-decoration: none; border-radius: 8px; }
        </style>
    </head>
    <body>
        <div class="box">
            <div class="icon">❌</div>
            <h1>Harga Tidak Valid</h1>
            <p>Harga minimal adalah Rp 1.000</p>
            <a href="javascript:history.back()">← Kembali</a>
        </div>
    </body>
    </html>
    ');
}

// Kirim ke NEO PGA
$data = [
    'reference_id' => $orderId,
    'amount' => $harga,
    'payment_method' => METODE_BAYAR,
    'description' => $produk,
    'customer_name' => $nama,
    'customer_email' => $email,
    'customer_phone' => $hp,
    'expiry_minutes' => WAKTU_EXPIRED,
    'callback_url' => BASE_URL . '/callback.php',
    'success_redirect_url' => BASE_URL . '/sukses.php?order=' . urlencode($orderId),
    'failed_redirect_url' => BASE_URL . '/gagal.php?order=' . urlencode($orderId)
];

$result = neopga_request('/api/create.php', $data);

// Berhasil - Redirect ke halaman pembayaran
if ($result && $result['success'] && isset($result['data']['payment_url'])) {
    // Simpan info order ke session untuk halaman sukses
    session_start();
    $_SESSION['last_order'] = [
        'order_id' => $orderId,
        'invoice' => $result['data']['invoice_number'] ?? '',
        'produk' => $produk,
        'harga' => $harga,
        'nama' => $nama,
        'email' => $email
    ];

    header('Location: ' . $result['data']['payment_url']);
    exit;
}

// Gagal - Tampilkan error
$errorMsg = $result['error'] ?? 'Gagal membuat pembayaran. Silakan coba lagi.';
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Error - <?= htmlspecialchars(NAMA_TOKO) ?></title>
    <style>
        body { font-family: -apple-system, sans-serif; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; background: #f3f4f6; }
        .box { background: white; padding: 40px; border-radius: 16px; text-align: center; box-shadow: 0 4px 20px rgba(0,0,0,0.1); max-width: 400px; }
        .icon { font-size: 48px; margin-bottom: 16px; }
        h1 { color: #dc2626; margin: 0 0 8px; font-size: 24px; }
        p { color: #6b7280; margin: 0 0 24px; }
        .error-detail { background: #fef2f2; padding: 12px; border-radius: 8px; color: #991b1b; font-size: 14px; margin-bottom: 24px; }
        a { display: inline-block; padding: 12px 24px; background: #0d9488; color: white; text-decoration: none; border-radius: 8px; }
        a:hover { background: #0f766e; }
    </style>
</head>
<body>
    <div class="box">
        <div class="icon">⚠️</div>
        <h1>Pembayaran Gagal Dibuat</h1>
        <p>Terjadi kesalahan saat memproses pembayaran</p>
        <div class="error-detail"><?= htmlspecialchars($errorMsg) ?></div>
        <a href="javascript:history.back()">← Coba Lagi</a>
    </div>
</body>
</html>

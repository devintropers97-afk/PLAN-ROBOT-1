<?php
/**
 * NEO PGA Admin - Activity Log
 */
require_once __DIR__ . '/../includes/init.php';

$auth = new Auth('admin');
$auth->requireAuth();

$adminUser = $auth->user();
$db = Database::getInstance();

// Pagination
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 50;
$offset = ($page - 1) * $perPage;

// Filters
$filterUser = $_GET['user_type'] ?? '';
$filterAction = $_GET['action'] ?? '';

$where = "1=1";
$params = [];

if ($filterUser) {
    $where .= " AND user_type = ?";
    $params[] = $filterUser;
}
if ($filterAction) {
    $where .= " AND action LIKE ?";
    $params[] = "%$filterAction%";
}

$total = $db->fetch("SELECT COUNT(*) as c FROM activity_logs WHERE $where", $params)['c'] ?? 0;
$totalPages = ceil($total / $perPage);

$logs = $db->fetchAll(
    "SELECT * FROM activity_logs WHERE $where ORDER BY created_at DESC LIMIT $perPage OFFSET $offset",
    $params
);

$pageTitle = 'Activity Log';
$currentPage = 'activity';

$extraCss = '
.filter-bar { display: flex; gap: 1rem; margin-bottom: 1.5rem; flex-wrap: wrap; }
.filter-bar .form-select { min-width: 150px; }
.log-table td { font-size: 0.875rem; }
.log-action { font-weight: 600; }
.log-desc { color: var(--gray-600); max-width: 300px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.log-time { color: var(--gray-500); font-size: 0.8rem; }
.log-ip { font-family: monospace; font-size: 0.75rem; color: var(--gray-500); }
.pagination { display: flex; gap: 0.5rem; justify-content: center; margin-top: 1.5rem; }
.pagination a, .pagination span { padding: 0.5rem 1rem; border-radius: 6px; text-decoration: none; }
.pagination a { background: var(--gray-100); color: var(--gray-700); }
.pagination a:hover { background: var(--gray-200); }
.pagination .active { background: var(--primary); color: white; }
';

ob_start();
?>

<div class="flex justify-between items-center mb-6">
    <div>
        <h1 class="text-2xl font-bold text-gray-900">Activity Log</h1>
        <p class="text-gray-500">Log aktivitas sistem (<?= number_format($total) ?> total)</p>
    </div>
</div>

<!-- Filters -->
<div class="filter-bar">
    <form method="GET" class="flex gap-2 items-center">
        <select name="user_type" class="form-select">
            <option value="">Semua User Type</option>
            <option value="admin" <?= $filterUser === 'admin' ? 'selected' : '' ?>>Admin</option>
            <option value="merchant" <?= $filterUser === 'merchant' ? 'selected' : '' ?>>Merchant</option>
        </select>
        <input type="text" name="action" class="form-input" placeholder="Filter action..." value="<?= htmlspecialchars($filterAction) ?>" style="width:200px">
        <button type="submit" class="btn btn-primary">Filter</button>
        <?php if ($filterUser || $filterAction): ?>
        <a href="activity.php" class="btn btn-secondary">Reset</a>
        <?php endif; ?>
    </form>
</div>

<!-- Log Table -->
<div class="card">
    <div class="table-wrapper">
        <table class="table log-table">
            <thead>
                <tr>
                    <th>Waktu</th>
                    <th>User</th>
                    <th>Action</th>
                    <th>Module</th>
                    <th>Deskripsi</th>
                    <th>IP Address</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($logs)): ?>
                <tr><td colspan="6" style="text-align:center;padding:2rem;color:var(--gray-500)">Tidak ada log</td></tr>
                <?php else: ?>
                <?php foreach ($logs as $log): ?>
                <tr>
                    <td class="log-time"><?= date('d/m/Y H:i:s', strtotime($log['created_at'])) ?></td>
                    <td>
                        <span class="badge badge-<?= $log['user_type'] === 'admin' ? 'info' : 'success' ?>"><?= ucfirst($log['user_type']) ?></span>
                        <span style="font-size:0.75rem;color:var(--gray-500)">#<?= $log['user_id'] ?></span>
                    </td>
                    <td class="log-action"><?= htmlspecialchars($log['action']) ?></td>
                    <td><span class="badge badge-neutral"><?= htmlspecialchars($log['module'] ?? '-') ?></span></td>
                    <td class="log-desc" title="<?= htmlspecialchars($log['description'] ?? '') ?>"><?= htmlspecialchars($log['description'] ?? '-') ?></td>
                    <td class="log-ip"><?= htmlspecialchars($log['ip_address'] ?? '-') ?></td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Pagination -->
<?php if ($totalPages > 1): ?>
<div class="pagination">
    <?php if ($page > 1): ?>
    <a href="?page=<?= $page - 1 ?>&user_type=<?= urlencode($filterUser) ?>&action=<?= urlencode($filterAction) ?>">← Prev</a>
    <?php endif; ?>
    
    <?php for ($i = max(1, $page - 2); $i <= min($totalPages, $page + 2); $i++): ?>
    <?php if ($i == $page): ?>
    <span class="active"><?= $i ?></span>
    <?php else: ?>
    <a href="?page=<?= $i ?>&user_type=<?= urlencode($filterUser) ?>&action=<?= urlencode($filterAction) ?>"><?= $i ?></a>
    <?php endif; ?>
    <?php endfor; ?>
    
    <?php if ($page < $totalPages): ?>
    <a href="?page=<?= $page + 1 ?>&user_type=<?= urlencode($filterUser) ?>&action=<?= urlencode($filterAction) ?>">Next →</a>
    <?php endif; ?>
</div>
<?php endif; ?>

<?php
$content = ob_get_clean();
include __DIR__ . '/layout.php';
?>

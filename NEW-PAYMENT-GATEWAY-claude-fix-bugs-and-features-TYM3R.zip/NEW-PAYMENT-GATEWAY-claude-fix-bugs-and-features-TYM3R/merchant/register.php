<?php
/**
 * NEO PGA Merchant Registration
 * Modern Teal Theme with Animated Background
 */
require_once __DIR__ . '/../includes/init.php';

// Redirect if already logged in
if (isset($_SESSION['merchant_user'])) {
    header('Location: index.php');
    exit;
}

$error = '';
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verify CSRF token
    verifyCsrf();

    $businessName = sanitize($_POST['business_name'] ?? '');
    $ownerName = sanitize($_POST['owner_name'] ?? '');
    $email = sanitize($_POST['email'] ?? '');
    $phone = sanitize($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';
    $businessType = sanitize($_POST['business_type'] ?? '');
    $businessDescription = sanitize($_POST['business_description'] ?? '');
    $expectedVolume = sanitize($_POST['expected_volume'] ?? '');
    $website = sanitize($_POST['website'] ?? '');
    $address = sanitize($_POST['address'] ?? '');
    
    // Validation
    if (empty($businessName) || empty($ownerName) || empty($email) || empty($phone) || empty($password)) {
        $error = 'Semua field wajib harus diisi';
    } elseif (empty($businessType)) {
        $error = 'Pilih jenis usaha Anda';
    } elseif (empty($businessDescription)) {
        $error = 'Jelaskan tentang bisnis dan tujuan penggunaan';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Format email tidak valid';
    } elseif (strlen($password) < 6) {
        $error = 'Password minimal 6 karakter';
    } elseif ($password !== $confirmPassword) {
        $error = 'Password tidak cocok';
    } else {
        $db = Database::getInstance();
        
        // Check if email already exists
        $existing = $db->fetch("SELECT id FROM merchants WHERE email = ?", [$email]);
        if ($existing) {
            $error = 'Email sudah terdaftar';
        } else {
            // Generate merchant code
            $merchantCode = 'M-' . strtoupper(substr(md5(time() . $email), 0, 8));
            
            // Generate API Key dan Secret Key
            $apiKey = 'nb_live_' . bin2hex(random_bytes(16));
            $secretKey = 'nb_secret_' . bin2hex(random_bytes(24));
            
            // Insert new merchant
            try {
                $db->insert('merchants', [
                    'merchant_code' => $merchantCode,
                    'business_name' => $businessName,
                    'owner_name' => $ownerName,
                    'email' => $email,
                    'phone' => $phone,
                    'password' => password_hash($password, PASSWORD_BCRYPT, ['cost' => HASH_COST]),
                    'business_type' => $businessType,
                    'business_description' => $businessDescription,
                    'expected_volume' => $expectedVolume,
                    'website' => $website,
                    'address' => $address,
                    'api_key' => $apiKey,
                    'secret_key' => $secretKey,
                    'status' => 'pending',
                    'commission_rate' => 2.5,
                    'created_at' => date('Y-m-d H:i:s')
                ]);
                
                $success = true;
            } catch (Exception $e) {
                error_log("Registration error: " . $e->getMessage());
                $error = 'Gagal mendaftar. Silakan coba lagi.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Merchant - <?= APP_NAME ?></title>
    <link rel="icon" type="image/svg+xml" href="<?= ASSETS_URL ?>/images/favicon.svg">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #0d9488;
            --primary-light: #14b8a6;
            --primary-dark: #0f766e;
            --secondary: #0f172a;
        }
        
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: #0f172a;
            color: #e2e8f0;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem;
            overflow-x: hidden;
        }
        
        .bg-animation {
            position: fixed;
            top: 0; left: 0;
            width: 100%; height: 100%;
            z-index: 0;
            overflow: hidden;
        }
        
        .gradient-orb {
            position: absolute;
            border-radius: 50%;
            filter: blur(80px);
            opacity: 0.35;
            animation: float 20s infinite;
        }
        
        .orb-1 {
            width: 450px; height: 450px;
            background: linear-gradient(135deg, #0d9488, #14b8a6);
            top: -150px; right: -100px;
        }
        
        .orb-2 {
            width: 350px; height: 350px;
            background: linear-gradient(135deg, #0891b2, #06b6d4);
            bottom: -100px; left: -100px;
            animation-delay: -10s;
        }
        
        .orb-3 {
            width: 200px; height: 200px;
            background: linear-gradient(135deg, #10b981, #34d399);
            top: 50%; left: 30%;
            animation-delay: -5s;
        }
        
        @keyframes float {
            0%, 100% { transform: translate(0, 0) scale(1); }
            25% { transform: translate(50px, -50px) scale(1.1); }
            50% { transform: translate(-30px, 30px) scale(0.9); }
            75% { transform: translate(-50px, -30px) scale(1.05); }
        }
        
        .register-wrapper {
            position: relative;
            z-index: 10;
            width: 100%;
            max-width: 560px;
        }
        
        .register-logo {
            text-align: center;
            margin-bottom: 2rem;
        }
        
        .register-logo a {
            display: inline-flex;
            align-items: center;
            gap: 0.75rem;
            text-decoration: none;
        }
        
        .logo-icon {
            width: 52px; height: 52px;
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 20px rgba(13, 148, 136, 0.4);
        }
        
        .logo-icon svg { width: 28px; height: 28px; color: white; }
        
        .logo-text {
            font-size: 1.75rem;
            font-weight: 800;
            color: white;
        }
        
        .logo-text span {
            background: linear-gradient(135deg, var(--primary-light), #5eead4);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .register-subtitle {
            color: #94a3b8;
            font-size: 0.95rem;
            margin-top: 0.5rem;
        }
        
        .register-card {
            background: rgba(30, 41, 59, 0.8);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 1.5rem;
            padding: 2.5rem;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
        }
        
        .card-header {
            text-align: center;
            margin-bottom: 2rem;
        }
        
        .card-header h1 {
            font-size: 1.5rem;
            font-weight: 700;
            color: white;
            margin-bottom: 0.5rem;
        }
        
        .card-header p {
            color: #94a3b8;
            font-size: 0.9rem;
        }
        
        .success-card {
            text-align: center;
            padding: 2rem 0;
        }
        
        .success-icon {
            width: 80px; height: 80px;
            background: linear-gradient(135deg, #10b981, #34d399);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1.5rem;
            box-shadow: 0 8px 30px rgba(16, 185, 129, 0.4);
        }
        
        .success-icon svg { width: 40px; height: 40px; color: white; }
        
        .success-card h2 { font-size: 1.5rem; color: white; margin-bottom: 0.75rem; }
        .success-card p { color: #94a3b8; margin-bottom: 1.5rem; line-height: 1.6; }
        
        .alert {
            padding: 1rem 1.25rem;
            border-radius: 0.75rem;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            font-size: 0.9rem;
        }
        
        .alert-danger {
            background: rgba(239, 68, 68, 0.15);
            border: 1px solid rgba(239, 68, 68, 0.3);
            color: #fca5a5;
        }
        
        .alert svg { width: 20px; height: 20px; flex-shrink: 0; }
        
        .form-section {
            margin-bottom: 1.5rem;
            padding-bottom: 1.5rem;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .form-section:last-child {
            border-bottom: none;
            margin-bottom: 0;
            padding-bottom: 0;
        }
        
        .section-title {
            font-size: 0.8rem;
            text-transform: uppercase;
            color: var(--primary-light);
            font-weight: 600;
            letter-spacing: 0.05em;
            margin-bottom: 1rem;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }
        
        .form-group { margin-bottom: 1rem; }
        .form-group.full-width { grid-column: 1 / -1; }
        
        .form-label {
            display: block;
            font-size: 0.875rem;
            font-weight: 600;
            color: #e2e8f0;
            margin-bottom: 0.5rem;
        }
        
        .form-label .required { color: #f87171; }
        
        .form-input, .form-select, .form-textarea {
            width: 100%;
            padding: 0.75rem 1rem;
            background: rgba(15, 23, 42, 0.6);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 0.75rem;
            font-size: 0.95rem;
            color: white;
            transition: all 0.3s;
            font-family: inherit;
        }
        
        .form-textarea { resize: vertical; min-height: 80px; }
        .form-select { cursor: pointer; }
        .form-select option { background: #1e293b; color: white; }
        
        .form-input::placeholder, .form-textarea::placeholder { color: #64748b; }
        
        .form-input:focus, .form-select:focus, .form-textarea:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(13, 148, 136, 0.2);
            background: rgba(15, 23, 42, 0.8);
        }
        
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            padding: 0.875rem 1.5rem;
            border-radius: 0.75rem;
            font-weight: 600;
            font-size: 1rem;
            text-decoration: none;
            transition: all 0.3s;
            cursor: pointer;
            border: none;
            width: 100%;
            font-family: inherit;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            color: white;
            box-shadow: 0 4px 20px rgba(13, 148, 136, 0.4);
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 30px rgba(13, 148, 136, 0.5);
        }
        
        .btn-secondary {
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(255,255,255,0.1);
            color: #e2e8f0;
        }
        
        .btn-secondary:hover {
            background: rgba(255,255,255,0.1);
        }
        
        .btn svg { width: 20px; height: 20px; }
        
        .login-link {
            text-align: center;
            margin-top: 1.5rem;
            color: #94a3b8;
            font-size: 0.9rem;
        }
        
        .login-link a {
            color: var(--primary-light);
            text-decoration: none;
            font-weight: 600;
        }
        
        .login-link a:hover { color: #5eead4; }
        
        .back-home {
            text-align: center;
            margin-top: 2rem;
        }
        
        .back-home a {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            color: #64748b;
            text-decoration: none;
            font-size: 0.875rem;
            transition: color 0.3s;
        }
        
        .back-home a:hover { color: white; }
        .back-home svg { width: 16px; height: 16px; }
        
        .copyright {
            text-align: center;
            margin-top: 1.5rem;
            color: #475569;
            font-size: 0.8rem;
        }
        
        @media (max-width: 600px) {
            body { padding: 1rem; }
            .register-card { padding: 1.5rem; }
            .logo-text { font-size: 1.5rem; }
            .form-row { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <div class="bg-animation">
        <div class="gradient-orb orb-1"></div>
        <div class="gradient-orb orb-2"></div>
        <div class="gradient-orb orb-3"></div>
    </div>
    
    <div class="register-wrapper">
        <div class="register-logo">
            <a href="<?= APP_URL ?>">
                <div class="logo-icon">
                    <svg viewBox="0 0 24 24" fill="none">
                        <path d="M4 20 C4 20, 7 15, 10 10 C11 8, 11.5 6, 12 4" stroke="#14B8A6" stroke-width="2.5" stroke-linecap="round"/>
                        <path d="M20 20 C20 20, 17 15, 14 10 C13 8, 12.5 6, 12 4" stroke="#0D9488" stroke-width="2.5" stroke-linecap="round"/>
                        <circle cx="12" cy="4" r="2.5" fill="#F59E0B"/>
                        <line x1="12" y1="7" x2="12" y2="18" stroke="#0D9488" stroke-width="2" stroke-linecap="round"/>
                    </svg>
                </div>
                <span class="logo-text">NEO <span>PGA</span></span>
            </a>
            <p class="register-subtitle">Payment Gateway Platform</p>
        </div>
        
        <div class="register-card">
            <?php if ($success): ?>
            <div class="success-card">
                <div class="success-icon">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                    </svg>
                </div>
                <h2>Pendaftaran Berhasil! 🎉</h2>
                <p>
                    Akun Anda sedang dalam proses review.<br>
                    Tim kami akan memverifikasi data Anda dalam <strong>1x24 jam kerja</strong>.<br>
                    Kami akan menghubungi Anda via email.
                </p>
                <a href="login.php" class="btn btn-primary">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1"/>
                    </svg>
                    Ke Halaman Login
                </a>
            </div>
            <?php else: ?>
            <div class="card-header">
                <h1>Daftar Jadi Merchant</h1>
                <p>Mulai terima pembayaran digital untuk bisnis Anda</p>
            </div>
            
            <?php if ($error): ?>
            <div class="alert alert-danger">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                </svg>
                <span><?= htmlspecialchars($error) ?></span>
            </div>
            <?php endif; ?>
            
            <form method="POST">
                <?= csrfField() ?>
                <!-- Basic Info -->
                <div class="form-section">
                    <div class="section-title">📋 Informasi Dasar</div>
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Nama Bisnis <span class="required">*</span></label>
                            <input type="text" name="business_name" class="form-input" placeholder="Toko ABC" required value="<?= htmlspecialchars($_POST['business_name'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Nama Pemilik <span class="required">*</span></label>
                            <input type="text" name="owner_name" class="form-input" placeholder="John Doe" required value="<?= htmlspecialchars($_POST['owner_name'] ?? '') ?>">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Email <span class="required">*</span></label>
                            <input type="email" name="email" class="form-input" placeholder="email@bisnis.com" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label">No. WhatsApp <span class="required">*</span></label>
                            <input type="tel" name="phone" class="form-input" placeholder="08123456789" required value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>">
                        </div>
                    </div>
                </div>
                
                <!-- Business Info -->
                <div class="form-section">
                    <div class="section-title">🏪 Informasi Bisnis</div>
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Jenis Usaha <span class="required">*</span></label>
                            <select name="business_type" class="form-select" required>
                                <option value="">-- Pilih Jenis Usaha --</option>
                                <option value="e-commerce" <?= ($_POST['business_type'] ?? '') === 'e-commerce' ? 'selected' : '' ?>>E-Commerce / Online Shop</option>
                                <option value="services" <?= ($_POST['business_type'] ?? '') === 'services' ? 'selected' : '' ?>>Jasa / Services</option>
                                <option value="fnb" <?= ($_POST['business_type'] ?? '') === 'fnb' ? 'selected' : '' ?>>Food & Beverage</option>
                                <option value="fashion" <?= ($_POST['business_type'] ?? '') === 'fashion' ? 'selected' : '' ?>>Fashion / Apparel</option>
                                <option value="electronics" <?= ($_POST['business_type'] ?? '') === 'electronics' ? 'selected' : '' ?>>Elektronik / Gadget</option>
                                <option value="health" <?= ($_POST['business_type'] ?? '') === 'health' ? 'selected' : '' ?>>Kesehatan / Beauty</option>
                                <option value="digital" <?= ($_POST['business_type'] ?? '') === 'digital' ? 'selected' : '' ?>>Produk Digital</option>
                                <option value="education" <?= ($_POST['business_type'] ?? '') === 'education' ? 'selected' : '' ?>>Pendidikan / Kursus</option>
                                <option value="travel" <?= ($_POST['business_type'] ?? '') === 'travel' ? 'selected' : '' ?>>Travel / Tour</option>
                                <option value="other" <?= ($_POST['business_type'] ?? '') === 'other' ? 'selected' : '' ?>>Lainnya</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Estimasi Transaksi/Bulan</label>
                            <select name="expected_volume" class="form-select">
                                <option value="">-- Pilih Range --</option>
                                <option value="< 5M" <?= ($_POST['expected_volume'] ?? '') === '< 5M' ? 'selected' : '' ?>>< Rp 5 Juta</option>
                                <option value="5-20M" <?= ($_POST['expected_volume'] ?? '') === '5-20M' ? 'selected' : '' ?>>Rp 5 - 20 Juta</option>
                                <option value="20-50M" <?= ($_POST['expected_volume'] ?? '') === '20-50M' ? 'selected' : '' ?>>Rp 20 - 50 Juta</option>
                                <option value="50-100M" <?= ($_POST['expected_volume'] ?? '') === '50-100M' ? 'selected' : '' ?>>Rp 50 - 100 Juta</option>
                                <option value="> 100M" <?= ($_POST['expected_volume'] ?? '') === '> 100M' ? 'selected' : '' ?>>> Rp 100 Juta</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group full-width">
                        <label class="form-label">Ceritakan Bisnis Anda <span class="required">*</span></label>
                        <textarea name="business_description" class="form-textarea" placeholder="Jelaskan bisnis Anda dan tujuan menggunakan NEO PGA..." required><?= htmlspecialchars($_POST['business_description'] ?? '') ?></textarea>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Website / Toko Online</label>
                            <input type="url" name="website" class="form-input" placeholder="https://tokosaya.com" value="<?= htmlspecialchars($_POST['website'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Kota/Kabupaten</label>
                            <input type="text" name="address" class="form-input" placeholder="Jakarta Selatan" value="<?= htmlspecialchars($_POST['address'] ?? '') ?>">
                        </div>
                    </div>
                </div>
                
                <!-- Password -->
                <div class="form-section">
                    <div class="section-title">🔐 Keamanan Akun</div>
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Password <span class="required">*</span></label>
                            <input type="password" name="password" class="form-input" placeholder="Minimal 6 karakter" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Konfirmasi Password <span class="required">*</span></label>
                            <input type="password" name="confirm_password" class="form-input" placeholder="Ulangi password" required>
                        </div>
                    </div>
                </div>
                
                <button type="submit" class="btn btn-primary">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z"/>
                    </svg>
                    Daftar Sekarang
                </button>
                
                <div class="login-link">
                    Sudah punya akun? <a href="login.php">Login di sini</a>
                </div>
            </form>
            <?php endif; ?>
        </div>
        
        <div class="back-home">
            <a href="<?= APP_URL ?>">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
                </svg>
                Kembali ke Homepage
            </a>
        </div>
        
        <p class="copyright">&copy; <?= date('Y') ?> <?= APP_NAME ?>. All rights reserved.</p>
    </div>

    <!-- Security Protection -->
    <script src="<?= ASSETS_URL ?>/js/security.js"></script>
</body>
</html>

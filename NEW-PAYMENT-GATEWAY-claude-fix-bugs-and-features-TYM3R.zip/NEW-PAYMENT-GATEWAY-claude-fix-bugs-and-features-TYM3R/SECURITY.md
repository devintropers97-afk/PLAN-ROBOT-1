# Dokumentasi Keamanan NEO PGA

## Ringkasan Keamanan

Website NEO PGA telah dilengkapi dengan **multiple layers of security** untuk melindungi dari berbagai jenis serangan.

---

## 1. Proteksi yang Sudah Diterapkan

### Server-Side Security (PHP) ✅ TIDAK BISA DILIHAT USER

| Fitur | Status | Keterangan |
|-------|--------|------------|
| SQL Injection Prevention | ✅ | PDO Prepared Statements |
| XSS Prevention | ✅ | htmlspecialchars() & sanitize() |
| CSRF Protection | ✅ | Token-based verification |
| Password Hashing | ✅ | BCrypt with cost 12 |
| Session Security | ✅ | HTTPOnly, Secure, Regeneration |
| Rate Limiting | ✅ | IP + API key based |
| Input Validation | ✅ | Type checking & sanitization |
| Brute Force Protection | ✅ | 5 attempts, 15 min lockout |
| File Upload Security | ✅ | MIME check, extension check |
| Encryption | ✅ | AES-256-CBC |
| HMAC Signature | ✅ | SHA-256 for webhooks |

### HTTP Security Headers ✅

| Header | Value | Fungsi |
|--------|-------|--------|
| X-Frame-Options | SAMEORIGIN | Prevent clickjacking |
| X-XSS-Protection | 1; mode=block | XSS filter |
| X-Content-Type-Options | nosniff | Prevent MIME sniffing |
| Referrer-Policy | strict-origin-when-cross-origin | Control referrer info |
| Permissions-Policy | geolocation=(), camera=() | Disable dangerous APIs |
| Cache-Control | no-store | Prevent caching sensitive pages |

### Client-Side Protection ⚠️ (Bisa di-bypass oleh expert)

| Fitur | Status | Keterangan |
|-------|--------|------------|
| Disable Right-Click | ✅ | Prevent casual inspection |
| Disable F12 | ✅ | Block DevTools shortcut |
| Disable Ctrl+U | ✅ | Block view source |
| Disable Ctrl+S | ✅ | Block save page |
| DevTools Detection | ✅ | Detect when DevTools opened |
| Console Warning | ✅ | Warning message in console |
| Iframe Protection | ✅ | Prevent embedding |

---

## 2. Fakta Penting tentang Keamanan Web

### Apa yang TIDAK BISA Dilihat User:

```
✅ File PHP (diproses di server)
✅ Database credentials
✅ API Secret Keys
✅ Server-side logic
✅ Config files
✅ Encryption keys
```

### Apa yang BISA Dilihat User (Standar Web):

```
⚠️ HTML output
⚠️ CSS styles
⚠️ JavaScript (client-side)
⚠️ Image files
⚠️ API responses (data only, bukan logic)
```

**PENTING:** Ini adalah STANDAR WEB GLOBAL. Tidak ada website di dunia yang bisa menyembunyikan HTML/CSS/JS dari browser. Bahkan Google, Facebook, dan bank-bank besar pun sama.

---

## 3. Mengapa NEO PGA Tetap Aman?

### Logic Bisnis di Server (PHP)

Semua logic penting ada di PHP:
- Validasi pembayaran
- Perhitungan fee
- Verifikasi transaksi
- Generate invoice
- Proses settlement

**User hanya melihat HASIL (HTML), bukan PROSES (PHP).**

### Contoh:

```php
// INI TIDAK BISA DILIHAT USER:
$amount = $request['amount'];
$fee = $amount * 0.015; // 1.5% fee
$merchant_receive = $amount - $fee;
$db->insert('transactions', [...]);
```

```html
<!-- USER HANYA LIHAT INI: -->
<div>Total: Rp 100.000</div>
<div>Fee: Rp 1.500</div>
<div>Terima: Rp 98.500</div>
```

---

## 4. Proteksi Tambahan

### Rate Limiting

```php
// Maksimum request per IP
- API: 100 request/menit
- Login: 5 attempt, lockout 15 menit
- Register: 3 request/jam
```

### Logging Keamanan

Semua aktivitas mencurigakan dicatat di:
```
/logs/security.log
```

Event yang dicatat:
- SQL injection attempts
- XSS attempts
- Failed logins
- Honeypot triggers
- Malicious file uploads

### Honeypot

Form dilengkapi honeypot untuk mendeteksi bot:
```html
<input type="text" name="website_url" style="display:none">
```

---

## 5. Checklist Keamanan Sebelum Go-Live

### Wajib Dilakukan:

- [ ] Ganti semua password default
- [ ] Set `APP_DEBUG = false`
- [ ] Set `APP_ENV = production`
- [ ] Enable HTTPS (uncomment di .htaccess)
- [ ] Ganti `APP_KEY` dengan random string
- [ ] Hapus file `install.php` setelah install
- [ ] Set permission folder: `chmod 755`
- [ ] Set permission config: `chmod 600`
- [ ] Backup database secara rutin
- [ ] Monitor `/logs/security.log`

### Rekomendasi Server:

- [ ] Gunakan PHP 8.0+
- [ ] Enable OPcache
- [ ] Disable `expose_php`
- [ ] Set `display_errors = Off`
- [ ] Enable mod_security (WAF)
- [ ] Setup firewall (UFW/iptables)
- [ ] Enable fail2ban
- [ ] Regular security updates

---

## 6. Cara Menambahkan Anti-Inspect ke Halaman

Tambahkan script ini sebelum `</body>`:

```html
<script src="<?= ASSETS_URL ?>/js/security.js"></script>
```

Script ini akan:
- Disable right-click
- Disable F12, Ctrl+U, Ctrl+S
- Detect DevTools
- Show warning di console

---

## 7. Jika Terjadi Serangan

### 1. SQL Injection
```
Status: DICEGAH
Metode: PDO Prepared Statements
Log: /logs/security.log
```

### 2. XSS Attack
```
Status: DICEGAH
Metode: htmlspecialchars() + CSP Header
Log: /logs/security.log
```

### 3. Brute Force
```
Status: DICEGAH
Metode: 5 attempts → lockout 15 menit
Log: /logs/security.log
```

### 4. CSRF Attack
```
Status: DICEGAH
Metode: Token verification
Log: Activity log
```

---

## 8. Kontak Keamanan

Jika menemukan kerentanan keamanan:
1. JANGAN publish secara publik
2. Hubungi tim teknis NEO PGA
3. Berikan detail lengkap
4. Tunggu konfirmasi perbaikan

---

## 9. FAQ Keamanan

### Q: Apakah source code PHP bisa dilihat?
**A: TIDAK.** PHP diproses di server. User hanya melihat output HTML.

### Q: Apakah API key aman?
**A: YA.** API key disimpan di database dan dienkripsi. Yang terlihat di frontend hanya masked version.

### Q: Kenapa HTML/CSS/JS masih bisa dilihat?
**A: Ini standar web global.** Semua website di dunia sama. Yang penting logic bisnis di PHP tetap aman.

### Q: Apakah anti-inspect 100% efektif?
**A: TIDAK.** Tidak ada yang 100% di dunia web. Tapi ini membuat lebih sulit bagi orang awam. Expert tetap bisa bypass, tapi mereka tidak akan mendapat informasi sensitif karena semua logic ada di PHP.

### Q: Bagaimana jika ada bug security?
**A: Laporkan ke tim teknis.** Jangan publish publik. Kami akan perbaiki dan update.

---

*Dokumen ini dibuat untuk panduan internal NEO PGA.*
*Terakhir diupdate: Desember 2024*

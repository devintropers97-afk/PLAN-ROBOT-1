<?php
/**
 * NEO PGA Merchant - Dashboard
 * Modern Clean Design with Error Handling
 */

// Error handling
error_reporting(E_ALL);
ini_set('display_errors', 0);

require_once __DIR__ . '/../includes/init.php';

$pageTitle = 'Dashboard';
$currentPage = 'dashboard';

// Include layout header (handles auth)
include __DIR__ . '/layout_header.php';

// Variables from layout_header: $merchant, $merchantId, $db
$merchantStatus = $merchant['status'] ?? 'pending';
?>

<style>
/* Dashboard Specific Styles */
.welcome-section {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
    flex-wrap: wrap;
    gap: 1rem;
}

.welcome-text h2 {
    font-size: 1.5rem;
    font-weight: 700;
    color: var(--gray-900);
    margin: 0;
}

.welcome-text p {
    color: var(--gray-500);
    margin-top: 0.25rem;
    font-size: 0.9rem;
}

/* Stats Grid */
.stats-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 1rem;
    margin-bottom: 1.5rem;
}

@media (max-width: 1024px) {
    .stats-grid {
        grid-template-columns: repeat(2, 1fr);
    }
}

@media (max-width: 640px) {
    .stats-grid {
        grid-template-columns: 1fr;
    }
}

.stat-card {
    background: var(--white);
    border: 1px solid var(--gray-200);
    border-radius: 16px;
    padding: 1.25rem;
    transition: all 0.2s ease;
}

.stat-card:hover {
    border-color: var(--primary-300);
    box-shadow: 0 4px 12px rgba(16, 185, 129, 0.1);
}

.stat-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 1rem;
}

.stat-icon {
    width: 48px;
    height: 48px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.stat-icon svg {
    width: 24px;
    height: 24px;
}

.stat-value {
    font-size: 1.75rem;
    font-weight: 800;
    color: var(--gray-900);
    margin-bottom: 0.25rem;
}

.stat-label {
    font-size: 0.85rem;
    color: var(--gray-500);
}

/* Cards */
.card {
    background: var(--white);
    border: 1px solid var(--gray-200);
    border-radius: 16px;
    overflow: hidden;
}

.card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 1rem 1.25rem;
    border-bottom: 1px solid var(--gray-100);
}

.card-header h3 {
    font-size: 1rem;
    font-weight: 600;
    color: var(--gray-800);
    margin: 0;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.card-header h3 svg {
    width: 20px;
    height: 20px;
    color: var(--primary-600);
}

.card-body {
    padding: 1.25rem;
}

/* Main Grid Layout */
.main-grid {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 1.5rem;
}

@media (max-width: 1024px) {
    .main-grid {
        grid-template-columns: 1fr;
    }
}

.charts-grid {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 1.5rem;
    margin-bottom: 1.5rem;
}

@media (max-width: 1024px) {
    .charts-grid {
        grid-template-columns: 1fr;
    }
}

/* Table Styles */
.table-container {
    overflow-x: auto;
}

.table {
    width: 100%;
    border-collapse: collapse;
}

.table th {
    padding: 0.75rem 1rem;
    text-align: left;
    font-size: 0.75rem;
    font-weight: 600;
    color: var(--gray-500);
    text-transform: uppercase;
    letter-spacing: 0.05em;
    background: var(--gray-50);
    border-bottom: 1px solid var(--gray-200);
}

.table td {
    padding: 0.875rem 1rem;
    font-size: 0.875rem;
    color: var(--gray-700);
    border-bottom: 1px solid var(--gray-100);
}

.table tr:hover td {
    background: var(--gray-50);
}

.invoice-link {
    color: var(--primary-600);
    font-weight: 500;
    text-decoration: none;
}

.invoice-link:hover {
    text-decoration: underline;
}

.invoice-code {
    font-size: 0.75rem;
    font-family: 'JetBrains Mono', monospace;
    background: var(--gray-100);
    padding: 0.25rem 0.5rem;
    border-radius: 4px;
}

/* Badges */
.badge {
    display: inline-flex;
    align-items: center;
    padding: 0.25rem 0.75rem;
    font-size: 0.75rem;
    font-weight: 600;
    border-radius: 9999px;
}

.badge-success {
    background: var(--primary-100);
    color: var(--primary-700);
}

.badge-warning {
    background: #fef3c7;
    color: #92400e;
}

.badge-danger {
    background: #fee2e2;
    color: #dc2626;
}

.badge-info {
    background: #dbeafe;
    color: #1e40af;
}

/* Buttons */
.btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
    padding: 0.625rem 1.25rem;
    font-size: 0.875rem;
    font-weight: 600;
    border-radius: 10px;
    border: none;
    cursor: pointer;
    transition: all 0.2s ease;
    text-decoration: none;
}

.btn svg {
    width: 18px;
    height: 18px;
}

.btn-primary {
    background: linear-gradient(135deg, var(--primary-500), var(--primary-600));
    color: white;
    box-shadow: 0 2px 8px rgba(16, 185, 129, 0.3);
}

.btn-primary:hover {
    background: linear-gradient(135deg, var(--primary-600), var(--primary-700));
    box-shadow: 0 4px 12px rgba(16, 185, 129, 0.4);
    transform: translateY(-1px);
}

.btn-secondary {
    background: var(--gray-100);
    color: var(--gray-700);
}

.btn-secondary:hover {
    background: var(--gray-200);
}

.btn-sm {
    padding: 0.375rem 0.875rem;
    font-size: 0.8rem;
}

/* Quick Action Cards */
.quick-action-btn {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    width: 100%;
    padding: 0.875rem 1rem;
    margin-bottom: 0.5rem;
    background: var(--gray-50);
    border: 1px solid var(--gray-200);
    border-radius: 12px;
    color: var(--gray-700);
    font-weight: 500;
    text-decoration: none;
    transition: all 0.2s ease;
}

.quick-action-btn:hover {
    background: var(--primary-50);
    border-color: var(--primary-200);
    color: var(--primary-700);
}

.quick-action-btn svg {
    width: 20px;
    height: 20px;
}

.quick-action-btn.primary {
    background: linear-gradient(135deg, var(--primary-500), var(--primary-600));
    border-color: transparent;
    color: white;
}

.quick-action-btn.primary:hover {
    background: linear-gradient(135deg, var(--primary-600), var(--primary-700));
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
}

/* Info Card Items */
.info-item {
    margin-bottom: 1rem;
}

.info-item:last-child {
    margin-bottom: 0;
}

.info-label {
    font-size: 0.75rem;
    color: var(--gray-500);
    margin-bottom: 0.25rem;
}

.info-value {
    font-weight: 600;
    color: var(--gray-800);
}

.info-value.mono {
    font-family: 'JetBrains Mono', monospace;
}

.info-value.primary {
    color: var(--primary-600);
    font-size: 1.1rem;
}

/* Monthly Stats */
.month-stats {
    text-align: center;
    padding: 1rem 0;
}

.month-amount {
    font-size: 1.75rem;
    font-weight: 800;
    color: var(--primary-600);
}

.month-count {
    font-size: 0.85rem;
    color: var(--gray-500);
    margin-top: 0.25rem;
}

/* API Steps */
.api-steps {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 1rem;
}

@media (max-width: 768px) {
    .api-steps {
        grid-template-columns: repeat(2, 1fr);
    }
}

.api-step {
    background: var(--gray-50);
    border: 1px solid var(--gray-200);
    padding: 1.25rem;
    border-radius: 12px;
    text-align: center;
    transition: all 0.2s ease;
}

.api-step:hover {
    border-color: var(--primary-300);
    background: var(--primary-50);
}

.api-step-num {
    width: 36px;
    height: 36px;
    background: linear-gradient(135deg, var(--primary-500), var(--primary-600));
    color: white;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 700;
    font-size: 1rem;
    margin: 0 auto 0.75rem;
}

.api-step-title {
    font-weight: 600;
    font-size: 0.85rem;
    color: var(--gray-700);
}

/* Status Cards (Pending/Rejected/Suspended) */
.status-container {
    max-width: 500px;
    margin: 2rem auto;
}

.status-card {
    background: var(--white);
    border-radius: 20px;
    padding: 2.5rem;
    text-align: center;
    box-shadow: 0 4px 24px rgba(0, 0, 0, 0.08);
}

.status-card.pending {
    border: 2px solid #fcd34d;
}

.status-card.rejected {
    border: 2px solid #fca5a5;
}

.status-card.suspended {
    border: 2px solid #fcd34d;
}

.status-icon {
    width: 80px;
    height: 80px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 1.5rem;
}

.status-icon svg {
    width: 40px;
    height: 40px;
}

.status-icon.pending {
    background: linear-gradient(135deg, #fef3c7, #fde68a);
    color: #d97706;
}

.status-icon.rejected {
    background: linear-gradient(135deg, #fee2e2, #fecaca);
    color: #dc2626;
}

.status-icon.suspended {
    background: linear-gradient(135deg, #fef3c7, #fde68a);
    color: #d97706;
}

.status-title {
    font-size: 1.5rem;
    font-weight: 700;
    margin-bottom: 0.75rem;
}

.status-title.pending { color: var(--gray-900); }
.status-title.rejected { color: #dc2626; }
.status-title.suspended { color: #d97706; }

.status-desc {
    color: var(--gray-600);
    line-height: 1.7;
    margin-bottom: 1.5rem;
}

.status-info-box {
    background: var(--gray-50);
    border-radius: 12px;
    padding: 1.5rem;
    text-align: left;
    margin-bottom: 1.5rem;
}

.status-info-box h4 {
    font-weight: 600;
    margin-bottom: 1rem;
    color: var(--gray-700);
    font-size: 0.9rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.status-info-box h4 svg {
    width: 18px;
    height: 18px;
}

.status-info-table {
    width: 100%;
    font-size: 0.875rem;
}

.status-info-table td {
    padding: 0.5rem 0;
}

.status-info-table td:first-child {
    color: var(--gray-500);
    width: 40%;
}

.status-info-table td:last-child {
    font-weight: 600;
    color: var(--gray-800);
}

.reject-reason-box {
    background: #fee2e2;
    border-radius: 12px;
    padding: 1.25rem;
    text-align: left;
    margin-bottom: 1.5rem;
    border: 1px solid #fca5a5;
}

.reject-reason-box strong {
    color: #dc2626;
    font-size: 0.85rem;
}

.reject-reason-box p {
    color: #7f1d1d;
    margin-top: 0.5rem;
    line-height: 1.6;
}

.status-contact {
    font-size: 0.85rem;
    color: var(--gray-500);
}

.status-contact a {
    color: var(--primary-600);
    font-weight: 600;
    text-decoration: none;
}

.status-contact a:hover {
    text-decoration: underline;
}

/* Empty State */
.empty-state {
    text-align: center;
    padding: 3rem;
}

.empty-icon {
    width: 64px;
    height: 64px;
    margin: 0 auto 1rem;
    color: var(--gray-300);
}

.empty-text {
    color: var(--gray-500);
    margin-bottom: 1.5rem;
}

/* Notification Toast Styles */
#notification-container {
    position: fixed;
    top: 80px;
    right: 20px;
    z-index: 9999;
    display: flex;
    flex-direction: column;
    gap: 10px;
    max-width: 350px;
}

@media (max-width: 1024px) {
    #notification-container {
        top: auto;
        bottom: 80px;
        left: 20px;
        right: 20px;
        max-width: none;
    }
}

.toast {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 14px 16px;
    background: white;
    border-radius: 12px;
    box-shadow: 0 10px 40px rgba(0,0,0,0.15);
    animation: slideIn 0.3s ease;
    border-left: 4px solid;
}

.toast-success { border-color: #10b981; }
.toast-warning { border-color: #f59e0b; }
.toast-info { border-color: #3b82f6; }

.toast-icon {
    width: 24px;
    height: 24px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.toast-icon svg {
    width: 14px;
    height: 14px;
}

.toast-success .toast-icon { background: #d1fae5; color: #065f46; }
.toast-warning .toast-icon { background: #fef3c7; color: #92400e; }
.toast-info .toast-icon { background: #dbeafe; color: #1e40af; }

.toast-message {
    flex: 1;
    font-size: 0.9rem;
    color: #374151;
}

.toast-close {
    background: none;
    border: none;
    font-size: 18px;
    color: #9ca3af;
    cursor: pointer;
    padding: 0;
    line-height: 1;
}

.toast-close:hover { color: #374151; }

@keyframes slideIn {
    from { transform: translateX(100%); opacity: 0; }
    to { transform: translateX(0); opacity: 1; }
}

/* Live Indicator */
#refresh-indicator {
    position: fixed;
    bottom: 20px;
    right: 20px;
    background: white;
    padding: 8px 14px;
    border-radius: 20px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 0.8rem;
    color: #6b7280;
    z-index: 100;
}

@media (max-width: 1024px) {
    #refresh-indicator {
        bottom: 80px;
    }
}

.refresh-dot {
    width: 8px;
    height: 8px;
    background: #10b981;
    border-radius: 50%;
    animation: pulse 2s infinite;
}

@keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.5; }
}

/* Spacing utilities */
.mb-4 { margin-bottom: 1rem; }
.mb-6 { margin-bottom: 1.5rem; }
</style>

<?php if ($merchantStatus === 'pending'): ?>
<!-- PENDING VERIFICATION -->
<div class="status-container">
    <div class="status-card pending">
        <div class="status-icon pending">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
            </svg>
        </div>
        <h2 class="status-title pending">Akun Sedang Direview</h2>
        <p class="status-desc">
            Terima kasih telah mendaftar di <?= APP_NAME ?>!<br>
            Tim kami sedang mereview pendaftaran Anda.<br>
            Proses ini biasanya memakan waktu <strong>1x24 jam kerja</strong>.
        </p>

        <div class="status-info-box">
            <h4>
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                </svg>
                Data Pendaftaran Anda
            </h4>
            <table class="status-info-table">
                <tr>
                    <td>Nama Bisnis</td>
                    <td><?= htmlspecialchars($merchant['business_name'] ?? '-') ?></td>
                </tr>
                <tr>
                    <td>Email</td>
                    <td><?= htmlspecialchars($merchant['email'] ?? '-') ?></td>
                </tr>
                <tr>
                    <td>Jenis Usaha</td>
                    <td><?= htmlspecialchars($merchant['business_type'] ?? '-') ?></td>
                </tr>
                <tr>
                    <td>Tanggal Daftar</td>
                    <td><?= isset($merchant['created_at']) ? date('d M Y, H:i', strtotime($merchant['created_at'])) : '-' ?></td>
                </tr>
            </table>
        </div>

        <p class="status-contact">
            Ada pertanyaan? Hubungi <a href="mailto:support@neopga.com">support@neopga.com</a>
        </p>
    </div>
</div>

<?php elseif ($merchantStatus === 'rejected'): ?>
<!-- REJECTED -->
<div class="status-container">
    <div class="status-card rejected">
        <div class="status-icon rejected">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
            </svg>
        </div>
        <h2 class="status-title rejected">Pendaftaran Ditolak</h2>
        <p class="status-desc">
            Maaf, pendaftaran Anda tidak dapat kami proses.
        </p>

        <?php if (!empty($merchant['reject_reason'])): ?>
        <div class="reject-reason-box">
            <strong>Alasan Penolakan:</strong>
            <p><?= nl2br(htmlspecialchars($merchant['reject_reason'])) ?></p>
        </div>
        <?php endif; ?>

        <p class="status-contact">
            Merasa ini kesalahan? Hubungi <a href="mailto:support@neopga.com">support@neopga.com</a>
        </p>
    </div>
</div>

<?php elseif ($merchantStatus === 'suspended'): ?>
<!-- SUSPENDED -->
<div class="status-container">
    <div class="status-card suspended">
        <div class="status-icon suspended">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 9v6m4-6v6m7-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
            </svg>
        </div>
        <h2 class="status-title suspended">Akun Disuspend</h2>
        <p class="status-desc">
            Akun Anda sedang dalam status suspend.<br>
            Anda tidak dapat menerima pembayaran untuk sementara waktu.
        </p>
        <p class="status-contact">
            Hubungi admin: <a href="mailto:support@neopga.com">support@neopga.com</a>
        </p>
    </div>
</div>

<?php else: ?>
<!-- ACTIVE MERCHANT DASHBOARD -->
<?php
// Get stats with error handling
$today = date('Y-m-d');
$thisMonth = date('Y-m');

try {
    // Today stats
    $todayStats = $db->fetch(
        "SELECT
            COUNT(*) as total,
            SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) as success,
            COALESCE(SUM(CASE WHEN status = 'success' THEN amount ELSE 0 END), 0) as amount
         FROM transactions WHERE merchant_id = ? AND DATE(created_at) = ?",
        [$merchantId, $today]
    );
    if (!$todayStats) {
        $todayStats = ['total' => 0, 'success' => 0, 'amount' => 0];
    }

    // Month stats
    $monthStats = $db->fetch(
        "SELECT
            COUNT(*) as total,
            COALESCE(SUM(CASE WHEN status = 'success' THEN amount ELSE 0 END), 0) as amount
         FROM transactions WHERE merchant_id = ? AND DATE_FORMAT(created_at, '%Y-%m') = ?",
        [$merchantId, $thisMonth]
    );
    if (!$monthStats) {
        $monthStats = ['total' => 0, 'amount' => 0];
    }

    // Available balance - use merchants.balance (already maintained by system)
    $balance = $merchant['balance'] ?? 0;

    // Pending transactions
    $pendingResult = $db->fetch("SELECT COUNT(*) as c FROM transactions WHERE merchant_id = ? AND status = 'pending'", [$merchantId]);
    $pendingTrx = $pendingResult['c'] ?? 0;

    // Recent transactions
    $recentTrx = $db->fetchAll(
        "SELECT * FROM transactions WHERE merchant_id = ? ORDER BY created_at DESC LIMIT 5",
        [$merchantId]
    ) ?: [];

    // Chart data: Last 7 days transactions
    $chartData = [];
    for ($i = 6; $i >= 0; $i--) {
        $date = date('Y-m-d', strtotime("-$i days"));
        $dayStats = $db->fetch(
            "SELECT
                COUNT(*) as total,
                SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) as success,
                COALESCE(SUM(CASE WHEN status = 'success' THEN amount ELSE 0 END), 0) as amount
             FROM transactions WHERE merchant_id = ? AND DATE(created_at) = ?",
            [$merchantId, $date]
        );
        $chartData[] = [
            'date' => date('d M', strtotime($date)),
            'total' => (int)($dayStats['total'] ?? 0),
            'success' => (int)($dayStats['success'] ?? 0),
            'amount' => (int)($dayStats['amount'] ?? 0)
        ];
    }

    // Chart data: Status breakdown (all time)
    $statusBreakdown = $db->fetchAll(
        "SELECT status, COUNT(*) as count FROM transactions WHERE merchant_id = ? GROUP BY status",
        [$merchantId]
    ) ?: [];

} catch (Exception $e) {
    // Set defaults if queries fail
    $todayStats = ['total' => 0, 'success' => 0, 'amount' => 0];
    $monthStats = ['total' => 0, 'amount' => 0];
    $balance = 0;
    $pendingTrx = 0;
    $recentTrx = [];
    $chartData = [];
    $statusBreakdown = [];
    error_log("Dashboard stats error: " . $e->getMessage());
}
?>

<!-- Welcome Section -->
<div class="welcome-section">
    <div class="welcome-text">
        <h2>Selamat datang, <?= htmlspecialchars($merchant['business_name'] ?? 'Merchant') ?>!</h2>
        <p>Berikut ringkasan aktivitas bisnis Anda hari ini</p>
    </div>
    <a href="create-payment.php" class="btn btn-primary">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
        </svg>
        <span>Buat Pembayaran</span>
    </a>
</div>

<!-- Stats Cards -->
<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-header">
            <div class="stat-icon" style="background: var(--primary-100); color: var(--primary-600);">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/>
                </svg>
            </div>
        </div>
        <div class="stat-value"><?= number_format($todayStats['total'] ?? 0) ?></div>
        <div class="stat-label">Transaksi Hari Ini</div>
    </div>

    <div class="stat-card">
        <div class="stat-header">
            <div class="stat-icon" style="background: #d1fae5; color: #065f46;">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                </svg>
            </div>
        </div>
        <div class="stat-value"><?= number_format($todayStats['success'] ?? 0) ?></div>
        <div class="stat-label">Sukses Hari Ini</div>
    </div>

    <div class="stat-card">
        <div class="stat-header">
            <div class="stat-icon" style="background: #dbeafe; color: #1e40af;">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                </svg>
            </div>
        </div>
        <div class="stat-value" style="font-size: 1.25rem;">Rp <?= number_format($todayStats['amount'] ?? 0, 0, ',', '.') ?></div>
        <div class="stat-label">Penjualan Hari Ini</div>
    </div>

    <div class="stat-card">
        <div class="stat-header">
            <div class="stat-icon" style="background: #fef3c7; color: #92400e;">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z"/>
                </svg>
            </div>
        </div>
        <div class="stat-value" style="font-size: 1.25rem;">Rp <?= number_format($balance, 0, ',', '.') ?></div>
        <div class="stat-label">Saldo Tersedia</div>
    </div>
</div>

<!-- Charts Section -->
<div class="charts-grid">
    <!-- Transaction Chart (Line) -->
    <div class="card">
        <div class="card-header">
            <h3>
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"/>
                </svg>
                Transaksi 7 Hari Terakhir
            </h3>
        </div>
        <div class="card-body" style="padding: 1rem;">
            <canvas id="transactionChart" height="200"></canvas>
        </div>
    </div>

    <!-- Status Breakdown (Doughnut) -->
    <div class="card">
        <div class="card-header">
            <h3>
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 3.055A9.001 9.001 0 1020.945 13H11V3.055z"/>
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.488 9H15V3.512A9.025 9.025 0 0120.488 9z"/>
                </svg>
                Status Transaksi
            </h3>
        </div>
        <div class="card-body" style="padding: 1rem; display: flex; align-items: center; justify-content: center;">
            <?php if (empty($statusBreakdown)): ?>
            <div class="empty-state" style="padding: 1.5rem;">
                <svg class="empty-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"/>
                </svg>
                <p class="empty-text">Belum ada data</p>
            </div>
            <?php else: ?>
            <canvas id="statusChart" height="200"></canvas>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Revenue Chart -->
<div class="card mb-6">
    <div class="card-header">
        <h3>
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
            </svg>
            Pendapatan 7 Hari Terakhir
        </h3>
    </div>
    <div class="card-body" style="padding: 1rem;">
        <canvas id="revenueChart" height="100"></canvas>
    </div>
</div>

<!-- Main Content Grid -->
<div class="main-grid">

    <!-- Recent Transactions -->
    <div class="card">
        <div class="card-header">
            <h3>
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/>
                </svg>
                Transaksi Terbaru
            </h3>
            <a href="transactions.php" class="btn btn-sm btn-secondary">Lihat Semua</a>
        </div>
        <?php if (empty($recentTrx)): ?>
        <div class="empty-state">
            <svg class="empty-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"/>
            </svg>
            <p class="empty-text">Belum ada transaksi</p>
            <a href="create-payment.php" class="btn btn-primary">Buat Pembayaran Pertama</a>
        </div>
        <?php else: ?>
        <div class="table-container">
            <table class="table">
                <thead>
                    <tr>
                        <th>Invoice</th>
                        <th>Customer</th>
                        <th>Jumlah</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recentTrx as $trx): ?>
                    <tr>
                        <td>
                            <a href="transaction-detail.php?id=<?= $trx['id'] ?>" class="invoice-link">
                                <code class="invoice-code"><?= htmlspecialchars($trx['invoice_number'] ?? '-') ?></code>
                            </a>
                        </td>
                        <td><?= htmlspecialchars($trx['customer_name'] ?? '-') ?></td>
                        <td style="font-weight: 600;">Rp <?= number_format($trx['total_amount'] ?? 0, 0, ',', '.') ?></td>
                        <td>
                            <?php
                            $status = $trx['status'] ?? 'pending';
                            switch ($status) {
                                case 'success':
                                    $statusClass = 'success';
                                    break;
                                case 'pending':
                                case 'waiting':
                                    $statusClass = 'warning';
                                    break;
                                default:
                                    $statusClass = 'danger';
                            }
                            ?>
                            <span class="badge badge-<?= $statusClass ?>"><?= ucfirst($status) ?></span>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>

    <!-- Right Sidebar -->
    <div>
        <!-- Quick Actions -->
        <div class="card mb-6">
            <div class="card-header">
                <h3>
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/>
                    </svg>
                    Aksi Cepat
                </h3>
            </div>
            <div class="card-body">
                <a href="create-payment.php" class="quick-action-btn primary">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
                    </svg>
                    <span>Buat Pembayaran</span>
                </a>
                <a href="settlements.php" class="quick-action-btn">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z"/>
                    </svg>
                    <span>Tarik Dana</span>
                </a>
                <a href="api-keys.php" class="quick-action-btn">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z"/>
                    </svg>
                    <span>Lihat API Key</span>
                </a>
            </div>
        </div>

        <!-- Account Info -->
        <div class="card mb-6">
            <div class="card-header">
                <h3>
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>
                    </svg>
                    Info Akun
                </h3>
            </div>
            <div class="card-body">
                <div class="info-item">
                    <div class="info-label">Kode Merchant</div>
                    <div class="info-value mono"><?= htmlspecialchars($merchant['merchant_code'] ?? '-') ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">Status</div>
                    <span class="badge badge-success">
                        <svg width="12" height="12" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="margin-right: 4px;">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                        </svg>
                        Active
                    </span>
                </div>
                <div class="info-item">
                    <div class="info-label">Komisi</div>
                    <div class="info-value primary"><?= number_format($merchant['commission_rate'] ?? 2.5, 1) ?>%</div>
                </div>
                <div class="info-item">
                    <div class="info-label">Transaksi Pending</div>
                    <div class="info-value"><?= $pendingTrx ?></div>
                </div>
            </div>
        </div>

        <!-- Monthly Stats -->
        <div class="card">
            <div class="card-header">
                <h3>
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                    </svg>
                    Bulan Ini
                </h3>
            </div>
            <div class="card-body">
                <div class="month-stats">
                    <div class="month-amount">Rp <?= number_format($monthStats['amount'] ?? 0, 0, ',', '.') ?></div>
                    <div class="month-count">dari <?= number_format($monthStats['total'] ?? 0) ?> transaksi</div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- API Integration Guide -->
<div class="card" style="margin-top: 1.5rem;">
    <div class="card-header">
        <h3>
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 9l3 3-3 3m5 0h3M5 20h14a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
            </svg>
            Integrasi API
        </h3>
        <a href="api-docs.php" class="btn btn-sm btn-primary">Dokumentasi Lengkap</a>
    </div>
    <div class="card-body">
        <p style="color: var(--gray-600); margin-bottom: 1.5rem;">
            Integrasikan <?= APP_NAME ?> ke website Anda untuk menerima pembayaran otomatis
        </p>
        <div class="api-steps">
            <div class="api-step">
                <div class="api-step-num">1</div>
                <div class="api-step-title">Copy API Key</div>
            </div>
            <div class="api-step">
                <div class="api-step-num">2</div>
                <div class="api-step-title">POST Request</div>
            </div>
            <div class="api-step">
                <div class="api-step-num">3</div>
                <div class="api-step-title">Redirect</div>
            </div>
            <div class="api-step">
                <div class="api-step-num">4</div>
                <div class="api-step-title">Callback</div>
            </div>
        </div>
    </div>
</div>

<?php endif; ?>

<!-- Chart.js Library -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>

<?php if ($merchantStatus === 'active'): ?>
<script>
// Chart data from PHP
const chartData = <?= json_encode($chartData) ?>;
const statusBreakdown = <?= json_encode($statusBreakdown) ?>;

// Chart.js defaults
Chart.defaults.font.family = "'Inter', -apple-system, sans-serif";
Chart.defaults.color = '#6b7280';

// 1. Transaction Line Chart
const transactionCtx = document.getElementById('transactionChart');
if (transactionCtx) {
    new Chart(transactionCtx, {
        type: 'line',
        data: {
            labels: chartData.map(d => d.date),
            datasets: [
                {
                    label: 'Total Transaksi',
                    data: chartData.map(d => d.total),
                    borderColor: '#0d9488',
                    backgroundColor: 'rgba(13, 148, 136, 0.1)',
                    tension: 0.4,
                    fill: true,
                    pointRadius: 4,
                    pointBackgroundColor: '#0d9488'
                },
                {
                    label: 'Sukses',
                    data: chartData.map(d => d.success),
                    borderColor: '#10b981',
                    backgroundColor: 'transparent',
                    tension: 0.4,
                    fill: false,
                    pointRadius: 4,
                    pointBackgroundColor: '#10b981',
                    borderDash: [5, 5]
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                    labels: { usePointStyle: true, padding: 15 }
                },
                tooltip: {
                    backgroundColor: '#1f2937',
                    padding: 12,
                    cornerRadius: 8
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { stepSize: 1 },
                    grid: { color: 'rgba(0,0,0,0.05)' }
                },
                x: {
                    grid: { display: false }
                }
            }
        }
    });
}

// 2. Status Doughnut Chart
<?php if (!empty($statusBreakdown)): ?>
const statusCtx = document.getElementById('statusChart');
if (statusCtx) {
    const statusColors = {
        'success': '#10b981',
        'pending': '#f59e0b',
        'waiting': '#3b82f6',
        'failed': '#ef4444',
        'expired': '#9ca3af',
        'cancelled': '#6b7280'
    };

    const statusLabels = {
        'success': 'Sukses',
        'pending': 'Pending',
        'waiting': 'Menunggu',
        'failed': 'Gagal',
        'expired': 'Expired',
        'cancelled': 'Dibatalkan'
    };

    new Chart(statusCtx, {
        type: 'doughnut',
        data: {
            labels: statusBreakdown.map(s => statusLabels[s.status] || s.status),
            datasets: [{
                data: statusBreakdown.map(s => parseInt(s.count)),
                backgroundColor: statusBreakdown.map(s => statusColors[s.status] || '#9ca3af'),
                borderWidth: 2,
                borderColor: '#ffffff'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '65%',
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { usePointStyle: true, padding: 15 }
                },
                tooltip: {
                    backgroundColor: '#1f2937',
                    padding: 12,
                    cornerRadius: 8,
                    callbacks: {
                        label: function(context) {
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = ((context.raw / total) * 100).toFixed(1);
                            return `${context.label}: ${context.raw} (${percentage}%)`;
                        }
                    }
                }
            }
        }
    });
}
<?php endif; ?>

// 3. Revenue Bar Chart
const revenueCtx = document.getElementById('revenueChart');
if (revenueCtx) {
    new Chart(revenueCtx, {
        type: 'bar',
        data: {
            labels: chartData.map(d => d.date),
            datasets: [{
                label: 'Pendapatan (Rp)',
                data: chartData.map(d => d.amount),
                backgroundColor: 'rgba(13, 148, 136, 0.7)',
                borderColor: '#0d9488',
                borderWidth: 1,
                borderRadius: 6,
                barThickness: 40
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: '#1f2937',
                    padding: 12,
                    cornerRadius: 8,
                    callbacks: {
                        label: function(context) {
                            return 'Rp ' + context.raw.toLocaleString('id-ID');
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: { color: 'rgba(0,0,0,0.05)' },
                    ticks: {
                        callback: function(value) {
                            if (value >= 1000000) return 'Rp ' + (value / 1000000).toFixed(1) + 'jt';
                            if (value >= 1000) return 'Rp ' + (value / 1000).toFixed(0) + 'rb';
                            return 'Rp ' + value;
                        }
                    }
                },
                x: {
                    grid: { display: false }
                }
            }
        }
    });
}

// =============================================
// Dashboard Stats Update Integration
// =============================================
// Note: Auto-refresh is handled by layout_footer.php (2-second interval)
// This integrates with MerchantAutoRefresh to update dashboard-specific elements

// Override the default updateElements function for dashboard-specific updates
if (typeof MerchantAutoRefresh !== 'undefined') {
    const originalUpdateElements = MerchantAutoRefresh.updateElements;
    MerchantAutoRefresh.updateElements = function() {
        // Call original function first
        if (typeof originalUpdateElements === 'function') {
            originalUpdateElements.call(this);
        }

        // Fetch and update dashboard stats
        fetch('api/dashboard-stats.php')
            .then(res => res.json())
            .then(data => {
                if (!data.success) return;

                const stats = data.data;

                // Update stat cards
                const statValues = document.querySelectorAll('.stat-value');
                if (statValues[0]) statValues[0].textContent = stats.today.total.toLocaleString('id-ID');
                if (statValues[1]) statValues[1].textContent = stats.today.success.toLocaleString('id-ID');
                if (statValues[2]) statValues[2].innerHTML = 'Rp ' + new Intl.NumberFormat('id-ID').format(stats.today.amount);
                if (statValues[3]) statValues[3].innerHTML = 'Rp ' + new Intl.NumberFormat('id-ID').format(stats.balance);
            })
            .catch(err => console.log('Dashboard stats update failed:', err));
    };
}
</script>

<!-- Notification Container -->
<div id="notification-container"></div>
<?php endif; ?>

<?php include __DIR__ . '/layout_footer.php'; ?>

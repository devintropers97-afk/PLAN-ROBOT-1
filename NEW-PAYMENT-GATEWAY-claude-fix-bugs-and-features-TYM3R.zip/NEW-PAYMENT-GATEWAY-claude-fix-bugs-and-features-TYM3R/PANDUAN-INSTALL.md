# 📋 PANDUAN INSTALASI NEO PGA
## Super Mudah - Tinggal Copy Paste!

---

## ⚡ INSTALASI CEPAT (5 Menit)

### Step 1: Upload
1. Extract `neopga-complete-v2.2.zip`
2. Upload folder `neopga/` ke hosting via cPanel File Manager
3. Taruh di `public_html/neopga/` atau subdomain

### Step 2: Database  
1. Buka **phpMyAdmin** di cPanel
2. Klik **New** → buat database (contoh: `situneoxx_neopga`)
3. Klik database → **Import** → pilih `DATABASE.sql` → Go

### Step 3: Konfigurasi
1. Edit file `config/config.php`
2. Ganti dengan data Anda:

```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'situneoxx_neopga');  // nama database
define('DB_USER', 'situneoxx_user');       // username database
define('DB_PASS', 'password123');          // password database

define('APP_URL', 'https://domain.com/neopga');  // URL website
```

### Step 4: Login
- **Admin:** https://domain.com/neopga/admin
- **Username:** admin
- **Password:** admin123
- ⚠️ SEGERA GANTI PASSWORD!

---

## ✅ CHECKLIST SETELAH INSTALL

- [ ] Admin bisa login
- [ ] Merchant bisa register
- [ ] Admin bisa approve merchant
- [ ] Merchant bisa buat pembayaran
- [ ] Customer bisa akses halaman bayar
- [ ] Admin bisa verifikasi transaksi
- [ ] Merchant bisa tarik saldo

---

## 🔧 TROUBLESHOOTING

### Error "Database connection failed"
→ Cek username/password database di `config/config.php`

### Halaman blank/putih
→ Cek error di cPanel → Metrics → Errors

### Login tidak bisa
→ Clear browser cache, coba incognito mode

### CSRF Token Invalid
→ Logout, clear cache, login ulang

---

## 📞 BUTUH BANTUAN?

**WhatsApp:** 0895-3434-07575
Kirim URL + akses cPanel, akan dibantu gratis!

---

*NEO PGA v2.2 - SITUNEO Digital*

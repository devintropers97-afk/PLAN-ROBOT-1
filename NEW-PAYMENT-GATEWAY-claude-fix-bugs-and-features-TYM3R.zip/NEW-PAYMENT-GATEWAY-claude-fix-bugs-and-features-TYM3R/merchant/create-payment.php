<?php
/**
 * NEO PGA Merchant - Create Payment
 * Buat pembayaran dengan pilihan metode yang tersedia
 */
require_once __DIR__ . '/../includes/init.php';

$pageTitle = 'Buat Pembayaran';
$currentPage = 'create-payment';

// Include layout header first (handles auth)
include __DIR__ . '/layout_header.php';

// Now we have $merchant, $merchantId, $db from layout_header
$createdTransaction = null;
$errors = [];

// Get active banks
$activeBanks = $db->fetchAll("SELECT * FROM bank_accounts WHERE is_active = 1 ORDER BY display_order, bank_name") ?: [];

// Check QRIS status
$qrisEnabled = true;
try {
    $qrisSetting = $db->fetch("SELECT setting_value FROM system_settings WHERE setting_key = 'qris_enabled'");
    if ($qrisSetting && $qrisSetting['setting_value'] == '0') {
        $qrisEnabled = false;
    }
} catch (Exception $e) {
    // Keep enabled if table doesn't exist
}

// Process form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verify CSRF token
    verifyCsrf();

    // Check for XSS attempts in all inputs
    $xssDetected = detectXSS($_POST['reference_id'] ?? '') ||
                   detectXSS($_POST['customer_name'] ?? '') ||
                   detectXSS($_POST['customer_email'] ?? '') ||
                   detectXSS($_POST['customer_phone'] ?? '') ||
                   detectXSS($_POST['description'] ?? '');

    if ($xssDetected) {
        $errors[] = 'Input tidak valid terdeteksi!';
    }

    $referenceId = sanitize($_POST['reference_id'] ?? '');
    $amount = (int)str_replace(['.', ',', ' '], '', $_POST['amount'] ?? 0);
    $paymentMethod = sanitize($_POST['payment_method'] ?? 'qris');
    $selectedBank = (int)($_POST['bank_id'] ?? 0);
    $customerName = sanitize($_POST['customer_name'] ?? '');
    $customerEmail = sanitize($_POST['customer_email'] ?? '');
    $customerPhone = sanitize($_POST['customer_phone'] ?? '');
    $description = sanitize($_POST['description'] ?? '');
    $expiryMinutes = (int)($_POST['expiry_minutes'] ?? 60);

    // Validation
    if (empty($referenceId)) {
        $errors[] = 'Reference ID harus diisi';
    }

    if ($amount < 1000) {
        $errors[] = 'Jumlah minimal Rp 1.000';
    }

    if ($amount > 100000000) {
        $errors[] = 'Jumlah maksimal Rp 100.000.000';
    }

    if ($paymentMethod === 'bank_transfer' && $selectedBank <= 0) {
        $errors[] = 'Pilih bank tujuan transfer';
    }

    if (empty($errors)) {
        try {
            // Use Transaction class for proper unique code handling from payment_codes pool
            $transaction = new Transaction();
            $result = $transaction->create([
                'merchant_id' => $merchantId,
                'reference_id' => $referenceId,
                'amount' => $amount,
                'payment_method' => $paymentMethod,
                'bank_account_id' => $selectedBank > 0 ? $selectedBank : null,
                'customer_name' => $customerName,
                'customer_email' => $customerEmail,
                'customer_phone' => $customerPhone,
                'description' => $description,
                'expiry_minutes' => $expiryMinutes
            ]);

            if ($result['success']) {
                $createdTransaction = [
                    'id' => $result['data']['id'],
                    'invoice_number' => $result['data']['invoice_number'],
                    'total_amount' => $result['data']['total_amount'],
                    'payment_url' => rtrim(APP_URL, '/') . '/public/pay.php?invoice=' . $result['data']['invoice_number']
                ];
            } else {
                $errors[] = $result['message'] ?? 'Gagal membuat payment';
            }

        } catch (Exception $e) {
            error_log("Create payment error: " . $e->getMessage());
            $errors[] = 'Gagal membuat payment. Silakan coba lagi.';
        }
    }
}
?>

<style>
.payment-methods { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-bottom: 1.5rem; }
.method-card { 
    background: white; 
    border: 2px solid var(--gray-200); 
    border-radius: 12px; 
    padding: 1.25rem; 
    cursor: pointer; 
    transition: all 0.2s;
    text-align: center;
}
.method-card:hover { border-color: var(--primary); }
.method-card.selected { border-color: var(--primary); background: var(--primary-50); }
.method-card.disabled { opacity: 0.5; cursor: not-allowed; }
.method-card .icon { font-size: 2rem; margin-bottom: 0.5rem; }
.method-card .name { font-weight: 600; color: var(--gray-800); }
.method-card .desc { font-size: 0.75rem; color: var(--gray-500); margin-top: 0.25rem; }
.bank-list { display: none; margin-top: 1rem; }
.bank-list.show { display: block; }
.bank-option { 
    display: flex; 
    align-items: center; 
    gap: 1rem; 
    padding: 1rem; 
    background: white; 
    border: 1px solid var(--gray-200); 
    border-radius: 10px; 
    margin-bottom: 0.5rem;
    cursor: pointer;
    transition: all 0.2s;
}
.bank-option:hover { border-color: var(--primary); }
.bank-option.selected { border-color: var(--primary); background: var(--primary-50); }
.bank-option .bank-logo { 
    width: 48px; 
    height: 48px; 
    background: var(--gray-100); 
    border-radius: 8px; 
    display: flex; 
    align-items: center; 
    justify-content: center;
    font-weight: 700;
    font-size: 0.7rem;
    color: var(--gray-600);
}
.bank-option .bank-info h4 { font-weight: 600; margin-bottom: 0.125rem; }
.bank-option .bank-info p { font-size: 0.8rem; color: var(--gray-500); margin: 0; }
.success-box { 
    background: linear-gradient(135deg, #dcfce7, #bbf7d0); 
    border: 1px solid #86efac; 
    border-radius: 16px; 
    padding: 2rem; 
    text-align: center;
    margin-bottom: 1.5rem;
}
.success-box h2 { color: #166534; margin-bottom: 0.5rem; }
.success-box .invoice { font-family: 'JetBrains Mono', monospace; font-size: 1.25rem; font-weight: 700; color: #15803d; }
.success-box .amount { font-size: 2rem; font-weight: 800; color: #166534; margin: 1rem 0; }
.payment-link { 
    background: white; 
    border: 1px solid var(--gray-300); 
    border-radius: 10px; 
    padding: 1rem; 
    display: flex; 
    align-items: center; 
    gap: 1rem;
    margin-top: 1.5rem;
}
.payment-link input { flex: 1; border: none; font-size: 0.85rem; font-family: 'JetBrains Mono', monospace; background: transparent; }
.payment-link button { background: var(--primary); color: white; border: none; padding: 0.5rem 1rem; border-radius: 6px; cursor: pointer; font-weight: 600; }
</style>

<?php if ($createdTransaction): ?>
<!-- Success View -->
<div class="success-box">
    <div style="font-size: 3rem; margin-bottom: 1rem;">✅</div>
    <h2>Pembayaran Berhasil Dibuat!</h2>
    <div class="invoice"><?= $createdTransaction['invoice_number'] ?></div>
    <div class="amount">Rp <?= number_format($createdTransaction['total_amount'], 0, ',', '.') ?></div>
</div>

<div class="card">
    <div class="card-header">
        <h3>🔗 Link Pembayaran</h3>
    </div>
    <div class="card-body">
        <p style="color: var(--gray-600); margin-bottom: 1rem;">Kirim link ini ke customer untuk melakukan pembayaran:</p>
        <div class="payment-link">
            <input type="text" id="paymentUrl" value="<?= $createdTransaction['payment_url'] ?>" readonly>
            <button onclick="copyLink()">📋 Copy</button>
        </div>
        <div style="display: flex; gap: 1rem; margin-top: 1.5rem;">
            <a href="<?= $createdTransaction['payment_url'] ?>" target="_blank" class="btn btn-primary" style="flex: 1;">
                🔗 Buka Halaman Pembayaran
            </a>
            <a href="transaction-detail.php?id=<?= $createdTransaction['id'] ?>" class="btn btn-secondary" style="flex: 1;">
                📋 Lihat Detail
            </a>
        </div>
    </div>
</div>

<div style="text-align: center; margin-top: 1.5rem;">
    <a href="create-payment.php" class="btn btn-secondary">➕ Buat Pembayaran Lagi</a>
</div>

<script>
function copyLink() {
    const input = document.getElementById('paymentUrl');
    input.select();
    document.execCommand('copy');
    alert('Link berhasil dicopy!');
}
</script>

<?php else: ?>
<!-- Create Form -->
<?php if (!empty($errors)): ?>
<div class="alert alert-danger" style="margin-bottom: 1.5rem;">
    ❌ <?= implode('<br>', $errors) ?>
</div>
<?php endif; ?>

<form method="POST">
    <?= csrfField() ?>
    <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 1.5rem;">
        <!-- Left Column -->
        <div>
            <!-- Payment Method -->
            <div class="card mb-6">
                <div class="card-header">
                    <h3>💳 Pilih Metode Pembayaran</h3>
                </div>
                <div class="card-body">
                    <div class="payment-methods">
                        <?php if ($qrisEnabled): ?>
                        <label class="method-card selected" onclick="selectMethod('qris')">
                            <input type="radio" name="payment_method" value="qris" checked style="display: none;">
                            <div class="icon">📱</div>
                            <div class="name">QRIS</div>
                            <div class="desc">GoPay, OVO, DANA, dll</div>
                        </label>
                        <?php endif; ?>
                        
                        <?php if (!empty($activeBanks)): ?>
                        <label class="method-card" onclick="selectMethod('bank_transfer')">
                            <input type="radio" name="payment_method" value="bank_transfer" style="display: none;">
                            <div class="icon">🏦</div>
                            <div class="name">Transfer Bank</div>
                            <div class="desc"><?= count($activeBanks) ?> bank tersedia</div>
                        </label>
                        <?php endif; ?>
                    </div>
                    
                    <?php if (empty($activeBanks) && !$qrisEnabled): ?>
                    <div style="text-align: center; padding: 2rem; color: var(--gray-500);">
                        <div style="font-size: 2rem; margin-bottom: 0.5rem;">⚠️</div>
                        <p>Tidak ada metode pembayaran yang aktif.<br>Hubungi admin untuk mengaktifkan.</p>
                    </div>
                    <?php endif; ?>
                    
                    <!-- Bank List (shown when bank_transfer selected) -->
                    <?php if (!empty($activeBanks)): ?>
                    <div class="bank-list" id="bankList">
                        <h4 style="font-weight: 600; margin-bottom: 1rem; color: var(--gray-700);">Pilih Bank Tujuan:</h4>
                        <?php foreach ($activeBanks as $bank): ?>
                        <label class="bank-option" onclick="selectBank(<?= $bank['id'] ?>)">
                            <input type="radio" name="bank_id" value="<?= $bank['id'] ?>" style="display: none;">
                            <div class="bank-logo"><?= strtoupper(substr($bank['bank_code'] ?: $bank['bank_name'], 0, 3)) ?></div>
                            <div class="bank-info">
                                <h4><?= htmlspecialchars($bank['bank_name']) ?></h4>
                                <p><?= htmlspecialchars($bank['account_number']) ?> - <?= htmlspecialchars($bank['account_name']) ?></p>
                            </div>
                        </label>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Payment Details -->
            <div class="card">
                <div class="card-header">
                    <h3>📝 Detail Pembayaran</h3>
                </div>
                <div class="card-body">
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                        <div class="form-group">
                            <label class="form-label">Reference ID *</label>
                            <input type="text" name="reference_id" class="form-input" placeholder="ORDER-001" required value="<?= htmlspecialchars($_POST['reference_id'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Jumlah (Rp) *</label>
                            <input type="text" name="amount" id="amountInput" class="form-input" placeholder="100000" required value="<?= htmlspecialchars($_POST['amount'] ?? '') ?>">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Deskripsi</label>
                        <input type="text" name="description" class="form-input" placeholder="Pembelian Produk ABC" value="<?= htmlspecialchars($_POST['description'] ?? '') ?>">
                    </div>
                    
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                        <div class="form-group">
                            <label class="form-label">Nama Customer</label>
                            <input type="text" name="customer_name" class="form-input" placeholder="John Doe" value="<?= htmlspecialchars($_POST['customer_name'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Email Customer</label>
                            <input type="email" name="customer_email" class="form-input" placeholder="john@email.com" value="<?= htmlspecialchars($_POST['customer_email'] ?? '') ?>">
                        </div>
                    </div>
                    
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                        <div class="form-group">
                            <label class="form-label">No. HP Customer</label>
                            <input type="text" name="customer_phone" class="form-input" placeholder="08123456789" value="<?= htmlspecialchars($_POST['customer_phone'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Kadaluarsa (menit)</label>
                            <select name="expiry_minutes" class="form-select">
                                <option value="30">30 menit</option>
                                <option value="60" selected>1 jam</option>
                                <option value="180">3 jam</option>
                                <option value="360">6 jam</option>
                                <option value="720">12 jam</option>
                                <option value="1440">24 jam</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Right Column - Summary -->
        <div>
            <div class="card" style="position: sticky; top: 100px;">
                <div class="card-header">
                    <h3>📊 Ringkasan</h3>
                </div>
                <div class="card-body">
                    <div style="margin-bottom: 1rem;">
                        <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
                            <span style="color: var(--gray-600);">Subtotal</span>
                            <span id="subtotalDisplay">Rp 0</span>
                        </div>
                        <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
                            <span style="color: var(--gray-600);">Kode Unik</span>
                            <span style="color: var(--primary);">+Rp XXX</span>
                        </div>
                        <div style="display: flex; justify-content: space-between; padding-top: 0.75rem; border-top: 1px solid var(--gray-200);">
                            <span style="font-weight: 600;">Total</span>
                            <span style="font-weight: 700; font-size: 1.25rem; color: var(--primary);" id="totalDisplay">Rp 0</span>
                        </div>
                    </div>
                    
                    <div style="background: var(--gray-50); border-radius: 8px; padding: 1rem; margin-bottom: 1.5rem;">
                        <div style="font-size: 0.8rem; color: var(--gray-600);">
                            <strong>Komisi Anda:</strong> <?= number_format($merchant['commission_rate'] ?? 2.5, 1) ?>%
                        </div>
                    </div>
                    
                    <button type="submit" class="btn btn-primary" style="width: 100%;">
                        ✨ Buat Link Pembayaran
                    </button>
                </div>
            </div>
        </div>
    </div>
</form>

<script>
function selectMethod(method) {
    document.querySelectorAll('.method-card').forEach(card => card.classList.remove('selected'));
    document.querySelector(`input[value="${method}"]`).closest('.method-card').classList.add('selected');
    document.querySelector(`input[value="${method}"]`).checked = true;
    
    const bankList = document.getElementById('bankList');
    if (bankList) {
        bankList.classList.toggle('show', method === 'bank_transfer');
    }
}

function selectBank(bankId) {
    document.querySelectorAll('.bank-option').forEach(opt => opt.classList.remove('selected'));
    document.querySelector(`input[value="${bankId}"]`).closest('.bank-option').classList.add('selected');
    document.querySelector(`input[value="${bankId}"]`).checked = true;
}

// Format amount input
const amountInput = document.getElementById('amountInput');
amountInput.addEventListener('input', function(e) {
    let value = this.value.replace(/[^\d]/g, '');
    if (value) {
        this.value = parseInt(value).toLocaleString('id-ID');
        updateSummary(parseInt(value));
    } else {
        updateSummary(0);
    }
});

function updateSummary(amount) {
    document.getElementById('subtotalDisplay').textContent = 'Rp ' + amount.toLocaleString('id-ID');
    document.getElementById('totalDisplay').textContent = 'Rp ' + (amount > 0 ? (amount + 100).toLocaleString('id-ID') + '+' : '0');
}
</script>
<?php endif; ?>

<?php include __DIR__ . '/layout_footer.php'; ?>

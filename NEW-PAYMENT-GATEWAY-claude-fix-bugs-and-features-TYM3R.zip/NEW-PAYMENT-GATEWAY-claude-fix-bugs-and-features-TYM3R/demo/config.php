<?php
/**
 * ============================================
 * DIGISTORE - FILE KONFIGURASI
 * ============================================
 * 
 * File ini berisi semua pengaturan yang dibutuhkan.
 * Cukup edit file ini saja, file lain akan mengikuti.
 * 
 * 📁 Lokasi: /config.php
 */

// =====================================================
// 🔐 KREDENSIAL NEO PGA
// =====================================================
// Dapatkan dari Dashboard Merchant NEO PGA → API Keys

define('NEOPGA_URL', 'https://your-neopga-domain.com');  // GANTI INI!
define('NEOPGA_API_KEY', 'GANTI_DENGAN_API_KEY_ANDA');  // GANTI INI!
define('NEOPGA_SECRET_KEY', 'GANTI_DENGAN_SECRET_KEY_ANDA');  // GANTI INI!

// =====================================================
// 🌐 URL TOKO KAMU
// =====================================================

define('STORE_URL', 'https://your-store-domain.com');  // GANTI INI!

// URL untuk webhook dan callback
define('WEBHOOK_URL', STORE_URL . '/webhook.php');
define('SUCCESS_URL', STORE_URL . '/success.php');

// =====================================================
// 🏪 INFORMASI TOKO
// =====================================================

define('STORE_NAME', 'DigiStore');  // Ganti dengan nama toko Anda
define('STORE_EMAIL', 'support@your-domain.com');  // GANTI INI!
define('STORE_WHATSAPP', '628xxxxxxxxxx');  // GANTI INI!

// =====================================================
// 📁 PENYIMPANAN DATA
// =====================================================

define('DATA_DIR', __DIR__ . '/data');
define('ORDERS_FILE', DATA_DIR . '/orders.json');
define('LOG_FILE', DATA_DIR . '/webhook.log');

// =====================================================
// 💰 PENGATURAN PRODUK
// =====================================================

$PRODUCTS = [
    // ========== TEST PRODUCT ==========
    'test-product' => [
        'name' => 'Test Product',
        'price' => 1000,  // Rp 1.000 untuk testing
        'description' => 'Produk test untuk coba pembayaran',
        'download_url' => '#',
        'category' => 'Test',
        'icon' => '🧪',
        'badge' => 'Test',
        'visual_class' => 'test',
        'type' => 'digital'  // digital = harga fixed
    ],
    
    // ========== DIGITAL PRODUCTS ==========
    'ui-kit-pro' => [
        'name' => 'UI Kit Pro Bundle',
        'price' => 150000,
        'description' => '500+ komponen UI siap pakai untuk Figma & Sketch',
        'download_url' => 'https://drive.google.com/file/xxx',
        'category' => 'Design Assets',
        'icon' => '🎨',
        'badge' => 'Best Seller',
        'visual_class' => 'design',
        'type' => 'digital'
    ],
    'laravel-starter' => [
        'name' => 'Laravel Starter Kit',
        'price' => 299000,
        'description' => 'Boilerplate lengkap dengan auth, dashboard admin, API ready',
        'download_url' => 'https://drive.google.com/file/yyy',
        'category' => 'Source Code',
        'icon' => '💻',
        'badge' => 'New',
        'visual_class' => 'code',
        'type' => 'digital'
    ],
    'business-template' => [
        'name' => 'Business Plan Template',
        'price' => 75000,
        'description' => 'Template pitch deck profesional dengan 50+ slide',
        'download_url' => 'https://drive.google.com/file/zzz',
        'category' => 'Template',
        'icon' => '📊',
        'badge' => '',
        'visual_class' => 'business',
        'type' => 'digital'
    ],
    
    // ========== TOP UP GAME (Input Manual) ==========
    'topup-ml' => [
        'name' => 'Top Up Mobile Legends',
        'price' => 0,  // 0 = input manual
        'description' => 'Top up diamond Mobile Legends. Masukkan nominal sendiri.',
        'download_url' => '',
        'category' => 'Game Top Up',
        'icon' => '🎮',
        'badge' => 'Top Up',
        'visual_class' => 'game',
        'type' => 'topup',  // topup = input manual
        'min_amount' => 5000,
        'max_amount' => 5000000
    ],
    'topup-ff' => [
        'name' => 'Top Up Free Fire',
        'price' => 0,
        'description' => 'Top up diamond Free Fire. Masukkan nominal sendiri.',
        'download_url' => '',
        'category' => 'Game Top Up',
        'icon' => '🔥',
        'badge' => 'Top Up',
        'visual_class' => 'game',
        'type' => 'topup',
        'min_amount' => 5000,
        'max_amount' => 5000000
    ],
    'topup-pubg' => [
        'name' => 'Top Up PUBG Mobile',
        'price' => 0,
        'description' => 'Top up UC PUBG Mobile. Masukkan nominal sendiri.',
        'download_url' => '',
        'category' => 'Game Top Up',
        'icon' => '🎯',
        'badge' => 'Top Up',
        'visual_class' => 'game',
        'type' => 'topup',
        'min_amount' => 5000,
        'max_amount' => 5000000
    ]
];

// =====================================================
// 🛠️ FUNGSI HELPER
// =====================================================

/**
 * Buat folder data jika belum ada
 */
function initDataDir() {
    if (!file_exists(DATA_DIR)) {
        mkdir(DATA_DIR, 0755, true);
    }
    
    $htaccess = DATA_DIR . '/.htaccess';
    if (!file_exists($htaccess)) {
        file_put_contents($htaccess, "Deny from all");
    }
    
    if (!file_exists(ORDERS_FILE)) {
        file_put_contents(ORDERS_FILE, json_encode([], JSON_PRETTY_PRINT));
    }
}

/**
 * Simpan pesanan baru
 */
function saveOrder($orderData) {
    initDataDir();
    $orders = json_decode(file_get_contents(ORDERS_FILE), true) ?: [];
    $orders[$orderData['order_id']] = $orderData;
    file_put_contents(ORDERS_FILE, json_encode($orders, JSON_PRETTY_PRINT));
    return true;
}

/**
 * Ambil data pesanan berdasarkan order_id
 */
function getOrder($orderId) {
    if (!file_exists(ORDERS_FILE)) return null;
    $orders = json_decode(file_get_contents(ORDERS_FILE), true) ?: [];
    return $orders[$orderId] ?? null;
}

/**
 * Ambil pesanan berdasarkan invoice number
 */
function getOrderByInvoice($invoiceNumber) {
    if (!file_exists(ORDERS_FILE)) return null;
    $orders = json_decode(file_get_contents(ORDERS_FILE), true) ?: [];
    foreach ($orders as $order) {
        if (($order['invoice_number'] ?? '') === $invoiceNumber) {
            return $order;
        }
    }
    return null;
}

/**
 * Update status pesanan
 */
function updateOrderStatus($orderId, $status, $additionalData = []) {
    if (!file_exists(ORDERS_FILE)) return false;
    $orders = json_decode(file_get_contents(ORDERS_FILE), true) ?: [];
    if (!isset($orders[$orderId])) return false;
    
    $orders[$orderId]['status'] = $status;
    $orders[$orderId]['updated_at'] = date('Y-m-d H:i:s');
    
    foreach ($additionalData as $key => $value) {
        $orders[$orderId][$key] = $value;
    }
    
    file_put_contents(ORDERS_FILE, json_encode($orders, JSON_PRETTY_PRINT));
    return true;
}

/**
 * Tulis log webhook
 */
function writeLog($message, $data = []) {
    initDataDir();
    $timestamp = date('Y-m-d H:i:s');
    $logEntry = "[{$timestamp}] {$message}";
    if (!empty($data)) {
        $logEntry .= " | Data: " . json_encode($data);
    }
    $logEntry .= "\n";
    file_put_contents(LOG_FILE, $logEntry, FILE_APPEND);
}

/**
 * Sanitize input string untuk keamanan
 */
function sanitize($input) {
    if (is_array($input)) {
        return array_map('sanitize', $input);
    }
    return htmlspecialchars(trim($input ?? ''), ENT_QUOTES, 'UTF-8');
}

/**
 * Format angka ke Rupiah
 */
function formatRupiah($amount) {
    return 'Rp ' . number_format($amount, 0, ',', '.');
}

/**
 * Generate Order ID unik
 */
function generateOrderId() {
    return 'DGS-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -6));
}

/**
 * Verifikasi signature webhook dari NEO PGA
 */
function verifyWebhookSignature($payload, $signature) {
    $expectedSignature = hash_hmac('sha256', $payload, NEOPGA_SECRET_KEY);
    return hash_equals($expectedSignature, $signature);
}

/**
 * Kirim request ke API NEO PGA
 */
function callNeoPGAAPI($endpoint, $method = 'GET', $data = []) {
    $url = NEOPGA_URL . $endpoint;

    $ch = curl_init();
    $options = [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'X-API-Key: ' . NEOPGA_API_KEY
        ],
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYPEER => false
    ];

    if ($method === 'POST') {
        $options[CURLOPT_POST] = true;
        $options[CURLOPT_POSTFIELDS] = json_encode($data);
    }

    curl_setopt_array($ch, $options);
    $response = curl_exec($ch);
    $error = curl_error($ch);
    curl_close($ch);

    if ($error) {
        return ['success' => false, 'message' => 'Connection error: ' . $error];
    }

    $result = json_decode($response, true);
    return $result ?: ['success' => false, 'message' => 'Invalid response'];
}

// Inisialisasi
initDataDir();

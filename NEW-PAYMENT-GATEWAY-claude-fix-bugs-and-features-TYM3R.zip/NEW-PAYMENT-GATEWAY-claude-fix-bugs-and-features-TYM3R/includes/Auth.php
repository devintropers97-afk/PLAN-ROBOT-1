<?php
/**
 * NEO PGA Authentication Class
 * Handles admin and merchant authentication
 */

class Auth
{
    private $db;
    private $userType; // 'admin' or 'merchant'
    private $sessionKey;

    public function __construct(string $userType = 'merchant')
    {
        $this->db = db();
        $this->userType = $userType;
        $this->sessionKey = $userType === 'admin' ? 'admin_user' : 'merchant_user';
    }

    /**
     * Attempt login
     */
    public function attempt(string $email, string $password, bool $remember = false): array
    {
        $table = $this->userType === 'admin' ? 'admins' : 'merchants';
        $statusField = $this->userType === 'admin' ? 'is_active' : 'status';
        
        // Find user
        $user = $this->db->findBy($table, ['email' => $email]);
        
        if (!$user) {
            return ['success' => false, 'message' => 'Email tidak terdaftar'];
        }

        // Check status
        if ($this->userType === 'admin' && !$user['is_active']) {
            return ['success' => false, 'message' => 'Akun tidak aktif'];
        }
        
        if ($this->userType === 'merchant' && $user['status'] !== 'active') {
            $statusMessages = [
                'pending' => 'Akun menunggu verifikasi',
                'suspended' => 'Akun dinonaktifkan sementara',
                'banned' => 'Akun diblokir'
            ];
            return ['success' => false, 'message' => $statusMessages[$user['status']] ?? 'Status akun tidak valid'];
        }

        // Verify password
        if (!password_verify($password, $user['password'])) {
            $this->logActivity('login_failed', 'Percobaan login gagal');
            return ['success' => false, 'message' => 'Password salah'];
        }

        // Set session
        $this->setUserSession($user);

        // Update last login
        $this->db->update($table, [
            'last_login' => date('Y-m-d H:i:s'),
            'login_ip' => $this->getClientIP()
        ], 'id = ?', [$user['id']]);

        // Handle remember me
        if ($remember) {
            $this->setRememberToken($user['id']);
        }

        $this->logActivity('login_success', 'Login berhasil');

        return ['success' => true, 'message' => 'Login berhasil', 'user' => $user];
    }

    /**
     * Set user session
     */
    private function setUserSession(array $user): void
    {
        unset($user['password'], $user['secret_key'], $user['two_factor_secret']);
        $_SESSION[$this->sessionKey] = $user;
        $_SESSION[$this->sessionKey . '_time'] = time();
        
        // Regenerate session ID for security
        session_regenerate_id(true);
    }

    /**
     * Check if user is logged in
     */
    public function check(): bool
    {
        if (!isset($_SESSION[$this->sessionKey])) {
            return $this->checkRememberToken();
        }

        // Check session expiry
        $sessionTime = $_SESSION[$this->sessionKey . '_time'] ?? 0;
        if (time() - $sessionTime > SESSION_LIFETIME) {
            $this->logout();
            return false;
        }

        return true;
    }

    /**
     * Get logged in user
     */
    public function user(): ?array
    {
        if (!$this->check()) {
            return null;
        }
        return $_SESSION[$this->sessionKey] ?? null;
    }

    /**
     * Get user ID
     */
    public function id(): ?int
    {
        $user = $this->user();
        return $user ? (int) $user['id'] : null;
    }

    /**
     * Logout user
     */
    public function logout(): void
    {
        $userId = $this->id();
        
        if ($userId) {
            // Clear remember token
            $table = $this->userType === 'admin' ? 'admins' : 'merchants';
            $this->db->update($table, ['remember_token' => null], 'id = ?', [$userId]);
            
            $this->logActivity('logout', 'Logout berhasil');
        }

        // Clear session
        unset($_SESSION[$this->sessionKey], $_SESSION[$this->sessionKey . '_time']);
        
        // Clear remember cookie
        if (isset($_COOKIE['remember_' . $this->userType])) {
            setcookie('remember_' . $this->userType, '', time() - 3600, '/');
        }
    }

    /**
     * Set remember token
     */
    private function setRememberToken(int $userId): void
    {
        $token = bin2hex(random_bytes(32));
        $hashedToken = hash('sha256', $token);
        
        $table = $this->userType === 'admin' ? 'admins' : 'merchants';
        $this->db->update($table, ['remember_token' => $hashedToken], 'id = ?', [$userId]);
        
        // Set cookie for 30 days
        setcookie(
            'remember_' . $this->userType,
            $userId . '|' . $token,
            time() + (30 * 24 * 60 * 60),
            '/',
            '',
            APP_ENV === 'production',
            true
        );
    }

    /**
     * Check remember token
     */
    private function checkRememberToken(): bool
    {
        $cookieName = 'remember_' . $this->userType;
        
        if (!isset($_COOKIE[$cookieName])) {
            return false;
        }

        $parts = explode('|', $_COOKIE[$cookieName]);
        if (count($parts) !== 2) {
            return false;
        }

        [$userId, $token] = $parts;
        $hashedToken = hash('sha256', $token);
        
        $table = $this->userType === 'admin' ? 'admins' : 'merchants';
        $user = $this->db->find($table, (int) $userId);

        if (!$user || $user['remember_token'] !== $hashedToken) {
            setcookie($cookieName, '', time() - 3600, '/');
            return false;
        }

        $this->setUserSession($user);
        return true;
    }

    /**
     * Update password
     */
    public function updatePassword(int $userId, string $newPassword): bool
    {
        $table = $this->userType === 'admin' ? 'admins' : 'merchants';
        $hashedPassword = password_hash($newPassword, PASSWORD_BCRYPT, ['cost' => HASH_COST]);
        
        return $this->db->update($table, [
            'password' => $hashedPassword,
            'password_changed_at' => date('Y-m-d H:i:s')
        ], 'id = ?', [$userId]) > 0;
    }

    /**
     * Verify current password
     */
    public function verifyPassword(string $password): bool
    {
        $table = $this->userType === 'admin' ? 'admins' : 'merchants';
        $user = $this->db->find($table, $this->id());
        
        return $user && password_verify($password, $user['password']);
    }

    /**
     * Check if user has role (admin only)
     */
    public function hasRole(string $role): bool
    {
        if ($this->userType !== 'admin') {
            return false;
        }
        
        $user = $this->user();
        return $user && $user['role'] === $role;
    }

    /**
     * Check if user is super admin
     */
    public function isSuperAdmin(): bool
    {
        return $this->hasRole('super_admin');
    }

    /**
     * Create password reset token
     */
    public function createPasswordResetToken(string $email): ?string
    {
        $table = $this->userType === 'admin' ? 'admins' : 'merchants';
        $user = $this->db->findBy($table, ['email' => $email]);
        
        if (!$user) {
            return null;
        }

        $token = bin2hex(random_bytes(32));
        
        // Delete old tokens
        $this->db->delete('password_resets', 'email = ? AND user_type = ?', [$email, $this->userType]);
        
        // Insert new token
        $this->db->insert('password_resets', [
            'email' => $email,
            'token' => hash('sha256', $token),
            'user_type' => $this->userType,
            'expires_at' => date('Y-m-d H:i:s', strtotime('+1 hour'))
        ]);

        return $token;
    }

    /**
     * Verify password reset token
     */
    public function verifyPasswordResetToken(string $token): ?array
    {
        $hashedToken = hash('sha256', $token);
        
        $reset = $this->db->findBy('password_resets', [
            'token' => $hashedToken,
            'user_type' => $this->userType
        ]);

        if (!$reset) {
            return null;
        }

        if (strtotime($reset['expires_at']) < time()) {
            return null;
        }

        if ($reset['used_at']) {
            return null;
        }

        return $reset;
    }

    /**
     * Reset password with token
     */
    public function resetPassword(string $token, string $newPassword): bool
    {
        $reset = $this->verifyPasswordResetToken($token);
        
        if (!$reset) {
            return false;
        }

        $table = $this->userType === 'admin' ? 'admins' : 'merchants';
        $user = $this->db->findBy($table, ['email' => $reset['email']]);
        
        if (!$user) {
            return false;
        }

        // Update password
        $this->updatePassword($user['id'], $newPassword);
        
        // Mark token as used
        $this->db->update('password_resets', [
            'used_at' => date('Y-m-d H:i:s')
        ], 'id = ?', [$reset['id']]);

        return true;
    }

    /**
     * Log activity
     */
    private function logActivity(string $action, string $description): void
    {
        $this->db->insert('activity_logs', [
            'user_type' => $this->userType,
            'user_id' => $this->id(),
            'action' => $action,
            'module' => 'auth',
            'description' => $description,
            'ip_address' => $this->getClientIP(),
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? null
        ]);
    }

    /**
     * Get client IP
     */
    private function getClientIP(): string
    {
        $headers = ['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'REMOTE_ADDR'];
        
        foreach ($headers as $header) {
            if (!empty($_SERVER[$header])) {
                $ips = explode(',', $_SERVER[$header]);
                return trim($ips[0]);
            }
        }
        
        return '0.0.0.0';
    }

    /**
     * Require authentication (redirect if not logged in)
     */
    public function requireAuth(): void
    {
        if (!$this->check()) {
            $loginUrl = $this->userType === 'admin' ? ADMIN_URL . '/login.php' : MERCHANT_URL . '/login.php';
            header('Location: ' . $loginUrl);
            exit;
        }
    }

    /**
     * Require guest (redirect if logged in)
     */
    public function requireGuest(): void
    {
        if ($this->check()) {
            $dashboardUrl = $this->userType === 'admin' ? ADMIN_URL . '/index.php' : MERCHANT_URL . '/index.php';
            header('Location: ' . $dashboardUrl);
            exit;
        }
    }
}

<?php
/**
 * Plugin Name: NEO PGA Payment Gateway
 * Description: Terima pembayaran online di WordPress dengan mudah!
 * Version: 1.0
 * Author: NEO PGA
 *
 * ================================================================================
 *                    NEO PGA UNTUK WORDPRESS
 * ================================================================================
 *
 * CARA PAKAI:
 * 1. Upload file ini ke folder wp-content/plugins/
 * 2. Aktifkan plugin di Dashboard WordPress > Plugins
 * 3. Ganti API_KEY dan SECRET_KEY di bawah
 * 4. Pakai shortcode [neopga] di halaman/post mana saja
 *
 * CONTOH SHORTCODE:
 * [neobayar produk="Kaos Polos" harga="150000"]
 * [neobayar produk="Ebook" harga="50000" metode="qris"]
 *
 * ================================================================================
 */

// ===== GANTI INI DENGAN PUNYA KAMU =====
define('NB_API_KEY', 'YOUR_API_KEY_HERE');
define('NB_SECRET_KEY', 'YOUR_SECRET_KEY_HERE');
define('NB_URL', 'https://domain-neopga.com');
// ========================================

// Jangan edit di bawah ini kecuali kamu tahu apa yang dilakukan
// ================================================================================

// Shortcode untuk form pembayaran
add_shortcode('neobayar', 'neobayar_form_shortcode');

function neobayar_form_shortcode($atts) {
    $atts = shortcode_atts([
        'produk' => 'Produk',
        'harga' => '100000',
        'metode' => 'qris'
    ], $atts);

    $harga_format = number_format((int)$atts['harga'], 0, ',', '.');

    ob_start();
    ?>
    <style>
        .nb-form { max-width: 400px; margin: 20px auto; padding: 30px; background: #fff; border-radius: 16px; box-shadow: 0 4px 20px rgba(0,0,0,0.1); }
        .nb-form h3 { margin: 0 0 20px; text-align: center; color: #1a1a1a; }
        .nb-form .nb-group { margin-bottom: 16px; }
        .nb-form label { display: block; margin-bottom: 6px; font-weight: 500; color: #374151; }
        .nb-form input { width: 100%; padding: 12px; border: 2px solid #e5e7eb; border-radius: 10px; font-size: 16px; box-sizing: border-box; }
        .nb-form input:focus { outline: none; border-color: #0d9488; }
        .nb-form .nb-harga { text-align: center; font-size: 28px; font-weight: 800; color: #0d9488; margin: 20px 0; }
        .nb-form .nb-btn { width: 100%; padding: 16px; background: linear-gradient(135deg, #0d9488, #0f766e); color: #fff; border: none; border-radius: 12px; font-size: 18px; font-weight: 600; cursor: pointer; }
        .nb-form .nb-btn:hover { opacity: 0.9; }
        .nb-form .nb-secure { text-align: center; margin-top: 16px; color: #6b7280; font-size: 12px; }
    </style>
    <form class="nb-form" method="POST" action="">
        <h3>Pembayaran</h3>

        <input type="hidden" name="nb_action" value="create_payment">
        <input type="hidden" name="nb_produk" value="<?php echo esc_attr($atts['produk']); ?>">
        <input type="hidden" name="nb_harga" value="<?php echo esc_attr($atts['harga']); ?>">
        <input type="hidden" name="nb_metode" value="<?php echo esc_attr($atts['metode']); ?>">

        <div class="nb-group">
            <label>Produk</label>
            <input type="text" value="<?php echo esc_attr($atts['produk']); ?>" readonly>
        </div>

        <div class="nb-harga">Rp <?php echo $harga_format; ?></div>

        <div class="nb-group">
            <label>Nama Lengkap</label>
            <input type="text" name="nb_nama" placeholder="Nama kamu" required>
        </div>

        <div class="nb-group">
            <label>Email</label>
            <input type="email" name="nb_email" placeholder="email@contoh.com" required>
        </div>

        <div class="nb-group">
            <label>No. HP</label>
            <input type="tel" name="nb_hp" placeholder="08123456789" required>
        </div>

        <button type="submit" class="nb-btn">Bayar Sekarang</button>
        <div class="nb-secure">🔒 Pembayaran aman & terenkripsi</div>
    </form>
    <?php
    return ob_get_clean();
}

// Handle form submission
add_action('init', 'neobayar_handle_payment');

function neobayar_handle_payment() {
    if (!isset($_POST['nb_action']) || $_POST['nb_action'] !== 'create_payment') {
        return;
    }

    $data = [
        'reference_id' => 'WP-' . time() . '-' . wp_rand(1000, 9999),
        'amount' => (int)$_POST['nb_harga'],
        'payment_method' => sanitize_text_field($_POST['nb_metode']),
        'description' => sanitize_text_field($_POST['nb_produk']),
        'customer_name' => sanitize_text_field($_POST['nb_nama']),
        'customer_email' => sanitize_email($_POST['nb_email']),
        'customer_phone' => sanitize_text_field($_POST['nb_hp']),
        'expiry_minutes' => 60
    ];

    $jsonData = json_encode($data);
    $signature = hash_hmac('sha256', $jsonData, NB_SECRET_KEY);

    $response = wp_remote_post(NB_URL . '/api/create.php', [
        'headers' => [
            'Content-Type' => 'application/json',
            'X-API-Key' => NB_API_KEY,
            'X-Signature' => $signature
        ],
        'body' => $jsonData,
        'timeout' => 30
    ]);

    if (is_wp_error($response)) {
        wp_die('Error: Gagal terhubung ke payment gateway');
    }

    $result = json_decode(wp_remote_retrieve_body($response), true);

    if ($result && $result['success'] && isset($result['data']['payment_url'])) {
        wp_redirect($result['data']['payment_url']);
        exit;
    } else {
        $error = $result['error'] ?? 'Gagal membuat pembayaran';
        wp_die('Error: ' . esc_html($error));
    }
}

// Callback endpoint
add_action('rest_api_init', function() {
    register_rest_route('neobayar/v1', '/callback', [
        'methods' => 'POST',
        'callback' => 'neobayar_callback_handler',
        'permission_callback' => '__return_true'
    ]);
});

function neobayar_callback_handler($request) {
    $rawData = $request->get_body();
    $data = json_decode($rawData, true);

    if (!$data) {
        return new WP_Error('no_data', 'No data received', ['status' => 400]);
    }

    // Verify signature
    $signature = $request->get_header('X-Signature');
    $expectedSignature = hash_hmac('sha256', $rawData, NB_SECRET_KEY);

    if (!hash_equals($expectedSignature, $signature ?? '')) {
        return new WP_Error('invalid_signature', 'Invalid signature', ['status' => 401]);
    }

    $invoice = $data['invoice_number'] ?? '';
    $orderId = $data['reference_id'] ?? '';
    $status = $data['status'] ?? '';

    // Log payment
    error_log("NEO PGA Callback: Invoice=$invoice, Order=$orderId, Status=$status");

    // You can add custom logic here, e.g., update WooCommerce order, send email, etc.
    do_action('neobayar_payment_received', $data);

    if ($status === 'success') {
        do_action('neobayar_payment_success', $data);
    }

    return ['success' => true, 'message' => 'OK'];
}

// Add settings link
add_filter('plugin_action_links_' . plugin_basename(__FILE__), function($links) {
    $links[] = '<a href="https://github.com/NEO PGA/docs">Dokumentasi</a>';
    return $links;
});

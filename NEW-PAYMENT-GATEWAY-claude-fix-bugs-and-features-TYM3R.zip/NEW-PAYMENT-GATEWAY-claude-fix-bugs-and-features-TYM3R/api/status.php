<?php
/**
 * NEO PGA API - Check Transaction Status
 * 
 * GET /api/status.php?invoice=INV123
 * or
 * GET /api/status.php?reference_id=ORDER-123
 * 
 * Headers:
 *   X-API-Key: your_api_key
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-API-Key');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Config loaded via init.php (includes RateLimiter)
require_once __DIR__ . '/../includes/init.php';

$startTime = microtime(true);

// IP-based rate limiting (120 requests/minute - more lenient for status checks)
checkIpRateLimit(120, 60);

// Only GET allowed
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

// Get API Key
$apiKey = $_SERVER['HTTP_X_API_KEY'] ?? '';

if (empty($apiKey)) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'API key required']);
    exit;
}

$db = Database::getInstance();

// Validate merchant
$merchant = $db->fetch("SELECT * FROM merchants WHERE api_key = ? AND status = 'active'", [$apiKey]);

if (!$merchant) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Invalid or inactive API key']);
    exit;
}

// API key based rate limiting (200 requests/minute for status checks)
checkApiKeyRateLimit($apiKey, 200, 60);

// Get transaction by invoice or reference_id (sanitized)
$invoice = sanitize($_GET['invoice'] ?? '');
$referenceId = sanitize($_GET['reference_id'] ?? '');

if (empty($invoice) && empty($referenceId)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'invoice or reference_id is required']);
    exit;
}

$transaction = null;

if ($invoice) {
    $transaction = $db->fetch(
        "SELECT * FROM transactions WHERE merchant_id = ? AND invoice_number = ?",
        [$merchant['id'], $invoice]
    );
} elseif ($referenceId) {
    $transaction = $db->fetch(
        "SELECT * FROM transactions WHERE merchant_id = ? AND reference_id = ? ORDER BY created_at DESC LIMIT 1",
        [$merchant['id'], $referenceId]
    );
}

if (!$transaction) {
    http_response_code(404);
    echo json_encode(['success' => false, 'error' => 'Transaction not found']);
    exit;
}

// Check if expired
if ($transaction['status'] === 'pending' && strtotime($transaction['expired_at']) < time()) {
    $db->query("UPDATE transactions SET status = 'expired' WHERE id = ?", [$transaction['id']]);
    $transaction['status'] = 'expired';
    
    // Release payment code
    if ($transaction['payment_code_id']) {
        $db->query(
            "UPDATE payment_codes SET status = 'available', transaction_id = NULL, reserved_at = NULL, expires_at = NULL WHERE id = ?",
            [$transaction['payment_code_id']]
        );
    }
}

// Build response
$response = [
    'success' => true,
    'data' => [
        'transaction_id' => (int)$transaction['id'],
        'invoice_number' => $transaction['invoice_number'],
        'reference_id' => $transaction['reference_id'],
        'payment_method' => $transaction['payment_method'],
        'amount' => (int)$transaction['amount'],
        'unique_code' => (int)$transaction['unique_code'],
        'total_amount' => (int)$transaction['total_amount'],
        'commission_amount' => (int)$transaction['commission_amount'],
        'net_amount' => (int)$transaction['net_amount'],
        'status' => $transaction['status'],
        'customer' => [
            'name' => $transaction['customer_name'],
            'email' => $transaction['customer_email'],
            'phone' => $transaction['customer_phone']
        ],
        'description' => $transaction['description'],
        'expired_at' => $transaction['expired_at'],
        'paid_at' => $transaction['paid_at'],
        'created_at' => $transaction['created_at'],
        'payment_url' => PUBLIC_URL . '/pay.php?invoice=' . $transaction['invoice_number']
    ]
];

// Add QRIS if applicable
if ($transaction['payment_method'] === 'qris' && $transaction['qris_string']) {
    $response['data']['qris_string'] = $transaction['qris_string'];
}

// Add bank info if applicable
if ($transaction['bank_account_id']) {
    $bank = $db->fetch("SELECT bank_name, bank_code, account_number, account_name FROM bank_accounts WHERE id = ?", [$transaction['bank_account_id']]);
    if ($bank) {
        $response['data']['bank'] = $bank;
    }
}

// Log API request
logApiRequest($merchant['id'], '/api/status', 'GET', $_GET, 200, $response, $startTime);

echo json_encode($response);

<?php
/**
 * NEO PGA - SEO Helper
 * Konfigurasi dan fungsi untuk optimasi SEO maksimal
 */

// ============================================
// KONFIGURASI SEO UTAMA
// ============================================

define('SEO_SITE_NAME', 'NEO PGA');
define('SEO_SITE_URL', 'https://neopga.com');
define('SEO_DEFAULT_TITLE', 'NEO PGA - Payment Gateway Termudah untuk UMKM Indonesia');
define('SEO_DEFAULT_DESCRIPTION', 'Payment Gateway Indonesia dengan fee terendah 15%. Daftar langsung aktif, terima pembayaran via QRIS & Bank Transfer. Verifikasi otomatis, tanpa coding, cocok untuk UMKM.');
define('SEO_DEFAULT_KEYWORDS', 'payment gateway indonesia, payment gateway umkm, qris payment, terima pembayaran online, payment gateway murah, gateway pembayaran, integrasi pembayaran, bank transfer otomatis, verifikasi pembayaran otomatis, fee payment gateway rendah');
define('SEO_AUTHOR', 'NEO PGA Team');
define('SEO_LOCALE', 'id_ID');
define('SEO_TWITTER_HANDLE', '@neopga');
define('SEO_THEME_COLOR', '#0D9488');

// ============================================
// FUNGSI SEO
// ============================================

/**
 * Generate meta tags untuk SEO
 */
function generateMetaTags($options = []) {
    $title = $options['title'] ?? SEO_DEFAULT_TITLE;
    $description = $options['description'] ?? SEO_DEFAULT_DESCRIPTION;
    $keywords = $options['keywords'] ?? SEO_DEFAULT_KEYWORDS;
    $canonical = $options['canonical'] ?? SEO_SITE_URL;
    $image = $options['image'] ?? SEO_SITE_URL . '/assets/images/og-image.png';
    $type = $options['type'] ?? 'website';
    $noindex = $options['noindex'] ?? false;

    $robots = $noindex ? 'noindex, nofollow' : 'index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1';

    $html = <<<HTML
    <!-- Primary Meta Tags -->
    <title>{$title}</title>
    <meta name="title" content="{$title}">
    <meta name="description" content="{$description}">
    <meta name="keywords" content="{$keywords}">
    <meta name="author" content="NEO PGA Team">
    <meta name="robots" content="{$robots}">
    <meta name="googlebot" content="{$robots}">
    <meta name="bingbot" content="{$robots}">
    <link rel="canonical" href="{$canonical}">

    <!-- Theme & App Meta -->
    <meta name="theme-color" content="#0D9488">
    <meta name="msapplication-TileColor" content="#0D9488">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">
    <meta name="apple-mobile-web-app-title" content="NEO PGA">

    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="{$type}">
    <meta property="og:url" content="{$canonical}">
    <meta property="og:title" content="{$title}">
    <meta property="og:description" content="{$description}">
    <meta property="og:image" content="{$image}">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="630">
    <meta property="og:image:alt" content="{$title}">
    <meta property="og:site_name" content="NEO PGA">
    <meta property="og:locale" content="id_ID">

    <!-- Twitter -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:url" content="{$canonical}">
    <meta name="twitter:title" content="{$title}">
    <meta name="twitter:description" content="{$description}">
    <meta name="twitter:image" content="{$image}">
    <meta name="twitter:site" content="@neopga">
    <meta name="twitter:creator" content="@neopga">

    <!-- Additional SEO Meta -->
    <meta name="geo.region" content="ID">
    <meta name="geo.country" content="Indonesia">
    <meta name="language" content="Indonesian">
    <meta name="distribution" content="global">
    <meta name="rating" content="general">
    <meta name="revisit-after" content="7 days">
HTML;

    return $html;
}

/**
 * Generate Organization Schema (JSON-LD)
 */
function generateOrganizationSchema() {
    $schema = [
        '@context' => 'https://schema.org',
        '@type' => 'Organization',
        'name' => 'NEO PGA',
        'alternateName' => 'NEO Payment Gateway',
        'url' => SEO_SITE_URL,
        'logo' => SEO_SITE_URL . '/assets/images/logo.svg',
        'description' => 'Payment Gateway termudah untuk UMKM Indonesia dengan fee terendah dan verifikasi otomatis.',
        'foundingDate' => '2024',
        'founders' => [
            [
                '@type' => 'Person',
                'name' => 'SITUNEO Team'
            ]
        ],
        'address' => [
            '@type' => 'PostalAddress',
            'addressCountry' => 'ID',
            'addressRegion' => 'Indonesia'
        ],
        'contactPoint' => [
            [
                '@type' => 'ContactPoint',
                'contactType' => 'customer service',
                'availableLanguage' => ['Indonesian', 'English']
            ]
        ],
        'sameAs' => [
            // Tambahkan social media URLs di sini
        ]
    ];

    return '<script type="application/ld+json">' . json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) . '</script>';
}

/**
 * Generate WebSite Schema (JSON-LD)
 */
function generateWebsiteSchema() {
    $schema = [
        '@context' => 'https://schema.org',
        '@type' => 'WebSite',
        'name' => 'NEO PGA',
        'alternateName' => 'NEO Payment Gateway Indonesia',
        'url' => SEO_SITE_URL,
        'description' => SEO_DEFAULT_DESCRIPTION,
        'inLanguage' => 'id-ID',
        'potentialAction' => [
            '@type' => 'SearchAction',
            'target' => [
                '@type' => 'EntryPoint',
                'urlTemplate' => SEO_SITE_URL . '/search?q={search_term_string}'
            ],
            'query-input' => 'required name=search_term_string'
        ]
    ];

    return '<script type="application/ld+json">' . json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) . '</script>';
}

/**
 * Generate SoftwareApplication Schema untuk Payment Gateway
 */
function generateSoftwareSchema() {
    $schema = [
        '@context' => 'https://schema.org',
        '@type' => 'SoftwareApplication',
        'name' => 'NEO PGA - Payment Gateway',
        'applicationCategory' => 'FinanceApplication',
        'operatingSystem' => 'Web Browser',
        'description' => 'Payment Gateway untuk UMKM Indonesia dengan fee terendah 15%. Terima pembayaran via QRIS dan Bank Transfer dengan verifikasi otomatis.',
        'url' => SEO_SITE_URL,
        'author' => [
            '@type' => 'Organization',
            'name' => 'NEO PGA'
        ],
        'offers' => [
            '@type' => 'Offer',
            'price' => '0',
            'priceCurrency' => 'IDR',
            'description' => 'Gratis daftar, fee hanya 15% per transaksi'
        ],
        'aggregateRating' => [
            '@type' => 'AggregateRating',
            'ratingValue' => '4.8',
            'ratingCount' => '150',
            'bestRating' => '5',
            'worstRating' => '1'
        ],
        'featureList' => [
            'QRIS Payment',
            'Bank Transfer Otomatis',
            'Verifikasi Pembayaran Otomatis',
            'Dashboard Real-time',
            'API Integration',
            'Webhook Notification',
            'Multi-Merchant Support',
            'Settlement Otomatis'
        ]
    ];

    return '<script type="application/ld+json">' . json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) . '</script>';
}

/**
 * Generate FAQ Schema (JSON-LD)
 */
function generateFAQSchema($faqs) {
    $mainEntity = [];

    foreach ($faqs as $faq) {
        $mainEntity[] = [
            '@type' => 'Question',
            'name' => $faq['question'],
            'acceptedAnswer' => [
                '@type' => 'Answer',
                'text' => $faq['answer']
            ]
        ];
    }

    $schema = [
        '@context' => 'https://schema.org',
        '@type' => 'FAQPage',
        'mainEntity' => $mainEntity
    ];

    return '<script type="application/ld+json">' . json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) . '</script>';
}

/**
 * Generate BreadcrumbList Schema
 */
function generateBreadcrumbSchema($items) {
    $itemListElement = [];
    $position = 1;

    foreach ($items as $item) {
        $itemListElement[] = [
            '@type' => 'ListItem',
            'position' => $position,
            'name' => $item['name'],
            'item' => $item['url']
        ];
        $position++;
    }

    $schema = [
        '@context' => 'https://schema.org',
        '@type' => 'BreadcrumbList',
        'itemListElement' => $itemListElement
    ];

    return '<script type="application/ld+json">' . json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) . '</script>';
}

/**
 * Generate LocalBusiness Schema
 */
function generateLocalBusinessSchema() {
    $schema = [
        '@context' => 'https://schema.org',
        '@type' => 'FinancialService',
        'name' => 'NEO PGA - Payment Gateway Indonesia',
        'description' => 'Layanan payment gateway untuk UMKM Indonesia dengan fee terendah dan sistem verifikasi otomatis.',
        'url' => SEO_SITE_URL,
        'logo' => SEO_SITE_URL . '/assets/images/logo.svg',
        'image' => SEO_SITE_URL . '/assets/images/og-image.png',
        'priceRange' => '$$',
        'address' => [
            '@type' => 'PostalAddress',
            'addressCountry' => 'ID'
        ],
        'geo' => [
            '@type' => 'GeoCoordinates',
            'latitude' => '-6.2088',
            'longitude' => '106.8456'
        ],
        'areaServed' => [
            '@type' => 'Country',
            'name' => 'Indonesia'
        ],
        'serviceType' => 'Payment Gateway',
        'hasOfferCatalog' => [
            '@type' => 'OfferCatalog',
            'name' => 'Layanan Payment Gateway',
            'itemListElement' => [
                [
                    '@type' => 'Offer',
                    'itemOffered' => [
                        '@type' => 'Service',
                        'name' => 'QRIS Payment',
                        'description' => 'Terima pembayaran via QRIS dari semua e-wallet dan mobile banking'
                    ]
                ],
                [
                    '@type' => 'Offer',
                    'itemOffered' => [
                        '@type' => 'Service',
                        'name' => 'Bank Transfer',
                        'description' => 'Terima pembayaran via transfer bank dengan kode unik otomatis'
                    ]
                ]
            ]
        ]
    ];

    return '<script type="application/ld+json">' . json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) . '</script>';
}

/**
 * Generate HowTo Schema untuk cara kerja
 */
function generateHowToSchema() {
    $schema = [
        '@context' => 'https://schema.org',
        '@type' => 'HowTo',
        'name' => 'Cara Menggunakan NEO PGA Payment Gateway',
        'description' => 'Panduan lengkap cara daftar dan menggunakan NEO PGA untuk menerima pembayaran online.',
        'totalTime' => 'PT5M',
        'estimatedCost' => [
            '@type' => 'MonetaryAmount',
            'currency' => 'IDR',
            'value' => '0'
        ],
        'step' => [
            [
                '@type' => 'HowToStep',
                'position' => 1,
                'name' => 'Daftar Akun',
                'text' => 'Daftar akun merchant gratis di NEO PGA. Langsung aktif tanpa verifikasi dokumen.',
                'url' => SEO_SITE_URL . '/merchant/register.php'
            ],
            [
                '@type' => 'HowToStep',
                'position' => 2,
                'name' => 'Integrasi',
                'text' => 'Integrasikan NEO PGA ke website atau aplikasi Anda menggunakan API yang mudah.',
                'url' => SEO_SITE_URL . '/sdk/'
            ],
            [
                '@type' => 'HowToStep',
                'position' => 3,
                'name' => 'Terima Pembayaran',
                'text' => 'Mulai terima pembayaran dari pelanggan via QRIS dan Bank Transfer.',
                'url' => SEO_SITE_URL
            ],
            [
                '@type' => 'HowToStep',
                'position' => 4,
                'name' => 'Withdraw Dana',
                'text' => 'Tarik dana ke rekening bank Anda kapan saja dengan proses cepat.',
                'url' => SEO_SITE_URL . '/merchant/'
            ]
        ]
    ];

    return '<script type="application/ld+json">' . json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) . '</script>';
}

/**
 * Generate semua schema untuk homepage
 */
function generateAllSchemas() {
    $output = generateOrganizationSchema() . "\n";
    $output .= generateWebsiteSchema() . "\n";
    $output .= generateSoftwareSchema() . "\n";
    $output .= generateLocalBusinessSchema() . "\n";
    $output .= generateHowToSchema() . "\n";

    return $output;
}

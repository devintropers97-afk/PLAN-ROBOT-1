<?php
$page_title = 'Pricing';
require_once 'includes/header.php';
?>

<section class="section" style="padding-top: calc(var(--navbar-height) + 3rem);">
    <div class="container">
        <div class="section-header fade-in">
            <span class="section-badge">Pricing</span>
            <h1 class="section-title">Pilih Paket Anda</h1>
            <p class="section-desc">
                Mulai GRATIS dengan 2 strategi dasar, upgrade kapan saja untuk akses strategi premium dengan win rate lebih tinggi.
            </p>
        </div>

        <div class="row g-4 justify-content-center">
            <!-- FREE -->
            <div class="col-lg-3 col-md-6 fade-in">
                <div class="card pricing-card h-100">
                    <div class="card-body d-flex flex-column">
                        <span class="badge bg-secondary mb-2">STARTER</span>
                        <h3 class="pricing-name">FREE</h3>
                        <div class="pricing-price">
                            <span class="amount">FREE</span>
                            <span class="period">forever</span>
                        </div>
                        <p class="text-muted small">Cocok untuk pemula yang ingin mencoba</p>
                        <ul class="pricing-features flex-grow-1">
                            <li><i class="fas fa-check"></i> <strong>2 Strategi</strong></li>
                            <li><i class="fas fa-check"></i> BLITZ-SIGNAL (60-78%)</li>
                            <li><i class="fas fa-check"></i> APEX-HUNTER (55-86%)</li>
                            <li><i class="fas fa-check"></i> Statistik dasar</li>
                            <li><i class="fas fa-check"></i> History 30 hari</li>
                            <li><i class="fas fa-check"></i> Telegram support</li>
                            <li class="disabled"><i class="fas fa-times"></i> Strategi premium</li>
                            <li class="disabled"><i class="fas fa-times"></i> Auto-pause system</li>
                        </ul>
                        <a href="register.php" class="btn btn-secondary w-100 mt-3">Mulai Gratis</a>
                        <small class="d-block text-muted mt-2 text-center">Daftar via link afiliasi</small>
                    </div>
                </div>
            </div>

            <!-- PRO -->
            <div class="col-lg-3 col-md-6 fade-in">
                <div class="card pricing-card h-100">
                    <div class="card-body d-flex flex-column">
                        <span class="badge bg-info mb-2">POPULAR</span>
                        <h3 class="pricing-name">PRO</h3>
                        <div class="pricing-price">
                            <span class="amount">$29</span>
                            <span class="period">/ month</span>
                        </div>
                        <p class="text-muted small">Untuk trader yang serius</p>
                        <ul class="pricing-features flex-grow-1">
                            <li><i class="fas fa-check"></i> <strong>4 Strategi</strong></li>
                            <li><i class="fas fa-check"></i> Semua FREE +</li>
                            <li><i class="fas fa-check"></i> TITAN-PULSE (73%)</li>
                            <li><i class="fas fa-check"></i> SHADOW-EDGE (73%)</li>
                            <li><i class="fas fa-check"></i> Statistik lengkap</li>
                            <li><i class="fas fa-check"></i> History 90 hari</li>
                            <li><i class="fas fa-check"></i> Priority support</li>
                            <li class="disabled"><i class="fas fa-times"></i> Strategi 81%+</li>
                        </ul>
                        <a href="<?php echo isLoggedIn() ? 'subscribe.php?plan=pro' : 'register.php'; ?>" class="btn btn-info w-100 mt-3">
                            <?php echo isLoggedIn() ? 'Upgrade' : 'Mulai'; ?>
                        </a>
                    </div>
                </div>
            </div>

            <!-- ELITE (Featured) -->
            <div class="col-lg-3 col-md-6 fade-in">
                <div class="card pricing-card featured h-100">
                    <div class="card-body d-flex flex-column">
                        <span class="badge bg-warning text-dark mb-2">BEST VALUE</span>
                        <h3 class="pricing-name">ELITE</h3>
                        <div class="pricing-price">
                            <span class="amount">$79</span>
                            <span class="period">/ month</span>
                        </div>
                        <p class="text-muted small">Win rate tinggi, fitur lengkap</p>
                        <ul class="pricing-features flex-grow-1">
                            <li><i class="fas fa-check"></i> <strong>7 Strategi</strong></li>
                            <li><i class="fas fa-check"></i> Semua PRO +</li>
                            <li><i class="fas fa-check"></i> STEALTH-MODE (81%)</li>
                            <li><i class="fas fa-check"></i> PHOENIX-X1 (75-83%)</li>
                            <li><i class="fas fa-check"></i> VORTEX-PRO (78%)</li>
                            <li><i class="fas fa-check"></i> History 180 hari</li>
                            <li><i class="fas fa-check"></i> Auto-pause system</li>
                            <li class="disabled"><i class="fas fa-times"></i> ORACLE-PRIME 90%+</li>
                        </ul>
                        <a href="<?php echo isLoggedIn() ? 'subscribe.php?plan=elite' : 'register.php'; ?>" class="btn btn-primary w-100 mt-3">
                            <?php echo isLoggedIn() ? 'Upgrade' : 'Mulai'; ?>
                        </a>
                    </div>
                </div>
            </div>

            <!-- VIP -->
            <div class="col-lg-3 col-md-6 fade-in">
                <div class="card pricing-card h-100" style="border-color: var(--primary-color);">
                    <div class="card-body d-flex flex-column">
                        <span class="badge bg-primary mb-2"><i class="fas fa-crown"></i> PREMIUM</span>
                        <h3 class="pricing-name text-gradient">VIP</h3>
                        <div class="pricing-price">
                            <span class="amount">$149</span>
                            <span class="period">/ month</span>
                        </div>
                        <p class="text-muted small">Akses penuh, win rate tertinggi</p>
                        <ul class="pricing-features flex-grow-1">
                            <li><i class="fas fa-crown text-warning"></i> <strong>All 10 Strategies</strong></li>
                            <li><i class="fas fa-check"></i> ORACLE-PRIME <strong class="text-success">(90-91%)</strong></li>
                            <li><i class="fas fa-check"></i> NEXUS-WAVE (87%)</li>
                            <li><i class="fas fa-check"></i> QUANTUM-FLOW (80-90%)</li>
                            <li><i class="fas fa-check"></i> History 1 year</li>
                            <li><i class="fas fa-check"></i> Direct owner support</li>
                            <li><i class="fas fa-check"></i> Priority signal queue</li>
                            <li><i class="fas fa-check"></i> Beta features access</li>
                        </ul>
                        <a href="<?php echo isLoggedIn() ? 'subscribe.php?plan=vip' : 'register.php'; ?>" class="btn btn-outline-primary w-100 mt-3">
                            <?php echo isLoggedIn() ? 'Upgrade' : 'Mulai'; ?>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Strategy Comparison Table -->
        <div class="mt-5 fade-in">
            <h3 class="text-center mb-4">Perbandingan Strategi per Paket</h3>
            <div class="table-responsive">
                <table class="table table-dark table-hover">
                    <thead>
                        <tr>
                            <th>Strategi</th>
                            <th>Win Rate</th>
                            <th class="text-center">FREE</th>
                            <th class="text-center">PRO</th>
                            <th class="text-center">ELITE</th>
                            <th class="text-center">VIP</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>ORACLE-PRIME</td>
                            <td><span class="text-success fw-bold">90-91%</span></td>
                            <td class="text-center"><i class="fas fa-times text-danger"></i></td>
                            <td class="text-center"><i class="fas fa-times text-danger"></i></td>
                            <td class="text-center"><i class="fas fa-times text-danger"></i></td>
                            <td class="text-center"><i class="fas fa-check text-success"></i></td>
                        </tr>
                        <tr>
                            <td>NEXUS-WAVE</td>
                            <td><span class="text-success fw-bold">87%</span></td>
                            <td class="text-center"><i class="fas fa-times text-danger"></i></td>
                            <td class="text-center"><i class="fas fa-times text-danger"></i></td>
                            <td class="text-center"><i class="fas fa-times text-danger"></i></td>
                            <td class="text-center"><i class="fas fa-check text-success"></i></td>
                        </tr>
                        <tr>
                            <td>STEALTH-MODE</td>
                            <td><span class="text-info">81%</span></td>
                            <td class="text-center"><i class="fas fa-times text-danger"></i></td>
                            <td class="text-center"><i class="fas fa-times text-danger"></i></td>
                            <td class="text-center"><i class="fas fa-check text-success"></i></td>
                            <td class="text-center"><i class="fas fa-check text-success"></i></td>
                        </tr>
                        <tr>
                            <td>PHOENIX-X1</td>
                            <td><span class="text-info">75-83%</span></td>
                            <td class="text-center"><i class="fas fa-times text-danger"></i></td>
                            <td class="text-center"><i class="fas fa-times text-danger"></i></td>
                            <td class="text-center"><i class="fas fa-check text-success"></i></td>
                            <td class="text-center"><i class="fas fa-check text-success"></i></td>
                        </tr>
                        <tr>
                            <td>VORTEX-PRO</td>
                            <td><span class="text-info">78%</span></td>
                            <td class="text-center"><i class="fas fa-times text-danger"></i></td>
                            <td class="text-center"><i class="fas fa-times text-danger"></i></td>
                            <td class="text-center"><i class="fas fa-check text-success"></i></td>
                            <td class="text-center"><i class="fas fa-check text-success"></i></td>
                        </tr>
                        <tr>
                            <td>TITAN-PULSE</td>
                            <td><span class="text-warning">73%</span></td>
                            <td class="text-center"><i class="fas fa-times text-danger"></i></td>
                            <td class="text-center"><i class="fas fa-check text-success"></i></td>
                            <td class="text-center"><i class="fas fa-check text-success"></i></td>
                            <td class="text-center"><i class="fas fa-check text-success"></i></td>
                        </tr>
                        <tr>
                            <td>SHADOW-EDGE</td>
                            <td><span class="text-warning">73%</span></td>
                            <td class="text-center"><i class="fas fa-times text-danger"></i></td>
                            <td class="text-center"><i class="fas fa-check text-success"></i></td>
                            <td class="text-center"><i class="fas fa-check text-success"></i></td>
                            <td class="text-center"><i class="fas fa-check text-success"></i></td>
                        </tr>
                        <tr>
                            <td>BLITZ-SIGNAL</td>
                            <td><span class="text-secondary">60-78%</span></td>
                            <td class="text-center"><i class="fas fa-check text-success"></i></td>
                            <td class="text-center"><i class="fas fa-check text-success"></i></td>
                            <td class="text-center"><i class="fas fa-check text-success"></i></td>
                            <td class="text-center"><i class="fas fa-check text-success"></i></td>
                        </tr>
                        <tr>
                            <td>APEX-HUNTER</td>
                            <td><span class="text-secondary">55-86%</span></td>
                            <td class="text-center"><i class="fas fa-check text-success"></i></td>
                            <td class="text-center"><i class="fas fa-check text-success"></i></td>
                            <td class="text-center"><i class="fas fa-check text-success"></i></td>
                            <td class="text-center"><i class="fas fa-check text-success"></i></td>
                        </tr>
                        <tr>
                            <td>QUANTUM-FLOW</td>
                            <td><span class="text-success fw-bold">80-90%</span></td>
                            <td class="text-center"><i class="fas fa-times text-danger"></i></td>
                            <td class="text-center"><i class="fas fa-times text-danger"></i></td>
                            <td class="text-center"><i class="fas fa-times text-danger"></i></td>
                            <td class="text-center"><i class="fas fa-check text-success"></i></td>
                        </tr>
                    </tbody>
                    <tfoot>
                        <tr class="table-secondary">
                            <td><strong>Total Strategi</strong></td>
                            <td></td>
                            <td class="text-center"><strong>2</strong></td>
                            <td class="text-center"><strong>4</strong></td>
                            <td class="text-center"><strong>7</strong></td>
                            <td class="text-center"><strong>10</strong></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>

        <!-- Testimonials Section (Social Proof) -->
        <div class="mt-5 fade-in">
            <h3 class="text-center mb-4">Apa Kata Pengguna?</h3>
            <div class="row g-4">
                <div class="col-md-4">
                    <div class="card h-100 bg-dark border">
                        <div class="card-body">
                            <div class="d-flex align-items-center mb-3">
                                <div class="rating text-warning me-2">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                </div>
                                <span class="badge bg-success">VERIFIED</span>
                            </div>
                            <p class="mb-3">"Awalnya ragu, tapi setelah pakai VIP seminggu, profit saya naik 3x lipat. Robot ini WORTH IT!"</p>
                            <div class="d-flex align-items-center">
                                <div class="avatar bg-primary rounded-circle me-2" style="width:40px;height:40px;display:flex;align-items:center;justify-content:center;">
                                    <span class="fw-bold">A</span>
                                </div>
                                <div>
                                    <strong>Andi S.</strong>
                                    <small class="text-muted d-block">Jakarta, Indonesia</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card h-100 bg-dark border">
                        <div class="card-body">
                            <div class="d-flex align-items-center mb-3">
                                <div class="rating text-warning me-2">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                </div>
                                <span class="badge bg-success">VERIFIED</span>
                            </div>
                            <p class="mb-3">"Sekarang tidur tenang, bangun tinggal cek profit. Ga perlu mantau chart lagi. Mantap! 😂"</p>
                            <div class="d-flex align-items-center">
                                <div class="avatar bg-info rounded-circle me-2" style="width:40px;height:40px;display:flex;align-items:center;justify-content:center;">
                                    <span class="fw-bold">B</span>
                                </div>
                                <div>
                                    <strong>Budi P.</strong>
                                    <small class="text-muted d-block">Surabaya, Indonesia</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card h-100 bg-dark border">
                        <div class="card-body">
                            <div class="d-flex align-items-center mb-3">
                                <div class="rating text-warning me-2">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star-half-alt"></i>
                                </div>
                                <span class="badge bg-success">VERIFIED</span>
                            </div>
                            <p class="mb-3">"Dari FREE upgrade ke ELITE, langsung kerasa bedanya. Win rate beneran naik! Recommended."</p>
                            <div class="d-flex align-items-center">
                                <div class="avatar bg-warning text-dark rounded-circle me-2" style="width:40px;height:40px;display:flex;align-items:center;justify-content:center;">
                                    <span class="fw-bold">S</span>
                                </div>
                                <div>
                                    <strong>Sari W.</strong>
                                    <small class="text-muted d-block">Bandung, Indonesia</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Stats Counter -->
            <div class="row g-4 mt-4 text-center">
                <div class="col-md-3 col-6">
                    <div class="p-3 bg-dark rounded">
                        <h3 class="text-primary mb-0">1,250+</h3>
                        <small class="text-muted">Active Users</small>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="p-3 bg-dark rounded">
                        <h3 class="text-success mb-0">85%</h3>
                        <small class="text-muted">Avg Win Rate</small>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="p-3 bg-dark rounded">
                        <h3 class="text-warning mb-0">50K+</h3>
                        <small class="text-muted">Trades Executed</small>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="p-3 bg-dark rounded">
                        <h3 class="text-info mb-0">4.8/5</h3>
                        <small class="text-muted">User Rating</small>
                    </div>
                </div>
            </div>
        </div>

        <!-- Payment Methods -->
        <div class="text-center mt-5 fade-in">
            <h4 class="mb-4">Metode Pembayaran</h4>
            <div class="d-flex justify-content-center gap-4 flex-wrap">
                <div class="text-center">
                    <div class="p-3 bg-dark rounded mb-2">
                        <i class="fas fa-qrcode fa-2x"></i>
                    </div>
                    <small class="text-muted">QRIS</small>
                </div>
                <div class="text-center">
                    <div class="p-3 bg-dark rounded mb-2">
                        <i class="fas fa-university fa-2x"></i>
                    </div>
                    <small class="text-muted">Transfer Bank</small>
                </div>
                <div class="text-center">
                    <div class="p-3 bg-dark rounded mb-2">
                        <i class="fas fa-wallet fa-2x"></i>
                    </div>
                    <small class="text-muted">E-Wallet</small>
                </div>
                <div class="text-center">
                    <div class="p-3 bg-dark rounded mb-2">
                        <i class="fab fa-paypal fa-2x"></i>
                    </div>
                    <small class="text-muted">PayPal</small>
                </div>
            </div>
        </div>

        <!-- FAQ Section -->
        <div class="mt-5 fade-in">
            <h3 class="text-center mb-4">Pertanyaan Umum</h3>
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="accordion" id="pricingFaq">
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#faq1">
                                    Apakah bisa upgrade atau downgrade paket?
                                </button>
                            </h2>
                            <div id="faq1" class="accordion-collapse collapse show" data-bs-parent="#pricingFaq">
                                <div class="accordion-body">
                                    Ya! Anda bisa upgrade kapan saja dan selisih harga akan dihitung pro-rata. Downgrade berlaku di periode billing berikutnya.
                                </div>
                            </div>
                        </div>

                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq2">
                                    Apakah FREE tier memiliki batasan waktu?
                                </button>
                            </h2>
                            <div id="faq2" class="accordion-collapse collapse" data-bs-parent="#pricingFaq">
                                <div class="accordion-body">
                                    Tidak! FREE tier bisa digunakan selamanya tanpa batasan waktu. Anda hanya mendapat akses ke 2 strategi dasar (#8 dan #9).
                                </div>
                            </div>
                        </div>

                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq3">
                                    Mengapa win rate strategi berbeda-beda?
                                </button>
                            </h2>
                            <div id="faq3" class="accordion-collapse collapse" data-bs-parent="#pricingFaq">
                                <div class="accordion-body">
                                    Setiap strategi menggunakan kombinasi indikator yang berbeda. Strategi VIP seperti ORACLE-PRIME menggunakan 3 RSI period sekaligus untuk akurasi maksimal, menghasilkan win rate 90-91%.
                                </div>
                            </div>
                        </div>

                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq4">
                                    Apakah robot bekerja di akun demo?
                                </button>
                            </h2>
                            <div id="faq4" class="accordion-collapse collapse" data-bs-parent="#pricingFaq">
                                <div class="accordion-body">
                                    <strong class="text-warning">Tidak.</strong> Robot hanya bekerja di akun REAL OlympTrade. Ini untuk memastikan komitmen serius dari pengguna dan kualitas sinyal trading.
                                </div>
                            </div>
                        </div>

                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq5">
                                    Market apa saja yang didukung?
                                </button>
                            </h2>
                            <div id="faq5" class="accordion-collapse collapse" data-bs-parent="#pricingFaq">
                                <div class="accordion-body">
                                    Saat ini robot mendukung EUR/USD dan GBP/USD dengan timeframe 5M, 15M, 30M, dan 1H.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>

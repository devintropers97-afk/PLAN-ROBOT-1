<?php
/**
 * NEO PGA - Export Reports to CSV
 */
// Config loaded via init.php
require_once __DIR__ . '/../includes/init.php';

if (!isset($_SESSION['admin_user']['id'])) {
    die('Unauthorized');
}

$db = Database::getInstance();

// Date range
$startDate = $_GET['start_date'] ?? date('Y-m-01');
$endDate = $_GET['end_date'] ?? date('Y-m-d');
$merchantId = $_GET['merchant_id'] ?? '';

$params = [$startDate, $endDate];
$merchantWhere = '';
if ($merchantId) {
    $merchantWhere = " AND t.merchant_id = ?";
    $params[] = $merchantId;
}

// Get data
$transactions = $db->fetchAll(
    "SELECT t.*, m.business_name, m.merchant_code 
     FROM transactions t 
     JOIN merchants m ON t.merchant_id = m.id 
     WHERE DATE(t.created_at) BETWEEN ? AND ? $merchantWhere
     ORDER BY t.created_at DESC",
    $params
);

// Generate CSV
$filename = 'neopga_report_' . $startDate . '_to_' . $endDate . '.csv';

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');

$output = fopen('php://output', 'w');

// UTF-8 BOM for Excel
fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));

// Header
fputcsv($output, [
    'Invoice Number',
    'Reference ID',
    'Merchant',
    'Merchant Code',
    'Customer Name',
    'Customer Email',
    'Amount',
    'Unique Code',
    'Total Amount',
    'Commission',
    'Net Amount',
    'Payment Method',
    'Status',
    'Created At',
    'Paid At',
    'Expired At'
]);

// Data
foreach ($transactions as $t) {
    fputcsv($output, [
        $t['invoice_number'],
        $t['reference_id'],
        $t['business_name'],
        $t['merchant_code'],
        $t['customer_name'],
        $t['customer_email'],
        $t['amount'],
        $t['unique_code'],
        $t['total_amount'],
        $t['commission_amount'],
        $t['net_amount'],
        $t['payment_method'],
        $t['status'],
        $t['created_at'],
        $t['paid_at'],
        $t['expired_at']
    ]);
}

fclose($output);
exit;

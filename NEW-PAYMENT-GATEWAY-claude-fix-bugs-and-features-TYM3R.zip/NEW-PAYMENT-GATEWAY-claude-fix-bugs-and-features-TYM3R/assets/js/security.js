/**
 * NEO PGA - Client-Side Security
 * Anti-inspection & Protection Measures
 *
 * CATATAN PENTING:
 * - Ini TIDAK 100% mencegah inspect (tidak mungkin di web)
 * - Tapi membuat lebih SULIT bagi orang awam
 * - Logic bisnis tetap aman di PHP (server-side)
 */

(function() {
    'use strict';

    // ============================================
    // DISABLE RIGHT-CLICK
    // ============================================
    document.addEventListener('contextmenu', function(e) {
        e.preventDefault();
        console.log('%c⚠️ Right-click disabled', 'color: red; font-size: 14px;');
        return false;
    });

    // ============================================
    // DISABLE KEYBOARD SHORTCUTS
    // ============================================
    document.addEventListener('keydown', function(e) {
        // F12 - Developer Tools
        if (e.key === 'F12' || e.keyCode === 123) {
            e.preventDefault();
            return false;
        }

        // Ctrl+Shift+I - Developer Tools
        if (e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'i' || e.keyCode === 73)) {
            e.preventDefault();
            return false;
        }

        // Ctrl+Shift+J - Console
        if (e.ctrlKey && e.shiftKey && (e.key === 'J' || e.key === 'j' || e.keyCode === 74)) {
            e.preventDefault();
            return false;
        }

        // Ctrl+Shift+C - Element Inspector
        if (e.ctrlKey && e.shiftKey && (e.key === 'C' || e.key === 'c' || e.keyCode === 67)) {
            e.preventDefault();
            return false;
        }

        // Ctrl+U - View Source
        if (e.ctrlKey && (e.key === 'U' || e.key === 'u' || e.keyCode === 85)) {
            e.preventDefault();
            return false;
        }

        // Ctrl+S - Save Page
        if (e.ctrlKey && (e.key === 'S' || e.key === 's' || e.keyCode === 83)) {
            e.preventDefault();
            return false;
        }

        // Ctrl+P - Print
        if (e.ctrlKey && (e.key === 'P' || e.key === 'p' || e.keyCode === 80)) {
            e.preventDefault();
            return false;
        }
    });

    // ============================================
    // DISABLE TEXT SELECTION (Optional - commented out)
    // ============================================
    // document.addEventListener('selectstart', function(e) {
    //     e.preventDefault();
    //     return false;
    // });

    // ============================================
    // DISABLE DRAG
    // ============================================
    document.addEventListener('dragstart', function(e) {
        e.preventDefault();
        return false;
    });

    // ============================================
    // DETECT DEVTOOLS OPEN
    // ============================================
    var devtools = {
        isOpen: false,
        orientation: undefined
    };

    var threshold = 160;

    var emitEvent = function(isOpen, orientation) {
        devtools.isOpen = isOpen;
        devtools.orientation = orientation;

        if (isOpen) {
            console.clear();
            console.log('%c⛔ PERINGATAN KEAMANAN', 'color: red; font-size: 40px; font-weight: bold;');
            console.log('%cMencoba mengakses kode ini adalah pelanggaran.', 'color: red; font-size: 16px;');
            console.log('%cAktivitas Anda telah dicatat.', 'color: orange; font-size: 14px;');
        }
    };

    setInterval(function() {
        var widthThreshold = window.outerWidth - window.innerWidth > threshold;
        var heightThreshold = window.outerHeight - window.innerHeight > threshold;
        var orientation = widthThreshold ? 'vertical' : 'horizontal';

        if (!(heightThreshold && widthThreshold) &&
            ((window.Firebug && window.Firebug.chrome && window.Firebug.chrome.isInitialized) ||
            widthThreshold || heightThreshold)) {
            if (!devtools.isOpen || devtools.orientation !== orientation) {
                emitEvent(true, orientation);
            }
        } else {
            if (devtools.isOpen) {
                emitEvent(false, undefined);
            }
        }
    }, 500);

    // ============================================
    // DEBUGGER TRAP (Makes debugging harder)
    // ============================================
    (function() {
        function block() {
            if (window.outerHeight - window.innerHeight > 200 ||
                window.outerWidth - window.innerWidth > 200) {
                document.body.innerHTML = '';
            }
            setInterval(function() {
                (function() {
                    return false;
                })
                ['constructor']('debugger')
                ['call']();
            }, 50);
        }

        try {
            block();
        } catch (err) {}
    })();

    // ============================================
    // DISABLE COPY (Optional - can be enabled)
    // ============================================
    // document.addEventListener('copy', function(e) {
    //     e.preventDefault();
    //     return false;
    // });

    // ============================================
    // CONSOLE WARNING
    // ============================================
    console.log('%c⚠️ STOP!', 'color: red; font-size: 50px; font-weight: bold; text-shadow: 2px 2px black;');
    console.log('%cIni adalah fitur browser untuk developer.', 'font-size: 18px;');
    console.log('%cJika seseorang meminta Anda untuk copy-paste sesuatu di sini, itu adalah penipuan.', 'font-size: 16px; color: red;');
    console.log('%c© NEO PGA - Payment Gateway Indonesia', 'font-size: 12px; color: gray;');

    // ============================================
    // DISABLE IFRAME EMBEDDING
    // ============================================
    if (window.top !== window.self) {
        window.top.location = window.self.location;
    }

    // ============================================
    // OBFUSCATE/HIDE SENSITIVE ELEMENTS
    // ============================================
    document.addEventListener('DOMContentLoaded', function() {
        // Hide API keys and sensitive data in DOM
        var sensitiveElements = document.querySelectorAll('[data-sensitive]');
        sensitiveElements.forEach(function(el) {
            el.setAttribute('data-protected', 'true');
        });

        // ============================================
        // INPUT VALIDATION & XSS PROTECTION
        // ============================================

        // Dangerous patterns to block
        var dangerousPatterns = [
            /<script\b[^>]*>/i,
            /javascript:/i,
            /on\w+\s*=/i,
            /<iframe/i,
            /<object/i,
            /<embed/i,
            /<link/i,
            /<meta/i,
            /vbscript:/i
        ];

        // Check if input contains XSS
        function containsXSS(value) {
            if (!value) return false;
            for (var i = 0; i < dangerousPatterns.length; i++) {
                if (dangerousPatterns[i].test(value)) {
                    return true;
                }
            }
            return false;
        }

        // Sanitize input value
        function sanitizeInput(value) {
            if (!value) return '';
            // Remove HTML tags
            value = value.replace(/<[^>]*>/g, '');
            // Remove null bytes
            value = value.replace(/\x00/g, '');
            return value.trim();
        }

        // Show warning message
        function showInputWarning(input, message) {
            // Remove existing warning
            var existingWarning = input.parentNode.querySelector('.xss-warning');
            if (existingWarning) {
                existingWarning.remove();
            }

            // Create warning element
            var warning = document.createElement('div');
            warning.className = 'xss-warning';
            warning.style.cssText = 'color:#ef4444;font-size:12px;margin-top:4px;display:flex;align-items:center;gap:4px;';
            warning.innerHTML = '<svg width="14" height="14" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/></svg>' + message;
            input.parentNode.appendChild(warning);

            // Add error styling to input
            input.style.borderColor = '#ef4444';
            input.style.boxShadow = '0 0 0 3px rgba(239,68,68,0.2)';
        }

        // Clear warning message
        function clearInputWarning(input) {
            var existingWarning = input.parentNode.querySelector('.xss-warning');
            if (existingWarning) {
                existingWarning.remove();
            }
            input.style.borderColor = '';
            input.style.boxShadow = '';
        }

        // Apply validation to all text inputs
        var textInputs = document.querySelectorAll('input[type="text"], input[type="email"], input[type="tel"], input[type="url"], textarea');

        textInputs.forEach(function(input) {
            // Validate on input
            input.addEventListener('input', function(e) {
                var value = e.target.value;

                if (containsXSS(value)) {
                    showInputWarning(input, 'Karakter tidak diizinkan terdeteksi');
                    // Auto-sanitize
                    e.target.value = sanitizeInput(value);
                } else if (/<|>/.test(value)) {
                    showInputWarning(input, 'Karakter < dan > tidak diizinkan');
                    // Remove < and >
                    e.target.value = value.replace(/[<>]/g, '');
                } else {
                    clearInputWarning(input);
                }
            });

            // Validate on paste
            input.addEventListener('paste', function(e) {
                setTimeout(function() {
                    var value = input.value;
                    if (containsXSS(value) || /<|>/.test(value)) {
                        showInputWarning(input, 'Konten yang di-paste mengandung karakter tidak diizinkan');
                        input.value = sanitizeInput(value).replace(/[<>]/g, '');
                    }
                }, 10);
            });
        });

        // Form submit validation
        var forms = document.querySelectorAll('form');
        forms.forEach(function(form) {
            form.addEventListener('submit', function(e) {
                var inputs = form.querySelectorAll('input[type="text"], input[type="email"], input[type="tel"], input[type="url"], textarea');
                var hasXSS = false;

                inputs.forEach(function(input) {
                    if (containsXSS(input.value) || /<|>/.test(input.value)) {
                        hasXSS = true;
                        showInputWarning(input, 'Perbaiki input sebelum submit');
                        input.value = sanitizeInput(input.value).replace(/[<>]/g, '');
                    }
                });

                if (hasXSS) {
                    e.preventDefault();
                    alert('Input mengandung karakter tidak diizinkan. Silakan perbaiki dan coba lagi.');
                    return false;
                }
            });
        });

        console.log('%c🛡️ Input validation aktif', 'color: #10b981; font-size: 12px;');
    });

})();

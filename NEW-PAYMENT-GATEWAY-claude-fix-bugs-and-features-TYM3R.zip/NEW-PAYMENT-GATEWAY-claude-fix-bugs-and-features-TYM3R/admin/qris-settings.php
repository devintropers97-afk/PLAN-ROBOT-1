<?php
/**
 * NEO PGA Admin - QRIS Settings
 * Dengan fitur: Import dari String ATAU Upload Foto QR
 */
require_once __DIR__ . '/../includes/init.php';

$auth = new Auth('admin');
$auth->requireAuth();

$adminUser = $auth->user();
$db = Database::getInstance();
$message = '';
$messageType = '';

// Nama tabel settings
$tableName = 'system_settings';

// Get current QRIS settings
$qrisSettings = [];
$qrisKeys = ['qris_nmid', 'qris_gopay_id', 'qris_gopay_short', 'qris_acquirer', 'qris_display_name', 'qris_city', 'qris_mcc', 'qris_enabled'];
foreach ($qrisKeys as $key) {
    try {
        $row = $db->fetch("SELECT setting_value FROM $tableName WHERE setting_key = ?", [$key]);
        $qrisSettings[$key] = $row['setting_value'] ?? '';
    } catch (Exception $e) {
        $qrisSettings[$key] = '';
    }
}

// Default values
$defaults = [
    'qris_nmid' => 'ID1025436258392',
    'qris_gopay_id' => '936009143670340254',
    'qris_gopay_short' => 'G670340254',
    'qris_acquirer' => 'UKE',
    'qris_display_name' => 'NEO PGA',
    'qris_city' => 'JAKARTA',
    'qris_mcc' => '5812',
    'qris_enabled' => '1'
];

foreach ($defaults as $key => $value) {
    if (empty($qrisSettings[$key])) {
        $qrisSettings[$key] = $value;
    }
}

// Handle Save
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_qris'])) {
    verifyCsrf();

    // Check for XSS attempts
    $xssDetected = detectXSS($_POST['qris_nmid'] ?? '') ||
                   detectXSS($_POST['qris_gopay_id'] ?? '') ||
                   detectXSS($_POST['qris_gopay_short'] ?? '') ||
                   detectXSS($_POST['qris_acquirer'] ?? '') ||
                   detectXSS($_POST['qris_display_name'] ?? '') ||
                   detectXSS($_POST['qris_city'] ?? '') ||
                   detectXSS($_POST['qris_mcc'] ?? '');

    if ($xssDetected) {
        $message = 'Input tidak valid terdeteksi!';
        $messageType = 'danger';
    } else {
        $updates = [
            'qris_nmid' => strtoupper(sanitize($_POST['qris_nmid'] ?? '')),
            'qris_gopay_id' => sanitize($_POST['qris_gopay_id'] ?? ''),
            'qris_gopay_short' => sanitize($_POST['qris_gopay_short'] ?? ''),
            'qris_acquirer' => strtoupper(sanitize($_POST['qris_acquirer'] ?? '')),
            'qris_display_name' => strtoupper(sanitize($_POST['qris_display_name'] ?? '')),
            'qris_city' => strtoupper(sanitize($_POST['qris_city'] ?? '')),
            'qris_mcc' => sanitize($_POST['qris_mcc'] ?? ''),
            'qris_enabled' => isset($_POST['qris_enabled']) ? '1' : '0'
        ];

        try {
            foreach ($updates as $key => $value) {
                $exists = $db->fetch("SELECT id FROM $tableName WHERE setting_key = ?", [$key]);
                if ($exists) {
                    $db->query("UPDATE $tableName SET setting_value = ? WHERE setting_key = ?", [$value, $key]);
                } else {
                    $db->query("INSERT INTO $tableName (setting_key, setting_value) VALUES (?, ?)", [$key, $value]);
                }
                $qrisSettings[$key] = $value;
            }

            updateQRISGenerator($updates);

            $message = 'Pengaturan QRIS berhasil disimpan!';
            $messageType = 'success';
        } catch (Exception $e) {
            $message = 'Gagal menyimpan: ' . $e->getMessage();
            $messageType = 'danger';
        }
    }
}

// Handle Parse QR String
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['parse_qris'])) {
    verifyCsrf();

    // Check for XSS attempts
    if (detectXSS($_POST['qris_string'] ?? '')) {
        $message = 'Input tidak valid terdeteksi!';
        $messageType = 'danger';
    }

    $qrisString = sanitize($_POST['qris_string'] ?? '');
    
    if (!empty($qrisString)) {
        $parsed = parseQRISString($qrisString);
        if ($parsed) {
            $qrisSettings = array_merge($qrisSettings, $parsed);
            $message = 'QRIS berhasil di-parse! Silakan review dan simpan.';
            $messageType = 'success';
        } else {
            $message = 'Format QRIS tidak valid';
            $messageType = 'danger';
        }
    }
}

// Handle Upload QR Image
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['upload_qris'])) {
    verifyCsrf();
    
    if (isset($_FILES['qr_image']) && $_FILES['qr_image']['error'] === UPLOAD_ERR_OK) {
        $tmpFile = $_FILES['qr_image']['tmp_name'];
        $mimeType = mime_content_type($tmpFile);
        
        if (in_array($mimeType, ['image/png', 'image/jpeg', 'image/jpg', 'image/gif'])) {
            // Try to decode QR using external API
            $qrisString = decodeQRImage($tmpFile);
            
            if ($qrisString) {
                $parsed = parseQRISString($qrisString);
                if ($parsed) {
                    $qrisSettings = array_merge($qrisSettings, $parsed);
                    $message = 'QR berhasil dibaca! Data QRIS: ' . substr($qrisString, 0, 50) . '...';
                    $messageType = 'success';
                } else {
                    $message = 'QR terbaca tapi format bukan QRIS standar. String: ' . substr($qrisString, 0, 100);
                    $messageType = 'warning';
                }
            } else {
                $message = 'Gagal membaca QR dari gambar. Coba gunakan metode input string manual.';
                $messageType = 'danger';
            }
        } else {
            $message = 'File harus berupa gambar (PNG/JPG)';
            $messageType = 'danger';
        }
    } else {
        $message = 'Pilih file gambar QR terlebih dahulu';
        $messageType = 'danger';
    }
}

/**
 * Decode QR image using goqr.me API
 */
function decodeQRImage($filePath) {
    // Method 1: Using goqr.me API
    $imageData = base64_encode(file_get_contents($filePath));
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://api.qrserver.com/v1/read-qr-code/');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, ['file' => new CURLFile($filePath)]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    
    $response = curl_exec($ch);
    curl_close($ch);
    
    if ($response) {
        $data = json_decode($response, true);
        if (isset($data[0]['symbol'][0]['data'])) {
            return $data[0]['symbol'][0]['data'];
        }
    }
    
    return null;
}

/**
 * Parse QRIS string
 */
function parseQRISString($qris) {
    $result = [];
    $i = 0;
    $fields = [];
    
    while ($i < strlen($qris)) {
        if ($i + 4 > strlen($qris)) break;
        $tag = substr($qris, $i, 2);
        $length = (int)substr($qris, $i + 2, 2);
        $value = substr($qris, $i + 4, $length);
        $fields[$tag] = $value;
        $i += 4 + $length;
    }
    
    // Parse tag 26 (GoPay)
    if (isset($fields['26'])) {
        $sub = parseSubfields($fields['26']);
        if (isset($sub['01'])) $result['qris_gopay_id'] = $sub['01'];
        if (isset($sub['02'])) $result['qris_gopay_short'] = $sub['02'];
        if (isset($sub['03'])) $result['qris_acquirer'] = $sub['03'];
    }
    
    // Parse tag 51 (QRIS NMID)
    if (isset($fields['51'])) {
        $sub = parseSubfields($fields['51']);
        if (isset($sub['02'])) $result['qris_nmid'] = $sub['02'];
    }
    
    if (isset($fields['52'])) $result['qris_mcc'] = $fields['52'];
    if (isset($fields['59'])) $result['qris_display_name'] = substr($fields['59'], 0, 15);
    if (isset($fields['60'])) $result['qris_city'] = $fields['60'];
    
    return !empty($result) ? $result : null;
}

function parseSubfields($value) {
    $result = [];
    $j = 0;
    while ($j < strlen($value)) {
        if ($j + 4 > strlen($value)) break;
        $stag = substr($value, $j, 2);
        $slen = (int)substr($value, $j + 2, 2);
        $sval = substr($value, $j + 4, $slen);
        $result[$stag] = $sval;
        $j += 4 + $slen;
    }
    return $result;
}

/**
 * Update QRISGenerator.php
 */
function updateQRISGenerator($settings) {
    $path = __DIR__ . '/../includes/QRISGenerator.php';
    if (!file_exists($path)) return false;
    
    $content = file_get_contents($path);
    
    $replacements = [
        '/private \$realNMID = "[^"]*";/' => 'private $realNMID = "' . ($settings['qris_nmid'] ?? '') . '";',
        '/private \$realGopayId = "[^"]*";/' => 'private $realGopayId = "' . ($settings['qris_gopay_id'] ?? '') . '";',
        '/private \$realGopayShort = "[^"]*";/' => 'private $realGopayShort = "' . ($settings['qris_gopay_short'] ?? '') . '";',
        '/private \$acquirerCode = "[^"]*";/' => 'private $acquirerCode = "' . ($settings['qris_acquirer'] ?? '') . '";',
        '/private \$displayMerchantName = "[^"]*";/' => 'private $displayMerchantName = "' . ($settings['qris_display_name'] ?? '') . '";',
        '/private \$displayCity = "[^"]*";/' => 'private $displayCity = "' . ($settings['qris_city'] ?? '') . '";',
        '/private \$mcc = "[^"]*";/' => 'private $mcc = "' . ($settings['qris_mcc'] ?? '') . '";',
    ];
    
    foreach ($replacements as $pattern => $replacement) {
        $content = preg_replace($pattern, $replacement, $content);
    }
    
    return file_put_contents($path, $content);
}

$pageTitle = 'Pengaturan QRIS';
$currentPage = 'qris';

$extraCss = '
.qris-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; }
.qris-section { background: white; border-radius: 12px; border: 1px solid var(--gray-200); }
.qris-section-header { padding: 1rem 1.5rem; border-bottom: 1px solid var(--gray-100); font-weight: 600; }
.qris-section-body { padding: 1.5rem; }
.info-box { background: var(--gray-50); border-radius: 8px; padding: 1rem; margin-bottom: 1rem; font-size: 0.875rem; }
.info-box.warning { background: #fef3c7; border: 1px solid #f59e0b; }
.info-box.success { background: #dcfce7; border: 1px solid #22c55e; }
.upload-zone { border: 2px dashed var(--gray-300); border-radius: 8px; padding: 2rem; text-align: center; cursor: pointer; transition: all 0.2s; }
.upload-zone:hover { border-color: var(--primary); background: var(--primary-light); }
.upload-zone.dragover { border-color: var(--primary); background: var(--primary-light); }
.tab-buttons { display: flex; gap: 0.5rem; margin-bottom: 1rem; }
.tab-btn { padding: 0.5rem 1rem; border-radius: 6px; border: 1px solid var(--gray-300); background: white; cursor: pointer; font-size: 0.875rem; }
.tab-btn.active { background: var(--primary); color: white; border-color: var(--primary); }
.tab-content { display: none; }
.tab-content.active { display: block; }
@media (max-width: 1024px) { .qris-grid { grid-template-columns: 1fr; } }
';

ob_start();
?>

<div class="flex justify-between items-center mb-6">
    <div>
        <h1 class="text-2xl font-bold text-gray-900">📱 Pengaturan QRIS</h1>
        <p class="text-gray-500">Konfigurasi QRIS untuk menerima pembayaran</p>
    </div>
</div>

<?php if ($message): ?>
<div class="alert alert-<?= $messageType ?> mb-6"><?= $message ?></div>
<?php endif; ?>

<div class="qris-grid">
    <!-- Left: QRIS Settings -->
    <div>
        <form method="POST" id="qrisForm">
            <?= csrfField() ?>
            <input type="hidden" name="save_qris" value="1">
            
            <!-- Data QRIS Asli -->
            <div class="qris-section mb-4">
                <div class="qris-section-header">🔐 Data QRIS Asli (Penerima Dana)</div>
                <div class="qris-section-body">
                    <div class="info-box warning">
                        <strong>⚠️ Penting:</strong> Data ini menentukan kemana uang masuk. Pastikan NMID dan GoPay ID sesuai dengan QRIS asli Anda.
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">NMID (National Merchant ID) *</label>
                        <input type="text" name="qris_nmid" id="qris_nmid" class="form-input" value="<?= htmlspecialchars($qrisSettings['qris_nmid']) ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">GoPay Merchant ID *</label>
                        <input type="text" name="qris_gopay_id" id="qris_gopay_id" class="form-input" value="<?= htmlspecialchars($qrisSettings['qris_gopay_id']) ?>" required>
                    </div>
                    
                    <div class="grid grid-cols-2 gap-4">
                        <div class="form-group">
                            <label class="form-label">GoPay Short ID</label>
                            <input type="text" name="qris_gopay_short" id="qris_gopay_short" class="form-input" value="<?= htmlspecialchars($qrisSettings['qris_gopay_short']) ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Acquirer Code</label>
                            <input type="text" name="qris_acquirer" id="qris_acquirer" class="form-input" value="<?= htmlspecialchars($qrisSettings['qris_acquirer']) ?>">
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Display Settings -->
            <div class="qris-section mb-4">
                <div class="qris-section-header">🏪 Tampilan ke Customer</div>
                <div class="qris-section-body">
                    <div class="form-group">
                        <label class="form-label">Nama Merchant (Display)</label>
                        <input type="text" name="qris_display_name" id="qris_display_name" class="form-input" value="<?= htmlspecialchars($qrisSettings['qris_display_name']) ?>" maxlength="15">
                    </div>
                    
                    <div class="grid grid-cols-2 gap-4">
                        <div class="form-group">
                            <label class="form-label">Kota</label>
                            <input type="text" name="qris_city" id="qris_city" class="form-input" value="<?= htmlspecialchars($qrisSettings['qris_city']) ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label">MCC</label>
                            <input type="text" name="qris_mcc" id="qris_mcc" class="form-input" value="<?= htmlspecialchars($qrisSettings['qris_mcc']) ?>">
                        </div>
                    </div>
                    
                    <div class="form-group mb-0">
                        <label class="flex items-center gap-2">
                            <input type="checkbox" name="qris_enabled" <?= $qrisSettings['qris_enabled'] == '1' ? 'checked' : '' ?>>
                            <span>Aktifkan pembayaran QRIS</span>
                        </label>
                    </div>
                </div>
            </div>
            
            <button type="submit" class="btn btn-primary" style="width:100%">💾 Simpan Pengaturan QRIS</button>
        </form>
    </div>
    
    <!-- Right: Import Options -->
    <div>
        <!-- Import Section -->
        <div class="qris-section mb-4">
            <div class="qris-section-header">📥 Import Data QRIS</div>
            <div class="qris-section-body">
                <p style="font-size:0.875rem;color:var(--gray-600);margin-bottom:1rem">
                    Pilih cara import data QRIS Anda:
                </p>
                
                <!-- Tab Buttons -->
                <div class="tab-buttons">
                    <button type="button" class="tab-btn active" onclick="switchTab('upload')">📷 Upload Foto QR</button>
                    <button type="button" class="tab-btn" onclick="switchTab('string')">📝 Input String</button>
                </div>
                
                <!-- Tab 1: Upload Foto -->
                <div id="tab-upload" class="tab-content active">
                    <form method="POST" enctype="multipart/form-data">
                        <?= csrfField() ?>
                        <input type="hidden" name="upload_qris" value="1">
                        
                        <div class="upload-zone" onclick="document.getElementById('qr_image').click()" id="uploadZone">
                            <div style="font-size:3rem;margin-bottom:0.5rem">📷</div>
                            <p style="font-weight:600;margin-bottom:0.25rem">Klik atau drag foto QR ke sini</p>
                            <p style="font-size:0.75rem;color:var(--gray-500)">Format: PNG, JPG (max 5MB)</p>
                            <input type="file" name="qr_image" id="qr_image" accept="image/*" style="display:none" onchange="handleFileSelect(this)">
                        </div>
                        <div id="fileName" style="margin-top:0.5rem;font-size:0.875rem;color:var(--gray-600);display:none"></div>
                        
                        <button type="submit" class="btn btn-primary" style="width:100%;margin-top:1rem">🔍 Baca QR dari Foto</button>
                    </form>
                    
                    <div class="info-box" style="margin-top:1rem">
                        <strong>💡 Tips:</strong>
                        <ul style="margin:0.5rem 0 0 1rem;font-size:0.8rem;color:var(--gray-600)">
                            <li>Gunakan foto QR yang jelas dan tidak blur</li>
                            <li>Pastikan QR code terlihat penuh dalam foto</li>
                            <li>Hindari foto dengan bayangan atau refleksi</li>
                        </ul>
                    </div>
                </div>
                
                <!-- Tab 2: Input String -->
                <div id="tab-string" class="tab-content">
                    <form method="POST">
                        <?= csrfField() ?>
                        <input type="hidden" name="parse_qris" value="1">
                        
                        <div class="form-group">
                            <label class="form-label">QRIS String</label>
                            <textarea name="qris_string" class="form-input" rows="4" placeholder="00020101021126610014COM.GO-JEK.WWW..."></textarea>
                        </div>
                        
                        <button type="submit" class="btn btn-primary" style="width:100%">🔍 Parse QRIS String</button>
                    </form>
                    
                    <div class="info-box" style="margin-top:1rem">
                        <strong>💡 Cara mendapat QRIS String:</strong>
                        <ol style="margin:0.5rem 0 0 1rem;font-size:0.8rem;color:var(--gray-600)">
                            <li>Scan QR dengan app scanner (bukan e-wallet)</li>
                            <li>Pilih "Copy Text" atau "Share"</li>
                            <li>Paste string yang dimulai dengan "00020101..."</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Current Config Preview -->
        <div class="qris-section">
            <div class="qris-section-header">📋 Konfigurasi Saat Ini</div>
            <div class="qris-section-body">
                <table style="width:100%;font-size:0.875rem">
                    <tr>
                        <td style="padding:0.5rem 0;color:var(--gray-500)">NMID</td>
                        <td style="padding:0.5rem 0;font-weight:600;text-align:right"><code><?= htmlspecialchars($qrisSettings['qris_nmid']) ?></code></td>
                    </tr>
                    <tr>
                        <td style="padding:0.5rem 0;color:var(--gray-500)">GoPay ID</td>
                        <td style="padding:0.5rem 0;font-weight:600;text-align:right;font-size:0.7rem"><code><?= htmlspecialchars($qrisSettings['qris_gopay_id']) ?></code></td>
                    </tr>
                    <tr>
                        <td style="padding:0.5rem 0;color:var(--gray-500)">Acquirer</td>
                        <td style="padding:0.5rem 0;font-weight:600;text-align:right"><?= htmlspecialchars($qrisSettings['qris_acquirer']) ?></td>
                    </tr>
                    <tr>
                        <td style="padding:0.5rem 0;color:var(--gray-500)">Display Name</td>
                        <td style="padding:0.5rem 0;font-weight:600;text-align:right"><?= htmlspecialchars($qrisSettings['qris_display_name']) ?>-[BANK]</td>
                    </tr>
                    <tr>
                        <td style="padding:0.5rem 0;color:var(--gray-500)">Status</td>
                        <td style="padding:0.5rem 0;text-align:right">
                            <span class="badge badge-<?= $qrisSettings['qris_enabled'] == '1' ? 'success' : 'danger' ?>">
                                <?= $qrisSettings['qris_enabled'] == '1' ? 'Aktif' : 'Nonaktif' ?>
                            </span>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
function switchTab(tab) {
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
    
    document.querySelector(`.tab-btn[onclick*="${tab}"]`).classList.add('active');
    document.getElementById('tab-' + tab).classList.add('active');
}

function handleFileSelect(input) {
    if (input.files && input.files[0]) {
        document.getElementById('fileName').style.display = 'block';
        document.getElementById('fileName').textContent = '📎 ' + input.files[0].name;
    }
}

// Drag and drop
const uploadZone = document.getElementById('uploadZone');
uploadZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    uploadZone.classList.add('dragover');
});
uploadZone.addEventListener('dragleave', () => {
    uploadZone.classList.remove('dragover');
});
uploadZone.addEventListener('drop', (e) => {
    e.preventDefault();
    uploadZone.classList.remove('dragover');
    const files = e.dataTransfer.files;
    if (files.length) {
        document.getElementById('qr_image').files = files;
        handleFileSelect(document.getElementById('qr_image'));
    }
});
</script>

<?php
$content = ob_get_clean();
include __DIR__ . '/layout.php';
?>

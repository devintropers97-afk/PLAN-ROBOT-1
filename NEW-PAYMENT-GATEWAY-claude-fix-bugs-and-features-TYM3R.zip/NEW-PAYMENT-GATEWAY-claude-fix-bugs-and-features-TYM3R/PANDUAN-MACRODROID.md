# 📱 PANDUAN SETUP MACRODROID - AUTO-VERIFY PEMBAYARAN

## 🎯 Tujuan
Otomatis approve pembayaran ketika ada notifikasi masuk dari GoPay atau SMS Bank, tanpa perlu cek manual.

---

## 📥 1. INSTALL MACRODROID

1. Download **MacroDroid** dari Play Store
2. Buka app → Allow semua permissions (Notifikasi, SMS, dll)
3. Skip tutorial atau pelajari basic-nya

---

## ⚙️ 2. SETUP UNTUK QRIS (GOPAY/OVO/DANA)

### **A. Buat Macro Baru**

1. Tap **"+"** (Add Macro)
2. Nama: **"NEO PGA - QRIS Auto-Verify"**
3. Tap **Add Trigger**

### **B. Trigger: Notification Received**

1. Pilih **Notification** → **Notification Received**
2. **Application**: Pilih **GoPay** (atau OVO, DANA)
3. **Notification Title**: Contains `Pembayaran diterima`
4. **Notification Text**: Contains `QRIS`
5. Tap **OK**

### **C. Constraint (Opsional - Filter notifikasi)**

1. Tap **Add Constraint**
2. Pilih **Notification Text** → **Contains**: `Vokentra` (nama merchant kamu)
3. Ini untuk memastikan hanya notifikasi merchant kamu yang di-process

### **D. Action: Extract Amount dari Notifikasi**

1. Tap **Add Action**
2. Pilih **Variables** → **Variable Set String**
3. Nama variable: `notification_text`
4. Value: `{notification_text}` (magic text dari notifikasi)
5. Tap **OK**

### **E. Action: Parse Amount dengan Regex**

1. Tap **Add Action**
2. Pilih **Variables** → **Extract Text via Regex**
3. Input text: `{lv=notification_text}` (variable dari step D)
4. Regex pattern: `Rp\s*([\d\.]+)`
5. Output variable: `amount`
6. Tap **OK**

### **F. Action: Clean Amount (Hapus titik/dot)**

1. Tap **Add Action**
2. Pilih **Variables** → **String Replace**
3. Input: `{lv=amount}`
4. Find: `.` (titik)
5. Replace with: `` (kosong - hapus titik)
6. Output variable: `amount_clean`
7. Tap **OK**

### **G. Action: HTTP Request ke NEO PGA API**

1. Tap **Add Action**
2. Pilih **Connectivity** → **HTTP Request**
3. **URL**: `https://neopga.com/api/auto-verify.php`
4. **Method**: **POST**
5. **Content Type**: `application/json`
6. **Request Body**:
```json
{
  "method": "qris",
  "amount": {lv=amount_clean}
}
```
7. **Headers** (Optional - jika pakai auth key):
   - Header: `Authorization`
   - Value: `YOUR_SECRET_KEY_HERE`
8. **Response Variable**: `api_response`
9. Tap **OK**

### **H. Action: Show Toast (Notifikasi di HP)**

1. Tap **Add Action**
2. Pilih **User Interface** → **Toast Message**
3. Text: `✅ Auto-verified: Rp {lv=amount_clean}`
4. Duration: **Short**
5. Tap **OK**

### **I. Save Macro**

1. Tap **✓** (Save)
2. Macro sudah aktif!

---

## 🏦 3. SETUP UNTUK BANK TRANSFER (SMS BANKING)

### **Butuh Screenshot SMS Bank Dulu!**

Sebelum setup, tolong screenshot SMS dari bank (BCA/BNI/Mandiri/BRI) saat ada transfer masuk.

**Format biasanya:**
```
[BCA] Terima transfer Rp 150.123 dari JOHN DOE ke rek 1234567890. Saldo: Rp XXX.XXX
```

### **Setup Macro (Mirip QRIS, tapi trigger & regex beda)**

1. **Trigger**: SMS Received
2. **Sender**: Contains `BCA` atau `BNI` (sesuai bank)
3. **Content**: Contains `Terima` atau `transfer`
4. **Regex untuk extract**:
```regex
Rp\s*([\d\.]+)
```
5. **Extract 3 digit terakhir** sebagai kode unik:
```
Kode unik = amount % 1000
```
6. **HTTP Request Body**:
```json
{
  "method": "bank_transfer",
  "amount": {lv=amount_clean},
  "unique_code": {lv=unique_code}
}
```

---

## 🔐 4. KEAMANAN (RECOMMENDED!)

### **Setup Auth Key di NEO PGA**

1. Login ke **Admin Panel** → Settings
2. Tambah setting baru:
   - Key: `macrodroid_secret_key`
   - Value: Generate random string (32 karakter)
   - Contoh: `nb_macro_xyz123abc456def789`
3. Save

### **Tambah Auth Key di MacroDroid**

Di step **HTTP Request**, tambah header:
```
Authorization: nb_macro_xyz123abc456def789
```

Ini memastikan hanya MacroDroid kamu yang bisa hit API auto-verify.

---

## 🧪 5. TESTING

### **Test QRIS:**

1. Buat transaksi test di NEO PGA (amount: Rp 1.000)
2. Scan QRIS dengan GoPay
3. Bayar Rp 1.000
4. Tunggu notifikasi masuk
5. MacroDroid otomatis trigger
6. Cek di dashboard → Status jadi "Success" ✅

### **Test Bank Transfer:**

1. Buat transaksi test (amount: Rp 150.000)
2. System assign kode unik: 123
3. Transfer ke bank: Rp 150.123
4. Tunggu SMS masuk
5. MacroDroid otomatis trigger
6. Cek dashboard → Status jadi "Success" ✅

### **Cek Log:**

- Dashboard → Activity Logs
- Lihat entry: "auto_verify_success"
- Pastikan webhook terkirim ke merchant

---

## 📊 6. MONITORING

### **MacroDroid Logs:**

1. Buka MacroDroid
2. Tap **☰** → **Log**
3. Lihat history macro yang di-trigger
4. Check error jika ada yang gagal

### **NEO PGA API Logs:**

1. Admin Panel → API Logs
2. Filter endpoint: `/api/auto-verify.php`
3. Lihat success rate & response time

---

## ⚠️ 7. TROUBLESHOOTING

### **Problem: Macro tidak trigger**

✅ **Check:**
- Notification permission enabled?
- MacroDroid running di background?
- Battery optimization disabled untuk MacroDroid?

### **Problem: Amount tidak ke-extract**

✅ **Check:**
- Regex pattern benar?
- Format notifikasi berubah?
- Test regex di https://regex101.com

### **Problem: API return error**

✅ **Check:**
- Internet connection OK?
- API URL benar?
- Auth key valid?
- Check response di MacroDroid log

### **Problem: Salah approve transaksi (QRIS)**

✅ **Solusi:**
- Sistem approve yang **paling lama pending** (FIFO)
- Atau pakai bank transfer (100% akurat dengan kode unik)

---

## 💡 8. TIPS & BEST PRACTICES

### **1. Backup Macro**

MacroDroid → ☰ → Backup/Restore → Backup
Simpan file backup di Google Drive

### **2. Multiple Bank Accounts**

Buat macro terpisah untuk tiap bank:
- Macro 1: BCA
- Macro 2: BNI
- Macro 3: Mandiri

### **3. Notifikasi Suara**

Tambah action **Play Sound** biar tahu kalau ada payment masuk!

### **4. Log ke Google Sheets (Advanced)**

MacroDroid bisa HTTP POST ke Google Apps Script → simpan log payment ke spreadsheet untuk monitoring.

---

## 📞 BUTUH BANTUAN SETUP?

**WhatsApp: 0895-3434-07575**

Kirim:
- Screenshot notifikasi (QRIS atau SMS bank)
- URL NEO PGA kamu
- Saya bantu setupin MacroDroid-nya! 😊

---

## 🎬 VIDEO TUTORIAL (Coming Soon!)

Saya akan buat video tutorial step-by-step di YouTube:
- Setup MacroDroid dari 0
- Test real payment
- Troubleshooting

Subscribe channel: **[NEO PGA Official]**

---

**© 2025 NEO PGA - Payment Gateway Termudah di Indonesia**

<?php
/**
 * NEO PGA Transaction Class
 * Handles all payment transaction operations
 */

class Transaction
{
    private Database $db;
    private QRISGenerator $qris;

    public function __construct()
    {
        $this->db = db();
        $this->qris = new QRISGenerator();
    }

    /**
     * Create new transaction
     */
    public function create(array $data): array
    {
        try {
            $this->db->beginTransaction();

            // Validate merchant
            $merchant = $this->db->find('merchants', $data['merchant_id']);
            if (!$merchant || $merchant['status'] !== 'active') {
                throw new Exception('Merchant tidak valid atau tidak aktif');
            }

            // Validate amount
            $amount = (int) $data['amount'];
            if ($amount < MIN_AMOUNT || $amount > MAX_AMOUNT) {
                throw new Exception('Jumlah tidak valid (min: ' . formatRupiah(MIN_AMOUNT) . ', max: ' . formatRupiah(MAX_AMOUNT) . ')');
            }

            // Generate invoice number
            $invoiceNumber = $this->generateInvoiceNumber();

            // Get unique code
            $uniqueCode = $this->getUniqueCode($merchant['id']);

            // Calculate amounts
            $adminFee = 0; // Can be configured per merchant
            $totalAmount = $amount + $uniqueCode + $adminFee;
            $commissionAmount = round($amount * ($merchant['commission_rate'] / 100), 2);
            $netAmount = $amount - $commissionAmount;

            // Set expiry
            $expiryMinutes = $data['expiry_minutes'] ?? PAYMENT_EXPIRY_MINUTES;
            $expiredAt = date('Y-m-d H:i:s', strtotime("+{$expiryMinutes} minutes"));

            // Build transaction data
            $transactionData = [
                'invoice_number' => $invoiceNumber,
                'merchant_id' => $merchant['id'],
                'reference_id' => $data['reference_id'] ?? null,
                'customer_name' => $data['customer_name'] ?? null,
                'customer_email' => $data['customer_email'] ?? null,
                'customer_phone' => $data['customer_phone'] ?? null,
                'description' => $data['description'] ?? null,
                'amount' => $amount,
                'unique_code' => $uniqueCode,
                'admin_fee' => $adminFee,
                'total_amount' => $totalAmount,
                'commission_amount' => $commissionAmount,
                'net_amount' => $netAmount,
                'payment_method' => $data['payment_method'] ?? 'qris',
                'payment_channel' => $data['payment_channel'] ?? null,
                'status' => 'pending',
                'expired_at' => $expiredAt,
                'ip_address' => getClientIP(),
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? null,
                'metadata' => isset($data['metadata']) ? json_encode($data['metadata']) : null
            ];

            // Handle payment method specific data
            if ($transactionData['payment_method'] === 'qris') {
                $qrisResult = $this->qris->generateWithResult($totalAmount, $invoiceNumber);
                if (!$qrisResult['success']) {
                    throw new Exception('Gagal generate QRIS: ' . ($qrisResult['message'] ?? 'Unknown error'));
                }
                $transactionData['qris_string'] = $qrisResult['qris_string'];
                $transactionData['qris_image_url'] = $this->qris->generateQRImage($qrisResult['qris_string']);
            } elseif ($transactionData['payment_method'] === 'bank_transfer') {
                $bankAccountId = $data['bank_account_id'] ?? null;
                if (!$bankAccountId) {
                    // Get default bank account
                    $bankAccount = $this->db->query(
                        "SELECT id FROM bank_accounts WHERE is_active = 1 ORDER BY display_order LIMIT 1"
                    )->fetch();
                    $bankAccountId = $bankAccount['id'] ?? null;
                }
                $transactionData['bank_account_id'] = $bankAccountId;
            }

            // Reserve payment code
            if ($uniqueCode > 0) {
                $paymentCode = $this->reservePaymentCode($merchant['id'], $uniqueCode);
                $transactionData['payment_code_id'] = $paymentCode['id'] ?? null;
            }

            // Insert transaction
            $transactionId = $this->db->insert('transactions', $transactionData);

            // Update payment code with transaction ID
            if (isset($paymentCode['id'])) {
                $this->db->update('payment_codes', [
                    'transaction_id' => $transactionId,
                    'status' => 'reserved'
                ], 'id = ?', [$paymentCode['id']]);
            }

            // Update transaction status to waiting
            $this->db->update('transactions', ['status' => 'waiting'], 'id = ?', [$transactionId]);

            $this->db->commit();

            // Get full transaction data
            $transaction = $this->getById($transactionId);

            // Send notification to merchant
            $this->sendMerchantNotification($transaction, 'created');

            return [
                'success' => true,
                'message' => 'Transaksi berhasil dibuat',
                'data' => $this->formatTransactionResponse($transaction)
            ];

        } catch (Exception $e) {
            $this->db->rollback();
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }

    /**
     * Get transaction by ID
     */
    public function getById(int $id): ?array
    {
        return $this->db->query(
            "SELECT t.*, m.business_name as merchant_name, m.merchant_code,
                    ba.bank_name, ba.account_number as bank_account_number, ba.account_name as bank_account_name
             FROM transactions t
             LEFT JOIN merchants m ON t.merchant_id = m.id
             LEFT JOIN bank_accounts ba ON t.bank_account_id = ba.id
             WHERE t.id = ?",
            [$id]
        )->fetch();
    }

    /**
     * Get transaction by invoice number
     */
    public function getByInvoice(string $invoiceNumber): ?array
    {
        return $this->db->query(
            "SELECT t.*, m.business_name as merchant_name, m.merchant_code,
                    ba.bank_name, ba.account_number as bank_account_number, ba.account_name as bank_account_name
             FROM transactions t
             LEFT JOIN merchants m ON t.merchant_id = m.id
             LEFT JOIN bank_accounts ba ON t.bank_account_id = ba.id
             WHERE t.invoice_number = ?",
            [$invoiceNumber]
        )->fetch();
    }

    /**
     * Find transaction by unique amount (for auto-verification)
     */
    public function findByUniqueAmount(int $amount, int $merchantId = null): ?array
    {
        $sql = "SELECT t.*, m.webhook_url, m.secret_key
                FROM transactions t
                LEFT JOIN merchants m ON t.merchant_id = m.id
                WHERE t.total_amount = ?
                AND t.status IN ('pending', 'waiting')
                AND t.expired_at > NOW()";
        
        $params = [$amount];
        
        if ($merchantId) {
            $sql .= " AND t.merchant_id = ?";
            $params[] = $merchantId;
        }
        
        $sql .= " ORDER BY t.created_at DESC LIMIT 1";

        return $this->db->query($sql, $params)->fetch();
    }

    /**
     * Verify/confirm payment
     */
    public function verify(int $transactionId, int $adminId = null, string $notes = ''): array
    {
        try {
            $this->db->beginTransaction();

            $transaction = $this->getById($transactionId);
            
            if (!$transaction) {
                throw new Exception('Transaksi tidak ditemukan');
            }

            if ($transaction['status'] === 'success') {
                throw new Exception('Transaksi sudah diverifikasi');
            }

            if (!in_array($transaction['status'], ['pending', 'waiting', 'processing'])) {
                throw new Exception('Status transaksi tidak valid untuk verifikasi');
            }

            // Update transaction status
            $this->db->update('transactions', [
                'status' => 'success',
                'paid_at' => date('Y-m-d H:i:s'),
                'verified_by' => $adminId,
                'verified_at' => date('Y-m-d H:i:s'),
                'verification_notes' => $notes
            ], 'id = ?', [$transactionId]);

            // Update merchant balance
            $this->updateMerchantBalance($transaction);

            // Release payment code
            if ($transaction['payment_code_id']) {
                $this->releasePaymentCode($transaction['payment_code_id'], true);
            }

            $this->db->commit();

            // Get updated transaction
            $transaction = $this->getById($transactionId);

            // Send webhook
            $this->sendWebhook($transaction);

            // Send notification
            $this->sendMerchantNotification($transaction, 'verified');

            return [
                'success' => true,
                'message' => 'Transaksi berhasil diverifikasi',
                'data' => $transaction
            ];

        } catch (Exception $e) {
            $this->db->rollback();
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }

    /**
     * Auto-verify transaction by amount
     */
    public function autoVerify(int $amount, int $merchantId = null): array
    {
        $transaction = $this->findByUniqueAmount($amount, $merchantId);

        if (!$transaction) {
            return [
                'success' => false,
                'message' => 'Transaksi tidak ditemukan dengan nominal tersebut'
            ];
        }

        return $this->verify($transaction['id'], null, 'Auto-verified by system');
    }

    /**
     * Cancel transaction
     */
    public function cancel(int $transactionId, string $reason = ''): array
    {
        try {
            $transaction = $this->getById($transactionId);
            
            if (!$transaction) {
                throw new Exception('Transaksi tidak ditemukan');
            }

            if (!in_array($transaction['status'], ['pending', 'waiting'])) {
                throw new Exception('Transaksi tidak dapat dibatalkan');
            }

            $this->db->update('transactions', [
                'status' => 'cancelled',
                'verification_notes' => $reason
            ], 'id = ?', [$transactionId]);

            // Release payment code
            if ($transaction['payment_code_id']) {
                $this->releasePaymentCode($transaction['payment_code_id'], false);
            }

            return [
                'success' => true,
                'message' => 'Transaksi berhasil dibatalkan'
            ];

        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }

    /**
     * Expire old transactions
     */
    public function expireOldTransactions(): int
    {
        // Get expired transactions
        $expired = $this->db->query(
            "SELECT id, payment_code_id FROM transactions 
             WHERE status IN ('pending', 'waiting') 
             AND expired_at < NOW()"
        )->fetchAll();

        $count = 0;
        foreach ($expired as $transaction) {
            $this->db->update('transactions', ['status' => 'expired'], 'id = ?', [$transaction['id']]);
            
            if ($transaction['payment_code_id']) {
                $this->releasePaymentCode($transaction['payment_code_id'], false);
            }
            $count++;
        }

        return $count;
    }

    /**
     * Get transactions with filters
     */
    public function getList(array $filters = [], int $page = 1, int $perPage = 20): array
    {
        $where = ['1=1'];
        $params = [];

        if (!empty($filters['merchant_id'])) {
            $where[] = 't.merchant_id = ?';
            $params[] = $filters['merchant_id'];
        }

        if (!empty($filters['status'])) {
            $where[] = 't.status = ?';
            $params[] = $filters['status'];
        }

        if (!empty($filters['payment_method'])) {
            $where[] = 't.payment_method = ?';
            $params[] = $filters['payment_method'];
        }

        if (!empty($filters['date_from'])) {
            $where[] = 't.created_at >= ?';
            $params[] = $filters['date_from'] . ' 00:00:00';
        }

        if (!empty($filters['date_to'])) {
            $where[] = 't.created_at <= ?';
            $params[] = $filters['date_to'] . ' 23:59:59';
        }

        if (!empty($filters['search'])) {
            $where[] = '(t.invoice_number LIKE ? OR t.customer_name LIKE ? OR t.customer_email LIKE ?)';
            $search = '%' . $filters['search'] . '%';
            $params = array_merge($params, [$search, $search, $search]);
        }

        $whereClause = implode(' AND ', $where);

        // Count total - ensure we get an integer
        $totalResult = $this->db->query(
            "SELECT COUNT(*) FROM transactions t WHERE {$whereClause}",
            $params
        )->fetchColumn();
        $total = (int) ($totalResult ?: 0);

        // Get data with pagination
        $offset = ($page - 1) * $perPage;
        $data = $this->db->query(
            "SELECT t.*, m.business_name as merchant_name, m.merchant_code
             FROM transactions t
             LEFT JOIN merchants m ON t.merchant_id = m.id
             WHERE {$whereClause}
             ORDER BY t.created_at DESC
             LIMIT {$perPage} OFFSET {$offset}",
            $params
        )->fetchAll();

        return [
            'data' => $data,
            'pagination' => [
                'current_page' => $page,
                'per_page' => $perPage,
                'total' => $total,
                'total_pages' => $total > 0 ? (int) ceil($total / $perPage) : 0
            ]
        ];
    }

    /**
     * Get transaction statistics
     */
    public function getStats(?int $merchantId = null, string $period = 'today'): array
    {
        // PHP 7.4 compatible (no match expression)
        switch ($period) {
            case 'today':
                $dateCondition = "DATE(created_at) = CURDATE()";
                break;
            case 'yesterday':
                $dateCondition = "DATE(created_at) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)";
                break;
            case 'week':
                $dateCondition = "created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)";
                break;
            case 'month':
                $dateCondition = "created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
                break;
            case 'year':
                $dateCondition = "created_at >= DATE_SUB(NOW(), INTERVAL 1 YEAR)";
                break;
            default:
                $dateCondition = "1=1";
        }

        $merchantCondition = $merchantId ? "AND merchant_id = {$merchantId}" : "";

        $stats = $this->db->query(
            "SELECT 
                COUNT(*) as total_transactions,
                SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) as success_count,
                SUM(CASE WHEN status = 'pending' OR status = 'waiting' THEN 1 ELSE 0 END) as pending_count,
                SUM(CASE WHEN status = 'failed' OR status = 'expired' THEN 1 ELSE 0 END) as failed_count,
                SUM(CASE WHEN status = 'success' THEN amount ELSE 0 END) as total_amount,
                SUM(CASE WHEN status = 'success' THEN commission_amount ELSE 0 END) as total_commission
             FROM transactions
             WHERE {$dateCondition} {$merchantCondition}"
        )->fetch();

        // Ensure all values are properly typed even if null
        $totalTransactions = (int) ($stats['total_transactions'] ?? 0);
        $successCount = (int) ($stats['success_count'] ?? 0);
        
        return [
            'total_transactions' => $totalTransactions,
            'success_count' => $successCount,
            'pending_count' => (int) ($stats['pending_count'] ?? 0),
            'failed_count' => (int) ($stats['failed_count'] ?? 0),
            'total_amount' => (float) ($stats['total_amount'] ?? 0),
            'total_commission' => (float) ($stats['total_commission'] ?? 0),
            'success_rate' => $totalTransactions > 0 
                ? round(($successCount / $totalTransactions) * 100, 2) 
                : 0.0
        ];
    }

    // ==========================================
    // PRIVATE HELPER METHODS
    // ==========================================

    /**
     * Generate unique invoice number
     */
    private function generateInvoiceNumber(): string
    {
        do {
            $invoice = 'NB' . date('Ymd') . strtoupper(generateRandomString(6, 'alphanumeric'));
        } while ($this->db->exists('transactions', 'invoice_number = ?', [$invoice]));

        return $invoice;
    }

    /**
     * Get available unique code (WAJIB - tidak boleh tanpa kode unik)
     * Dengan auto-reset jika kode habis atau hampir habis
     */
    private function getUniqueCode(int $merchantId): int
    {
        // Auto-reset expired/used codes terlebih dahulu
        $this->autoResetPaymentCodes($merchantId);

        // Cek jumlah kode tersedia
        $availableCount = $this->getAvailableCodeCount($merchantId);

        // Jika kode tersedia kurang dari 5, langsung auto-reset kode used
        // Ini untuk memastikan selalu ada kode tersedia
        if ($availableCount < 5) {
            $this->forceResetAllPaymentCodes($merchantId);

            // Log bahwa auto-reset terjadi karena kode hampir habis
            logActivity('system', null, 'payment_code_auto_reset', 'payment_codes',
                "Auto-reset triggered: available codes for merchant #{$merchantId} was {$availableCount}");
        }

        // Get available code from pool
        $code = $this->db->query(
            "SELECT code FROM payment_codes
             WHERE merchant_id = ? AND status = 'available'
             ORDER BY RAND() LIMIT 1",
            [$merchantId]
        )->fetch();

        if ($code) {
            return (int) $code['code'];
        }

        // Jika semua kode habis, force reset semua kode 'used' menjadi 'available'
        $this->forceResetAllPaymentCodes($merchantId);

        // Coba ambil lagi setelah reset
        $code = $this->db->query(
            "SELECT code FROM payment_codes
             WHERE merchant_id = ? AND status = 'available'
             ORDER BY RAND() LIMIT 1",
            [$merchantId]
        )->fetch();

        if ($code) {
            return (int) $code['code'];
        }

        // Jika masih tidak ada (pool kosong), generate pool baru
        $this->generatePaymentCodePool($merchantId);

        // Ambil kode dari pool yang baru dibuat
        $code = $this->db->query(
            "SELECT code FROM payment_codes
             WHERE merchant_id = ? AND status = 'available'
             ORDER BY RAND() LIMIT 1",
            [$merchantId]
        )->fetch();

        return $code ? (int) $code['code'] : rand(UNIQUE_CODE_MIN, UNIQUE_CODE_MAX);
    }

    /**
     * Get count of available payment codes for merchant
     */
    private function getAvailableCodeCount(int $merchantId): int
    {
        $result = $this->db->query(
            "SELECT COUNT(*) as count FROM payment_codes
             WHERE merchant_id = ? AND status = 'available'",
            [$merchantId]
        )->fetch();

        return (int) ($result['count'] ?? 0);
    }
    
    /**
     * Auto-reset expired payment codes
     */
    private function autoResetPaymentCodes(int $merchantId): void
    {
        // Reset kode yang expired (transaksi sudah expired tapi kode masih reserved)
        $this->db->query(
            "UPDATE payment_codes pc
             LEFT JOIN transactions t ON pc.transaction_id = t.id
             SET pc.status = 'available', 
                 pc.transaction_id = NULL, 
                 pc.reserved_at = NULL, 
                 pc.expires_at = NULL,
                 pc.used_at = NULL
             WHERE pc.merchant_id = ? 
             AND pc.status = 'reserved'
             AND (pc.expires_at < NOW() OR t.status IN ('expired', 'cancelled', 'failed'))",
            [$merchantId]
        );
        
        // Reset kode 'used' yang transaksinya sudah lebih dari 24 jam (recycle)
        $this->db->query(
            "UPDATE payment_codes pc
             SET pc.status = 'available', 
                 pc.transaction_id = NULL, 
                 pc.reserved_at = NULL, 
                 pc.expires_at = NULL,
                 pc.used_at = NULL
             WHERE pc.merchant_id = ? 
             AND pc.status = 'used'
             AND pc.used_at < DATE_SUB(NOW(), INTERVAL 24 HOUR)",
            [$merchantId]
        );
    }
    
    /**
     * Force reset semua payment codes (ketika kode habis)
     */
    private function forceResetAllPaymentCodes(int $merchantId): void
    {
        // Reset semua kode 'used' menjadi 'available'
        $this->db->query(
            "UPDATE payment_codes 
             SET status = 'available', 
                 transaction_id = NULL, 
                 reserved_at = NULL, 
                 expires_at = NULL,
                 used_at = NULL
             WHERE merchant_id = ? 
             AND status = 'used'",
            [$merchantId]
        );
        
        // Log aktivitas
        logActivity('system', null, 'payment_code_reset', 'payment_codes', 
            "Auto-reset payment codes for merchant #{$merchantId} - codes depleted");
    }
    
    /**
     * Generate payment code pool untuk merchant
     */
    private function generatePaymentCodePool(int $merchantId): void
    {
        $min = defined('UNIQUE_CODE_MIN') ? UNIQUE_CODE_MIN : 1;
        $max = defined('UNIQUE_CODE_MAX') ? UNIQUE_CODE_MAX : 999;
        
        // Generate kode dari min sampai max
        for ($code = $min; $code <= $max; $code++) {
            // Cek apakah kode sudah ada
            $exists = $this->db->fetch(
                "SELECT id FROM payment_codes WHERE merchant_id = ? AND code = ?",
                [$merchantId, $code]
            );
            
            if (!$exists) {
                $this->db->query(
                    "INSERT INTO payment_codes (merchant_id, code, status) VALUES (?, ?, 'available')",
                    [$merchantId, $code]
                );
            }
        }
        
        logActivity('system', null, 'payment_code_pool_generated', 'payment_codes', 
            "Generated payment code pool for merchant #{$merchantId}");
    }

    /**
     * Reserve payment code
     */
    private function reservePaymentCode(int $merchantId, int $code): ?array
    {
        $paymentCode = $this->db->query(
            "SELECT * FROM payment_codes 
             WHERE merchant_id = ? AND code = ? AND status = 'available'
             LIMIT 1 FOR UPDATE",
            [$merchantId, $code]
        )->fetch();

        if ($paymentCode) {
            $this->db->update('payment_codes', [
                'status' => 'reserved',
                'reserved_at' => date('Y-m-d H:i:s'),
                'expires_at' => date('Y-m-d H:i:s', strtotime('+' . PAYMENT_EXPIRY_MINUTES . ' minutes'))
            ], 'id = ?', [$paymentCode['id']]);

            return $paymentCode;
        }

        return null;
    }

    /**
     * Release payment code
     */
    private function releasePaymentCode(int $paymentCodeId, bool $markAsUsed): void
    {
        $status = $markAsUsed ? 'used' : 'available';
        $update = ['status' => $status];
        
        if ($markAsUsed) {
            $update['used_at'] = date('Y-m-d H:i:s');
        } else {
            $update['reserved_at'] = null;
            $update['expires_at'] = null;
            $update['transaction_id'] = null;
        }

        $this->db->update('payment_codes', $update, 'id = ?', [$paymentCodeId]);
    }

    /**
     * Update merchant balance
     */
    private function updateMerchantBalance(array $transaction): void
    {
        $merchant = $this->db->find('merchants', $transaction['merchant_id']);
        
        $balanceBefore = $merchant['balance'];
        $balanceAfter = $balanceBefore + $transaction['net_amount'];

        // Update balance
        $this->db->update('merchants', [
            'balance' => $balanceAfter
        ], 'id = ?', [$transaction['merchant_id']]);

        // Log balance change
        $this->db->insert('balance_logs', [
            'merchant_id' => $transaction['merchant_id'],
            'transaction_id' => $transaction['id'],
            'type' => 'credit',
            'amount' => $transaction['net_amount'],
            'balance_before' => $balanceBefore,
            'balance_after' => $balanceAfter,
            'description' => 'Payment received: ' . $transaction['invoice_number']
        ]);
    }

    /**
     * Send webhook notification
     */
    private function sendWebhook(array $transaction): void
    {
        if (!WEBHOOK_ENABLED) return;

        $merchant = $this->db->find('merchants', $transaction['merchant_id']);
        
        if (empty($merchant['webhook_url'])) return;

        // Build webhook payload - format yang kompatibel dengan client
        $payload = [
            'event' => 'payment.success',
            'data' => [
                'invoice_number' => $transaction['invoice_number'],
                'reference_id' => $transaction['reference_id'],
                'amount' => (int) $transaction['amount'],
                'unique_code' => (int) $transaction['unique_code'],
                'total_amount' => (int) $transaction['total_amount'],
                'status' => 'success',
                'paid_at' => $transaction['paid_at'] ?? date('Y-m-d H:i:s'),
                'customer' => [
                    'name' => $transaction['customer_name'],
                    'email' => $transaction['customer_email'],
                    'phone' => $transaction['customer_phone']
                ],
                'payment_method' => $transaction['payment_method']
            ],
            'timestamp' => date('c')
        ];

        // Generate signature
        $signature = hash_hmac('sha256', json_encode($payload), $merchant['secret_key']);

        // Send webhook
        $ch = curl_init($merchant['webhook_url']);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($payload),
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'X-Signature: ' . $signature,
                'X-Webhook-ID: ' . uniqid('wh_')
            ],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => WEBHOOK_TIMEOUT
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        // Log webhook
        $this->db->insert('webhook_logs', [
            'transaction_id' => $transaction['id'],
            'merchant_id' => $transaction['merchant_id'],
            'webhook_url' => $merchant['webhook_url'],
            'request_payload' => json_encode($payload),
            'response_code' => $httpCode,
            'response_body' => $response,
            'status' => ($httpCode >= 200 && $httpCode < 300) ? 'success' : 'failed',
            'error_message' => $error ?: null
        ]);

        // Update transaction webhook status
        $currentAttempts = (int) ($transaction['webhook_attempts'] ?? 0);
        $this->db->update('transactions', [
            'webhook_status' => ($httpCode >= 200 && $httpCode < 300) ? 'success' : 'failed',
            'webhook_attempts' => $currentAttempts + 1,
            'webhook_last_attempt' => date('Y-m-d H:i:s'),
            'webhook_response' => $response
        ], 'id = ?', [$transaction['id']]);
    }

    /**
     * Send notification to merchant
     */
    private function sendMerchantNotification(array $transaction, string $event): void
    {
        $titles = [
            'created' => 'Transaksi Baru',
            'verified' => 'Pembayaran Berhasil'
        ];

        $messages = [
            'created' => "Transaksi baru #{$transaction['invoice_number']} sebesar " . formatRupiah($transaction['amount']),
            'verified' => "Pembayaran #{$transaction['invoice_number']} sebesar " . formatRupiah($transaction['amount']) . " berhasil diverifikasi"
        ];

        $this->db->insert('notifications', [
            'merchant_id' => $transaction['merchant_id'],
            'type' => 'payment',
            'title' => $titles[$event] ?? 'Notifikasi',
            'message' => $messages[$event] ?? '',
            'action_url' => '/merchant/transactions.php?id=' . $transaction['id'],
            'metadata' => json_encode(['transaction_id' => $transaction['id']])
        ]);
    }

    /**
     * Format transaction for API response
     */
    private function formatTransactionResponse(array $transaction): array
    {
        return [
            'invoice_number' => $transaction['invoice_number'],
            'reference_id' => $transaction['reference_id'],
            'amount' => (float) $transaction['amount'],
            'unique_code' => (int) $transaction['unique_code'],
            'admin_fee' => (float) $transaction['admin_fee'],
            'total_amount' => (float) $transaction['total_amount'],
            'payment_method' => $transaction['payment_method'],
            'status' => $transaction['status'],
            'customer' => [
                'name' => $transaction['customer_name'],
                'email' => $transaction['customer_email'],
                'phone' => $transaction['customer_phone']
            ],
            'payment_details' => $this->getPaymentDetails($transaction),
            'expired_at' => $transaction['expired_at'],
            'paid_at' => $transaction['paid_at'],
            'created_at' => $transaction['created_at']
        ];
    }

    /**
     * Get payment details based on method
     */
    private function getPaymentDetails(array $transaction): array
    {
        if ($transaction['payment_method'] === 'qris') {
            return [
                'qris_string' => $transaction['qris_string'],
                'qris_image_url' => $transaction['qris_image_url']
            ];
        }

        if ($transaction['payment_method'] === 'bank_transfer') {
            return [
                'bank_name' => $transaction['bank_name'] ?? null,
                'account_number' => $transaction['bank_account_number'] ?? null,
                'account_name' => $transaction['bank_account_name'] ?? null
            ];
        }

        return [];
    }
}

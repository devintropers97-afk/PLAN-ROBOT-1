<?php
/**
 * =====================================================================
 * NEO PGA SDK - VERSI FULL (QRIS + BANK TRANSFER)
 * =====================================================================
 *
 * SDK ini cocok untuk:
 * - Toko online / e-commerce
 * - Checkout produk dengan harga tetap
 * - Sistem booking / reservasi
 * - Invoice / tagihan
 *
 * FITUR:
 * - Pembayaran QRIS (GoPay, OVO, DANA, LinkAja, dll)
 * - Transfer Bank (BCA, Mandiri, BNI, BRI, dll)
 * - Unique code untuk verifikasi otomatis
 * - Webhook/callback untuk notifikasi real-time
 *
 * ALUR PEMBAYARAN:
 * 1. Customer checkout dengan produk/layanan tertentu
 * 2. Sistem membuat invoice dengan nominal tetap
 * 3. Customer pilih metode: QRIS atau Transfer Bank
 * 4. Customer bayar sesuai nominal + kode unik
 * 5. Pembayaran sukses -> Webhook dikirim ke callback.php
 *
 * =====================================================================
 * CARA PAKAI:
 * =====================================================================
 *
 * LANGKAH 1: Copy file ini ke hosting (misal: /includes/neopga.php)
 *
 * LANGKAH 2: Ganti kredensial di bawah
 *
 * LANGKAH 3: Di halaman checkout:
 *
 *   require_once 'includes/neopga.php';
 *
 *   // Checkout dengan QRIS
 *   $result = NeoPGA::checkout(150000, 'ORDER-123', 'Pembelian Produk ABC', [
 *       'name'  => 'John Doe',
 *       'email' => 'john@email.com'
 *   ], 'qris');
 *
 *   // ATAU checkout dengan Bank Transfer
 *   $result = NeoPGA::checkout(150000, 'ORDER-456', 'Pembelian', [], 'bank_transfer');
 *
 *   if ($result['success']) {
 *       header('Location: ' . $result['payment_url']);
 *       exit;
 *   }
 *
 * LANGKAH 4: Buat callback.php untuk terima notifikasi
 *
 * =====================================================================
 */

class NeoPGA
{
    // =====================================================================
    // GANTI DENGAN KREDENSIAL ANDA (dari menu API Keys di dashboard)
    // =====================================================================
    const API_KEY    = 'GANTI_DENGAN_API_KEY_ANDA';
    const SECRET_KEY = 'GANTI_DENGAN_SECRET_KEY_ANDA';
    const BASE_URL   = 'https://DOMAIN_NEOPGA_ANDA.com';  // Tanpa trailing slash
    // =====================================================================

    // Metode pembayaran yang tersedia
    const METHOD_QRIS = 'qris';
    const METHOD_BANK = 'bank_transfer';

    /**
     * BUAT PEMBAYARAN (CHECKOUT)
     *
     * @param int    $amount      Nominal pembayaran (harga produk)
     * @param string $referenceId ID unik order dari sistem Anda
     * @param string $description Deskripsi pembayaran
     * @param array  $customer    Data customer
     * @param string $method      'qris' atau 'bank_transfer'
     * @return array
     *
     * CONTOH:
     *
     *   // Checkout QRIS - harga Rp 150.000
     *   $result = NeoPGA::checkout(150000, 'ORDER-001', 'Beli Sepatu Nike', [
     *       'name'  => 'John Doe',
     *       'email' => 'john@email.com',
     *       'phone' => '081234567890'
     *   ], 'qris');
     *
     *   // Checkout Bank Transfer
     *   $result = NeoPGA::checkout(500000, 'ORDER-002', 'Booking Hotel', [
     *       'name' => 'Jane Doe'
     *   ], 'bank_transfer');
     *
     *   // Hasil
     *   if ($result['success']) {
     *       $invoiceNumber = $result['data']['invoice_number'];
     *       $totalAmount = $result['data']['total_amount'];  // Termasuk kode unik
     *       $uniqueCode = $result['data']['unique_code'];
     *       $paymentUrl = $result['payment_url'];
     *
     *       // Redirect ke halaman pembayaran
     *       header('Location: ' . $paymentUrl);
     *       exit;
     *   } else {
     *       echo 'Error: ' . $result['error'];
     *   }
     */
    public static function checkout($amount, $referenceId, $description = '', $customer = [], $method = 'qris')
    {
        $data = [
            'reference_id'   => $referenceId,
            'amount'         => (int) $amount,
            'payment_method' => $method,
            'description'    => $description ?: 'Pembayaran',
            'customer_name'  => $customer['name'] ?? '',
            'customer_email' => $customer['email'] ?? '',
            'customer_phone' => $customer['phone'] ?? '',
        ];

        return self::request('POST', '/api/create.php', $data);
    }

    /**
     * BUAT PEMBAYARAN QRIS
     *
     * Shortcut untuk checkout dengan QRIS
     */
    public static function createQRIS($amount, $referenceId, $description = '', $customer = [])
    {
        return self::checkout($amount, $referenceId, $description, $customer, self::METHOD_QRIS);
    }

    /**
     * BUAT PEMBAYARAN BANK TRANSFER
     *
     * Shortcut untuk checkout dengan Bank Transfer
     */
    public static function createBankTransfer($amount, $referenceId, $description = '', $customer = [])
    {
        return self::checkout($amount, $referenceId, $description, $customer, self::METHOD_BANK);
    }

    /**
     * CEK STATUS PEMBAYARAN
     *
     * @param string $invoice Invoice number dari NEO PGA
     * @return array
     *
     * CONTOH:
     *   $status = NeoPGA::checkStatus('INV20231209ABCD1234');
     *
     *   if ($status['success']) {
     *       switch ($status['data']['status']) {
     *           case 'success':
     *               echo 'Pembayaran berhasil!';
     *               break;
     *           case 'pending':
     *               echo 'Menunggu pembayaran...';
     *               break;
     *           case 'expired':
     *               echo 'Pembayaran expired';
     *               break;
     *           case 'failed':
     *               echo 'Pembayaran gagal';
     *               break;
     *       }
     *   }
     */
    public static function checkStatus($invoice)
    {
        return self::request('GET', '/api/status.php?invoice=' . urlencode($invoice));
    }

    /**
     * CEK STATUS BY REFERENCE ID
     *
     * Cek status menggunakan order ID dari sistem Anda
     */
    public static function checkStatusByRef($referenceId)
    {
        return self::request('GET', '/api/status.php?reference_id=' . urlencode($referenceId));
    }

    /**
     * VERIFIKASI CALLBACK/WEBHOOK
     *
     * Panggil di file callback.php untuk memverifikasi request dari NEO PGA
     *
     * @return array|false Data pembayaran jika valid, false jika tidak
     *
     * CONTOH (buat file callback.php):
     *
     *   <?php
     *   require_once 'includes/neopga.php';
     *
     *   $payment = NeoPGA::verifyCallback();
     *
     *   if ($payment && $payment['status'] === 'success') {
     *       // Data yang tersedia:
     *       $orderId = $payment['reference_id'];       // ID order Anda
     *       $amount = $payment['amount'];              // Nominal asli
     *       $totalAmount = $payment['total_amount'];   // Nominal + kode unik
     *       $uniqueCode = $payment['unique_code'];     // Kode unik
     *       $method = $payment['payment_method'];      // 'qris' atau 'bank_transfer'
     *       $invoice = $payment['invoice_number'];
     *       $paidAt = $payment['paid_at'];
     *
     *       // Update order di database
     *       updateOrderStatus($orderId, 'paid');
     *
     *       // Kirim email konfirmasi
     *       sendOrderConfirmation($orderId);
     *
     *       // WAJIB: Response 200 OK
     *       http_response_code(200);
     *       echo json_encode(['status' => 'ok']);
     *   }
     */
    public static function verifyCallback()
    {
        $payload = file_get_contents('php://input');
        $signature = $_SERVER['HTTP_X_SIGNATURE'] ?? '';

        if (empty($payload) || empty($signature)) {
            return false;
        }

        $expectedSignature = hash_hmac('sha256', $payload, self::SECRET_KEY);

        if (!hash_equals($expectedSignature, $signature)) {
            return false;
        }

        $data = json_decode($payload, true);
        return $data['data'] ?? $data;
    }

    /**
     * GET PAYMENT URL
     */
    public static function getPaymentUrl($invoice)
    {
        return self::BASE_URL . '/public/pay.php?invoice=' . urlencode($invoice);
    }

    // =====================================================================
    // INTERNAL METHODS
    // =====================================================================

    private static function request($method, $endpoint, $data = [])
    {
        $url = self::BASE_URL . $endpoint;

        $headers = [
            'Content-Type: application/json',
            'X-API-Key: ' . self::API_KEY,
        ];

        if ($method === 'POST' && !empty($data)) {
            $jsonData = json_encode($data);
            $signature = hash_hmac('sha256', $jsonData, self::SECRET_KEY);
            $headers[] = 'X-Signature: ' . $signature;
        }

        $ch = curl_init();

        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData ?? '');
        }

        curl_setopt_array($ch, [
            CURLOPT_URL            => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 30,
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);

        $response = curl_exec($ch);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) {
            return ['success' => false, 'error' => 'Connection error: ' . $error];
        }

        $result = json_decode($response, true);

        if (!$result) {
            return ['success' => false, 'error' => 'Invalid response from server'];
        }

        if (isset($result['data']['invoice_number'])) {
            $result['payment_url'] = self::getPaymentUrl($result['data']['invoice_number']);
        }

        return $result;
    }
}

// =====================================================================
// SHORTCUT FUNCTIONS
// =====================================================================

function neopga_checkout($amount, $referenceId, $description = '', $customer = [], $method = 'qris')
{
    return NeoPGA::checkout($amount, $referenceId, $description, $customer, $method);
}

function neopga_qris($amount, $referenceId, $description = '', $customer = [])
{
    return NeoPGA::createQRIS($amount, $referenceId, $description, $customer);
}

function neopga_bank($amount, $referenceId, $description = '', $customer = [])
{
    return NeoPGA::createBankTransfer($amount, $referenceId, $description, $customer);
}

function neopga_status($invoice)
{
    return NeoPGA::checkStatus($invoice);
}

function neopga_verify()
{
    return NeoPGA::verifyCallback();
}


// =====================================================================
// CONTOH LENGKAP IMPLEMENTASI E-COMMERCE
// =====================================================================
/*

============================================================
FILE 1: checkout.php (Halaman Checkout)
============================================================

<?php
session_start();
require_once 'includes/neopga.php';
require_once 'includes/database.php';

// Ambil data cart dari session
$cart = $_SESSION['cart'] ?? [];
$totalHarga = 0;
foreach ($cart as $item) {
    $totalHarga += $item['price'] * $item['qty'];
}

// Process checkout
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize semua input untuk keamanan XSS
    $customerName = htmlspecialchars(strip_tags($_POST['name'] ?? ''), ENT_QUOTES, 'UTF-8');
    $customerEmail = filter_var($_POST['email'] ?? '', FILTER_SANITIZE_EMAIL);
    $customerPhone = preg_replace('/[^0-9+]/', '', $_POST['phone'] ?? '');
    $paymentMethod = htmlspecialchars(strip_tags($_POST['payment_method'] ?? 'qris'), ENT_QUOTES, 'UTF-8');

    // Validasi
    if (empty($customerName) || empty($customerEmail)) {
        $error = 'Nama dan email wajib diisi';
    } elseif ($totalHarga < 10000) {
        $error = 'Minimum order Rp 10.000';
    } else {
        // Simpan order ke database
        $orderId = 'ORD-' . date('Ymd') . '-' . rand(1000, 9999);

        $pdo->prepare("
            INSERT INTO orders (order_id, customer_name, customer_email, customer_phone, total, status, created_at)
            VALUES (?, ?, ?, ?, ?, 'pending', NOW())
        ")->execute([$orderId, $customerName, $customerEmail, $customerPhone, $totalHarga]);

        // Simpan order items
        foreach ($cart as $item) {
            $pdo->prepare("
                INSERT INTO order_items (order_id, product_id, product_name, price, qty)
                VALUES (?, ?, ?, ?, ?)
            ")->execute([$orderId, $item['id'], $item['name'], $item['price'], $item['qty']]);
        }

        // Buat pembayaran di NEO PGA
        $result = NeoPGA::checkout($totalHarga, $orderId, 'Pembelian di Toko ABC', [
            'name'  => $customerName,
            'email' => $customerEmail,
            'phone' => $customerPhone
        ], $paymentMethod);

        if ($result['success']) {
            // Simpan invoice number
            $invoice = $result['data']['invoice_number'];
            $pdo->prepare("UPDATE orders SET invoice_number = ? WHERE order_id = ?")->execute([$invoice, $orderId]);

            // Kosongkan cart
            unset($_SESSION['cart']);

            // Redirect ke halaman pembayaran
            header('Location: ' . $result['payment_url']);
            exit;
        } else {
            $error = $result['error'];
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Checkout</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; padding: 20px; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input, select { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 8px; font-size: 16px; }
        .order-summary { background: #f9f9f9; padding: 20px; border-radius: 10px; margin-bottom: 20px; }
        .total { font-size: 24px; font-weight: bold; color: #10b981; }
        .payment-options { display: flex; gap: 15px; margin-bottom: 20px; }
        .payment-option { flex: 1; padding: 20px; border: 2px solid #ddd; border-radius: 10px; text-align: center; cursor: pointer; }
        .payment-option:hover { border-color: #10b981; }
        .payment-option.selected { border-color: #10b981; background: #ecfdf5; }
        .payment-option input { display: none; }
        .checkout-btn { width: 100%; padding: 15px; background: #10b981; color: white; border: none;
                        border-radius: 10px; font-size: 18px; font-weight: bold; cursor: pointer; }
        .checkout-btn:hover { background: #059669; }
        .error { color: red; padding: 15px; background: #fee; border-radius: 8px; margin-bottom: 20px; }
    </style>
</head>
<body>
    <h1>Checkout</h1>

    <?php if (isset($error)): ?>
    <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="order-summary">
        <h3>Ringkasan Pesanan</h3>
        <?php foreach ($cart as $item): ?>
        <div style="display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid #eee;">
            <span><?= htmlspecialchars($item['name']) ?> x <?= $item['qty'] ?></span>
            <span>Rp <?= number_format($item['price'] * $item['qty']) ?></span>
        </div>
        <?php endforeach; ?>
        <div style="margin-top: 15px; padding-top: 15px; border-top: 2px solid #ddd;">
            <span>Total:</span>
            <span class="total">Rp <?= number_format($totalHarga) ?></span>
        </div>
    </div>

    <form method="POST">
        <div class="form-group">
            <label>Nama Lengkap *</label>
            <input type="text" name="name" required>
        </div>

        <div class="form-group">
            <label>Email *</label>
            <input type="email" name="email" required>
        </div>

        <div class="form-group">
            <label>No. HP</label>
            <input type="tel" name="phone">
        </div>

        <div class="form-group">
            <label>Metode Pembayaran</label>
            <div class="payment-options">
                <label class="payment-option selected" onclick="selectPayment('qris', this)">
                    <input type="radio" name="payment_method" value="qris" checked>
                    <div style="font-size: 32px;">📱</div>
                    <div style="font-weight: bold;">QRIS</div>
                    <div style="font-size: 12px; color: #666;">GoPay, OVO, DANA, dll</div>
                </label>
                <label class="payment-option" onclick="selectPayment('bank_transfer', this)">
                    <input type="radio" name="payment_method" value="bank_transfer">
                    <div style="font-size: 32px;">🏦</div>
                    <div style="font-weight: bold;">Transfer Bank</div>
                    <div style="font-size: 12px; color: #666;">BCA, Mandiri, BNI, BRI</div>
                </label>
            </div>
        </div>

        <button type="submit" class="checkout-btn">BAYAR Rp <?= number_format($totalHarga) ?></button>
    </form>

    <script>
    function selectPayment(value, element) {
        document.querySelectorAll('.payment-option').forEach(el => el.classList.remove('selected'));
        element.classList.add('selected');
        element.querySelector('input').checked = true;
    }
    </script>
</body>
</html>


============================================================
FILE 2: callback.php (Webhook Handler)
============================================================

<?php
require_once 'includes/neopga.php';
require_once 'includes/database.php';

// Log request untuk debugging
$logFile = 'logs/callback.log';
$logData = [
    'time' => date('Y-m-d H:i:s'),
    'ip' => $_SERVER['REMOTE_ADDR'],
    'method' => $_SERVER['REQUEST_METHOD'],
    'headers' => getallheaders(),
    'body' => file_get_contents('php://input')
];
file_put_contents($logFile, json_encode($logData) . "\n", FILE_APPEND);

// Verifikasi callback
$payment = NeoPGA::verifyCallback();

if ($payment && $payment['status'] === 'success') {
    // Data pembayaran
    $orderId = $payment['reference_id'];
    $amount = $payment['amount'];
    $totalAmount = $payment['total_amount'];
    $invoice = $payment['invoice_number'];
    $method = $payment['payment_method'];
    $paidAt = $payment['paid_at'];

    // Log sukses
    file_put_contents($logFile, date('Y-m-d H:i:s') . " - SUCCESS: $orderId ($method) - Rp $amount\n", FILE_APPEND);

    // Cek apakah order sudah pernah diproses (idempotency)
    $existingOrder = $pdo->query("SELECT status FROM orders WHERE order_id = '$orderId'")->fetch();

    if ($existingOrder && $existingOrder['status'] !== 'paid') {
        // Update status order
        $pdo->prepare("
            UPDATE orders
            SET status = 'paid',
                payment_method = ?,
                paid_amount = ?,
                paid_at = ?
            WHERE order_id = ?
        ")->execute([$method, $totalAmount, $paidAt, $orderId]);

        // Ambil data order untuk email
        $order = $pdo->query("SELECT * FROM orders WHERE order_id = '$orderId'")->fetch();

        // Kirim email konfirmasi ke customer
        if ($order['customer_email']) {
            $subject = "Pembayaran Berhasil - Order #$orderId";
            $message = "
                Halo {$order['customer_name']},

                Pembayaran Anda telah berhasil!

                Order ID: $orderId
                Total: Rp " . number_format($amount) . "
                Metode: " . ($method === 'qris' ? 'QRIS' : 'Transfer Bank') . "
                Tanggal: $paidAt

                Terima kasih telah berbelanja!
            ";
            // mail($order['customer_email'], $subject, $message);
        }

        // Kirim notifikasi ke admin (opsional)
        // sendTelegramNotification("Order baru dibayar: $orderId - Rp " . number_format($amount));
    }

    // Response sukses
    http_response_code(200);
    echo json_encode(['status' => 'ok', 'order_id' => $orderId]);

} else {
    // Callback tidak valid
    file_put_contents($logFile, date('Y-m-d H:i:s') . " - INVALID callback\n", FILE_APPEND);

    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Invalid callback']);
}


============================================================
FILE 3: order-status.php (Cek Status Order)
============================================================

<?php
require_once 'includes/neopga.php';
require_once 'includes/database.php';

$orderId = $_GET['order_id'] ?? '';

if (empty($orderId)) {
    die('Order ID tidak valid');
}

// Ambil data order dari database
$order = $pdo->query("SELECT * FROM orders WHERE order_id = '$orderId'")->fetch();

if (!$order) {
    die('Order tidak ditemukan');
}

// Jika ada invoice, cek status real-time dari NEO PGA
$neopgaStatus = null;
if ($order['invoice_number']) {
    $neopgaStatus = NeoPGA::checkStatus($order['invoice_number']);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Status Order #<?= htmlspecialchars($orderId) ?></title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 500px; margin: 50px auto; padding: 20px; }
        .status-card { background: #f9f9f9; padding: 30px; border-radius: 15px; text-align: center; }
        .status-icon { font-size: 64px; margin-bottom: 15px; }
        .status-paid { color: #10b981; }
        .status-pending { color: #f59e0b; }
        .status-expired { color: #ef4444; }
        .detail-row { display: flex; justify-content: space-between; padding: 12px 0; border-bottom: 1px solid #eee; }
        .pay-btn { display: block; width: 100%; padding: 15px; background: #10b981; color: white;
                   border: none; border-radius: 10px; font-size: 16px; font-weight: bold;
                   text-align: center; text-decoration: none; margin-top: 20px; }
    </style>
</head>
<body>
    <h2 style="text-align: center;">Status Order</h2>

    <div class="status-card">
        <?php if ($order['status'] === 'paid'): ?>
            <div class="status-icon status-paid">✓</div>
            <h3 class="status-paid">Pembayaran Berhasil</h3>
        <?php elseif ($neopgaStatus && $neopgaStatus['data']['status'] === 'expired'): ?>
            <div class="status-icon status-expired">✗</div>
            <h3 class="status-expired">Pembayaran Expired</h3>
        <?php else: ?>
            <div class="status-icon status-pending">⏳</div>
            <h3 class="status-pending">Menunggu Pembayaran</h3>
        <?php endif; ?>
    </div>

    <div style="margin-top: 30px;">
        <div class="detail-row">
            <span>Order ID</span>
            <strong><?= htmlspecialchars($orderId) ?></strong>
        </div>
        <div class="detail-row">
            <span>Total</span>
            <strong>Rp <?= number_format($order['total']) ?></strong>
        </div>
        <div class="detail-row">
            <span>Tanggal Order</span>
            <strong><?= date('d M Y H:i', strtotime($order['created_at'])) ?></strong>
        </div>
        <?php if ($order['paid_at']): ?>
        <div class="detail-row">
            <span>Tanggal Bayar</span>
            <strong><?= date('d M Y H:i', strtotime($order['paid_at'])) ?></strong>
        </div>
        <?php endif; ?>
    </div>

    <?php if ($order['status'] === 'pending' && $order['invoice_number']): ?>
        <a href="<?= NeoPGA::getPaymentUrl($order['invoice_number']) ?>" class="pay-btn">
            Lanjutkan Pembayaran
        </a>
        <script>
            // Auto refresh setiap 5 detik untuk cek status
            setTimeout(() => location.reload(), 5000);
        </script>
    <?php endif; ?>

    <p style="text-align: center; margin-top: 30px;">
        <a href="/" style="color: #10b981;">Kembali ke Beranda</a>
    </p>
</body>
</html>


============================================================
DATABASE SCHEMA
============================================================

CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id VARCHAR(50) UNIQUE NOT NULL,
    invoice_number VARCHAR(100),
    customer_name VARCHAR(255),
    customer_email VARCHAR(255),
    customer_phone VARCHAR(50),
    total DECIMAL(15,2) NOT NULL,
    paid_amount DECIMAL(15,2),
    payment_method VARCHAR(50),
    status ENUM('pending', 'paid', 'cancelled', 'expired') DEFAULT 'pending',
    paid_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_order_id (order_id),
    INDEX idx_status (status),
    INDEX idx_invoice (invoice_number)
);

CREATE TABLE order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id VARCHAR(50) NOT NULL,
    product_id INT,
    product_name VARCHAR(255),
    price DECIMAL(15,2),
    qty INT DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_order_id (order_id)
);

*/

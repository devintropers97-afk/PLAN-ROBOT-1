<?php
/**
 * NEO PGA - Webhook Testing Tool
 * Test webhook endpoint dengan sample payload
 */
require_once __DIR__ . '/../includes/init.php';

$pageTitle = 'Webhook Tester';
$currentPage = 'webhook-test';

include __DIR__ . '/layout_header.php';

$db = Database::getInstance();
$testResult = null;
$testPayload = null;

// Get merchant webhook settings
$webhookUrl = $merchant['webhook_url'] ?? '';
$secretKey = $merchant['secret_key'] ?? '';

// Sample payload data
$samplePayload = [
    'event' => 'payment.success',
    'data' => [
        'invoice_number' => 'INV-' . date('Ymd') . '-SAMPLE',
        'reference_id' => 'REF-TEST-001',
        'amount' => 100000,
        'total_amount' => 100123,
        'unique_code' => 123,
        'status' => 'success',
        'payment_method' => 'qris',
        'customer_name' => 'Test Customer',
        'customer_email' => 'test@example.com',
        'paid_at' => date('c')
    ],
    'timestamp' => time()
];

// Handle test webhook
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['test_webhook'])) {
    verifyCsrf();

    // Check for XSS attempts
    if (detectXSS($_POST['webhook_url'] ?? '')) {
        $testResult = ['success' => false, 'error' => 'Input tidak valid terdeteksi!'];
    }

    $testUrl = sanitize($_POST['webhook_url'] ?? '');

    if (empty($testUrl)) {
        $testResult = ['success' => false, 'error' => 'Webhook URL tidak boleh kosong'];
    } elseif (!filter_var($testUrl, FILTER_VALIDATE_URL)) {
        $testResult = ['success' => false, 'error' => 'URL tidak valid'];
    } else {
        // Prepare payload
        $payload = $samplePayload;
        $payloadJson = json_encode($payload);

        // Generate signature
        $signature = hash_hmac('sha256', $payloadJson, $secretKey);

        $testPayload = [
            'url' => $testUrl,
            'payload' => $payload,
            'signature' => $signature
        ];

        // Send test webhook
        $ch = curl_init($testUrl);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $payloadJson,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'X-Signature: ' . $signature,
                'X-Event: payment.success',
                'X-Timestamp: ' . $payload['timestamp'],
                'User-Agent: NEO PGA-Webhook/1.0'
            ]
        ]);

        $startTime = microtime(true);
        $response = curl_exec($ch);
        $duration = round((microtime(true) - $startTime) * 1000);

        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) {
            $testResult = [
                'success' => false,
                'error' => 'Connection error: ' . $error,
                'duration' => $duration
            ];
        } else {
            $testResult = [
                'success' => $httpCode >= 200 && $httpCode < 300,
                'http_code' => $httpCode,
                'response' => $response,
                'duration' => $duration
            ];
        }

        // Log webhook test
        logActivity('merchant', $merchantId, 'webhook_test', 'webhook',
            "Tested webhook to: {$testUrl} - HTTP {$httpCode}");
    }
}

// Get recent webhook logs
$webhookLogs = $db->fetchAll(
    "SELECT wl.*, t.invoice_number
     FROM webhook_logs wl
     LEFT JOIN transactions t ON wl.transaction_id = t.id
     WHERE t.merchant_id = ?
     ORDER BY wl.created_at DESC LIMIT 20",
    [$merchantId]
) ?: [];
?>

<style>
.webhook-layout {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 1.5rem;
}

.webhook-card {
    background: white;
    border-radius: 16px;
    border: 1px solid var(--gray-200);
    overflow: hidden;
}

.webhook-card-header {
    padding: 1.25rem 1.5rem;
    border-bottom: 1px solid var(--gray-100);
    background: linear-gradient(135deg, var(--gray-50), white);
}

.webhook-card-header h3 {
    margin: 0;
    font-size: 1.1rem;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.webhook-card-body {
    padding: 1.5rem;
}

/* Test Result */
.test-result {
    border-radius: 12px;
    padding: 1.25rem;
    margin-bottom: 1.5rem;
}

.test-result.success {
    background: #d1fae5;
    border: 1px solid #10b981;
}

.test-result.error {
    background: #fee2e2;
    border: 1px solid #ef4444;
}

.test-result-header {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    margin-bottom: 0.75rem;
}

.test-result-icon {
    width: 36px;
    height: 36px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.25rem;
}

.test-result.success .test-result-icon { background: #10b981; color: white; }
.test-result.error .test-result-icon { background: #ef4444; color: white; }

.test-result-title {
    font-weight: 600;
    font-size: 1rem;
}

.test-result.success .test-result-title { color: #065f46; }
.test-result.error .test-result-title { color: #991b1b; }

.test-result-meta {
    display: flex;
    gap: 1.5rem;
    font-size: 0.85rem;
    margin-top: 0.5rem;
}

.test-result.success .test-result-meta { color: #047857; }
.test-result.error .test-result-meta { color: #b91c1c; }

/* Code Block */
.code-block {
    background: #1e293b;
    border-radius: 10px;
    padding: 1rem;
    overflow-x: auto;
    font-family: 'JetBrains Mono', monospace;
    font-size: 0.8rem;
    color: #e2e8f0;
    line-height: 1.6;
}

.code-block-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 0.75rem;
}

.code-block-title {
    font-size: 0.75rem;
    font-weight: 600;
    color: var(--gray-500);
    text-transform: uppercase;
}

.copy-btn {
    background: var(--gray-100);
    border: none;
    padding: 0.375rem 0.75rem;
    border-radius: 6px;
    font-size: 0.75rem;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 0.375rem;
}

.copy-btn:hover {
    background: var(--gray-200);
}

/* Response Preview */
.response-preview {
    background: var(--gray-50);
    border: 1px solid var(--gray-200);
    border-radius: 10px;
    padding: 1rem;
    max-height: 200px;
    overflow: auto;
    font-family: 'JetBrains Mono', monospace;
    font-size: 0.8rem;
    color: var(--gray-700);
    margin-top: 1rem;
}

/* Webhook Logs */
.log-item {
    display: flex;
    align-items: center;
    gap: 1rem;
    padding: 1rem;
    border-bottom: 1px solid var(--gray-100);
}

.log-item:last-child {
    border-bottom: none;
}

.log-status {
    width: 10px;
    height: 10px;
    border-radius: 50%;
    flex-shrink: 0;
}

.log-status.success { background: #10b981; }
.log-status.failed { background: #ef4444; }

.log-info {
    flex: 1;
    min-width: 0;
}

.log-invoice {
    font-family: 'JetBrains Mono', monospace;
    font-size: 0.8rem;
    color: var(--primary);
}

.log-time {
    font-size: 0.75rem;
    color: var(--gray-500);
}

.log-meta {
    text-align: right;
}

.log-code {
    font-weight: 600;
    font-size: 0.9rem;
}

.log-code.success { color: #10b981; }
.log-code.failed { color: #ef4444; }

.log-duration {
    font-size: 0.75rem;
    color: var(--gray-500);
}

/* Verification Guide */
.verification-guide {
    background: var(--info-light);
    border: 1px solid #93c5fd;
    border-radius: 12px;
    padding: 1.25rem;
    margin-top: 1.5rem;
}

.verification-guide h4 {
    color: #1e40af;
    margin: 0 0 1rem 0;
    font-size: 0.95rem;
}

@media (max-width: 1024px) {
    .webhook-layout {
        grid-template-columns: 1fr;
    }
}
</style>

<?php if ($testResult): ?>
<div class="test-result <?= $testResult['success'] ? 'success' : 'error' ?>">
    <div class="test-result-header">
        <div class="test-result-icon"><?= $testResult['success'] ? '✓' : '✗' ?></div>
        <div class="test-result-title">
            <?= $testResult['success'] ? 'Webhook Test Berhasil!' : 'Webhook Test Gagal' ?>
        </div>
    </div>
    <div class="test-result-meta">
        <?php if (isset($testResult['http_code'])): ?>
        <span>HTTP <?= $testResult['http_code'] ?></span>
        <?php endif; ?>
        <?php if (isset($testResult['duration'])): ?>
        <span>⏱ <?= $testResult['duration'] ?>ms</span>
        <?php endif; ?>
        <?php if (isset($testResult['error'])): ?>
        <span><?= htmlspecialchars($testResult['error']) ?></span>
        <?php endif; ?>
    </div>

    <?php if (isset($testResult['response']) && $testResult['response']): ?>
    <div class="response-preview">
        <strong>Response:</strong><br>
        <?= htmlspecialchars(substr($testResult['response'], 0, 1000)) ?>
        <?= strlen($testResult['response']) > 1000 ? '...' : '' ?>
    </div>
    <?php endif; ?>
</div>
<?php endif; ?>

<div class="webhook-layout">
    <!-- Test Form -->
    <div class="webhook-card">
        <div class="webhook-card-header">
            <h3>🧪 Test Webhook</h3>
        </div>
        <div class="webhook-card-body">
            <form method="POST">
                <?= csrfField() ?>

                <div class="form-group">
                    <label class="form-label">Webhook URL</label>
                    <input type="url" name="webhook_url" class="form-input" value="<?= htmlspecialchars($webhookUrl) ?>" placeholder="https://yoursite.com/callback.php" required>
                    <small style="color: var(--gray-500); font-size: 0.75rem; margin-top: 0.25rem; display: block;">
                        URL harus HTTPS untuk production
                    </small>
                </div>

                <div class="form-group">
                    <label class="form-label">Secret Key (untuk signature)</label>
                    <input type="text" class="form-input" value="<?= htmlspecialchars($secretKey) ?>" readonly style="background: var(--gray-50);">
                </div>

                <button type="submit" name="test_webhook" value="1" class="btn btn-primary" style="width: 100%;">
                    🚀 Kirim Test Webhook
                </button>
            </form>

            <!-- Sample Payload Preview -->
            <div style="margin-top: 1.5rem;">
                <div class="code-block-header">
                    <span class="code-block-title">Sample Payload yang akan dikirim</span>
                    <button class="copy-btn" onclick="copyPayload()">📋 Copy</button>
                </div>
                <div class="code-block" id="payload-preview">
<?= htmlspecialchars(json_encode($samplePayload, JSON_PRETTY_PRINT)) ?>
                </div>
            </div>

            <!-- Headers Info -->
            <div style="margin-top: 1.5rem;">
                <div class="code-block-header">
                    <span class="code-block-title">HTTP Headers</span>
                </div>
                <div class="code-block">
Content-Type: application/json
X-Signature: &lt;HMAC-SHA256 signature&gt;
X-Event: payment.success
X-Timestamp: <?= time() ?>

User-Agent: NEO PGA-Webhook/1.0
                </div>
            </div>

            <!-- Verification Guide -->
            <div class="verification-guide">
                <h4>📖 Cara Verifikasi Signature</h4>
                <div class="code-block" style="background: #1e3a5f;">
<span style="color: #93c5fd;">// PHP Example</span>
$payload = file_get_contents('php://input');
$signature = $_SERVER['HTTP_X_SIGNATURE'] ?? '';
$secretKey = 'YOUR_SECRET_KEY';

$expectedSignature = hash_hmac('sha256', $payload, $secretKey);

if (hash_equals($expectedSignature, $signature)) {
    <span style="color: #86efac;">// Signature valid - proses pembayaran</span>
    $data = json_decode($payload, true);
    // ...
} else {
    <span style="color: #fca5a5;">// Signature invalid - tolak request</span>
    http_response_code(401);
    exit;
}
                </div>
            </div>
        </div>
    </div>

    <!-- Webhook Logs -->
    <div class="webhook-card">
        <div class="webhook-card-header">
            <h3>📋 Webhook History</h3>
        </div>
        <div class="webhook-card-body" style="padding: 0;">
            <?php if (empty($webhookLogs)): ?>
            <div style="padding: 3rem; text-align: center; color: var(--gray-400);">
                <div style="font-size: 2.5rem; margin-bottom: 1rem;">📭</div>
                <p>Belum ada webhook log</p>
            </div>
            <?php else: ?>
            <div style="max-height: 600px; overflow-y: auto;">
                <?php foreach ($webhookLogs as $log): ?>
                <?php
                $isSuccess = (int)($log['response_code'] ?? 0) >= 200 && (int)($log['response_code'] ?? 0) < 300;
                ?>
                <div class="log-item">
                    <div class="log-status <?= $isSuccess ? 'success' : 'failed' ?>"></div>
                    <div class="log-info">
                        <div class="log-invoice"><?= htmlspecialchars($log['invoice_number'] ?? '-') ?></div>
                        <div class="log-time"><?= date('d/m/Y H:i:s', strtotime($log['created_at'])) ?></div>
                    </div>
                    <div class="log-meta">
                        <div class="log-code <?= $isSuccess ? 'success' : 'failed' ?>">
                            HTTP <?= $log['response_code'] ?? '-' ?>
                        </div>
                        <?php if (isset($log['response_time'])): ?>
                        <div class="log-duration"><?= $log['response_time'] ?>ms</div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
function copyPayload() {
    const payload = document.getElementById('payload-preview').textContent;
    navigator.clipboard.writeText(payload).then(() => {
        alert('Payload berhasil disalin!');
    });
}
</script>

<?php include __DIR__ . '/layout_footer.php'; ?>

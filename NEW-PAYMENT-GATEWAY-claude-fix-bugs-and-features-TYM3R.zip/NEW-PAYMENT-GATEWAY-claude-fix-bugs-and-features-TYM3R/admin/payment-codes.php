<?php
/**
 * NEO PGA Admin - Payment Codes Management
 * Kelola kode unik pembayaran
 */
require_once __DIR__ . '/../includes/init.php';

$auth = new Auth('admin');
$auth->requireAuth();

$adminUser = $auth->user();
$db = Database::getInstance();

$message = '';
$messageType = '';

// Auto-reset kode unik yang hampir habis (threshold: 5 atau kurang tersedia)
// Ini dijalankan setiap kali halaman dimuat untuk memastikan kode selalu tersedia
$autoResetResults = [];
$merchantsNeedingReset = $db->fetchAll(
    "SELECT m.id, m.business_name,
            COUNT(CASE WHEN pc.status = 'available' THEN 1 END) as available,
            COUNT(CASE WHEN pc.status = 'used' THEN 1 END) as used
     FROM merchants m
     LEFT JOIN payment_codes pc ON m.id = pc.merchant_id
     GROUP BY m.id
     HAVING available <= 5 AND used > 0"
);

foreach ($merchantsNeedingReset as $m) {
    // Reset kode used menjadi available untuk merchant ini
    $db->query(
        "UPDATE payment_codes
         SET status = 'available',
             transaction_id = NULL,
             reserved_at = NULL,
             expires_at = NULL,
             used_at = NULL
         WHERE merchant_id = ? AND status = 'used'",
        [$m['id']]
    );
    $resetCount = $db->rowCount();
    if ($resetCount > 0) {
        $autoResetResults[] = "{$m['business_name']}: {$resetCount} kode direset";
        logActivity('system', null, 'payment_code_auto_reset_page', 'payment_codes',
            "Auto-reset {$resetCount} codes for merchant #{$m['id']} ({$m['business_name']}) - triggered by page load");
    }
}

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $action = sanitize($_POST['action'] ?? '');
    $merchantId = (int)($_POST['merchant_id'] ?? 0);
    
    if ($action === 'reset_all' && $merchantId > 0) {
        // Reset semua kode used menjadi available
        $db->query(
            "UPDATE payment_codes 
             SET status = 'available', 
                 transaction_id = NULL, 
                 reserved_at = NULL, 
                 expires_at = NULL,
                 used_at = NULL
             WHERE merchant_id = ? AND status = 'used'",
            [$merchantId]
        );
        $count = $db->rowCount();
        $message = "Berhasil reset $count kode unik untuk merchant ini";
        $messageType = 'success';
        
        logActivity('admin', $auth->id(), 'payment_code_manual_reset', 'payment_codes', 
            "Manual reset $count codes for merchant #$merchantId");
    }
    
    if ($action === 'reset_reserved' && $merchantId > 0) {
        // Reset kode reserved yang stuck
        $db->query(
            "UPDATE payment_codes 
             SET status = 'available', 
                 transaction_id = NULL, 
                 reserved_at = NULL, 
                 expires_at = NULL
             WHERE merchant_id = ? AND status = 'reserved'",
            [$merchantId]
        );
        $count = $db->rowCount();
        $message = "Berhasil reset $count kode reserved";
        $messageType = 'success';
    }
    
    if ($action === 'generate_pool' && $merchantId > 0) {
        // Generate pool baru
        $min = defined('UNIQUE_CODE_MIN') ? UNIQUE_CODE_MIN : 1;
        $max = defined('UNIQUE_CODE_MAX') ? UNIQUE_CODE_MAX : 999;
        $generated = 0;
        
        for ($code = $min; $code <= $max; $code++) {
            $exists = $db->fetch(
                "SELECT id FROM payment_codes WHERE merchant_id = ? AND code = ?",
                [$merchantId, $code]
            );
            
            if (!$exists) {
                $db->query(
                    "INSERT INTO payment_codes (merchant_id, code, status) VALUES (?, ?, 'available')",
                    [$merchantId, $code]
                );
                $generated++;
            }
        }
        
        $message = "Berhasil generate $generated kode unik baru (range: $min - $max)";
        $messageType = 'success';
        
        logActivity('admin', $auth->id(), 'payment_code_generate', 'payment_codes', 
            "Generated $generated codes for merchant #$merchantId");
    }
    
    if ($action === 'reset_global') {
        // Reset SEMUA kode di seluruh sistem
        $db->query(
            "UPDATE payment_codes 
             SET status = 'available', 
                 transaction_id = NULL, 
                 reserved_at = NULL, 
                 expires_at = NULL,
                 used_at = NULL
             WHERE status IN ('used', 'reserved')"
        );
        $count = $db->rowCount();
        $message = "GLOBAL RESET: $count kode unik direset ke available";
        $messageType = 'success';
        
        logActivity('admin', $auth->id(), 'payment_code_global_reset', 'payment_codes', 
            "Global reset $count codes");
    }
}

// Get merchants with code stats
$merchants = $db->fetchAll(
    "SELECT m.id, m.business_name, m.merchant_code, m.status,
            COUNT(pc.id) as total_codes,
            SUM(CASE WHEN pc.status = 'available' THEN 1 ELSE 0 END) as available,
            SUM(CASE WHEN pc.status = 'reserved' THEN 1 ELSE 0 END) as reserved,
            SUM(CASE WHEN pc.status = 'used' THEN 1 ELSE 0 END) as used
     FROM merchants m
     LEFT JOIN payment_codes pc ON m.id = pc.merchant_id
     GROUP BY m.id
     ORDER BY m.business_name"
);

// Global stats
$globalStats = $db->fetch(
    "SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status = 'available' THEN 1 ELSE 0 END) as available,
        SUM(CASE WHEN status = 'reserved' THEN 1 ELSE 0 END) as reserved,
        SUM(CASE WHEN status = 'used' THEN 1 ELSE 0 END) as used
     FROM payment_codes"
);

$pageTitle = 'Kelola Kode Unik';
$currentPage = 'payment-codes';

$extraCss = '
.stats-row { display: grid; grid-template-columns: repeat(4, 1fr); gap: 1rem; margin-bottom: 2rem; }
.stat-box { background: white; border-radius: 12px; padding: 1.25rem; text-align: center; border: 1px solid var(--gray-200); }
.stat-box.success { border-color: #10b981; background: #f0fdf4; }
.stat-box.warning { border-color: #f59e0b; background: #fffbeb; }
.stat-box.neutral { border-color: #6b7280; background: #f9fafb; }
.stat-value { font-size: 2rem; font-weight: 700; }
.stat-label { font-size: 0.8rem; color: var(--gray-500); text-transform: uppercase; margin-top: 4px; }
.merchant-card { background: white; border-radius: 12px; border: 1px solid var(--gray-200); margin-bottom: 1rem; overflow: hidden; }
.merchant-header { padding: 1rem 1.5rem; border-bottom: 1px solid var(--gray-100); display: flex; justify-content: space-between; align-items: center; }
.merchant-name { font-weight: 600; font-size: 1.1rem; }
.merchant-code { font-size: 0.8rem; color: var(--gray-500); font-family: monospace; }
.merchant-body { padding: 1.5rem; }
.code-stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 1rem; margin-bottom: 1rem; }
.code-stat { text-align: center; padding: 0.75rem; background: var(--gray-50); border-radius: 8px; }
.code-stat-value { font-size: 1.25rem; font-weight: 700; }
.code-stat-label { font-size: 0.7rem; color: var(--gray-500); }
.progress-bar { height: 8px; background: var(--gray-200); border-radius: 4px; overflow: hidden; margin-bottom: 1rem; }
.progress-fill { height: 100%; transition: width 0.3s; }
.action-btns { display: flex; gap: 0.5rem; flex-wrap: wrap; }
@media (max-width: 768px) { .stats-row, .code-stats { grid-template-columns: repeat(2, 1fr); } }
';

ob_start();
?>

<?php if (!empty($autoResetResults)): ?>
<div class="alert alert-success mb-6" style="background: linear-gradient(135deg, rgba(16, 185, 129, 0.15), rgba(5, 150, 105, 0.15)); border: 2px solid #10b981;">
    <div style="display: flex; align-items: center; gap: 10px;">
        <span style="font-size: 1.5rem;">🔄</span>
        <div>
            <strong style="color: #059669;">AUTO-RESET TRIGGERED!</strong>
            <p style="margin: 4px 0 0; font-size: 0.85rem; color: #065f46;">
                Kode unik hampir habis dan sudah di-reset otomatis:<br>
                <?= implode('<br>', $autoResetResults) ?>
            </p>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if ($message): ?>
<div class="alert alert-<?= $messageType ?> mb-6"><?= $message ?></div>
<?php endif; ?>

<!-- Global Stats -->
<div class="stats-row">
    <div class="stat-box">
        <div class="stat-value" style="color: var(--gray-700)"><?= number_format($globalStats['total'] ?? 0) ?></div>
        <div class="stat-label">Total Kode</div>
    </div>
    <div class="stat-box success">
        <div class="stat-value" style="color: #10b981"><?= number_format($globalStats['available'] ?? 0) ?></div>
        <div class="stat-label">Tersedia</div>
    </div>
    <div class="stat-box warning">
        <div class="stat-value" style="color: #f59e0b"><?= number_format($globalStats['reserved'] ?? 0) ?></div>
        <div class="stat-label">Digunakan</div>
    </div>
    <div class="stat-box neutral">
        <div class="stat-value" style="color: #6b7280"><?= number_format($globalStats['used'] ?? 0) ?></div>
        <div class="stat-label">Selesai</div>
    </div>
</div>

<!-- Global Actions -->
<div class="card mb-6">
    <div class="card-header">
        <h3 class="card-title">🔧 Aksi Global</h3>
    </div>
    <div class="card-body">
        <div style="display:flex;gap:1rem;flex-wrap:wrap;align-items:center">
            <form method="POST" style="display:inline">
                <?= csrfField() ?>
                <input type="hidden" name="action" value="reset_global">
                <button type="submit" class="btn btn-danger" onclick="return confirm('⚠️ PERINGATAN!\n\nIni akan RESET SEMUA kode unik di seluruh sistem!\n\nLanjutkan?')">
                    🔄 Reset Global (Semua Merchant)
                </button>
            </form>
            <span style="color:var(--gray-500);font-size:0.85rem">
                Gunakan dengan hati-hati! Ini akan mereset semua kode 'used' dan 'reserved' menjadi 'available'.
            </span>
        </div>
    </div>
</div>

<!-- Merchant List -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title">📊 Kode Unik per Merchant</h3>
    </div>
    <div class="card-body" style="padding:0">
        <?php foreach ($merchants as $m): ?>
        <?php 
            $total = $m['total_codes'] ?: 1;
            $availablePercent = ($m['available'] / $total) * 100;
            $reservedPercent = ($m['reserved'] / $total) * 100;
            $usedPercent = ($m['used'] / $total) * 100;
            
            // Warning jika available < 20%
            $isLow = $availablePercent < 20;
        ?>
        <div class="merchant-card" style="margin:1rem;<?= $isLow ? 'border-color:#f59e0b;background:#fffbeb' : '' ?>">
            <div class="merchant-header">
                <div>
                    <div class="merchant-name">
                        <?= htmlspecialchars($m['business_name']) ?>
                        <?php if ($isLow): ?>
                        <span style="color:#f59e0b;font-size:0.85rem">⚠️ Kode Menipis!</span>
                        <?php endif; ?>
                    </div>
                    <div class="merchant-code"><?= $m['merchant_code'] ?></div>
                </div>
                <span class="badge badge-<?= $m['status'] === 'active' ? 'success' : 'warning' ?>"><?= ucfirst($m['status']) ?></span>
            </div>
            <div class="merchant-body">
                <!-- Progress Bar -->
                <div class="progress-bar">
                    <div class="progress-fill" style="width:<?= $availablePercent ?>%;background:#10b981;float:left"></div>
                    <div class="progress-fill" style="width:<?= $reservedPercent ?>%;background:#f59e0b;float:left"></div>
                    <div class="progress-fill" style="width:<?= $usedPercent ?>%;background:#6b7280;float:left"></div>
                </div>
                
                <!-- Stats -->
                <div class="code-stats">
                    <div class="code-stat">
                        <div class="code-stat-value"><?= number_format($m['total_codes']) ?></div>
                        <div class="code-stat-label">Total</div>
                    </div>
                    <div class="code-stat" style="background:#f0fdf4">
                        <div class="code-stat-value" style="color:#10b981"><?= number_format($m['available']) ?></div>
                        <div class="code-stat-label">Tersedia</div>
                    </div>
                    <div class="code-stat" style="background:#fffbeb">
                        <div class="code-stat-value" style="color:#f59e0b"><?= number_format($m['reserved']) ?></div>
                        <div class="code-stat-label">Digunakan</div>
                    </div>
                    <div class="code-stat">
                        <div class="code-stat-value" style="color:#6b7280"><?= number_format($m['used']) ?></div>
                        <div class="code-stat-label">Selesai</div>
                    </div>
                </div>
                
                <!-- Actions -->
                <div class="action-btns">
                    <?php if ($m['total_codes'] == 0): ?>
                    <form method="POST" style="display:inline">
                        <?= csrfField() ?>
                        <input type="hidden" name="action" value="generate_pool">
                        <input type="hidden" name="merchant_id" value="<?= $m['id'] ?>">
                        <button type="submit" class="btn btn-sm btn-primary">
                            ➕ Generate Kode (1-999)
                        </button>
                    </form>
                    <?php else: ?>
                    <form method="POST" style="display:inline">
                        <?= csrfField() ?>
                        <input type="hidden" name="action" value="reset_all">
                        <input type="hidden" name="merchant_id" value="<?= $m['id'] ?>">
                        <button type="submit" class="btn btn-sm btn-warning" onclick="return confirm('Reset semua kode USED menjadi AVAILABLE?')">
                            🔄 Reset Used (<?= $m['used'] ?>)
                        </button>
                    </form>
                    <form method="POST" style="display:inline">
                        <?= csrfField() ?>
                        <input type="hidden" name="action" value="reset_reserved">
                        <input type="hidden" name="merchant_id" value="<?= $m['id'] ?>">
                        <button type="submit" class="btn btn-sm btn-secondary" onclick="return confirm('Reset kode RESERVED yang stuck?')">
                            ↩️ Reset Reserved (<?= $m['reserved'] ?>)
                        </button>
                    </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
        
        <?php if (empty($merchants)): ?>
        <div style="padding:3rem;text-align:center;color:var(--gray-500)">
            Tidak ada merchant terdaftar
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Info Box -->
<div style="background: linear-gradient(135deg, #dbeafe, #e0f2fe); border:2px solid #3b82f6; border-radius:16px; padding:1.5rem; margin-top:1.5rem">
    <h4 style="color:#1e40af;margin:0 0 1rem;display:flex;align-items:center;gap:8px">
        <span>💡</span> Informasi Kode Unik & Auto-Reset
    </h4>
    <ul style="color:#1e3a8a;font-size:0.9rem;margin:0;padding-left:1.5rem;line-height:1.8">
        <li><strong>Available:</strong> Kode siap digunakan untuk transaksi baru</li>
        <li><strong>Reserved:</strong> Kode sedang digunakan untuk transaksi pending</li>
        <li><strong>Used:</strong> Kode sudah dipakai untuk transaksi sukses</li>
        <li><strong>Range:</strong> Kode unik berkisar dari <?= UNIQUE_CODE_MIN ?> sampai <?= UNIQUE_CODE_MAX ?></li>
    </ul>

    <div style="margin-top: 1rem; padding: 1rem; background: rgba(16, 185, 129, 0.1); border-radius: 10px; border: 1px solid rgba(16, 185, 129, 0.3);">
        <h5 style="color: #059669; margin: 0 0 0.5rem; display: flex; align-items: center; gap: 6px;">
            <span>🔄</span> Fitur Auto-Reset Otomatis
        </h5>
        <ul style="color:#065f46; font-size:0.85rem; margin:0; padding-left:1.5rem; line-height:1.7">
            <li><strong>Threshold:</strong> Ketika kode tersedia ≤ 5, sistem AUTO-RESET kode "Used" menjadi "Available"</li>
            <li><strong>Trigger:</strong> Auto-reset dijalankan setiap halaman dimuat (dengan auto-refresh 2 detik)</li>
            <li><strong>Tidak perlu manual:</strong> Admin tidak perlu reset manual, sistem otomatis handle!</li>
            <li><strong>Real-time:</strong> Dengan auto-refresh aktif, kode akan di-recycle terus menerus</li>
        </ul>
    </div>
</div>

<?php
$content = ob_get_clean();
include __DIR__ . '/layout.php';
?>

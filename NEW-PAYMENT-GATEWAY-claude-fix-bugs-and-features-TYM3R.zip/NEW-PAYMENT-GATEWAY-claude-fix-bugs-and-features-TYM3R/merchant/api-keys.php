<?php
/**
 * NEO PGA - Merchant API Keys
 * Using Layout Template v2
 */
require_once __DIR__ . '/../includes/init.php';

// Page settings for layout
$pageTitle = 'API Keys';
$currentPage = 'api-keys';

// Handle actions before including layout (for flash messages)
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verify CSRF token first
    verifyCsrf();

    $db = Database::getInstance();
    // Fix: Use correct session key
    $merchantId = $_SESSION['merchant_user']['id'] ?? null;
    if (!$merchantId) {
        header('Location: login.php');
        exit;
    }
    $action = sanitize($_POST['action'] ?? '');

    if ($action === 'regenerate_api_key') {
        $newApiKey = 'nb_live_' . bin2hex(random_bytes(24));
        $db->query("UPDATE merchants SET api_key = ? WHERE id = ?", [$newApiKey, $merchantId]);
        $_SESSION['flash_message'] = 'API Key berhasil di-regenerate!';
        $_SESSION['flash_type'] = 'success';
        header('Location: api-keys.php');
        exit;
    }

    if ($action === 'regenerate_secret_key') {
        $newSecretKey = 'nb_secret_' . bin2hex(random_bytes(24));
        $db->query("UPDATE merchants SET secret_key = ? WHERE id = ?", [$newSecretKey, $merchantId]);
        $_SESSION['flash_message'] = 'Secret Key berhasil di-regenerate!';
        $_SESSION['flash_type'] = 'success';
        header('Location: api-keys.php');
        exit;
    }

    if ($action === 'update_webhook') {
        // Check for XSS attempts
        if (detectXSS($_POST['webhook_url'] ?? '')) {
            $message = 'Input tidak valid terdeteksi!';
            $messageType = 'error';
        } else {
            $webhookUrl = sanitize($_POST['webhook_url'] ?? '');

            if (!empty($webhookUrl) && !filter_var($webhookUrl, FILTER_VALIDATE_URL)) {
                $message = 'URL webhook tidak valid';
                $messageType = 'error';
            } else {
                $db->query("UPDATE merchants SET webhook_url = ? WHERE id = ?", [$webhookUrl ?: null, $merchantId]);
                $_SESSION['flash_message'] = 'Webhook URL berhasil diupdate!';
                $_SESSION['flash_type'] = 'success';
                header('Location: api-keys.php');
                exit;
            }
        }
    }

    if ($action === 'update_callback') {
        // Check for XSS attempts
        if (detectXSS($_POST['callback_url'] ?? '')) {
            $message = 'Input tidak valid terdeteksi!';
            $messageType = 'error';
        } else {
            $callbackUrl = sanitize($_POST['callback_url'] ?? '');

            if (!empty($callbackUrl) && !filter_var($callbackUrl, FILTER_VALIDATE_URL)) {
                $message = 'URL callback tidak valid';
                $messageType = 'error';
            } else {
                $db->query("UPDATE merchants SET callback_url = ? WHERE id = ?", [$callbackUrl ?: null, $merchantId]);
                $_SESSION['flash_message'] = 'Callback URL berhasil diupdate!';
                $_SESSION['flash_type'] = 'success';
                header('Location: api-keys.php');
                exit;
            }
        }
    }
}

// Include layout header (handles auth check)
include 'layout_header.php';

// Recent API logs
$apiLogs = $db->fetchAll(
    "SELECT * FROM api_logs WHERE merchant_id = ? ORDER BY created_at DESC LIMIT 20",
    [$merchantId]
);
?>

<style>
    /* API Keys page specific styles */
    .keys-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 1.5rem;
        margin-bottom: 2rem;
    }

    .key-card {
        background: white;
        border-radius: 16px;
        border: 1px solid var(--gray-200);
        overflow: hidden;
    }

    .key-card-header {
        padding: 1rem 1.5rem;
        border-bottom: 1px solid var(--gray-100);
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .key-card-title {
        font-size: 1rem;
        font-weight: 600;
        color: var(--gray-900);
    }

    .key-card-body {
        padding: 1.5rem;
    }

    .key-description {
        font-size: 0.85rem;
        color: var(--gray-500);
        margin-bottom: 1rem;
        line-height: 1.5;
    }

    .key-input-wrapper {
        position: relative;
        margin-bottom: 1rem;
    }

    .key-input {
        width: 100%;
        padding: 0.75rem 6rem 0.75rem 1rem;
        border: 1px solid var(--gray-300);
        border-radius: 10px;
        font-family: var(--font-mono);
        font-size: 0.85rem;
        background: var(--gray-50);
        color: var(--gray-700);
    }

    .key-input:focus {
        outline: none;
        border-color: var(--primary);
        box-shadow: 0 0 0 3px rgba(13, 148, 136, 0.1);
    }

    .key-actions {
        position: absolute;
        right: 0.5rem;
        top: 50%;
        transform: translateY(-50%);
        display: flex;
        gap: 0.25rem;
    }

    .btn-icon-sm {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 32px;
        height: 32px;
        border-radius: 8px;
        border: none;
        cursor: pointer;
        background: transparent;
        color: var(--gray-500);
        transition: all 0.2s;
    }

    .btn-icon-sm:hover {
        background: var(--gray-200);
        color: var(--gray-700);
    }

    .btn-icon-sm svg {
        width: 16px;
        height: 16px;
    }

    /* Badges */
    .badge {
        display: inline-flex;
        align-items: center;
        padding: 0.25rem 0.75rem;
        font-size: 0.7rem;
        font-weight: 600;
        border-radius: 6px;
        text-transform: uppercase;
        letter-spacing: 0.02em;
    }

    .badge-success {
        background: var(--success-light);
        color: #065f46;
    }

    .badge-warning {
        background: var(--warning-light);
        color: #92400e;
    }

    .badge-info {
        background: var(--info-light);
        color: #1e40af;
    }

    .badge-danger {
        background: var(--danger-light);
        color: #991b1b;
    }

    /* Buttons */
    .btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 0.5rem;
        padding: 0.625rem 1.25rem;
        border-radius: 8px;
        font-size: 0.875rem;
        font-weight: 500;
        text-decoration: none;
        cursor: pointer;
        border: none;
        transition: all 0.2s;
        font-family: inherit;
    }

    .btn-primary {
        background: var(--primary);
        color: white;
    }

    .btn-primary:hover {
        background: var(--primary-dark);
    }

    .btn-danger {
        background: var(--danger-light);
        color: var(--danger);
        border: 1px solid rgba(239, 68, 68, 0.2);
    }

    .btn-danger:hover {
        background: var(--danger);
        color: white;
    }

    .btn-sm {
        padding: 0.5rem 0.875rem;
        font-size: 0.8rem;
    }

    .btn svg {
        width: 16px;
        height: 16px;
    }

    /* URL Config Cards */
    .url-card {
        background: white;
        border-radius: 16px;
        border: 1px solid var(--gray-200);
        overflow: hidden;
    }

    .url-card-header {
        padding: 1rem 1.5rem;
        border-bottom: 1px solid var(--gray-100);
    }

    .url-card-title {
        font-size: 1rem;
        font-weight: 600;
        color: var(--gray-900);
    }

    .url-card-body {
        padding: 1.5rem;
    }

    .form-group {
        margin-bottom: 1rem;
    }

    .form-input {
        width: 100%;
        padding: 0.75rem 1rem;
        border: 1px solid var(--gray-300);
        border-radius: 10px;
        font-size: 0.9rem;
        font-family: inherit;
        transition: all 0.2s;
    }

    .form-input:focus {
        outline: none;
        border-color: var(--primary);
        box-shadow: 0 0 0 3px rgba(13, 148, 136, 0.1);
    }

    /* API Endpoints */
    .endpoints-card {
        background: white;
        border-radius: 16px;
        border: 1px solid var(--gray-200);
        margin-bottom: 2rem;
    }

    .endpoints-header {
        padding: 1rem 1.5rem;
        border-bottom: 1px solid var(--gray-100);
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .endpoints-title {
        font-size: 1rem;
        font-weight: 600;
        color: var(--gray-900);
    }

    .endpoints-body {
        padding: 1.5rem;
    }

    .endpoint-item {
        display: flex;
        align-items: center;
        gap: 1rem;
        padding: 0.875rem 1rem;
        background: var(--gray-50);
        border-radius: 10px;
        margin-bottom: 0.75rem;
    }

    .endpoint-item:last-child {
        margin-bottom: 0;
    }

    .endpoint-url {
        flex: 1;
        font-family: var(--font-mono);
        font-size: 0.85rem;
        color: var(--gray-700);
    }

    .endpoint-desc {
        font-size: 0.8rem;
        color: var(--gray-500);
    }

    /* Logs Table */
    .logs-card {
        background: white;
        border-radius: 16px;
        border: 1px solid var(--gray-200);
        overflow: hidden;
    }

    .logs-header {
        padding: 1rem 1.5rem;
        border-bottom: 1px solid var(--gray-100);
    }

    .logs-title {
        font-size: 1rem;
        font-weight: 600;
        color: var(--gray-900);
    }

    .table-wrapper {
        overflow-x: auto;
    }

    .table {
        width: 100%;
        border-collapse: collapse;
    }

    .table th {
        background: var(--gray-50);
        padding: 0.875rem 1rem;
        text-align: left;
        font-size: 0.75rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: var(--gray-600);
        border-bottom: 1px solid var(--gray-200);
    }

    .table td {
        padding: 0.875rem 1rem;
        border-bottom: 1px solid var(--gray-100);
        font-size: 0.85rem;
        color: var(--gray-700);
    }

    .table tbody tr:hover {
        background: var(--gray-50);
    }

    .table code {
        font-family: var(--font-mono);
        font-size: 0.8rem;
        background: var(--gray-100);
        padding: 0.2rem 0.5rem;
        border-radius: 4px;
        color: var(--gray-700);
    }

    .empty-state {
        padding: 3rem;
        text-align: center;
        color: var(--gray-400);
    }

    /* Alert */
    .alert {
        padding: 1rem 1.25rem;
        border-radius: 10px;
        margin-bottom: 1.5rem;
        font-size: 0.9rem;
    }

    .alert-error {
        background: var(--danger-light);
        color: #991b1b;
        border: 1px solid rgba(239, 68, 68, 0.2);
    }

    /* Responsive */
    @media (max-width: 1024px) {
        .keys-grid {
            grid-template-columns: 1fr;
        }
    }
</style>

<?php if ($message): ?>
<div class="alert alert-<?= $messageType ?>">
    <?= htmlspecialchars($message) ?>
</div>
<?php endif; ?>

<!-- API Key & Secret Key -->
<div class="keys-grid">
    <div class="key-card">
        <div class="key-card-header">
            <h3 class="key-card-title">API Key</h3>
            <?php if (!empty($merchant['api_key'])): ?>
            <span class="badge badge-success">Live</span>
            <?php else: ?>
            <span class="badge badge-warning">Belum Ada</span>
            <?php endif; ?>
        </div>
        <div class="key-card-body">
            <p class="key-description">Gunakan API key ini untuk mengautentikasi request ke API NEO PGA. Sertakan di header <code>X-API-Key</code>.</p>
            
            <?php if (!empty($merchant['api_key'])): ?>
            <div class="key-input-wrapper">
                <input type="text" id="apiKey" value="<?= htmlspecialchars($merchant['api_key']) ?>" readonly class="key-input">
                <div class="key-actions">
                    <button onclick="copyKey('apiKey')" class="btn-icon-sm" title="Copy">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3"/>
                        </svg>
                    </button>
                </div>
            </div>
            
            <form method="POST" onsubmit="return confirm('Regenerate API Key? Semua integrasi yang menggunakan key lama akan berhenti bekerja.')">
                <?= csrfField() ?>
                <input type="hidden" name="action" value="regenerate_api_key">
                <button type="submit" class="btn btn-danger btn-sm">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/>
                    </svg>
                    Regenerate
                </button>
            </form>
            <?php else: ?>
            <div style="background:#fef3c7;border:1px solid #f59e0b;border-radius:10px;padding:16px;margin-bottom:16px">
                <strong style="color:#92400e">⚠️ API Key belum tersedia</strong><br>
                <span style="color:#a16207;font-size:.9rem">Klik tombol di bawah untuk generate API Key baru.</span>
            </div>
            <form method="POST">
                <?= csrfField() ?>
                <input type="hidden" name="action" value="regenerate_api_key">
                <button type="submit" class="btn btn-primary">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="16" height="16">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"/>
                    </svg>
                    Generate API Key
                </button>
            </form>
            <?php endif; ?>
        </div>
    </div>

    <div class="key-card">
        <div class="key-card-header">
            <h3 class="key-card-title">Secret Key</h3>
            <?php if (!empty($merchant['secret_key'])): ?>
            <span class="badge badge-warning">Sensitive</span>
            <?php else: ?>
            <span class="badge badge-warning">Belum Ada</span>
            <?php endif; ?>
        </div>
        <div class="key-card-body">
            <p class="key-description">Secret key digunakan untuk menandatangani request dan memverifikasi webhook. Jangan pernah expose di client-side.</p>
            
            <?php if (!empty($merchant['secret_key'])): ?>
            <div class="key-input-wrapper">
                <input type="password" id="secretKey" value="<?= htmlspecialchars($merchant['secret_key']) ?>" readonly class="key-input">
                <div class="key-actions">
                    <button onclick="toggleSecret()" class="btn-icon-sm" title="Show/Hide">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" id="eyeIcon">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                        </svg>
                    </button>
                    <button onclick="copyKey('secretKey')" class="btn-icon-sm" title="Copy">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3"/>
                        </svg>
                    </button>
                </div>
            </div>
            
            <form method="POST" onsubmit="return confirm('Regenerate Secret Key? Pastikan Anda mengupdate webhook verification di server Anda.')">
                <?= csrfField() ?>
                <input type="hidden" name="action" value="regenerate_secret_key">
                <button type="submit" class="btn btn-danger btn-sm">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/>
                    </svg>
                    Regenerate
                </button>
            </form>
            <?php else: ?>
            <div style="background:#fef3c7;border:1px solid #f59e0b;border-radius:10px;padding:16px;margin-bottom:16px">
                <strong style="color:#92400e">⚠️ Secret Key belum tersedia</strong><br>
                <span style="color:#a16207;font-size:.9rem">Klik tombol di bawah untuk generate Secret Key baru.</span>
            </div>
            <form method="POST">
                <?= csrfField() ?>
                <input type="hidden" name="action" value="regenerate_secret_key">
                <button type="submit" class="btn btn-primary">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="16" height="16">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"/>
                    </svg>
                    Generate Secret Key
                </button>
            </form>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Penjelasan Webhook & Callback untuk Pemula -->
<div style="background:linear-gradient(135deg,#dbeafe,#eff6ff);border:1px solid #93c5fd;border-radius:16px;padding:24px;margin-bottom:24px">
    <h3 style="color:#1e40af;margin:0 0 16px;display:flex;align-items:center;gap:10px">
        <span style="font-size:1.5rem">📖</span> Penjelasan untuk Pemula
    </h3>
    <div style="display:grid;gap:16px">
        <div style="background:white;border-radius:12px;padding:16px">
            <strong style="color:#1e40af;display:block;margin-bottom:8px">🔔 Webhook URL = Notifikasi Otomatis</strong>
            <p style="color:#3b82f6;font-size:.9rem;margin:0 0 8px">Ketika customer bayar, NEO PGA akan mengirim POST request ke URL ini untuk memberitahu bahwa pembayaran berhasil.</p>
            <p style="color:#64748b;font-size:.85rem;margin:0"><strong>Contoh:</strong> <code style="background:#f1f5f9;padding:2px 6px;border-radius:4px">https://tokoku.com/webhook.php</code></p>
        </div>
        <div style="background:white;border-radius:12px;padding:16px">
            <strong style="color:#1e40af;display:block;margin-bottom:8px">↩️ Callback URL = Redirect Setelah Bayar</strong>
            <p style="color:#3b82f6;font-size:.9rem;margin:0 0 8px">Setelah customer selesai di halaman pembayaran, mereka akan di-redirect ke URL ini.</p>
            <p style="color:#64748b;font-size:.85rem;margin:0"><strong>Contoh:</strong> <code style="background:#f1f5f9;padding:2px 6px;border-radius:4px">https://tokoku.com/sukses.php</code></p>
        </div>
        <div style="background:#fef3c7;border-radius:12px;padding:16px">
            <strong style="color:#92400e;display:block;margin-bottom:8px">💡 Kapan Harus Diisi?</strong>
            <ul style="color:#a16207;font-size:.9rem;margin:0;padding-left:20px">
                <li><strong>Pakai 1 file (All-in-One)?</strong> → Tidak perlu diisi, sudah ditangani di file yang sama</li>
                <li><strong>Pakai multi file?</strong> → Isi Webhook dengan <code>callback.php</code> kamu</li>
                <li><strong>Website kamu tidak otomatis update?</strong> → Isi Webhook URL</li>
            </ul>
        </div>
    </div>
</div>

<!-- Webhook & Callback URLs -->
<div class="keys-grid">
    <div class="url-card">
        <div class="url-card-header">
            <h3 class="url-card-title">🔔 Webhook URL</h3>
        </div>
        <form method="POST" class="url-card-body">
            <?= csrfField() ?>
            <input type="hidden" name="action" value="update_webhook">
            <p class="key-description">URL untuk menerima notifikasi pembayaran secara real-time. NEO PGA akan mengirim POST request dengan data transaksi.</p>
            
            <div style="background:#f0fdf4;border:1px solid #86efac;border-radius:10px;padding:12px;margin-bottom:12px;font-size:.85rem">
                <strong style="color:#166534">Format data yang dikirim:</strong>
                <pre style="background:#dcfce7;border-radius:6px;padding:10px;margin:8px 0 0;overflow-x:auto;font-size:.8rem;color:#166534">{
  "order_id": "ORD-123",
  "amount": 150000,
  "status": "paid",
  "payment_method": "qris",
  "signature": "abc123..."
}</pre>
            </div>
            
            <div class="form-group">
                <input type="url" name="webhook_url" class="form-input" placeholder="https://tokoku.com/webhook.php" value="<?= htmlspecialchars($merchant['webhook_url'] ?? '') ?>">
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
        </form>
    </div>

    <div class="url-card">
        <div class="url-card-header">
            <h3 class="url-card-title">↩️ Callback URL</h3>
        </div>
        <form method="POST" class="url-card-body">
            <?= csrfField() ?>
            <input type="hidden" name="action" value="update_callback">
            <p class="key-description">URL redirect setelah customer selesai di halaman pembayaran. Bisa berisi halaman sukses atau cek status.</p>
            
            <div style="background:#fef3c7;border:1px solid #fcd34d;border-radius:10px;padding:12px;margin-bottom:12px;font-size:.85rem">
                <strong style="color:#92400e">💡 Tips:</strong>
                <ul style="color:#a16207;margin:8px 0 0;padding-left:20px">
                    <li>Halaman ini akan menerima <code>?order_id=xxx&status=xxx</code></li>
                    <li>Buat halaman yang bisa cek status via API</li>
                    <li>Kosongkan jika tidak perlu redirect</li>
                </ul>
            </div>
            
            <div class="form-group">
                <input type="url" name="callback_url" class="form-input" placeholder="https://tokoku.com/sukses.php" value="<?= htmlspecialchars($merchant['callback_url'] ?? '') ?>">
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
        </form>
    </div>
</div>

<!-- API Endpoints -->
<div class="endpoints-card">
    <div class="endpoints-header">
        <h3 class="endpoints-title">API Endpoints</h3>
        <a href="<?= APP_URL ?>/docs" target="_blank" class="btn btn-sm btn-primary">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/>
            </svg>
            Dokumentasi
        </a>
    </div>
    <div class="endpoints-body">
        <div class="endpoint-item">
            <span class="badge badge-success">POST</span>
            <code class="endpoint-url"><?= API_URL ?>/create.php</code>
            <span class="endpoint-desc">Buat transaksi baru</span>
        </div>
        <div class="endpoint-item">
            <span class="badge badge-info">GET</span>
            <code class="endpoint-url"><?= API_URL ?>/status.php</code>
            <span class="endpoint-desc">Cek status transaksi</span>
        </div>
        <div class="endpoint-item">
            <span class="badge badge-info">GET</span>
            <code class="endpoint-url"><?= API_URL ?>/transactions.php</code>
            <span class="endpoint-desc">Daftar transaksi</span>
        </div>
    </div>
</div>

<!-- API Logs -->
<div class="logs-card">
    <div class="logs-header">
        <h3 class="logs-title">API Request Log</h3>
    </div>
    <div class="table-wrapper">
        <table class="table">
            <thead>
                <tr>
                    <th>Endpoint</th>
                    <th>Method</th>
                    <th>Status</th>
                    <th>IP</th>
                    <th>Time</th>
                    <th>Waktu</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($apiLogs)): ?>
                <tr>
                    <td colspan="6">
                        <div class="empty-state">Belum ada API request</div>
                    </td>
                </tr>
                <?php else: ?>
                <?php foreach ($apiLogs as $log): ?>
                <tr>
                    <td><code><?= htmlspecialchars($log['endpoint']) ?></code></td>
                    <td><span class="badge badge-<?= $log['method'] === 'POST' ? 'success' : 'info' ?>"><?= $log['method'] ?></span></td>
                    <td>
                        <?php
                        $codeClass = $log['response_code'] >= 200 && $log['response_code'] < 300 ? 'success' : ($log['response_code'] >= 400 ? 'danger' : 'warning');
                        ?>
                        <span class="badge badge-<?= $codeClass ?>"><?= $log['response_code'] ?></span>
                    </td>
                    <td style="color: var(--gray-500); font-size: 0.8rem;"><?= htmlspecialchars($log['ip_address']) ?></td>
                    <td style="font-size: 0.85rem;"><?= $log['execution_time'] ?>s</td>
                    <td style="color: var(--gray-500); font-size: 0.8rem;"><?= timeAgo($log['created_at']) ?></td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
function copyKey(inputId) {
    const input = document.getElementById(inputId);
    const originalType = input.type;
    input.type = 'text';
    input.select();
    input.setSelectionRange(0, 99999);
    
    try {
        document.execCommand('copy');
        alert('Berhasil disalin!');
    } catch (err) {
        navigator.clipboard.writeText(input.value).then(function() {
            alert('Berhasil disalin!');
        });
    }
    
    input.type = originalType;
}

function toggleSecret() {
    const input = document.getElementById('secretKey');
    input.type = input.type === 'password' ? 'text' : 'password';
}
</script>

<?php include 'layout_footer.php'; ?>
